from pathlib import Path
import re, sys, hashlib
root=Path(__file__).resolve().parent
mod=root/'mod'
v108=Path('/mnt/data/v108src/mod/VRPlayer.cs')
v111=mod/'VRPlayer.cs'
issues=[]

def chk(cond,msg):
    print(('PASS ' if cond else 'FAIL ')+msg)
    if not cond: issues.append(msg)

def extract_method(src, signature):
    t=Path(src).read_text(encoding='utf-8-sig')
    i=t.find(signature)
    if i<0: return None
    b=t.find('{',i); d=0
    for j in range(b,len(t)):
        c=t[j]
        if c=='{': d+=1
        elif c=='}':
            d-=1
            if d==0: return t[i:j+1]
    return None

a=Path(v108).read_text(encoding='utf-8-sig')
b=Path(v111).read_text(encoding='utf-8-sig')
for sig in ['private void ConvertMinimapCanvasToWorldSpace()','private void UpdateVitalsPositionEndOfFrame()','private void UpdateMinimapPositionEndOfFrame()']:
    chk(extract_method(v108,sig)==extract_method(v111,sig), f'V108 HUD method exact: {sig}')
for pat in [r'public static float MinimapForwardDistance\s*=\s*([^;]+);', r'public static float MinimapScaleMultiplier\s*=\s*([^;]+);', r'public static float VitalsUiScaleMultiplier\s*=\s*([^;]+);']:
    ma=re.search(pat,a); mb=re.search(pat,b)
    chk(ma and mb and ma.group(1).strip()==mb.group(1).strip(), f'V108 HUD constant exact: {pat}')
chk('            UpdateVitalsUiScaleV14();' in b,'V108 UpdateVitalsUiScaleV14 active call restored')

st=(mod/'StereoRender.cs').read_text(encoding='utf-8-sig')
chk('AerHudDepthProxyV72Enabled = false' in st,'HUD depth proxy hard-off')
chk('AerHudDensePlanarRemapV76Enabled = false' in st,'HUD dense planar remap hard-off')
chk('AerHudDensePlanarTextBlackBackingV76 = false' in st,'HUD text backing hard-off')
chk('return false;' in extract_method(mod/'StereoRender.cs','private static bool EnsureExactHudProxyMeshesV74()'),'compiled HUD proxy allocator retired')
chk(not (mod/'HudProxyMeshesV74.cs').exists(),'HudProxyMeshesV74.cs absent')
chk('HudProxyMeshesV74.cs' not in (mod/'SonsVR_Mod.csproj').read_text(encoding='utf-8-sig'),'HudProxyMeshesV74 excluded from csproj')

chk('LOADING\\n" + frame + "\\nSOTF VR' in b,'three-line loading spinner')
chk('SetNativeLoadingVisualsSuppressedV110(true)' in b,'native loading visuals suppressed')
chk('ApplyTitleLoadingEyeLiftV110' in b and '0.30f' in st,'title/loading +0.30m eye-only lift retained')

rs=(mod/'RuntimeSettingsV105.cs').read_text(encoding='utf-8-sig')
chk('Vector3.one * 0.00068f' in rs,'settings panel 2x V110 apparent size')
chk('Vector3.one * 0.00046f' in rs,'stats panel 2x V110 apparent size')
chk('new Vector3(0.46f, 0.32f, 0.72f)' in rs,'stats panel moved top-right')
chk('IsPanelOpenV111 => _panelOpen' in rs,'settings panel exposes UI pin state')
chk('sendNavigationEvents = false' in rs and 'currentInputModule' in rs,'native pause input isolation retained')
chk('forceUiFullStereoV111' in st and '_aerScheduledEye = -1' in st,'pause/settings genuine BOTH-eye pin present')
chk('V111 pause/settings UI pin ended' in st,'AER warmup/resync on UI-pin exit')

son=(mod/'SonsVRMod.cs').read_text(encoding='utf-8-sig')
chk('[SonsVR V111]' in son,'startup marker V111')
chk((root/'BUILD_V111.bat').exists(),'BUILD_V111.bat exists')
chk((root/'PACK_V111_TRACE.bat').exists(),'PACK_V111_TRACE.bat exists')

print(f'\nRESULT: {len(issues)} failure(s)')
if issues:
    sys.exit(1)
