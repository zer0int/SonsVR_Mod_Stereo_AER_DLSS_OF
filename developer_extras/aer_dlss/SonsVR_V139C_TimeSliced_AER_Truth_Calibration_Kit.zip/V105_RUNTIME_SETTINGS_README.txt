SonsVR V105 - Runtime Settings + Lightweight Performance Telemetry
==================================================================

V105 keeps V104's permanent depth-guarded AER fill and adds one targeted refinement:
  tolerance = max(absTol, min(relativeTol * depth, maxDepthTolerance))
Default maxDepthTolerance = 1.50m.

Why: V104's 6%% relative rule allows 6m at 100m and 9m at 150m. That is a plausible
reason the only remaining visible jitter is layered foliage around 100-150m. The new cap
keeps close geometry unchanged while refusing to merge separate mid/far depth layers.

IN-HMD SETTINGS
---------------
Hold Xbox View + Menu together for ~0.45 seconds. L3+R3 is also supported as a fallback chord if the game reacts to View/Menu.
D-pad Up/Down  : select row
D-pad Left/Right: change value
A               : change selected value; on APPLY + SAVE commits all pending changes
B               : close without applying pending changes
X               : load defaults into pending values (not committed until APPLY)

Settings:
- DLSS on/off
- DLSS quality: Quality / Balanced / Performance / UltraPerformance
- NVOFA optical flow on/off
- NVOFA input resolution: 25 / 37.5 / 50 / 75 / 100%% linear
  (pixel workload is square of linear scale; 50%% = 25%% pixels, 37.5%% = 14.1%% pixels)
- VR render scale: 0.60 .. 1.20
- Gameplay far clip: 150 .. 24000m
- Menu/cooking far clip: 25 .. 250m
- Depth-guard max dZ: 0.5 .. 6m
- compact frame-time/FPS overlay on/off
- lightweight performance log on/off
- spike warning threshold

PERSISTENCE
-----------
Settings are saved as SonsVR_Settings.ini next to SonsVR_Mod.dll and loaded before VR eye
cameras are created on the next launch.

LIGHTWEIGHT PERFORMANCE LOG
---------------------------
When enabled, writes SonsVR_Perf_YYYYMMDD_HHMMSS.csv next to the mod DLL.
Steady sampling is 2 Hz; disk writes are buffered and flushed every 5s. Frame-time spikes
also emit a throttled WARNING row. No GPU readbacks, scene scans, raycasts or per-frame file I/O.

Columns include Unity frame time/EMA FPS, SteamVR client interval and GPU ms, dropped/reprojection
flags, scene, cheap gameplay context (GAMEPLAY / TARP_INVENTORY / GRABBAG_COOKING / BOOKLET /
BACKPACK_QUICKSELECT / UI_CURSOR_MENU), far clip, render scale, DLSS/OF settings, and depth-guard cap.

Deliberately NOT in the lightweight logger yet:
- min/max actual scene depth (needs a GPU reduction/readback path)
- "NPC in view" semantic detection (requires entity tracking/culling logic and is not free/reliable)
Those can be added as targeted optional instrumentation later instead of taxing every frame.
