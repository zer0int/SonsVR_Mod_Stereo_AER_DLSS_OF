from pathlib import Path
p=Path(__file__).parent/'mod'/'RuntimeSettingsV105.cs'
s=p.read_text(encoding='utf-8-sig')
checks={
'next-launch scale UI':'[restart-required]' in s,
'defer scale when eyes live':'deferRenderScaleToRestart' in s,
'live scale restored':'StereoRender.RenderResolutionScale = liveRenderScaleBefore;' in s,
'no render-scale rebuild':'bool rebuild = forceRebuild || dlssStateChanged;' in s,
'begin breadcrumb':'SETTINGS_APPLY_BEGIN' in s,
'end breadcrumb':'SETTINGS_APPLY_END' in s,
'warning immediate flush':'WritePerfRow("WARNING"' in s and 'FlushPerfWriterBestEffort();' in s,
'perf reports live scale':'StereoRender.RenderResolutionScale.ToString("F2", CultureInfo.InvariantCulture)' in s,
'overlay reports live scale':'R {StereoRender.RenderResolutionScale:F2}' in s,
'v105b Mathf alias retained':'using Mathf = UnityEngine.Mathf;' in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
if not all(checks.values()): raise SystemExit(1)
print(f'V105c static audit: {sum(checks.values())}/{len(checks)} passed')
