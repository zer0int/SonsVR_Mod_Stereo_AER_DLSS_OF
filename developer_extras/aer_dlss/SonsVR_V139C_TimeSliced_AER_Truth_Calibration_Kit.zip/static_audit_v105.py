from pathlib import Path
import sys
root=Path(__file__).resolve().parent
checks=[]

def has(path,*needles):
    s=(root/path).read_text(encoding='utf-8-sig',errors='replace')
    return all(n in s for n in needles)
checks += [
 ('settings source included', has('mod/SonsVR_Mod.csproj','RuntimeSettingsV105.cs')),
 ('settings loaded before InitVR', has('mod/SonsVRMod.cs','RuntimeSettingsV105.LoadEarly();','InitVR();')),
 ('settings tick', has('mod/SonsVRMod.cs','RuntimeSettingsV105.Tick();')),
 ('View+Menu chord + L3/R3 fallback', has('mod/RuntimeSettingsV105.cs','selectButton.isPressed && g.startButton.isPressed','leftStickButton.isPressed && g.rightStickButton.isPressed')),
 ('DLSS toggle + quality', has('mod/RuntimeSettingsV105.cs','DlssEnabled','DlssQuality')),
 ('OF toggle + linear scale', has('mod/RuntimeSettingsV105.cs','OpticalFlowEnabled','OpticalFlowResolutionScale','0.375f')),
 ('render scale', has('mod/RuntimeSettingsV105.cs','RenderResolutionScale')),
 ('menu/game clips', has('mod/RuntimeSettingsV105.cs','GameplayFarClipMeters','MenuFarClipMeters')),
 ('perf HUD', has('mod/RuntimeSettingsV105.cs','GetFrameTiming','StatsOverlayEnabled')),
 ('buffered 2Hz perf logger', has('mod/RuntimeSettingsV105.cs','_nextPerfSample = now + 0.50f','_nextPerfFlush = now + 5f')),
 ('cooking context', has('mod/VRPlayer.cs','GRABBAG_COOKING','GetPerformanceContextV105')),
 ('persistent ini beside assembly', has('mod/RuntimeSettingsV105.cs','Assembly.GetExecutingAssembly().Location','SonsVR_Settings.ini')),
 ('guard max tolerance C#', has('mod/StereoRender.cs','AerV105FillDepthMaxToleranceMeters = 1.50f','_V105FillDepthMaxToleranceMeters')),
 ('guard max tolerance shader', has('shader_project/Assets/DepthStereoWarp.shader','_V105FillDepthMaxToleranceMeters','min(relativeTol, max(0.001, _V105FillDepthMaxToleranceMeters))')),
 ('DLSS live disable clears per-eye flags', has('mod/StereoRender.cs','allowDeepLearningSuperSampling", "False"','allowDynamicResolution", "False"')),
 ('runtime reconfigure hook', has('mod/DlssRuntimeV91.cs','RequestRuntimeReconfigureV105')),
 ('V104 guarded fill remains permanent', has('mod/StereoRender.cs','AerV104DepthGuardedFillPermanentEnabled = true')),
 ('V100 fallback remains', has('mod/StereoRender.cs','bool useRotationHoleFallbackV100 = true')),
 ('heavy forensics remain off', has('mod/StereoRender.cs','AerV99ForensicsEnabled = false','AerV102OcclusionForensicsEnabled = false')),
]
for name,ok in checks: print(('PASS' if ok else 'FAIL'),name)
if not all(ok for _,ok in checks): sys.exit(1)
print(f'PASS {len(checks)}/{len(checks)}')
