SonsVR V64 - HUD scale fix + GPS mask probe

Behavioral change:
- Main gameplay ScreenSpaceCanvas now scales from its own logical RectTransform height.
  V63 measured Screen=3840x2160 but Canvas=1920x1080, proving Screen.height made the
  intended 0.35 m HUD exactly half-size. No ForceUpdateCanvases/layout rebuild is used.

Unchanged:
- V51/V50 AER world synthesis.
- V61 direct raw-UGUI replay remains hard-disabled.
- Ring remains anchored to ScreenBounds.

Diagnostics:
- [AER V64][MaskState] one-shot ScreenMask/ScreenBounds/MapRotatorGroup/MapRoot/Map/PlayerArrow component census.
- [AER V64][MinimapMotion] now includes MapRotatorGroup and local/world rotation.
- [AER V64][HudFrustum] verifies the corrected HUD plane span.
