"""Static-source safety checks for V128 (not a Windows C# compilation)."""
from pathlib import Path
import re
import subprocess
import sys
ROOT = Path(__file__).resolve().parent
MOD = ROOT/'mod'
router = (MOD/'NativeDlssReceiverRouterV128.cs').read_text(encoding='utf-8-sig')
dlss = (MOD/'DlssRuntimeV91.cs').read_text(encoding='utf-8-sig')
entry = (MOD/'SonsVRMod.cs').read_text(encoding='utf-8-sig')
csproj = (MOD/'SonsVR_Mod.csproj').read_text(encoding='utf-8-sig')
checks = {
    'V116 source audit passes': subprocess.run([sys.executable,str(ROOT/'static_audit_v116.py')], cwd=ROOT, capture_output=True).returncode == 0,
    'V127 passive contract telemetry retained': 'NativeDlssContractTraceV127.Tick();' in entry,
    'V128 added to project': 'Compile Include="NativeDlssReceiverRouterV128.cs"' in csproj,
    'V128 source applied to tick': 'NativeDlssReceiverRouterV128.Tick(stereo);' in dlss,
    '2E skips mod-owned global DLSS setters': 'if (!StereoRender.UserGameplayAERV112) return;' in dlss,
    '2E skips mod-owned fixed Quality/Optimal settings': 'if (NativeDlssReceiverRouterV128.Enabled && !StereoRender.UserGameplayAERV112)\n                return;' in dlss,
    'only active live-host clone created': router.count('new GameObject(') == 1,
    'inactive host prepared before adding component': router.index('_rightHost.SetActive(false);') < router.index('AddComponent('),
    'host activated after native fields/mapping assigned': router.index('_rightHost.SetActive(true)') > router.index('foreach (string field in new[]'),
    'one native left receiver retarget': 'Write(authored, "_targetCamera", left)' in router,
    'right cloned receiver from game type': 'Il2CppType.From(_receiverType)' in router,
    'right self-registration verified': 'right receiver OnEnable did not register' in router,
    'both receiver targets validated': 'ContainsReceiver(list, authored, left)' in router,
    'never FindObjectsOfType or Resources.FindObjectsOfTypeAll': 'FindObjectsOfType(' not in router and 'FindObjectsOfTypeAll(' not in router,
    'no manager quality setter invocation in router': '.Invoke(null, new[] {' not in router and 'SetDynamicResUpscaleFilter(' not in router,
    'automatic 2E to AER receiver restoration': 'Restore("AER selected;' in router,
    'scene change native-route cleanup': 'NativeDlssReceiverRouterV128.OnSceneLoaded();' in entry,
    'main camera retained for gameplay': 'originalCamera.allowDynamicResolution = false;' in router,
    'read-only previous V127 manager/scaler telemetry': 'NativeDlssContractTraceV127.cs' in csproj,
    'AER baseline camera policy stays unchanged': 'ResolveDlssQualityCode(SonsVRMod.V91DlssQuality)' in dlss,
    'receiver list sampled only periodically': '_nextHealth = now + 2.0f' in router,
    'baseline exit watchdog left in place': (MOD/'TransitionDlssAuditV117.cs').exists(),
}
for k,v in checks.items():
    print(('[PASS] ' if v else '[FAIL] ')+k)
print(f'V128 static audit: {sum(checks.values())}/{len(checks)} passed')
if not all(checks.values()): sys.exit(1)
