SonsVR V116 - V115 HUD polish + tarp session cache + DLSS truth probe
=====================================================================

What V115 established
---------------------
- Unified WorldSpace native HUD works and preserves interaction.
- Tarp/cooking interaction works again; cooking cache remains fast.
- No black compositor rectangle.
- HUD placement/size is broadly good.

What V116 changes
-----------------
1) Minimap/ring alignment
   V115 made the centers of ScreenBounds and VitalsRenderTexture coincide. The log proved
   that center separation was essentially 0 mm while the screenshot still looked wrong.
   That means we aligned the wrong geometric quantity.

   V116 uses Endnight's authored RectTransform pivots/anchors instead:
     main HUD: ToggleableHUD/PlayerVitalUiRenderTextureGroup
     minimap:  GPSTrackerSystem/Canvas/ScreenMask
   and preserves their native anchoredPosition delta in the common metres-per-pixel plane.
   No child RectTransforms or GPS internals are rewritten.

2) Tarp item-info popup
   The legacy ConvertItemInfoPanelToWorldSpace() nested-canvas workaround is disabled while
   UnifiedHudWorldPlaneV116 is active. Under V115 the parent HUD was already WorldSpace, so the
   nested conversion put InventoryItemInfoView head-locked at 0.4 m and made it huge/occlusive.

3) Tarp performance
   V115 still called FindObjectsOfType<LayoutItem>() every 0.2 seconds. The cooking profiler
   already proved global type searches can be ~100 ms-class in this game. V116 builds the tarp
   LayoutItem cache ONCE per tarp session and only refreshes on an actual gaze-target cache miss.
   It logs cache-build cost and 1-Hz average/max cost of our highlight/snap path.

4) Stats overlay
   u stays 0.66.
   v moves 1/3 from 0.84 toward center 0.50 -> 0.727.
   width scales to 70%: 0.28 -> 0.196.

5) Exit-to-menu fatal crash
   CameraCompositorAuditV114 is retired/disabled. V115 crashed because its CustomPass census
   dereferenced pass.name during scene teardown after the native IL2CPP object had died, causing
   Il2CppStringToManaged to enter a fatal CLR memory error. The CustomPass census body is also
   permanently no-op even if the audit is manually re-enabled later.

6) DLSS truth probe (measurement only)
   V115 showed a suspicious contradiction:
     - Sons' global manager accepts DLSS Quality / Ultra Performance.
     - HDAdditionalCameraData says DLSS/DRS allowed.
     - Camera.allowDynamicResolution later reads FALSE.
     - eye target RenderTexture.useDynamicScale reads FALSE.
     - visible quality/FPS does not change.

   V116 does NOT blindly force a new DLSS path. It passively records HDCamera.actualWidth/
   actualHeight for each VR eye in both AER and 2E, and reports active-to-target ratios in the
   existing EyeStatus log. Quality -> UltraPerformance should change that active viewport if the
   VR eyes are genuinely receiving the requested DLSS quality mode.

   V116 also logs RenderTexture.useDynamicScale immediately at eye-target construction and the
   immediate post-write Camera/HDRP dynamic-resolution flags. That tells us exactly where the
   eligibility is being lost.

7) Binoculars
   No binocular rendering change in this build. The old mod-created binocular zoom camera remains
   disabled. The existing source archaeology says the native game changes MainCameraFP FOV (roughly
   95 -> 40), but OpenVR eye projection matrices ignore Camera.fieldOfView. We will fix binocular
   zoom at the VR projection level after this stabilization pass, not resurrect the brittle second
   HDRP camera/RT experiment.

Build
-----
Run:
    BUILD_V116.bat

Test (no log-watching in HMD)
-----------------------------
1. Normal world: check HUD + map/ring alignment.
2. Open tarp: confirm item info sits by the item again and report FPS after ~10 seconds.
3. Cooking: sanity-check it remains fast.
4. Stats overlay: confirm smaller + lower placement.
5. DLSS test: choose 2E for the cleanest comparison. Set Quality, wait ~6 sec; set
   UltraPerformance, wait ~6 sec; set Quality again, wait ~6 sec. Just look normally; the log
   captures the actual HDRP viewport automatically.
6. Toggle AER and 2E once in an ordinary world view and spend ~10 sec in each.
7. Exit via pause menu -> main menu. This specifically verifies the fatal CustomPass audit crash
   is gone.
8. Binoculars may still fail to zoom in V116; that is expected and intentionally not conflated
   with this test.

Then run:
    PACK_V116_TRACE.bat

and send V116_TRACE_RETURN.zip.
