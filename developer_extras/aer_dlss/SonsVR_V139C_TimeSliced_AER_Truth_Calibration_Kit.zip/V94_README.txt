# SonsVR V94b — Exact HDRP Source-Raster Matrix A/B/A

Purpose: test the next strongest suspect after V93's clean null.

V93 result:
- Submit_Default vs Submit_TextureWithPose using the SAME fresh pose produced no perceptual
  or timing change. The compositor implicit-pose hypothesis is therefore sharply demoted.
- Scale remains 1.0. Real DLSS Quality remains active.
- Active AER reconstruction remains full per-pixel compute scatter. The 768 grid is fail-soft only.

Why V94b:
The historical depth/color reconstruction currently unprojects source depth using Camera-derived
matrices captured later in the render lifecycle. HDRP actually rasterizes cameraDepthBuffer through
HDCamera. V94b captures HDCamera.projectionMatrix and HDCamera.worldToCameraRHS in the exact
AfterOpaqueDepthAndNormal CustomPass invocation that supplies the depth raster.

One-load A/B/A:
- 0–30 s: existing Camera-derived historical SOURCE matrices
- 30–60 s: exact paired HDCamera SOURCE projection/view matrices
- >60 s: return to Camera-derived SOURCE matrices

Only source unprojection changes. Current/target-eye matrices remain unchanged.

Important diagnostic control:
- Half-res NVOFA still RUNS in every phase so GPU workload/history are constant.
- Its residual is intentionally NOT APPLIED anywhere in V94b. This exposes the original jitter that
  existed before optical flow instead of measuring the jelly/smoothing response to that jitter.
- OpenVR submission stays Submit_Default throughout; V93's submit experiment is disabled.

Sparse logs report:
- whether exact HDCamera matrices are paired to the historical depth frame
- max absolute HDCamera-vs-Camera matrix differences
- key projection entries m00/m11/m02/m12
- active matrix phase in temporal telemetry

Build:
  BUILD_V94b.bat

Install BOTH:
  OUTPUT\SonsVR_Mod.dll
  OUTPUT\SonsVR_NvOF_V90.dll

Pack:
  PACK_V94b_TRACE.bat

Test:
Keep medium/far rigid geometry or detailed scenery in the problematic upper region through the
~30 s and ~60 s switches if practical. A change at 30 s followed by reversal at 60 s implicates
source raster-matrix mismatch. A null plus near-zero matrix differences acquits this branch cleanly.
