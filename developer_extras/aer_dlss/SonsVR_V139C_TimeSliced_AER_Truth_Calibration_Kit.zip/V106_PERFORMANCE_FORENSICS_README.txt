SonsVR V106 - POST-SUBMIT / CAMERA / COOKING PERFORMANCE FORENSICS
===================================================================

WHY THIS BUILD EXISTS
---------------------
V105 logs showed the old startup/cooking collapse is NOT primarily the VR eye render.
A representative cooking frame was roughly:

  totalRenderGpu ~246 ms
  preSubmitGpu    ~17 ms
  postSubmitGpu  ~228 ms

Normal gameplay after the automatic pause-menu ritual was roughly:

  totalRenderGpu ~23 ms
  preSubmitGpu   ~20 ms
  postSubmitGpu   ~3 ms

V106 is designed to identify what application work/camera/state occupies that post-submit region,
and separately quantify any CPU stupidity in the cooking gaze path.

WHAT V106 LOGS
--------------
1. OpenVR frame timing:
   - total / pre-submit / post-submit GPU ms
   - client interval, presents, mis-presents, dropped frames, reprojection flags
   - compositor WaitGetPoses/Submit timing fields

2. CPU synchronization:
   - actual wall-clock CPU duration spent blocked in OpenVR.Compositor.WaitGetPoses()

3. EVERY SRP CAMERA (low-overhead ring + anomaly bursts):
   - camera name/id/type
   - PRE_SUBMIT / SUBMIT_WINDOW / POST_SUBMIT phase
   - culling mask, target texture/screen, resolution, active/enabled state
   - CPU beginCameraRendering -> endCameraRendering duration
   - non-eye cameras are logged continuously; eye camera rows become dense during anomaly bursts

4. Post-submit operations:
   - second-eye Submit pair CPU duration
   - post-submit Graphics.Blit mirror-capture CPU duration
   - desktop IMGUI mirror CPU duration

5. Frame-cap/cadence knobs:
   - Application.targetFrameRate
   - QualitySettings.vSyncCount
   - OnDemandRendering.renderFrameInterval (via reflection; -1 if unavailable)
   - SteamVR HMD display frequency when exposed by the bundled wrapper

6. COOKING CPU PATH:
   - entire UpdateGrabBagGazeHoverV10 duration
   - GrabBagLayoutItem FindObjectsOfType time and scan time
   - item/collider counts
   - CookingCog FindObjectsOfType time and scan time
   - cog/collider/renderer counts

7. Sparse CAMERA + HDRP VOLUME CENSUS snapshots:
   - scene/context changes
   - post-submit pathology beginning/recovering
   - severe frame-time/GPU spikes
   - exact automatic pause-menu FPS-fix completion event

OUTPUT FILES
------------
Mods\SonsVR_V106_Timeline_*.csv
Mods\SonsVR_V106_Snapshots_*.txt

The old lightweight SonsVR_Perf_*.csv still runs independently.

HMD PROTOCOL
------------
No log watching is required.

1. Launch normally. V106 logs loading/startup automatically.
2. Once gameplay is stable, an in-HMD card says:

     V106 PERFORMANCE LOGGER READY
     OPEN COOKING MENU WHEN CONVENIENT

3. Open the cooking/grab-bag menu and leave it open.
4. After ~8 seconds, the card says:

     V106 COOKING CAPTURED
     CLOSE COOKING MENU NOW

5. Close it. After recovery capture:

     V106 CAPTURE COMPLETE
     YOU CAN KEEP PLAYING OR PACK THE LOG

Spikes remain logged after the guided cycle, so feel free to swim, enter caves, open other menus,
or provoke other bad frames before quitting.

PACK
----
After exiting the game, run:

  PACK_V106_TRACE.bat

It packs V106 timeline/snapshots, Latest.log, settings, recent lightweight perf CSVs, Unity Player.log,
and SteamVR compositor/server/monitor logs when present.

IMPORTANT
---------
V106 DOES NOT intentionally change the production renderer, depth guard, AER, DLSS, NVOFA, mirror,
or native-camera policy. It is an instrumentation build. The only extra game-path work is timing and
sparse logging/census capture; expensive camera/volume censuses are event-driven, not per-frame.
