# V138 — AER + native game-menu DLSS resolution (experimental)

Baseline: V137 is the **pinned, known-good 2E DLSS build**. This is a TEST and does not replace it until headset verification.

## Exactly what changes

- Allow the V128 authored MainCameraFP receiver -> left eye + live right receiver route in **AER as well as 2E**. The native game graphics menu owns DLSS option and quality everywhere.
- Allow V136/137 camera-scoped HDRP `DLSSPass.CameraState.ScaleFn` hook for those two registered AER eye states. No global scaler-slot, min-fraction, or current-fraction writes.
- Turn off V91's *legacy parallel global DLSS setter* in AER, and its per-eye hardcoded Quality/Optimal stamp. The eye setup still enables DLSS and dynamic-resolution eligibility.
- Enable the proven V129 render-boundary TSV and V133B view-state trace in AER, without increased sample frequency.
- Add sparse metadata-only AER depth-size logs (`[V138 AER-DEPTH-RASTER]`) for per-eye HDCamera viewport, owned depth, full output and V103 guard parameters.

**Frozen:** V103 depth-guard shader, V100 rotation fallback, NVOFA, AER eye/submission scheduling, camera pose matrices, V116 unified HUD, V137 widened FPS overlay. No depth calibration intervention is made.

## Test in the headset

1. Back up known-good V137 first. Run `BUILD_V138.bat` and install both DLLs + shader bundle from OUTPUT as usual.
2. Enter 2E or AER according to your **current/last-used mode**, then select AER if necessary. In the game's graphics menu select **Performance (50%)** for the initial AER reference. Let the scene settle for ~8-10 seconds. Observe trees, sky, moving water/foliage, close objects.
3. Change **Quality (66.7%)**, wait ~8-10 seconds at the same scene. Look for depth wobble or stereo mismatch, especially 100–150 m trees/multilayer foliage.
4. Optional: **Balanced (58%)** ~6 seconds, **Ultra Performance** ~6 seconds (its request is 33.3%, but V137 measured a 50% clamp), then back to **Performance** for ~6 seconds.
5. If comfortable, turn **DLSS Off** briefly (~4 seconds) and back to **Performance** (~6 seconds). Off/On and quality changes can recreate DLSS contexts. If any serious stereo error, black screen or jitter, stop; don't keep testing.
6. Exit and run `PACK_V138_TRACE.bat`. If render freezes/crashes, pack logs **before relaunching** so Latest.log survives.

No in-HMD timed cue is necessary; all transitions are detected from the native manager in the TSV. There is no automated rendering-mode switch.

## What to look for in logs

- `[V138 AER-DLSS] ROUTER ACTIVE mode=AER`: both native receivers now target the eyes.
- `[V137 DLSS-SCALEFN] ARMED ... mode=AER`, `MENU_SCALE`, `HOOK_HITS`.
- V129 TSV `mode=AER`, eye begin/end `hdActual`, scale and camera flags; `EYE_BEGIN`/`EYE_END` should match the selected preset.
- V133B DLSS view state `reqQ`, `viewQ`, `viewIn` for each eye.
- `[V138 AER-DEPTH-RASTER]`: depth vs the current eye's HDRP raster, with `paired/coherent` and guard enabled.
- Existing AER logs: exact same-eye history validity, depth/latch fallback, guarded fill availability, pose and NVOFA.

## If jitter returns: calibration proposal, NOT implemented here

Keep the V103 absolute/relative depth-coherence guard as the baseline. First measure per-preset depth-cell occupancy, neighborhood support and reprojection angular residual versus scene depth. Since depth is captured at actual HDRP input resolution while reconstructed color/output stays presentation-size, any guard neighborhood-size calibration should be based on an observed pixel footprint in output coordinates, not on a fixed percentage. Compare the near (0–5m), mid (5–50m), far (50–150m) and sky/multilayer foliage bands; only adjust candidate support/radius within coherent depth clusters. Never re-enable cross-depth-layer recursive hole filling, and preserve V100 rotation fallback.

## Limitations

The source has undergone a static audit, not a Windows IL2CPP compilation or in-HMD validation here. AER may exhibit jitter or temporal-history discontinuities at quality transitions. Revert to V137 as the reference if necessary.
