from pathlib import Path
import re, sys
root=Path(__file__).resolve().parent
mod=root/'mod'
files={
 'hud':(mod/'NativeHudCompositorV113.cs').read_text(encoding='utf-8-sig'),
 'vr':(mod/'VRPlayer.cs').read_text(encoding='utf-8-sig'),
 'stereo':(mod/'StereoRender.cs').read_text(encoding='utf-8-sig'),
 'settings':(mod/'RuntimeSettingsV105.cs').read_text(encoding='utf-8-sig'),
 'main':(mod/'SonsVRMod.cs').read_text(encoding='utf-8-sig'),
 'proj':(mod/'SonsVR_Mod.csproj').read_text(encoding='utf-8-sig'),
}
checks=[]
def add(name, ok, detail=''):
    checks.append((name,bool(ok),detail))

def has(k,s): return s in files[k]

add('V113 source compiled', has('proj','<Compile Include="NativeHudCompositorV113.cs" />'))
add('HUD RT is 1920x1080', has('hud','TextureWidth = 1920') and has('hud','TextureHeight = 1080'))
add('HUD finite plane = 1.20m', has('hud','OverlayDistanceMeters = 1.20f'))
add('HUD angular width scaling', has('hud','2f * OverlayDistanceMeters') and has('hud','Mathf.Tan(OverlayHorizontalFovDegrees'))
add('HUD compositor transform is HMD-relative', has('hud','SetOverlayTransformTrackedDeviceRelative') and has('hud','OpenVR.k_unTrackedDeviceIndex_Hmd'))
add('HUD plane pose configured once', has('hud','_overlayPoseConfigured') and has('hud','if (_overlayPoseConfigured) return true;'))
add('Overlay texture resubmitted each frame', has('hud','SubmitOverlayTextureThisFrame()') and has('hud','SetOverlayTexture(_overlayHandle, ref texture)'))
add('D3D overlay V-flip retained', has('hud','vMin = 1f') and has('hud','vMax = 0f'))
add('Native HUD uses ScreenSpaceCamera', has('hud','RenderMode.ScreenSpaceCamera'))
add('Native CanvasScaler is enabled', has('hud','CanvasScaler scaler') and has('hud','scaler.enabled = true'))
add('Native 2D map row globally maps to eye height', has('hud','NativeHudReferenceRowPixelsY = 153.0f') and has('hud','DesiredHudReferenceViewportY = 0.50f'))
add('Held GPS explicitly untouched', has('hud','physically-held GPS') or has('hud','physical held GPS'))
add('Main update hands only player HUD canvases to compositor', has('vr','NativeHudCompositorV113.Tick(this, _screenSpaceCanvas, _playerMiniMapCanvas);'))
add('Legacy WorldSpace conversions are fallback-only', has('vr','if (NativeHudCompositorV113.Enabled)') and has('vr','Exact V108 fallback retained'))
add('Legacy HUD transform updates skipped under compositor', has('vr','if (!NativeHudCompositorV113.Enabled)') and has('vr','EnsureMinimapEndOfFrameCoroutine();'))
add('Minimap EOF mutation hard-stops under compositor', has('vr','if (NativeHudCompositorV113.Enabled) return;') and has('vr','private void UpdateMinimapPositionEndOfFrame()'))
add('Render-boundary HUD relayout hard-stops under compositor', has('vr','internal void RefreshHudLayoutForRenderV60()') and 'RefreshHudLayoutForRenderV60()\n        {\n            if (NativeHudCompositorV113.Enabled) return;' in files['vr'])
add('V112 child-only vertical centering default retired', has('vr','CenterMinimapVerticallyV112 = false'))
add('Runtime settings no longer applies child Y centering', not has('settings','VRPlayer.CenterMinimapVerticallyV112 = s.CenterHudVertically;'))
add('Settings identifies compositor HUD', has('settings','HUD presentation') and has('settings','NATIVE 2D -> COMPOSITOR'))
add('FPS overlay horizontal u moved 0.82->0.66', has('settings','0.66f, 0.84f, 0.28f, 1.25f') and not has('settings','0.82f, 0.84f, 0.28f, 1.25f'))
add('AER/2E live selector retained', has('settings','GameplayAerEnabled') and has('stereo','UserGameplayAERV112'))
add('FPS actual backend mode retained', has('settings','GetActualRenderModeV112()'))
add('BlankScene title lift now gated by gameplay readiness', has('stereo','bool preGameplayV113 = !AerGameplayReadyForActivation;') and has('stereo','preGameplayV113 && titleOrLoadingSceneV113'))
add('Old HUD depth catcher hard-off', has('stereo','AerHudDepthCatchersExperimentalEnabled = false'))
add('Old HUD depth proxy hard-off', has('stereo','AerHudDepthProxyV72Enabled = false'))
add('Old dense HUD remap hard-off', has('stereo','AerHudDensePlanarRemapV76Enabled = false'))
add('Native HUD shutdown wired', has('main','NativeHudCompositorV113.Shutdown();'))
add('V113 startup marker present', has('main','[SonsVR V113]'))
add('V108 cooking page cache retained', has('vr','V108 CookingPages'))
add('V107 loading suppression retained', has('vr','UpdatePreGameplayEyeRenderSuppressionV107();'))
add('V108 loading overlay retained', has('vr','UpdatePreGameplayLoadingOverlayV108();'))
add('V103/V104 depth guard remains production enabled', has('stereo','AerV104DepthGuardedFillPermanentEnabled = true'))

# Crude lexical brace audit on new file (strip comments/strings first).
t=files['hud']
t=re.sub(r'/\*.*?\*/','',t,flags=re.S)
t=re.sub(r'//.*','',t)
t=re.sub(r'@?"(?:\\.|""|[^"\\])*"','""',t)
bal=0; minbal=0
for ch in t:
    if ch=='{': bal+=1
    elif ch=='}': bal-=1; minbal=min(minbal,bal)
add('NativeHudCompositor brace balance', bal==0 and minbal>=0, f'bal={bal}, min={minbal}')

passed=sum(ok for _,ok,_ in checks)
for i,(name,ok,detail) in enumerate(checks,1):
    print(f'[{"PASS" if ok else "FAIL"}] {i:02d}. {name}' + (f' ({detail})' if detail else ''))
print(f'\nV113 static audit: {passed}/{len(checks)} passed')
if passed != len(checks): sys.exit(1)
