SONSVR V73 - EXACT BAKED HUD DEPTH MESHES
=========================================

THIS BUILD DOES ONE THING ONLY
------------------------------
V72's private-depth idea worked, but its proxy shapes were crude:
  GPS    = filled analytic circle
  vitals = much larger filled analytic circle
  text   = filled analytic rectangle

V73 replaces ONLY those support shapes with the user's exact baked geometry:
  GPS    -> disc_proxy.asset
  STATUS -> ring_proxy.asset
  TEXT   -> rect_proxy.asset

NO dense planar HUD remap is enabled yet.
NO V51 world reconstruction/fill/fallback changes are made.
NO visible HUD rendering changes are made.

WHY USE THE BAKED MESHES INSTEAD OF THE PNG MASKS?
--------------------------------------------------
The status ring is asymmetric because of the appendage bulbs, while the user
deliberately authored the origin at the MAIN circle center. A cropped PNG mask
does not preserve that meaningful origin by itself. The canonical baked Mesh
does, so V73 rasterizes the Mesh directly into V50's private RFloat depth latch.

PLACEMENT
---------
GPS disc:
  exact mesh fitted to ScreenMask.

Status ring:
  authored main-circle origin aligned to the HUD center.
  main-circle radius is scaled using Endnight's native GPS-side
  VitalsBackingCircle 160x160 reference, so appendages extend naturally.

Text:
  baked rectangle fitted to the union of currently-active MessageList Graphics.

USER-BAKED BUNDLE
-----------------
Embedded resource:
  mod\Resources\sonsvr_hudproxythingy

Bytes:
  63100

SHA256:
  ad9e1a3c13d66ad5802799d0c304e023867d905053d62adc0cea110127625f9f

BUILD
-----
  BUILD_V73.bat

Install ONLY:
  OUTPUT\SonsVR_Mod.dll

The OUTPUT copies of the two bundles are forensic/build artifacts; they do not
need to be copied into the game.

WHAT TO LOOK FOR
----------------
There are no timed phases.

Judge:
  1) Does the stable/anchored portion remain stable?
  2) Is the giant shredded/fallback area materially reduced now that proxy
     coverage matches actual HUD silhouettes?
  3) Is the ring silhouette positioned correctly around the map?

IMPORTANT LOGS
--------------
  [AER V73][HudDepthMesh] exact user-baked meshes loaded
  [AER V73][HudDepthMesh] APPLIED eye=L/R ... mode=EXACT-BAKED-MESH
  [AER V50][DepthLatch] CAPTURED eye=L/R
  [AER V51][DepthWarp] SYNTHETIC OPPOSITE EYE IS NOW IN THE HEADSET PATH

INTERPRETATION
--------------
If exact silhouettes largely cure the ugliness:
  V72's over-coverage was the main remaining issue.

If exact silhouettes are correctly placed but still become sparse/fallback
lasagna:
  the next justified step is the dense planar HUD remap after V51.
