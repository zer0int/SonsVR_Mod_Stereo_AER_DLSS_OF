from pathlib import Path
import sys,zipfile,subprocess,os,datetime
root=Path(__file__).resolve().parent
out=root/'V139_TRACE_RETURN.zip'
game=Path(os.environ.get('SOTF_GAME_DIR',r'D:\SteamLibrary\steamapps\common\Sons Of The Forest'))
files=[]
def add(p):
 if p.exists() and p.is_file() and p not in files:files.append(p)
melon=game/'MelonLoader';add(melon/'Latest.log')
for p in sorted((melon/'Logs').glob('*.log'), key=lambda p:p.stat().st_mtime,reverse=True)[:2]:add(p)
for pattern in ['SonsVR_V139C_GpuStages_*.log','SonsVR_V139_CalibrationTiles_*.csv','SonsVR_V129_DLSS_Live_*.tsv', 'SonsVR_Perf_*.csv']:
 for p in sorted((game/'Mods').glob(pattern),key=lambda p:p.stat().st_mtime,reverse=True)[:1]:add(p)
add(game/'Mods'/'SonsVR_Settings.ini')
add(Path.home()/'AppData'/'LocalLow'/'Endnight'/'SonsOfTheForest'/'Player.log')
if not files:raise SystemExit('No trace files found. Check SOTF_GAME_DIR.')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
 for i,p in enumerate(files):
  z.write(p,arcname=('V139_CalibrationTiles.csv' if 'SonsVR_V139_CalibrationTiles_' in p.name else f'logs/{i}_{p.name}'))
has_calibration = any('SonsVR_V139_CalibrationTiles_' in p.name for p in files)
if not has_calibration:
 print('WARNING: NO V139 CALIBRATION CSV FOUND. Capture probably never started or aborted before writing.')
 print('Check MelonLoader Latest.log for [V139 CAL] BOOT, WAIT_FOR_AER, SETUP_180_SECONDS or ABORT.')
 status='NO_CALIBRATION_CSV\nCheck [V139 CAL] logs and 2E/AER mode before retesting.\n'
 with zipfile.ZipFile(out,'a',zipfile.ZIP_DEFLATED) as z:
  z.writestr('V139_TRACE_STATUS.txt',status)
else:
 with zipfile.ZipFile(out,'a',zipfile.ZIP_DEFLATED) as z:
  z.writestr('V139_TRACE_STATUS.txt','CALIBRATION_CSV_PRESENT\nCheck report/coverage to verify that all three banks finished.\n')
print('TRACE PACKED',out, 'files',len(files))
# Run the analysis when calibration data exists; keep raw zip even if analysis fails.
if has_calibration:
 rc=subprocess.call([sys.executable,str(root/'analyze_v139.py'),str(out),'--out',str(root)])
 if rc==0:
  with zipfile.ZipFile(out,'a',zipfile.ZIP_DEFLATED) as z:
   for p in ['V139_CALIBRATION_REPORT.md','V139_CANDIDATE_RANKING.csv']:
    z.write(root/p,arcname=p)
