# V131B compile hotfix — HDRP getter-only settings

The four C# build errors came from direct assignments to struct-returning/read-only HDRP properties:

* CS1612: `settings.dynamicResolutionSettings.enableDLSS = ...`
* CS0200: `_asset.currentPlatformRenderPipelineSettings = settings`

The game IL2CPP wrapper is **not** the same writable API advertised by some public HDRP 14 documentation. In this game build, `currentPlatformRenderPipelineSettings` is getter-only.

V131B removes all four invalid compile-time assignments. On the original 30s/5s/two-frame schedule it:

1. Takes explicit value-type copies of the settings and `GlobalDynamicResolutionSettings`.
2. Tries to write the modified nested settings back through a writable field/property **only if one is actually exposed** in the generated runtime wrappers. No hardcoded IL2CPP offsets.
3. Tries to write the enclosing `RenderPipelineSettings` back to a real, writable asset member.
4. Reads the HDRP asset back to verify `enableDLSS` and reports precisely which member was used.
5. If no writable route exists, emits `NO_WRITE_UNSUPPORTED` and makes no claim about a pipeline rebuild or DLSS activation. Existing V129 passive resolution capture and 5-second cue still run.
6. Retains rollback when leaving the 2E mode, if the flag was actually changed.

**Limitations:** Changing a private asset field is not proven to rebuild Unity's pipeline or enable missing DLSS variants. The source fix is statically audited here, but can't be Windows-compiled or headset-tested in this environment. Whether a runtime writer exists is unknown until the actual game binary is queried.

## Hotfix installation

Extract this hotfix into your existing V131 directory, overwriting:

- `mod/NativeDlssForceActivationV131.cs`
- `static_audit_v131.py`
- `README_FIRST_V131.md`

Then run `BUILD_V131.bat` again. No V130 sibling directory is required when using the already corrected standalone audit kit.

## Trace results to look for

- `ASSET BEFORE` — whether the game asset already reports `enableDLSS=true`
- `ASSET WRITE RETURNED` — a *verified asset flag write*, **not** verification of an NVIDIA render pass
- `NO_WRITE_UNSUPPORTED` — no writable API discovered; don't interpret this as a successful attempt
- `EYE_BEGIN` / `EYE_END` in the V129 TSV — actual per-eye dimensions
