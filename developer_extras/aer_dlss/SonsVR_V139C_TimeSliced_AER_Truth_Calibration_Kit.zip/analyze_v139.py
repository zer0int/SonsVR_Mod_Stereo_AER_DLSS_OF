#!/usr/bin/env python3
"""Postprocess V139 genuine-2E offscreen candidate measurements (Python stdlib)."""
import argparse,csv,io,math,statistics,sys,zipfile,re
from pathlib import Path
from collections import defaultdict

GUARD = {'V103_GUARD_BASE','V103_GUARD_STRICT','V103_GUARD_RELAXED',
         'V103_GUARD_MID','V103_GUARD_HIGH_SUPPORT'}
VARIANTS={
 'V103_GUARD_BASE':'abs .30m, rel 6%, max 1.50m, support 60%/2',
 'V103_GUARD_STRICT':'abs .15m, rel 3%, max .75m, support 75%/3',
 'V103_GUARD_RELAXED':'abs .60m, rel 10%, max 2.0m, support 50%/2',
 'V103_GUARD_MID':'abs .20m, rel 6%, max 1.50m, support 60%/2',
 'V103_GUARD_HIGH_SUPPORT':'abs .30m, rel 6%, max 1.50m, support 80%/3'
}

def pct(a,p):
 if not a:return float('nan')
 a=sorted(a); i=(len(a)-1)*p; j=int(i); k=min(len(a)-1,j+1)
 return a[j]+(a[k]-a[j])*(i-j)

def finite(x,default=float('nan')):
 try:
  v=float(x)
  return v if math.isfinite(v) else default
 except (TypeError,ValueError):return default

def roi(r):
 # V99 image has raw Y flipped on OpenVR presentation.
 x=(int(r['tileX'])+.5)/int(r['tilesX'])
 y=(int(r['tileY'])+.5)/int(r['tilesY'])
 vertical='TOP' if y>=2/3 else 'BOTTOM' if y<1/3 else 'MIDDLE'
 horiz='CENTER' if 1/3<=x<2/3 else 'SIDE'
 return vertical+'_'+horiz

def evaluate(rows):
 all_count=len(rows)
 valid=[]
 for r in rows:
  yaw=finite(r.get('yawDeg')); pitch=finite(r.get('pitchDeg'))
  confidence=finite(r.get('matchConfidence'),0)
  coverage=finite(r.get('coverage'),0)
  edge=finite(r.get('edgeMAE'))
  if not (math.isfinite(yaw) and math.isfinite(pitch) and math.isfinite(edge)): continue
  if confidence < .005 or coverage<.05:continue
  # V139C: a maximum-radius shift is censored, NOT a measured optimum.
  if str(r.get('matchAtSearchBoundary','0')).strip() in ('1','True','true'):continue
  valid.append((r,yaw,pitch,edge,max(0,min(1,coverage))))
 if not valid:
  return {'n':0,'density':0,'score':float('inf'),'pitch90':float('nan'),'edge':float('nan'),'coverage':0}
 def weight(r):
  region=roi(r)
  return 4.0 if region=='TOP_CENTER' else 2.1 if region=='TOP_SIDE' else 1.5 if region=='MIDDLE_CENTER' else 1.0 if region=='BOTTOM_CENTER' else .7
 # ROI-weighted distribution, not the misleading whole-image average.
 pitches=[]; yaws=[]
 for r,yaw,pitch,edge,coverage in valid:
  n=round(weight(r)*3)
  pitches.extend([abs(pitch)]*n)
  yaws.extend([abs(yaw)]*n)
 pitch90=pct(pitches,.9); yaw90=pct(yaws,.9)
 edge=sum(edge*weight(r) for r,_,_,edge,_ in valid)/sum(weight(r) for r,_,_,_,_ in valid)
 coverage=sum(cov*weight(r) for r,_,_,_,cov in valid)/sum(weight(r) for r,_,_,_,_ in valid)
 # Penalty terms use fixed physical units and coverage; no special treatment for
 # blur/faint textures. Candidate with no reliable registration cannot win.
 score=2*pitch90+yaw90+.12*edge+.10*(1-coverage)
 return {'n':len(valid),'density':len(valid)/max(1,all_count),'score':score,
         'pitch90':pitch90,'yaw90':yaw90,'edge':edge,'coverage':coverage}

def load(path):
 if path.suffix.lower()=='.zip':
  with zipfile.ZipFile(path) as z:
   names=[n for n in z.namelist() if ('SonsVR_V139_CalibrationTiles_' in n or 'V139_CalibrationTiles.csv' in n) and n.endswith('.csv')]
   if not names: raise ValueError('ZIP has no V139 calibration tiles CSV (mod may not have reached CAPTURE)')
   filename=sorted(names)[-1]
   content=z.read(filename).decode('utf-8-sig')
   logs=[n for n in z.namelist() if n.endswith('.log') and 'Latest' in n]
   log=z.read(logs[0]).decode('utf-8',errors='replace') if logs else ''
   return list(csv.DictReader(io.StringIO(content))),log,filename
 else:
  return list(csv.DictReader(path.open(newline='',encoding='utf-8-sig'))),'',path.name

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('capture',type=Path)
 ap.add_argument('--out',type=Path,default=None)
 args=ap.parse_args()
 out=args.out or args.capture.parent
 out.mkdir(parents=True,exist_ok=True)
 try:rows,log,filename=load(args.capture)
 except Exception as e:
  print('[V139 analysis] '+str(e),file=sys.stderr);return 2
 if not rows:print('V139: empty CSV',file=sys.stderr);return 2
 by=defaultdict(list); byroi=defaultdict(list)
 for r in rows:
  try:
   key=(int(r['bank']),r['requestedQuality'],r['candidate'])
   by[key].append(r)
   byroi[key+(roi(r),)].append(r)
  except Exception:continue
 summaries={k:evaluate(v) for k,v in by.items()}
 reportrows=[]
 for (bank,quality,candidate),v in sorted(summaries.items()):
  group=by[(bank,quality,candidate)]
  train=evaluate([r for r in group if int(r['sample'])%2 == 1])
  test=evaluate([r for r in group if int(r['sample'])%2 == 0])
  eyes=[evaluate([r for r in group if int(r['eye'])==i]) for i in (0,1)]
  # Reject degenerate texture matches on either eye or holdout.
  valid=(v['n']>=50 and v['density']>=.10 and train['n']>=20 and test['n']>=20 and
         all(e['n']>=20 for e in eyes))
  reportrows.append({'bank':bank,'quality':quality,'candidate':candidate,'valid':valid,
     'score':v['score'],'holdoutScore':test['score'],'trainScore':train['score'],
     'p90PitchDeg':v['pitch90'],'p90YawDeg':v.get('yaw90',float('nan')),
     'edgeMAE':v['edge'],'coverage':v['coverage'],'validTiles':v['n'],
     'matchDensity':v['density'],'leftScore':eyes[0]['score'],'rightScore':eyes[1]['score']})
 cols=list(reportrows[0].keys()); output=out/'V139_CANDIDATE_RANKING.csv'
 with output.open('w',newline='',encoding='utf8') as f:
  writer=csv.DictWriter(f,fieldnames=cols);writer.writeheader();writer.writerows(reportrows)
 banks=sorted(set((r['bank'],r['quality']) for r in reportrows))
 txt=['# V139 automatic AER truth calibration — analysis',
      '',f'Input: `{filename}` · {len(rows):,} tile observations',
      '', '**What was optimized:** comparison of offscreen V99 historical candidates and five guarded-depth-fill parameter profiles against occasional genuine 2E reference frames. This is an empirical ranking, NOT a live automatic calibration or proof of perceptual comfort.',
      '', 'Physical HMD top is the **RAW texture bottom** in the underlying V99 atlas; ROI weights account for this inversion.',
      '', 'Scoring favors top-center signed-motion accuracy (angular P90), retains edge fidelity and coverage penalties, and rejects insufficient matches. Holdout samples are kept separate. V139C excludes matches at the search-window boundary (censored displacements).', '']
 for bank,quality in banks:
  subset=[r for r in reportrows if r['bank']==bank]
  names={int(r['sample']) for r in rows if int(r['bank'])==bank}
  txt.extend([f'## {quality} (bank {bank}, {len(names)} genuine stereo truth samples)', ''])
  ordered=sorted([r for r in subset if r['valid']],key=lambda x:x['holdoutScore'])
  baseline=next((r for r in subset if r['candidate']=='V103_GUARD_BASE'),None)
  if not ordered:
   txt.append('**INCONCLUSIVE:** insufficient reliable textured tiles, missing candidate data, or missing an eye. No profile should be promoted.')
  else:
   best=ordered[0]
   txt.append('| Rank | Offscreen candidate | Holdout score (lower better) | P90 vertical error (°) | Match density |')
   txt.append('|---:|---|---:|---:|---:|')
   for rank,r in enumerate(ordered[:7],1):
    txt.append(f'| {rank} | `{r["candidate"]}` | {r["holdoutScore"]:.5f} | {r["p90PitchDeg"]:.5f} | {r["matchDensity"]:.1%} |')
   guarded=[r for r in ordered if r['candidate'] in GUARD]
   if guarded:
    winner=guarded[0]
    txt.append('')
    txt.append('Best **V103 guarded-fill** candidate: `'+winner['candidate']+'` — '+VARIANTS[winner['candidate']]+'.')
    if baseline and baseline['valid'] and winner['candidate'] != 'V103_GUARD_BASE':
     relative=(baseline['holdoutScore']-winner['holdoutScore'])/max(1e-9,baseline['holdoutScore'])
     txt.append(f'Holdout improvement over guarded baseline: {relative:.1%}.'+
       (' **Not enough margin to recommend changing production.**' if relative<.05 else ' **Promising; verify on a second view and during normal head movement.**'))
   txt.append('')
   txt.append('This bank is a stationary-headset reference measurement; synthetic pose perturbations were **not** introduced. Pose/motion excursion must be validated separately before generalizing to moving-head jitter.')
  txt.append('')
  for region in ['TOP_CENTER','TOP_SIDE','MIDDLE_CENTER','BOTTOM_CENTER','BOTTOM_SIDE']:
   candidates=[]
   for k,tiles in byroi.items():
    if k[:2]!=(bank,quality) or k[2] not in GUARD or k[3]!=region:continue
    s=evaluate(tiles)
    if s['n']>=4:candidates.append((s['score'],k[2],s))
   if candidates:
    score,name,res=min(candidates)
    txt.append(f'- **{region}:** best guarded candidate `{name}`; P90 vertical angular error {res["pitch90"]:.5f}°, {res["n"]} valid tiles')
  txt.append('')
 if log:
  poses=[]
  for match in re.finditer(r'\[AER V102\]\[PoseInterval\].*?rotationAngle=([0-9.]+)deg',log):
   poses.append(float(match.group(1)))
  if poses:
   txt.extend(['## Camera-pose excitation','',
     f'Observed V99 truth intervals: {len(poses)}; median rotation {statistics.median(poses):.5f}°, P90 {pct(poses,.9):.5f}°.',
     '**CAUTION:** Minimal pose excursion cannot validate head-motion-dependent jitter. The next test should introduce reference-matched controlled motion, not just more stationary captures.' if pct(poses,.9)<.025 else 'Pose excursion recorded; still validate normal moving-head behavior.', ''])
 txt.extend(['## Interpretation limits','',
 '- Real 2E truth frames alter normal AER cadence; accepted frames are separated and evaluated with same captured history.',
 '- Guarded candidates reuse the V103 *guarded* shader path, but this is not a full search over projection matrices, temporal timing, or optical-flow parameters.',
 '- A profile may lower still-image reference error while increasing perceptual temporal jitter. No automatic promotion into the live renderer is performed.',
 '- Moving foliage/water and changing lighting are not entirely removed by console commands; compare regions and depth classes before accepting a result.',
 '- Use the live headset test for the final stereo comfort verdict.', ''])
 rep=out/'V139_CALIBRATION_REPORT.md'; rep.write_text('\n'.join(txt),encoding='utf8')
 print('[V139 analysis] '+str(rep));print('[V139 analysis] '+str(output))
 return 0

if __name__=='__main__':raise SystemExit(main())
