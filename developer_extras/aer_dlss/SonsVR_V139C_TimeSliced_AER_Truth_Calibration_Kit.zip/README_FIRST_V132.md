# V132 — One-launch DLSS/NVIDIA + Unity 2022.3 DRS workaround study

Start from the corrected **V131B** kit; V132 uses V128's successful native camera receiver route, V129's per-eye input-resolution TSV, and V116's known-good renderer/HUD. It **does not run** the ineffective V131 HDRP `enableDLSS=true` no-op or V130's continuous camera-attributes helper.

## Build

Run `BUILD_V132.bat` from this extracted folder. Install the `OUTPUT\SonsVR_Mod.dll` (and supplied native bridge DLL) after backing up the known-good game mod. The build runs a standalone audit first, compiles the existing Unity depth bundle and native bridge, then builds the mod. Windows Unity 2022.2.16f1 and your existing local MelonLoader reference DLLs are required. This kit was *not* compiled on Windows in the creation environment; a static audit cannot establish C# or IL2CPP runtime compatibility.

## ONE headset run (roughly 90 seconds)

Enter **2E gameplay**, with the native game menu set to **DLSS Quality**. Stand somewhere with fine texture like the waterfall/cattails. V132 waits for gameplay camera initialization and the V128 eye-router to become active before starting the clock. No tarp opening, exact user timing, or head immobilization is required.

1. **0–30 s: BASELINE.** No intervention, existing NVIDIA optimal-settings query and per-eye input-size measurements active. You can change Quality to Ultra Performance and back, but do not change AER/2E.
2. **30–35 s: 5-second in-HMD warning** ahead of Stage A. The cue is removed, then two frames pass before modifying policy.
3. **Stage A: manual scale.** Both eye `HDAdditionalCameraData` set `UseCustomAttributes=true`, `UseOptimalSettings=false`. V132 *attempts* to register a quality-driven percentage callback using HDRP's `SetDynamicResScaler`, but ONLY if it can recover both the original callback and original policy for restoration. This is deliberately conservative: the IL2CPP wrapper may hide the callback and the log will say `SCALER_NOT_INSTALLED`. An informational cue lasts 3 seconds, then clears, then ~20 seconds of comparison. Switch **Quality ↔ Ultra Performance** using the game's menu as convenient.
4. **Stage B: Unity 2022.3 workaround.** After another 5-second warning, V132 reads the current `DynamicResolutionHandler.m_MinScreenFraction`, attempts to write `0.25f`, and verifies the read-back. It logs the old value and whether the write actually stuck. Cue clears before the next 20-second Quality ↔ Ultra Performance comparison.
5. **Finish:** V132 restores the original eye-camera flags, the private min-fraction value if changed, and the original scaler callback/policy if one was safely captured. In-HMD cue says COMPLETE. Exit and run `PACK_V132_TRACE.bat`, then send `V132_TRACE_RETURN.zip`.

**If a crash occurs:** pack the logs before relaunching the game. The V129 TSV is flushed BEFORE each intervention. Do NOT switch to AER mid-experiment; AER's renderer is unmodified, but an experimental global callback is not a production feature. Restore V128 DLLs afterward if needed.

## Evidence and limitations

The Unity discussion dated 2024-10-22 (2022.3, case IN-87236) specifically proposes `m_MinScreenFraction = 0.25f` for `DynamicResolutionHandler.SetDynamicResScaler` not accepting custom screen fractions. It was observed in a 2022.3 game/editor; Sons is 2022.2.16f1 and need not share the defect. Source: https://discussions.unity.com/t/hdrp-dlss-custom-scaling-values-dont-work-as-advertised-in-the-docs/1541119

V132 adds **passive NVIDIA wrapper method call counting** for GraphicsDevice.CreateFeature, ExecuteDLSS, DestroyFeature via Harmony, with hooks installed once in gameplay. It also inventories DLSSPass members if exposed. A zero count means only that a managed wrapper hook saw no calls; it does **not** establish that NVIDIA native NGX or another inlined/native render path never executed. The already-working `GetOptimalSettings` query remains active after native menu transitions.

Key log tags: `[V132 DLSS-DRS]`, `[V132 NVIDIA-FEATURE]`, `[V129 DLSS-LIVE]`; file `Mods\SonsVR_V129_DLSS_Live_*.tsv`. Interpretation should use exact EYE_BEGIN/EYE_END dimensions, min fraction before/after, native quality enum, and callback calls, not uncontrolled NPC-dependent GPU timings. If `SCALER_NOT_INSTALLED`, do not interpret an unchanged image as a failed *manual callback* experiment, because no callback was installed.
