# SonsVR V128 — Native game-menu DLSS receiver reroute (2E experiment)

**Baseline:** V116 world/HUD/AER renderer from the user's supplied archive, with V127
read-only contract telemetry and V117 lightweight exit-to-title watchdog/transition trace.
**Status:** Complete C# source kit; static audit passed. **Not yet Windows-compiled or HMD-tested**.

## Build and install

1. Make a backup of the last good `SonsVR_Mod.dll` (V116 or V127) in your game Mods folder.
2. Run `BUILD_V128.bat`. It uses your existing Unity 2022.2.16f1 installation,
   shader bundler and native Optical Flow bridge build, followed by `mod/build_named.bat`.
   As in previous kits, adjust `UNITY_EXE` at top if your Unity is elsewhere.
3. Install from `OUTPUT/`: `SonsVR_Mod.dll` and `SonsVR_NvOF_V90.dll`
   into `D:\SteamLibrary\steamapps\common\Sons Of The Forest\Mods`.
   Keep shader resource packed into the compiled mod via the build procedure.
4. Start in your last-selected gameplay mode. **Select 2E** before doing the DLSS menu test.

## Architecture / significant code changes

- On 2E gameplay V128 skips **V116's one-time mod-owned global DLSS option/quality writes**.
  Endnight's original menu/manager stays in charge (no V125/V126 global option replay).
- On 2E camera initialization, skip **the V116 custom fixed `Quality`/`Optimal` stamp**.
  Existing `StereoRender` camera construction and render-texture allocation are otherwise
  unchanged, including the known 3141×3317 target sizes in the supplied trace.
- Discover only `DynamicResUpscaleManager._dynamicResolutionSettingReceivers` (small IL2CPP
  list), find its **registered** authored `MainCameraFP` receiver, save its original
  target/cached HD data, and prepare **one** extra receiver on a disabled host.
- Populate the extra receiver with the game's live Quality/Balanced/Performance/UltraPerformance
  enum mapping, target the right eye, **activate the host** to run Unity's native
  `OnEnable` registration, and verify it registered. Only then retarget the genuine
  authored receiver to the left eye. Initialize via receiver-local refresh, not
  manager-setting writes. Native `LateUpdate` remains active for both receivers.
- After confirming both receivers in the manager list, disable DLSS/DRS eligibility
  on the desktop `MainCameraFP` (it remains alive for interaction/Camera.main).
- If registration fails, returns to AER, a camera identity changes, or the receiver
  list becomes invalid, roll back the original receiver and deactivate the clone.
  Poll registered-receiver health every 2 seconds while active, without scene scans.
  Additive scene load does **not** itself tear down an active route.
- **AER is unchanged from V116**, including the fixed high-sensitivity source/depth
  lattice and V103 guarded hole fill. V128 does not set AER resolution, quality,
  optical flow or HUD. Starting in AER is supported; V128 routes only on 2E.
- Read-only `[V127 DLSS-CONTRACT]` and `[V127 DLSS-RECEIVERS]` lines are retained,
  alongside the added `[V128 NativeDLSS]` state logs and the V117 exit watchdog.

## One efficient HMD test

No synchronized action, overlay watching, or live log checking required.

1. Enter gameplay, **2E**. If stutter starts periodically, **abort** and revert the DLL.
2. Confirm `ROUTER ACTIVE` in the trace after the session (not while in HMD).
3. In the **game's own graphics menu**, select:
   **Quality (5 seconds) → Ultra Performance (5 seconds) → DLSS Off (5 seconds)
   → Quality (5 seconds)**, in that order.
4. Observe qualitatively whether sharpness and FPS change. Avoid touching the mod's
   own external DLSS settings during this test.
5. Optionally switch to AER briefly to verify the familiar stable image; do not
   attempt an AER quality sweep, since AER is not yet resolution-independent.
6. Exit, run `PACK_V128_TRACE.bat`, and send `V128_TRACE_RETURN.zip`.

**Success criterion:** the native manager + TWO active native receivers track the
menu, BOTH eye `QCode`/DLSS allow flags change appropriately, and *actual HDCamera
viewport dimensions* move in line with the selected quality. This is stronger than
seeing the quality enum update alone. Off must disable the DLSS path; a 50% render
viewport even while Off is a separately actionable fault, not grounds to claim success.

**Failure/rollback cues:** `ROUTE ERROR`, `ROLLBACK`, `right receiver OnEnable did not register`,
`eye registration...`, no `ROUTER ACTIVE`, persistent stutter, or new crashes.
Reinstall V116/V127 DLL to revert. If the route fails before retargeting the
native left receiver, V128 reverts any partial right host and backs off retries.

## Limits / honesty

A C# reflection-based router cannot prove the IL2CPP native method body's logic from
wrapper signatures alone. We have not verified that `VerifyProperties` uses
`_targetCamera` rather than its owner's GameObject. If the native class insists on
owner-local `HDAdditionalCameraData`, the left-eye retarget can still fail; the trace
records the per-eye cache and property states for exactly that outcome. The source
was statically audited, not built or run in the actual Windows game runtime.
