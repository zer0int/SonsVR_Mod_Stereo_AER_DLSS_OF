V65 QUICK START
===============

Run:
  BUILD_V65.bat

Install ONLY:
  OUTPUT\SonsVR_Mod.dll

Do NOT copy OUTPUT\sonsvr_depththingy into the game. It is already embedded in the DLL.

This build keeps V64's corrected main-HUD size, restores logical minimap scaling, and
refreshes Unity's native GPS stencil mask once after converting the minimap Canvas to
WorldSpace. No V61 raw-UGUI replay is enabled.
