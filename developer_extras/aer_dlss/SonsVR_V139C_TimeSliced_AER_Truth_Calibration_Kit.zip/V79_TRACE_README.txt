SONSVR V79 — PASSIVE HDRP HISTORY + V51 COVERAGE FORENSICS
============================================================

RENDERER
--------
V77/V76 rendering behavior is unchanged.

V79 is diagnostic only.

WHAT V78 ALREADY ESTABLISHED
----------------------------
At the exact VR-eye SRP_END callback where V50 captures depth:

  eye viewport          = 3141 x 3317
  eye target            = 3141 x 3317
  RTHandle current      = 3141 x 3317
  RTHandle allocation   = 3840 x 3317
  depth allocation      = 3840 x 4976
  rtHandleScale         = (0.82, 1.00, 0.82, 1.00)

and these do NOT change when the game DLSS setting changes.

But MainCameraFP DOES switch its global HDRP history/DRS state:
  DLSS on  -> 1920x1080 prior/scaled history-ish state
  DLSS off -> 3840x2160

At SRP_BEGIN of the VR eyes, that MainCamera global RTHandle state is still
visible before the eye later ends in its correct 3141x3317 state.

TWO QUESTIONS V79 ANSWERS
-------------------------

1) PER-EYE HDCAMERA HISTORY
Does HDCamera.GetOrCreate(VRLeftEye/VRRightEye).historyRTHandleProperties
itself follow MainCameraFP's DLSS-dependent 1920x1080 / 3840x2160 state?

V79 records:
  hdhistory.actualWidth / actualHeight
  hdhistory.cameraFrameCount
  hdhistory.historyRTHandleProperties
  internal BufferedRTHandleSystem properties where accessible

at SRP_BEGIN and SRP_END_PRE_DEPTH.

If the per-eye HDCamera history remains 3141x3317 throughout, global SRP state
at SRP_BEGIN is probably harmless setup noise.

If eye history itself changes with MainCamera DLSS, that is a serious temporal
cross-camera contamination lead.

2) DOES THE V51 FALLBACK REGION ACTUALLY MOVE?
The existing desktop confidence panel already encodes:
  white = direct/high-confidence V51 warp
  gray  = filled
  black = old target-eye fallback

V79 sparsely AsyncGPUReadbacks that existing small debug panel. It computes:
  hole fraction
  covered fraction
  high-confidence fraction
  mean confidence
  largest CONNECTED black-hole component fraction
  largest-hole normalized bounding box
  largest-hole centroid

No visual judgement is needed.

This gives a very strong fork:

A. COVERAGE bbox changes with DLSS:
   the failure rectangle really moves INSIDE V51.
   Chase projection/history/reconstruction state.

B. COVERAGE bbox stays fixed but headset rectangle moves:
   V51 geometry is exonerated from the spatial movement.
   Chase submission/compositor/downstream presentation.

OPENVR SUBMISSION
-----------------
V79 also logs change-only:
  left/right submitted RT name
  dimensions
  graphics format
  useDynamicScale
  native texture handle
  texture UV bounds
  SteamVR recommended scene size
  texture type

This closes the gap between syntheticRT and SteamVR submission.

ONE SESSION PROTOCOL
--------------------
Exactly the same easy protocol as V78:

1. Normal current DLSS/superscale state, wait ~3 sec.
2. Fully OFF, wait ~3 sec.
3. One DLSS mode (Quality is fine), wait ~3 sec.
4. Fully OFF again, wait ~3 sec.
5. Quit normally.

You do not need to look at the HUD or judge the flashing region.

BUILD
-----
  BUILD_V79_TRACE.bat

Install only:
  OUTPUT\SonsVR_Mod.dll

PACK
----
After quitting:
  PACK_V79_TRACE.bat

Send:
  V79_TRACE_RETURN.zip

KEY ROWS IN THE TSV
-------------------
  hdhistory.*
  COVERAGE_V79
  SUBMIT_V79
  sons.dlss.*
  rthandles.*
  drs.*

COVERAGE COORDINATES
--------------------
bboxBL and centroidBL are normalized 0..1 coordinates with bottom-left origin.
That is sufficient for comparing movement between setting states.
