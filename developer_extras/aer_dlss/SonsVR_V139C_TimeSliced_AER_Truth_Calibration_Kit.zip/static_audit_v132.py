from pathlib import Path
import hashlib, sys, subprocess
R=Path(__file__).resolve().parent; M=R/'mod'
entry=(M/'SonsVRMod.cs').read_text()
vr=(M/'VRPlayer.cs').read_text()
new=(M/'NativeDlssForensicsV132.cs').read_text()
feature=(M/'NvidiaFeatureTraceV132.cs').read_text()
csproj=(M/'SonsVR_Mod.csproj').read_text()
# Keep earlier baseline checks, but earlier audit was for V131 cue-path checksum.
# Our V132 control change explicitly changes the one cue gate in VRPlayer.
old=vr.replace('!global::SonsVRMod.NativeDlssForensicsV132.CueActive',
               '!global::SonsVRMod.NativeDlssForceActivationV131.CueActive')
expected={
 'StereoRender.cs':'f87ca07cadfb1a4e4910a4a21ea8e1d6031cd114aee61e04cd146bba430abf7c',
 'UnifiedHudWorldPlaneV116.cs':'bb2faf5ad30f6009acd7a493b381a62299055fa21aae7714b0e7a363a8553f52',
 'EyeDepthCaptureCustomPassV81.cs':'a3362c34e1a4ee8fa56d5551d967f111ddce7089a507ed157249a1b3bb583138',
 'EyeMotionCaptureCustomPassV89.cs':'93e7c4cc542b0f4292cd5ed0a8c3a899df3e7ad82f9d5a90f888bb196c028c56',
 'NvOpticalFlowV90.cs':'a897d1a9a463c1d9227b86a2b37e0af45e4405524d7269c40b48f6a77448241f',
 'NativeDlssReceiverRouterV128.cs':'b159d5196e48f422e9c4326ef2cfc1162c37c4f72458cc6418fbc9e1a0365366',
 'NativeDlssLiveResolutionTraceV129.cs':'4129a0205c0ca419a409a2f7bd625fa794dc4ff6d24724816c25c79120c71b8f'
}
checks={
 'baseline HDRP/HUD/router/flow SHA checks':all(hashlib.sha256((M/f).read_bytes()).hexdigest()==h for f,h in expected.items()),
 'VRPlayer only alters V131 cue gate': hashlib.sha256(old.encode()).hexdigest()=='80b47a626ba418c659f873521d3f7d1c615d81cad297161222cf04c45ed20e61',
 'V132 class compiled in project':'Compile Include="NativeDlssForensicsV132.cs"' in csproj,
 'NVIDIA observer class compiled in project':'Compile Include="NvidiaFeatureTraceV132.cs"' in csproj,
 'V132 Tick active and V131 one-shot no-op disabled':'NativeDlssForensicsV132.Tick();' in entry and 'NativeDlssForceActivationV131.Tick();' not in entry,
 'V130 conflicting automatic override disabled':'NativeDlssOptimalOverrideV130.Tick();' not in entry,
 'V132 restores before V129 trace shutdown':'NativeDlssForensicsV132.Shutdown();' in entry,
 '30s baseline and 5s in-HMD warning':'BaselineSeconds = 30f' in new and 'WarningSeconds = 5f' in new and 'SetAerV102HmdCue' in new,
 'manual phase separate from 2022.3 min clamp':'ApplyManualMode();' in new and 'ApplyMinFractionFix();' in new,
 'native 2022.3 min field reflected':'"m_MinScreenFraction"' in new and 'SetValue(_handler, 0.25f)' in new,
 'change logged and restored':'MIN_FIX_WRITE' in new and 'MIN_RESTORED' in new,
 'safe scaler install requires original callback/policy':'SCALER_NOT_INSTALLED' in new and '_oldScaler' in new and '_oldPolicy' in new and 'SCALER_RESTORED' in new,
 'renderer AER gate':'StereoRender.UserGameplayAERV112 || !NativeDlssReceiverRouterV128.Routed' in new,
 'Harmony type references fully qualified': 'private static HarmonyLib.Harmony _harmony' in feature and 'new HarmonyLib.Harmony(' in feature and 'private static Harmony _harmony' not in feature,
 'NVIDIA wrapper observation only':'CreateFeature' in feature and 'ExecuteDLSS' in feature and 'DestroyFeature' in feature and 'new HarmonyLib.Harmony(' in feature,
 'no new receiver registration, scene-wide searches':all(x not in new+feature for x in ('FindObjectsOfType(', 'new GameObject(', 'Register(', 'UpdateAndUseCamera(', 'SetActiveDynamicScalerSlot(')),
 'V129 TSV flush prior to intervention':'Flush("PRE_MANUAL_OVERRIDE")' in new and 'Flush("PRE_MIN_FRACTION_PATCH")' in new,
 'VRPlayer gate wired':'NativeDlssForensicsV132.CueActive' in vr,
}
for k,v in checks.items():print(('[PASS] ' if v else '[FAIL] ')+k)
print('V132 static audit: %d/%d checks' % (sum(checks.values()), len(checks)))
if not all(checks.values()): sys.exit(1)
