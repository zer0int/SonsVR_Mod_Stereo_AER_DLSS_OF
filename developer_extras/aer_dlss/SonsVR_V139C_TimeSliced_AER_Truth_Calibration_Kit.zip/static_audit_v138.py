#!/usr/bin/env python3
from pathlib import Path
import hashlib,sys
root=Path(__file__).resolve().parent
mod=root/'mod'
files=['SonsVRMod.cs','VRPlayer.cs','UnifiedHudWorldPlaneV116.cs','RuntimeSettingsV105.cs','NvOpticalFlowV90.cs','EyeDepthCaptureCustomPassV81.cs','EyeMotionCaptureCustomPassV89.cs','TransitionDlssAuditV117.cs']
baseline={'SonsVRMod.cs': '10f3088b71682efd7bcf830fe2e7314a0cbe3e156940836ab2ead4e8f07ebb94', 'VRPlayer.cs': 'cd8240b986b3823571bab830f8a9269f0b3d6b947367b0c54461355c3bd15244', 'UnifiedHudWorldPlaneV116.cs': 'bb2faf5ad30f6009acd7a493b381a62299055fa21aae7714b0e7a363a8553f52', 'RuntimeSettingsV105.cs': 'eed00e4a1f497d731919538d0eb7439f92759689f345121c0c6f5a1fce72b25d', 'NvOpticalFlowV90.cs': 'a897d1a9a463c1d9227b86a2b37e0af45e4405524d7269c40b48f6a77448241f', 'EyeDepthCaptureCustomPassV81.cs': 'a3362c34e1a4ee8fa56d5551d967f111ddce7089a507ed157249a1b3bb583138', 'EyeMotionCaptureCustomPassV89.cs': '93e7c4cc542b0f4292cd5ed0a8c3a899df3e7ad82f9d5a90f888bb196c028c56', 'TransitionDlssAuditV117.cs': '0946647d68a022eb61a91dbed9a08ae4bcc01fa24315177292ef9d6dcc407ea4'}
checks={'exists '+f:(mod/f).is_file() for f in files}
checks.update({'byte-identical V137 '+f:hashlib.sha256((mod/f).read_bytes()).hexdigest()==baseline[f] for f in files})
scale=(mod/'NativeDlssCameraScaleV136.cs').read_text(encoding='utf-8-sig')
router=(mod/'NativeDlssReceiverRouterV128.cs').read_text(encoding='utf-8-sig')
v91=(mod/'DlssRuntimeV91.cs').read_text(encoding='utf-8-sig')
stereo=(mod/'StereoRender.cs').read_text(encoding='utf-8-sig')
trace=(mod/'NativeDlssLiveResolutionTraceV129.cs').read_text(encoding='utf-8-sig')
feature=(mod/'NativeDlssFeatureStateV133.cs').read_text(encoding='utf-8-sig')
checks.update({
 'native route available in AER':'if (StereoRender.UserGameplayAERV112)' not in router.split('internal static void Tick(StereoRender stereo)')[1].split('if (stereo == null')[0],
 'legacy V91 global quality disabled for both modes':'NativeDlssReceiverRouterV128.Tick(stereo);\n                return;' in v91,
 'legacy V91 per-eye quality disabled for both modes':'if (NativeDlssReceiverRouterV128.Enabled)\n                return;' in v91,
 'AER allowed in hook':'StereoRender.UserGameplayAERV112 ||' not in scale and '!NativeDlssReceiverRouterV128.Routed' in scale,
 'same camera-scoped ScaleFn patch kept':'ScaleFnPrefix' in scale and 'HarmonyMethod(prefix)' in scale,
 'native DLSS Quality scale retained':'case "quality":' in scale and 'percentage = 66.7f;' in scale,
 'native DLSS Balanced scale retained':'case "balanced": percentage = 58.0f;' in scale,
 'native DLSS Performance scale retained':'case "maximumperformance": percentage = 50.0f;' in scale,
 'native DLSS Ultra Performance scale retained':'case "ultraperformance": percentage = 33.3f;' in scale,
 'no global scaler writes':all(x not in scale for x in ('SetDynamicResScaler(', 'SetSystemDynamicResScaler(', 'SetActiveDynamicScalerSlot(','.m_MinScreenFraction =','.m_CurrentFraction =')),
 'V129 logs AER':'StereoRender.UserGameplayAERV112 ||' not in trace and 'mode=AER' not in trace,
 'V133B inspects AER':'StereoRender.UserGameplayAERV112 ||' not in feature,
 'depth-guard pass remains':'HoleFillDepthGuardV103' in stereo and 'AerV104DepthGuardedFillPermanentEnabled' in stereo,
 'no depth-guard parameter modifications':'AerV103FillDepthAbsToleranceMeters = 0.30f;' in stereo and 'AerV103FillDepthRelativeTolerance = 0.06f;' in stereo,
 'AER depth dimensions sampled':'[V138 AER-DEPTH-RASTER]' in stereo and 'TryGetObservedViewportV116' in stereo,
 'no new async GPU readbacks in V138':'[V138 AER-DEPTH-RASTER]' in stereo and 'metadata only' in stereo,
 'build and pack included':(root/'BUILD_V138.bat').exists() and (root/'PACK_V138_TRACE.bat').exists(),
 'active mode not hardcoded to AER':'mode=" + (StereoRender.UserGameplayAERV112 ? "AER" : "2E")' in scale,
})
for k,v in checks.items():print(('[PASS] ' if v else '[FAIL] ')+k)
print('V138 audit:',sum(checks.values()),'/',len(checks))
sys.exit(0 if all(checks.values()) else 2)
