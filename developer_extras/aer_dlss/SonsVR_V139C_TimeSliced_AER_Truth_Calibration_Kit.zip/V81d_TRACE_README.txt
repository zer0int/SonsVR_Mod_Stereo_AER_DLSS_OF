SONSVR V81d — CUSTOM PASS LIFECYCLE / CAMERA-MODE DEPTH PROBE
================================================================

WHAT V81c ACTUALLY SHOWED
-------------------------
V81c's shader harness is fixed:
  secondary shader name is correct
  passCount = 8
  V80 pass executes successfully

BUT the CustomPass lifecycle still never ran:
  zero [EXEC-SEEN]
  zero LOCALDEPTH_V81
  explicit "CUSTOM PASS HAS NOT EXECUTED" warning

Therefore V81c again did NOT test cameraDepthBuffer.

WHY V81d IS DIFFERENT
---------------------
HDRP 14's documented runtime pattern is:

  volume.AddPassOfType(typeof(MyPass))

V81b/V81c instead manually did:
  new MyPass()
  volume.customPasses.Add(pass)

V81d stops doing that.

For EACH eye it creates an explicit camera-mode CustomPassVolume:
  targetCamera = VRLeftEye / VRRightEye
  injectionPoint = AfterOpaqueDepthAndNormal

and creates the pass via:
  CustomPassVolume.AddPassOfType(typeof(EyeDepthCaptureCustomPassV81))

It also:
  - places the volume GameObject on a layer already included by that eye's
    ordinary HDRP volumeLayerMask as belt-and-suspenders
  - logs the actual targetCamera, layer, mask, pass type and pass count
  - logs CustomPass.Setup() separately as [SETUP-SEEN]
  - logs Execute() BEFORE checking whether AER is enabled as [EXEC-SEEN]

So there are now three increasingly strong runtime proofs:

  installed
  -> SETUP-SEEN
  -> EXEC-SEEN
  -> LOCALDEPTH_V81

If Setup never runs, HDRP isn't accepting the injected pass lifecycle.
If Setup runs but Execute doesn't, scheduling/frame settings are the problem.
If Execute runs, we finally get the camera-local depth comparison.

BUILD
-----
  BUILD_V81d_TRACE.bat

As with V81c, shader validation is still mandatory and build-time enforced.

RUN
---
For the first ~5 seconds of actual gameplay, don't even bother changing DLSS.
The first question is simply whether you get SETUP-SEEN and EXEC-SEEN.

If yes, then do the fixed-view protocol:
  current DLSS ~4 sec
  OFF ~4 sec
  Quality ~4 sec
  OFF ~4 sec

PACK
----
  PACK_V81d_TRACE.bat

Send:
  V81d_TRACE_RETURN.zip
