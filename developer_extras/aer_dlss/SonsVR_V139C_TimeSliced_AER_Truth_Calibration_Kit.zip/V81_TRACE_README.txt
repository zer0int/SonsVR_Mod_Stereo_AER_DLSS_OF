SONSVR V81 — CAMERA-LOCAL HDRP DEPTH CUSTOM PASS
==================================================

PURPOSE
-------
V80 proved that the GLOBAL shader binding:

  Shader.GetGlobalTexture("_CameraDepthTexture")

changes catastrophically with the game's DLSS state.

V81 asks the definitive provenance question:

  What does HDRP's exact per-camera
  CustomPassContext.cameraDepthBuffer
  contain at the same time?

ARCHITECTURE
------------
Two camera-targeted CustomPassVolume objects:
  VRLeftEye
  VRRightEye

Injection:
  AfterOpaqueDepthAndNormal

Each pass reads:
  ctx.cameraDepthBuffer

and writes ONLY diagnostic-owned resources:

1) full-res RFloat raw-depth candidate:
   SonsVR_V81_CameraLocalRawDepth

2) 256x256 diagnostic:
   valid / nonzero / discontinuity / log-depth

Nothing from V81 is fed into V51.

V80 remains active, so a single TSV contains both:

  DEPTH_V80
      global _CameraDepthTexture at endCameraRendering

  LOCALDEPTH_V81
      exact camera-local CustomPassContext.cameraDepthBuffer

ARRAY-SLICE CHECK
-----------------
V81 logs TextureDimension and volumeDepth.

If cameraDepthBuffer is a Texture2DArray with more than one slice, it
automatically diagnoses slice 0 AND slice 1.

THE DREAM RESULT
----------------
DLSS OFF:

  DEPTH_V80:
      ~83% raw zero
      ~15-18% valid

  LOCALDEPTH_V81:
      remains normal

=> CASE CLOSED:
   global _CameraDepthTexture provenance/timing is wrong.
   The full-res V81 RFloat latch becomes the production candidate for V51.

OTHER RESULT
------------
If LOCALDEPTH_V81 collapses too:

=> the corruption happens deeper inside HDRP before/at
   AfterOpaqueDepthAndNormal.

SAFETY
------
V81 does NOT:
- feed new depth into V51
- change AER scheduling
- change OpenVR submission
- enable DLSS on eye cameras
- change DRS
- modify camera depth

It does explicitly enable FrameSettingsField.CustomPass on the two VR eyes so
the diagnostic pass can execute. That field was previously tested and was not
the source of the visual bug.

BUILD
-----
  BUILD_V81b_TRACE.bat

If compilation fails:
  DO NOT LOAD THE GAME.
  Send the compiler output.

RUN
---
Same one-session protocol:

1. Current DLSS state ~3 sec
2. Fully OFF ~3 sec
3. DLSS Quality ~3 sec
4. Fully OFF ~3 sec
5. Quit

No visual judgement required.

PACK
----
  PACK_V81_TRACE.bat

Send:
  V81_TRACE_RETURN.zip

VALIDITY
--------
Startup/runtime log should contain:
  [AER V81][CustomDepth] injected CustomPass type registered
  [AER V81][CustomDepth] camera-targeted CustomPass volumes INSTALLED

The decisive proof is LOCALDEPTH_V81 rows in the TSV.


V81b COMPILE HOTFIX
-------------------
Only three access modifiers changed to match this game's generated HDRP wrapper:

  protected override Setup   -> public override Setup
  protected override Execute -> public override Execute
  protected override Cleanup -> public override Cleanup

No diagnostic/render/runtime logic changed.
