SONSVR V84 — CLEAN V53-SPEED ANCHOR + LATEST HUD
=================================================

V83 was genuinely running at ~5 FPS-class frame times in the supplied trace, so its
temporal result was not a fair reconstruction test.  V84 deliberately restores the
V53-like world path while keeping the later HUD fixes, and removes the accumulated
forensic/debug stack from the headset run.

KEPT: current V38B one-real-eye scheduler, 1.0 eye size, V66 HUD timing, exact HUD
meshes, V76 dense HUD handling, V77 viewport safety, current OpenVR submission.

WORLD: current fresh eye -> opposite eye, old global _CameraDepthTexture mip0 latch,
1px+2px fill, raw old TARGET eye for true holes.  V36 is OFF.

OFF: V83 same-eye temporal; V81 CustomPass; V78 tracer; V79/V80/V81 readbacks; V83
truth board; post-submit desktop copies; V44/V46 probes.

This is a PERFORMANCE ANCHOR, not the final AER design.  If fluidity returns, add the
same-eye temporal method back on top of this clean anchor with only the minimum local
depth capture needed.

Build: BUILD_V84.bat
Expected log: [AER V84][PerfAnchor] V53-LIKE WORLD PATH READY
