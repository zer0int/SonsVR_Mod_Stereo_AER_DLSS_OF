SONSVR V81f — CAMERA-LOCAL DEPTH READBACK CALLBACK FIX
=======================================================

WHAT THE LAST RUN PROVED
------------------------
The post-spawn CustomPass lifecycle finally WORKED:

  SETUP-SEEN
  EXEC-SEEN

HDRP supplied, for each exact VR eye:

  ctx.cameraDepthBuffer =
    CameraDepthStencil_3840x3317_None_Tex2DArray

  allocation = 3840x3317
  HDCamera actual = 3141x3317
  dimension = Texture2DArray
  slices = 1

This is distinctly different from the global end-of-camera texture:

  _CameraDepthTexture =
    CameraDepthBufferMipChain_3840x4976_R32_SFloat_Tex2DArray_dynamic

So we finally have the actual camera-local base depth/stencil object.

WHY LOCALDEPTH_V81 WAS STILL EMPTY
----------------------------------
A code-placement bug:

  EyeDepthCaptureCustomPassV81.OnEndCameraRendering(camera)

had accidentally been inserted in:

  OnBeginCameraRenderingV60()

rather than:

  OnEndCameraRenderingV50()

Therefore every AsyncGPUReadback eligibility check happened BEFORE that frame's
AfterOpaqueDepthAndNormal CustomPass had written its diagnostic RT.

V81f simply moves that call to the ACTUAL endCameraRendering callback.

NO DEPTH / RENDER MATH CHANGED.

NEW LIVENESS LOGS
-----------------
A valid run should now show:

  [READBACK-REQUEST]
  [READBACK-DONE]

and the TSV should contain:

  LOCALDEPTH_V81

The first READBACK-DONE line already prints:
  zeroFrac
  validFrac
  medianDepthM

so we can know immediately whether the camera-local depth is sane.

RUN
---
Use the same fixed-view sequence:

  current DLSS ~4 sec
  OFF ~4 sec
  Quality ~4 sec
  OFF ~4 sec

Visual appearance is still expected to be unchanged.
V81f remains PASSIVE: local camera depth is NOT fed into V51 yet.

If LOCALDEPTH_V81 stays sane while DEPTH_V80 collapses with DLSS OFF,
the next build can finally route this full-res local RFloat latch into V51.

BUILD
-----
  BUILD_V81f_TRACE.bat

PACK
----
  PACK_V81f_TRACE.bat

Send:
  V81f_TRACE_RETURN.zip
