SonsVR V112 — VIEWPORT HUD CENTER + AER/2E LIVE MODE
=====================================================

BASE
----
V111, which restored the V108 HUD implementation and retained V110 loading/settings UX.

WHAT V112 CHANGES
-----------------
1) HUD vertical placement only
   - V108 minimap scale, ScreenBounds anchor, VitalsRenderTexture centering, forward distance,
     right offset, and all other HUD behavior remain intact.
   - Optional projection-aware correction translates ONLY the outer PlayerMiniMap container
     along head-up until its measured map centre is at stereo viewport Y=0.5.
   - Settings row: HUD vertical anchor = VIEW CENTER / V108 LEGACY Y.

2) Gameplay renderer switch
   - Settings row: Gameplay render mode = AER / 2E.
   - AER = production alternate-eye renderer (depth guard + V100 fallback + optional NVOFA/DLSS).
   - 2E = genuine left + right eye camera render every application frame.
   - Live switching is supported; returning to AER uses the existing safe both-eye warmup.

3) Actual backend-mode telemetry
   The yellow perf HUD reports one of:
     AER      - one real eye scheduled; partner synthesized
     2E       - configured full stereo
     2E/UI    - temporary real-both-eye pin while settings/single-player pause is active
     2E/WARM  - real-both-eye warmup before AER resumes
     2E/PRE   - title/loading before gameplay AER gate

4) V111 accidental 2E-stuck risk removed
   - V111's menu pin used the broad PauseMenu hierarchy signal.
   - V112 uses strict Time.timeScale==0 for single-player pause plus our explicit settings panel.
     A stale/hidden PauseMenu object can no longer keep normal gameplay in 2E.

5) Our custom overlays now use normalized stereo viewport coordinates
   - No more guessed Head-local x/y/z values pretending to be screen coordinates.
   - Stats target: centre=(0.82,0.84), width=0.28 viewport, distance=1.25m.
   - Settings target: centre=(0.50,0.52), width=0.66 viewport, distance=1.25m.
   - Position and angular scale are derived from BOTH actual asymmetric eye projections.
   - This does not yet turn them into OpenVR compositor overlays; it makes their current
     world-space placement deterministic and resolution-independent.

UNCHANGED
---------
- V103/V104 depth-coherence guarded fill remains the production path.
- V100 rotation-only true-hole fallback remains.
- V72/V74/V76 HUD catcher/proxy/dense-remap path remains hard-off.
- V107/V108 cooking performance + page handling remain.
- V107 loading-layer performance fix remains.
- V110 +0.30m title/loading eye lift, clean LOADING/spinner/SOTF VR, native old loading visual
  suppression, settings-table style, and pause-menu input isolation remain.

BUILD
-----
Run:
  BUILD_V112.bat

Install BOTH files from OUTPUT into the game's Mods directory:
  SonsVR_Mod.dll
  SonsVR_NvOF_V90.dll

FIRST TEST
----------
- With yellow stats HUD ON, normal gameplay should say AER after the short warmup.
- Open settings: actual mode should say 2E/UI while panel is visible.
- Close settings and unpause: it should briefly say 2E/WARM, then AER.
- Switch Gameplay render mode to 2E and Apply: normal gameplay should remain 2E.
- Switch back to AER and Apply: expect brief 2E/WARM then AER.
- HUD map/ring should retain V108 behavior but move vertically to true viewport centre when
  HUD vertical anchor is VIEW CENTER. Toggle to V108 LEGACY Y if desired for direct A/B.
- Yellow stats panel should occupy the top-right rather than centre-right/cut off.

COMPOSITOR OVERLAY NOTE
-----------------------
OpenVR compositor overlays are the clean next architecture for SonsVR-owned telemetry/settings:
they are rendered by SteamVR after the eye textures, so AER/TAA/DLSS cannot blur them. V112 does
NOT enable that path yet; it first gives us an unambiguous AER-vs-2E truth readout and deterministic
viewport placement. The native game HUD/title/pause UI are a separate problem because they belong
to the game's own complex canvas/render-texture/interactions rather than a standalone texture.
