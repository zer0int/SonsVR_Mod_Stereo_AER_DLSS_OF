START HERE: BUILD_V108.bat

V108 keeps V107's performance fixes, restores ingredient selection on later cooking pages with
one-shot page-transition discovery, and adds a large head-locked loading spinner on the cheap
layer-5 loading view.

After testing, run PACK_V108_TRACE.bat.
