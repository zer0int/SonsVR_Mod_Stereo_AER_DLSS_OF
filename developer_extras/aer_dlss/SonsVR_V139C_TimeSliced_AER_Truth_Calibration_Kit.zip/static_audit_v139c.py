from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parent
old=subprocess.run([sys.executable,str(R/'static_audit_v139.py')],cwd=R,capture_output=True,text=True)
print(old.stdout,end='');print(old.stderr,end='',file=sys.stderr)
checks={
 'baseline 31/31 audit':old.returncode==0,
 'actual staged GPU capture snapshot':'BeginStagedTruthV139C(self, sample)' in (R/'mod/StereoRender.cs').read_text(),
 'after-submit scheduling':'TickStagedTruthV139C();' in (R/'mod/StereoRender.cs').read_text(),
 'one work item per active fence':'if (_v139cPendingEye >= 0)' in (R/'mod/StereoRender.cs').read_text(),
 'GPU fence success/fail monitoring':'GPU_CONFIRMED eye=' in (R/'mod/StereoRender.cs').read_text() and 'GPU_FENCE_TIMEOUT' in (R/'mod/StereoRender.cs').read_text(),
 'frozen truth metadata':'SnapshotMetadataV139C()' in (R/'mod/StereoRender.cs').read_text(),
 'snapshot depth used':'j.TruthLatch.DepthRT = j.TruthDepth;' in (R/'mod/StereoRender.cs').read_text(),
 'truth scheduling blocked until complete':'if (_v139cJobActive || _v139cPendingEye >= 0 ||' in (R/'mod/StereoRender.cs').read_text(),
 'compact CSV readback':'ATLAS_PARSED sample=' in (R/'mod/StereoRender.cs').read_text(),
 'match boundary censor':'matchAtSearchBoundary' in (R/'mod/AerCalibrationV139.cs').read_text() and 'matchAtSearchBoundary' in (R/'analyze_v139.py').read_text(),
 'disk journal':'FileOptions.WriteThrough' in (R/'mod/AerCalibrationV139.cs').read_text(),
 'runtime heartbeat':'EOF_SUBMIT_HEARTBEAT' in (R/'mod/AerCalibrationV139.cs').read_text(),
 'trace includes journal':'SonsVR_V139C_GpuStages_*.log' in (R/'pack_v139_trace.py').read_text(),
 'pack BAT exists':(R/'PACK_V139C_TRACE.bat').exists(),
 'build BAT exists':(R/'BUILD_V139C.bat').exists(),
 'no global scaling hook changes':'_v139cJobActive' not in (R/'mod/NativeDlssCameraScaleV136.cs').read_text(),
}
for name,passed in checks.items():print('[PASS]' if passed else '[FAIL]',name)
print('V139C audit',sum(checks.values()),'/',len(checks))
raise SystemExit(0 if all(checks.values()) else 1)
