@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
cd /d "%ROOT%"
echo Packing SonsVR V139C staged calibration trace...
python "%ROOT%pack_v139_trace.py"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
    echo ERROR: Trace pack failed with exit code %RC%.
    pause
    exit /b %RC%
)
echo Trace complete: "%ROOT%V139_TRACE_RETURN.zip"
pause
exit /b 0
