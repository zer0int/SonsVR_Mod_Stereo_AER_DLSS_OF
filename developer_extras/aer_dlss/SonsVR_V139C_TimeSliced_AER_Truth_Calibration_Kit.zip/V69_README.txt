SONSVR V69 - HUD-PLANE DEPTH A/B/A PROBE
========================================

WHAT V68 ESTABLISHED
--------------------
The safe pre-render HUD transform sync is active in both full stereo and AER.
The remaining high-frequency HUD jitter persists when AER is active even while
the logged map/ring transforms remain perfectly coincident.

V69 DOES NOT TOUCH UNITY UI RENDERING.
It does NOT:
  - rebuild Canvases
  - capture/redraw UGUI
  - add a HUD camera
  - alter masks/materials
  - move HUD elements differently

Instead, after AER activates, V69 changes only the DEPTH USED BY THE SYNTHETIC
EYE warp for three representative source-eye rectangles:
  1) GPS ScreenMask
  2) visible VitalsRenderTexture RawImage
  3) MessageList

PHASES AFTER AER ACTIVATION
---------------------------
A: 4 seconds  - normal V51 scene depth (expected jitter baseline)
B: 8 seconds  - force those regions to 0.50 m HUD-plane reconstruction depth
C: thereafter - revert to normal V51 scene depth

IMPORTANT:
This is a causality diagnostic, NOT the final mask solution. The background
inside those rectangles is also intentionally treated as 0.50 m during Phase B,
so expect a visibly flattened/distorted patch behind the UI. Ignore that.
Watch whether the UI ITSELF stops jittering.

THE DECISIVE RESULT
-------------------
jitter in A
stable in B
jitter returns in C

=> transparent HUD color was being reprojected using unrelated background scene
depth. That directly confirms the common AER HUD-jitter mechanism.

Build:
  BUILD_V69.bat

Install only:
  OUTPUT\SonsVR_Mod.dll

Useful log tags:
  [AER V69][HudDepthProbe] PHASE A
  [AER V69][HudDepthProbe] PHASE B
  [AER V69][HudDepthProbe] sourceEye=...
  [AER V69][HudDepthProbe] PHASE C
