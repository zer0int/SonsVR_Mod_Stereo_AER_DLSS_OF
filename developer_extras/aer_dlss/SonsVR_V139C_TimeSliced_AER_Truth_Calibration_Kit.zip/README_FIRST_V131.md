# V131 — deliberate one-shot HDRP14 DLSS activation experiment

**Read first: important API correction.** In Unity HDRP 14, `DynamicResUpscaleFilter` does **not** have a `DLSS` enum member. The `drsFilter=TAAU` value logged by `DynamicResolutionHandler` is its *ordinary fallback upscaling filter*, which can remain TAAU even if advanced NVIDIA DLSS executes. Writing `SetUpscaleFilter(..., (DynamicResUpscaleFilter)fakeDlssValue)` would be meaningless and potentially crash for the wrong reason.

**What V131 actually does instead:** one time, after baseline capture and a visible five-second warning, V131B attempts to write `dynamicResolutionSettings.enableDLSS=true` through a writable HDRP asset member, if the game runtime exposes one. The generated IL2CPP wrapper has a getter-only `currentPlatformRenderPipelineSettings`, so the direct C# setter call from V131 is invalid. A supported runtime field write may be possible, but may not trigger a pipeline rebuild; this is now separately verified and logged. If DLSS was **already enabled**, V131 logs that this is a deliberate *pipeline reinitialization*, not an enable toggle. No generic filter enum is changed. It does not force scale, min/max, override the NVIDIA quality, alter RTs, modify the native receivers, or touch the AER renderer.

## Test instructions
1. Back up the working V130/V128 DLLs before installing. Compile V131 with `BUILD_V131.bat`; copy `OUTPUT\SonsVR_Mod.dll` and `OUTPUT\SonsVR_NvOF_V90.dll` into your game's `Mods` folder.
2. Enter **2E gameplay**, select **Quality**, and look toward the same waterfall/cattails. No need to freeze the HMD. V131 waits for the V128 native receiver reroute AND the post-loading HDRP camera copy before starting its own stopwatch.
3. For **30 seconds**, V127/V129 telemetry runs unmodified. (No message; use this time as the baseline.) At 30 seconds you will see the five-second in-HMD warning `V131 DLSS PIPELINE EXPERIMENT / OVERRIDE IN N SECONDS / BRACE FOR CHANGE / POSSIBLE CRASH`.
4. At ~35 seconds, the warning disappears. **Two frames later** the code flushes the baseline TSV and attempts the one-shot DLSS asset write if the runtime exposes a writable member; otherwise logs `NO_WRITE_UNSUPPORTED`. Stand around and watch for changes. It may hitch or crash. If it crashes, the pre-write V129 trace should already be on disk.
5. **If still stable**, try **Quality -> Ultra Performance -> Quality** (~8 seconds each) after the switch. No need to use Off, unless curious. Exit. Run `PACK_V131_TRACE.bat` and send `V131_TRACE_RETURN.zip`.
6. **If it crashes**, recover `Mods\SonsVR_V129_DLSS_Live_*.tsv` and `MelonLoader\Latest.log` (or the rolling `MelonLoader\Logs` log if `Latest.log` was truncated) before starting another game. The packer collects the latest available logs even without a successful exit.

## What is and is not established
- The V130 camera-local custom-attribute/optimal flags **did** stick, but all DLSS ON modes continued to have a fixed ~50% HDRP input lattice.
- The V130 `drsFilter=TAAU` alone is not proof DLSS wasn't used; the feature path is separate.
- After V131 we must inspect `ASSET BEFORE`, `ASSET WRITE RETURNED`, `POST_OVERRIDE`, **V129 EYE_BEGIN/EYE_END**, and, if present, Unity errors; a no-crash result is NOT evidence of successful NVIDIA DLSS execution.
- If the original HDRP asset enableDLSS is FALSE and V131 changes it, the mod restores the flag when leaving 2E. If already TRUE, it does not rebuild a second time just to restore an unchanged flag.
- **Do not switch to AER during the experiment.** The mode itself remains untouched, but changing a global HDRP asset in a running player can rebuild the entire pipeline; rollback on mode changes also rebuilds and has not been headset-tested.

## Scope and limitations
- V128 native routing, V130 optimal policy, V103 depth reconstruction, V116 unified HUD geometry, shader paths, and NVOFA are kept. Only one tiny existing VRPlayer cue-visibility condition is changed to reuse the already-present V102 in-HMD cue canvas. No new canvas, no HUD layout changes.
- This kit requires compilation on the supplied Windows installation. Linux environment cannot compile against the user's generated IL2CPP assemblies or run the VR game. The actual runtime may expose no safe writable pipeline settings member. In that case the experiment stops after logging `NO_WRITE_UNSUPPORTED`; compilation no longer assumes a setter.
- An HDRP asset may have features/shader variants restricted at build time. Even this real activation switch cannot guarantee availability of a missing NVIDIA plugin or DLSS shader path.
