SonsVR V90 — FULL-RES SAME-EYE + NVIDIA OPTICAL FLOW RESIDUAL A/B
=================================================================

WHAT THIS TESTS
---------------
V90 keeps the proven V88 full-resolution per-source-pixel depth scatter and asks
one remaining pre-DLSS question:

    Does image-derived apparent scene motion improve the residual AER micro-jitter?

NVIDIA Optical Flow Accelerator (NVOFA) runs on the RTX GPU via D3D11 using the
Optical Flow SDK 5.0.7 API. There are no CPU image copies/readbacks.

SAME-RUN A/B
------------
NVOFA executes throughout BOTH phases, so the ~30 s switch does not suddenly add
its runtime cost.

    first ~30 s presentation:
        full-res depth/camera reprojection only

    after automatic switch:
        identical reprojection
        + camera-subtracted NVOFA apparent-scene residual

Expected switch log:

    [AER V90][OpticalFlowAB] AUTO SWITCH ...
    DEPTH/CAMERA ONLY -> DEPTH + CAMERA-SUBTRACTED NVOFA RESIDUAL

NVOFA DIRECTION / TIME MODEL
----------------------------
For each physical eye, V90 keeps two genuine-real R8 luminance images and runs:

    CURRENT_REAL -> PREVIOUS_REAL

This makes the flow field anchored at the CURRENT stale source pixels that also
own our current depth/color history. The compute shader reconstructs what a
stationary world point would have done from camera motion alone, subtracts that
from the NVOFA vector, then extrapolates only the residual apparent scene motion.

No fixed x0.5 is assumed. V90 measures:

    scale = prediction_horizon / same_eye_real_flow_interval

from the actual real-eye capture timestamps (normally expected around ~0.5 at the
current alternating-eye cadence), clamped to 1.0 for catastrophic hitches.

BUILD
-----
Run:

    BUILD_V90.bat

This builds:
  1. SonsVR_NvOF_V90.dll (tiny native D3D11/NVOFA bridge)
  2. Unity shader AssetBundle
  3. SonsVR_Mod.dll

Then copy BOTH files from OUTPUT into the game's Mods folder:

    SonsVR_Mod.dll
    SonsVR_NvOF_V90.dll

The NVIDIA display driver supplies nvofapi64.dll. The downloaded SDK does not
need to be installed separately once the bridge is built.

TEST
----
Use the same distant-foliage / thin-branch region if convenient. Stay looking at
roughly the same region across the automatic ~30 s switch. Moving geometry is
welcome but no Virginia sacrifice is scientifically required. :P

The useful subjective answer is simply:

    better / worse / identical after the switch

Also report any global lurch, directionally wrong dragging, or large new fringe;
those are especially diagnostic of sign/history mismatch.

After the run:

    PACK_V90_TRACE.bat

Send V90_TRACE_RETURN.zip.

FAIL-SOFT BEHAVIOR
------------------
If Unity is not actually D3D11, the native bridge/DLL is missing, NVOFA runtime is
unavailable, 1x1 flow is unsupported, resource registration fails, or the exact
flow field is not ready, V90 stays on the known-good depth-only V88 compute path.
It should log why instead of submitting garbage.

INTENTIONAL NON-FEATURES
------------------------
- V89 HDRP object-motion CustomPass is OFF for this experiment.
- DLSS / dynamic resolution are still OFF.
- No optical-flow CPU readback/stat board.
- No shadow/AO experiments.
- No V36.
