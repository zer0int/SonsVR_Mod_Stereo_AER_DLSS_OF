SonsVR V105b - Compile Fix / Perf-Log Persistence Hardening
============================================================

Fixes the V105 compile errors reported by the game-side build:
- UnityEngine.Mathf vs Valve.VR.Mathf ambiguity: RuntimeSettingsV105.cs now aliases Mathf to UnityEngine.Mathf.
- StereoRender.LeftCam/RightCam are instance fields: settings code now uses the active StereoRender instance.

Perf logging clarification/hardening:
- SAMPLE and WARNING rows are append-only within each timestamped CSV. Flush() only pushes buffered bytes to disk; it never rotates, truncates, or deletes rows.
- Every logger open now creates a unique millisecond-stamped file with FileMode.CreateNew, so even rapid OFF->ON toggles cannot overwrite an earlier perf log.
- Warnings therefore remain preserved in the same session/segment CSV together with surrounding 2-Hz samples.

Build: BUILD_V105B.bat
Optional pack: PACK_V105B_LOG.bat
