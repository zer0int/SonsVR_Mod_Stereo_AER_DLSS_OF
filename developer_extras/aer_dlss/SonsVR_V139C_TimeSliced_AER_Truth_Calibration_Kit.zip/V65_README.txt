SonsVR V65 — GPS stencil refresh + matched HUD scale
=====================================================

Base: corrected V64 kit.

What V64 proved
---------------
1) Main ScreenSpaceCanvas was logical 1920x1080 while Screen was 3840x2160.
   Using Screen.height halved the physical HUD. V64 fixed that and the HUD spread returned.
2) GPS ScreenMask really has UnityEngine.UI.Mask enabled, showMaskGraphic=false.
3) The Map subtree translates/rotates under a fixed ScreenMask/PlayerArrow, which is normal
   minimap behavior — but the whole map surface is visibly escaping instead of being clipped.
4) The map became tiny only relative to the now-correct ring because GPS still used the old
   physical Screen.height denominator.

V65 changes
-----------
- KEEP V64 main-HUD logical-height scale fix.
- Restore V60 logical Canvas-height scaling for the GPS/minimap (Screen.height fallback only).
- After ScreenSpace -> WorldSpace conversion, one-shot refresh of the native GPS Mask graph:
    * toggle/re-arm ScreenMask Mask
    * MaskableGraphic.RecalculateMasking()
    * SetMaterialDirty()/SetVerticesDirty()
    * ONE Canvas.ForceUpdateCanvases() after corrected layout is established
  This does NOT manually draw UGUI and does NOT run per eye/frame.
- Log MaskUtilities.GetStencilDepth + materialForRendering before/after refresh.
- Track PlayerMiniMap/MiniMap sibling as a separate possible visible surface.

Build
-----
Run BUILD_V65.bat and install ONLY OUTPUT\SonsVR_Mod.dll.

Important log markers
---------------------
[AER V65][MinimapScale]
[AER V65][GPSMaskRefresh] BEFORE
[AER V65][GPSMaskRefresh] AFTER
[AER V65][MaskState]
[AER V65][MinimapMotion] PlayerMiniMap/MiniMap sibling
[AER V65][HudFrustum]
