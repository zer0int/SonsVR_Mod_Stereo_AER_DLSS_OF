from pathlib import Path
root=Path(__file__).resolve().parent
vr=(root/'mod'/'VRPlayer.cs').read_text(encoding='utf-8-sig')
mod=(root/'mod'/'SonsVRMod.cs').read_text(encoding='utf-8-sig')
checks={
 'v108 banner':'[SonsVR V108]' in mod,
 'loading update wired':'UpdatePreGameplayLoadingOverlayV108();' in vr,
 'loading root layer5':'_preGameplayLoadingOverlayV108.layer = 5' in vr,
 'loading main layer5':'mainGo.layer = 5' in vr,
 'loading sub layer5':'subGo.layer = 5' in vr,
 'loading no black fullscreen':'SonsVR_V108_LoadingOverlay' in vr and 'Background' not in vr[vr.find('SonsVR_V108_LoadingOverlay'):vr.find('private Camera _nativeTrashConfiguredCameraV107')],
 'loading spinner':'PreGameplayLoadingSpinnerFramesV108' in vr,
 'loading reassurance':'GAME IS STILL LOADING - PLEASE WAIT' in vr,
 'page refresh wired':'MaybeRefreshGrabBagItemsAfterPageChangeV108(activeItems);' in vr,
 'page transition guard':'activeItems != 0 || previous <= 0' in vr,
 'event global item search':'TryGlobalGrabBagItemCacheRefreshV108' in vr,
 'page discoveries persist':'_grabBagItemsGlobalFallbackV107.Add(c)' in vr,
 'probe session reset':'_itemPageGlobalProbesThisSessionV108 = 0;' in vr,
 'per-frame path still cached':'foreach (var item in _grabBagItemsCacheV107)' in vr,
 'v107 depth/loading retained':'UpdatePreGameplayEyeRenderSuppressionV107();' in vr,
}
for k,v in checks.items(): print(f"[{'PASS' if v else 'FAIL'}] {k}")
failed=[k for k,v in checks.items() if not v]
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
raise SystemExit(1 if failed else 0)
