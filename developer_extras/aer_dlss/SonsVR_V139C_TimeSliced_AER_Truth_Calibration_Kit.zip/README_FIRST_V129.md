# SonsVR V129 — live 2E DLSS input-lattice probe (passive)

**Base:** V128 successful native game-menu 2E DLSS receiver router, with V116
renderer, HUD, native interactions, depth guard, NVOFA, and AER unchanged.

**Goal:** Determine whether the real HDRP per-eye render input dimensions differ
between game-menu Quality and Ultra Performance, independent of uncontrolled
GPU timing (NPCs, wildlife, view changes, water, etc.).

## Build

1. Back up the working V128 DLL.
2. Run `BUILD_V129.bat` from the unpacked directory. As before, Unity 2022.2.16f1
   must be available (edit `UNITY_EXE` if necessary); the BAT builds the shader
   bundle, native OF bridge, and the C# mod and assembles `OUTPUT`.
3. Copy DLLs from `OUTPUT` into the game's `Mods` folder, as in V128.

**No additional HMD action synchronization is required.** The logging identifies
menu transitions automatically and captures live per-eye HDRP frame state using
existing Unity `beginCameraRendering`/`endCameraRendering` callbacks. Do not
stick anything in the proximity sensor for this experiment unless you want to;
we're not using uncontrolled GPU time as the primary endpoint.

## Minimal test

- Enter actual gameplay in **2E** (switch if the last-saved mode was AER).
- Ideally look at the same waterfall/cattails/forest scene as V128.
- From the **game's graphics menu**: select Quality, return to gameplay and allow
  ~8 seconds; select Ultra Performance and allow ~8 seconds; select DLSS Off
  and allow ~8 seconds; return to Quality for ~8 seconds. It is fine if each
  setting takes longer; exact switch timing isn't necessary.
- Stop there. AER is NOT a quality-sweep target in this build; nothing writes
  AER quality/resolution.
- Exit normally, then run `PACK_V129_TRACE.bat` and return `V129_TRACE_RETURN.zip`.

## New evidence in the trace

`Mods/SonsVR_V129_DLSS_Live_YYYYMMDD_HHMMSS.tsv`:

- `MENU_TRANSITION`: manager selection changed (automatic alignment)
- `EYE_BEGIN` and `EYE_END`: render-callback synchronized left/right camera
  `HDCamera.actualWidth/actualHeight` and full target dimensions
- camera flags, QCode, custom attributes, optimal settings, active/input fraction
- live `DynamicResolutionHandler` resolved scale, filter, viewport, camera
  request, dynamic resolution enabled, software/hardware modes and scaled size
- cached HDRP asset global DRS/DLSS policy and ScalableBufferManager scale
- dense sampling at up to 4Hz **only during the first 4 seconds after a menu
  transition**, then sparse ~0.67Hz; no GPU copies, readbacks, scene searches,
  custom passes, or timer-triggered renderer mutation

The retained V128 transition log now additionally receives an **advisory**
NVIDIA `GetOptimalSettings` query 1.5 seconds after each menu transition in live
2E gameplay. This query is NOT proof of which resolution DLSS actually rendered.
Use the per-eye HDCamera snapshots for that.

## Interpretation

- If `qCode` changes but `hdActual`, `drsResolvedScale`, and `drsLastScaledSize`
  stay fixed, the quality-selection routing is working but the effective render
  lattice isn't. Study HDRP asset/handler optimal-resolution policy next.
- If the handler scale changes but `hdActual` doesn't, investigate when the
  per-camera HDRP request is accepted; begin/end snapshots can localize this.
- If `hdActual` changes by preset but you still don't perceive a difference,
  analyze the downstream color/resolve source and actual NVIDIA feature execution.
- If only GPU time changes with no input-resolution change, it's NOT evidence
  that quality-dependent scaling works.

**No forced optimal-settings A/B yet.** Altering attributes before the passive
measurements would introduce a new variable. If the trace confirms fixed
50% at both extremes, the subsequent 2E-only opt-in A/B can change exactly
one policy at a time. V128 remains the fallback stable baseline.

## Build status and safety

This is a complete **source** kit. Static V116/V128 safety audits and file hash
checks run in `BUILD_V129.bat`; game-specific Windows C# compilation and HMD
execution cannot be performed in this environment. Do not use AER to measure
quality-dependent resolution until the reconstruction lattice is validated.

