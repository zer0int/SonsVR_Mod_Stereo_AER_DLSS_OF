SonsVR V113 — NATIVE 2D HUD -> OPENVR COMPOSITOR PLANE
======================================================

WHY
---
The returned native-HUD archaeology proved the pancake HUD already has a clean 2D contract:
  GPS ScreenMask                         bottom-right (-162, 153)
  GPS VitalsBackingCircle                bottom-right (-162, 152.1)
  PlayerVitalUiRenderTextureGroup        bottom-right (-162, 152)

They are aligned because independent native screen-space canvases use essentially the same
pixel anchor. The VR mod had been converting those canvases independently to WorldSpace and
then trying to reconstruct the relationship in metres.

V113 changes the architecture instead of tuning another offset.

PATH
----
  native SOTF 2D HUD canvases
        -> ScreenSpaceCamera (anchors/layout/masks/CanvasScaler retained)
        -> transparent 1920x1080 RenderTexture
        -> OpenVR compositor overlay
        -> finite HMD-relative plane

The physically-held GPS is a different, genuine WorldSpace item and is NOT touched.

FINITE PLANE / DISTANCE COMPENSATION
------------------------------------
The compositor plane is 1.20 m from the HMD, not at the eye/null plane.
Its width is derived from angular size:

  width = 2 * distance * tan(horizontalFOV / 2)

With distance=1.20 m and horizontalFOV=90 deg, width=2.40 m and 16:9 height=1.35 m.
Thus moving the plane away does not shrink it perceptually; physical plane size grows with distance.

The native HUD row around y=153/1080 is globally lifted to viewport y=0.50 by moving the WHOLE
plane. No map/ring/message child is independently re-positioned.

OTHER V113 CHANGES
------------------
- Fixes V112's stuck +0.30m eye-height problem: BlankScene no longer keeps title/loading lift
  after the proven gameplay-ready gate becomes true.
- FPS overlay horizontal normalized center moves 0.82 -> 0.66, exactly halfway toward center 0.50.
  Vertical coordinate remains 0.84.
- V112 AER / 2E gameplay selector and actual-backend mode readout remain.
- V103/V104 permanent depth guard, DLSS/NVOFA, V107/V108 loading/cooking fixes remain.
- All old HUD depth catcher/proxy/dense-remap experiments remain hard-off.

FIRST TEST
----------
1. Build with BUILD_V113.bat.
2. In gameplay, verify normal body/head height is restored.
3. Check native HUD as ONE sheet:
   - map centered with status ring
   - map/status and messages retain their native relative row/edge relationship
   - walking/strafe/jump cannot move HUD relative to HMD
   - no HUD AER shimmer/jitter
4. Check physically-held GPS still behaves as an ordinary 3D object.
5. Check FPS panel is still high but moved inward horizontally.
6. If HUD is blank, upside down, duplicated, or wrong scale/orientation, exit and run PACK_V113_TRACE.bat.

IMPORTANT
---------
This is the first compositor-HUD prototype. The architecture is evidence-driven, but headset behavior
is authoritative. Do not tune individual map/ring X/Y/Z values if something is wrong: report the
whole-sheet symptom so the compositor/capture contract can be corrected at the correct layer.
