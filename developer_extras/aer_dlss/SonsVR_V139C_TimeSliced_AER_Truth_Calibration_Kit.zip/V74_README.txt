SONSVR V74 - EXACT COMPILED HUD DEPTH MESHES
============================================

WHY V73 LOOKED EXACTLY LIKE V72
-------------------------------
The V73 runtime log proved:
  Il2CppAssetBundleManager.LoadFromMemory returned null (63100 bytes)
  mode=V72-ANALYTIC-FALLBACK

So V73 never used the user's baked mesh geometry.

It also still inherited V68's obsolete 15-second full-stereo causality window.

V74 FIXES BOTH.
---------------
1. NO secondary HUD AssetBundle exists anymore.
2. The user's Unity-baked canonical mesh triangles are compiled directly into
   SonsVR_Mod.dll as ordinary runtime Mesh data.
3. The 15-second V68 A/B control delay is removed.
4. Dense planar HUD remap is STILL OFF. This remains a geometry-only test.

COMPILED PROXIES
----------------
disc: 32 vertices, 58 triangles
ring: 252 vertices, 263 triangles
rect: 4 vertices, 4 triangles

The baker's duplicate front/back vertices and collapsed side-wall triangles were
removed offline; the exact front silhouette is preserved.

PLACEMENT
---------
The user's canonical disc radius = 0.01.
The user's canonical ring MAIN-circle radius = 0.01.

Therefore both disc and ring use the exact SAME projected GPS ScreenMask
center/diameter. The ring's authored origin is the map center; its appendage
bulbs extend outward naturally.

Message text still uses the compact active-Graphic union rectangle when present.

ACTIVATION
----------
No 15-second experimental wait anymore.

After the gameplay HDRP gate succeeds:
  EOF-safe AER activation
  -> normal existing 4-frame warmup
  -> alternating AER

BUILD
-----
  BUILD_V74.bat

Install only:
  OUTPUT\SonsVR_Mod.dll

VALIDITY LOGS
-------------
You should see:
  [AER V74][Activation] ... 15-second ... REMOVED
  [AER V74][HudDepthMesh] COMPILED exact meshes READY
  [AER V74][HudDepthMesh] APPLIED eye=L ... mode=EXACT-COMPILED-MESH
  [AER V74][HudDepthMesh] APPLIED eye=R ... mode=EXACT-COMPILED-MESH
  [AER V51][DepthWarp] SYNTHETIC OPPOSITE EYE IS NOW IN THE HEADSET PATH

You should NOT see:
  LoadFromMemory returned null
  mode=V72-ANALYTIC-FALLBACK
  FULL-STEREO ... CONTROL WINDOW START

WHAT THIS TEST ANSWERS
----------------------
Only whether exact proxy silhouettes materially improve the V72 result.

If the exact disc/ring/rect are correctly placed but near-field HUD pixels still
become sparse/fallback lasagna, THEN the next justified change is the dense
planar HUD remap after V51.
