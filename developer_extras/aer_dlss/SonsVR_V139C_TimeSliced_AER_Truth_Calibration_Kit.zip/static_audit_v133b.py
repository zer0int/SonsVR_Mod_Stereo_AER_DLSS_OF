#!/usr/bin/env python3
"""V133B isolation audit: confirm V133 baseline and the typed HDRP accessor fix."""
from pathlib import Path
import subprocess,sys
p=Path(__file__).resolve().parent
r=subprocess.run([sys.executable,str(p/'static_audit_v133.py')],cwd=p,text=True)
if r.returncode:raise SystemExit(r.returncode)
s=(p/'mod/NativeDlssFeatureStateV133.cs').read_text(encoding='utf8')
checks={
 'base pipeline TryCast<HDRenderPipeline>':'basePipeline.TryCast<HDRenderPipeline>()' in s,
 'IL2CPP runtime extension imported':'using Il2CppInterop.Runtime;' in s,
 'typed HDRP DLSSPass getter':'pipeline.m_DLSSPass;' in s,
 'typed HDRP enabled getter':'pipeline.m_DLSSPassEnabled;' in s,
 'base wrapper no longer reflected':'Read(pipeline, "m_DLSSPass")' not in s,
 'camera-state key enumeration limited':'i < 16' in s and 'CAMERA_STATE_KEYS' in s,
 'read-only probe':all(v not in s for v in ['SetDynamicResScaler(', 'SetSystemDynamicResScaler(', 'CreateFeature(', 'ExecuteDLSS(', 'DestroyFeature(', 'ScaleFn(', '.m_DLSSPass =', '.m_DLSSPassEnabled =']),
}
for k,v in checks.items():print(('[PASS]' if v else '[FAIL]')+' '+k)
print('V133B static audit:',sum(checks.values()),'/',len(checks))
raise SystemExit(0 if all(checks.values()) else 2)
