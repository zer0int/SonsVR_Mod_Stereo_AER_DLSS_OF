V50 build resource staging directory.
BUILD_V50.bat compiles shader_project/Assets/DepthStereoWarp.shader with Unity 2022.2.16f1,
then copies the resulting sonsVR_depththingy AssetBundle here as Resources\sonsvr_depththingy.
SonsVR_Mod.csproj embeds that exact file into SonsVR_Mod.dll as:
  SonsVRMod.Resources.sonsvr_depththingy
The bundle itself does NOT need to be copied beside the game DLL.
