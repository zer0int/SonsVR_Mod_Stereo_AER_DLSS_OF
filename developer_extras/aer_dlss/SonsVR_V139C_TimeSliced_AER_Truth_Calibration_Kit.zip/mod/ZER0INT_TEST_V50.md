# ZER0INT TEST V50 — camera-local depth latch

- Base: V49-R100, 1.0 render scale, 512x512 warp, confidence/fill/composite unchanged.
- New SRP hook: `RenderPipelineManager.endCameraRendering`.
- Only `VRLeftEye` / `VRRightEye` callbacks are accepted.
- Immediately copies packed HDRP mip-0 raw depth into an owned full-resolution `RFloat` RT using shader pass 4.
- Snapshots source projection inverse, cameraToWorld, `_ZBufferParams`, `_RTHandleScale`, `_ScreenSize`, source camera/RT ids, dimensions, and `Time.frameCount`.
- EOF synthesis accepts only exact camera+eye+target+dimensions and, by default, exact-frame latch.
- EOF headset warp no longer samples global `_CameraDepthTexture` at all.
- Missing/mismatched latch => V36 fallback for that frame.
