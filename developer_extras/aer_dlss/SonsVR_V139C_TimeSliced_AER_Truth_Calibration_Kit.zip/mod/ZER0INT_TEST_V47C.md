# ZER0INT TEST V47C

Compile-only correction to V47B.

The Il2CppInterop generated conversion from managed `byte[]` to `Il2CppStructArray<byte>` is an implicit conversion operator. C# forbids calling that operator/accessor explicitly (`CS0571`), so V47C changes only the conversion expression:

```csharp
Il2CppStructArray<byte> il2cppBundleData = bundleData;
```

This invokes the same implicit operator automatically. The V47B IL2CPP AssetBundle bridge, embedded THINGY bytes, shader board, AER path, depth tap, and OpenVR submission are otherwise unchanged.

Expected runtime success marker:

`[StereoRender][AER V47C][DepthShader] THINGY loaded through MelonLoader IL2CPP bridge ... Desktop-only depth board READY.`
