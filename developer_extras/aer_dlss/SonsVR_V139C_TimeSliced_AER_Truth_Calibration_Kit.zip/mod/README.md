# Sons of the Forest VR Mod (Unofficial) — Community Fork

> **Bring full VR support to *Sons of the Forest* using SteamVR and OpenVR — without official VR mode.**

This is a fork of [iPowerTech/SonsVR_Mod](https://github.com/iPowerTech/SonsVR_Mod), containing a large number of bug fixes and new features layered on top of the original. See **[CHANGELOG.md](CHANGELOG.md)** for the full list of what's changed. All credit for the original mod and its architecture goes to the upstream author (see Credits below) — this fork exists to share additional fixes and improvements built on top of that foundation, under the same license.

This mod injects a complete VR pipeline into *Sons of the Forest* (PC version), enabling immersive gameplay using **Valve Index**, **HTC Vive**, **Meta Quest (via Air Link/Virtual Desktop)**, and other **OpenVR-compatible headsets**.

Built with **MelonLoader**, **Il2CppInterop**, and **SteamVR Plugin**, it renders the game in stereo VR while supporting both a native Xbox/gamepad controller and the original VR-motion-controller gesture input.

---

## 🆕 What's Different in This Fork

- **Gamepad-first input**: this fork adds a `GamepadOnlyMode` (on by default) that lets a physical Xbox controller drive the game directly, using the game's own native controller support, instead of the original's VR-gesture-to-keyboard emulation. The original gesture/keyboard-emulation system (documented below) is still present and can be restored by setting `GamepadOnlyMode = false` in `VRPlayer.cs`.
- A large number of stability, camera-tracking, HUD, and vehicle fixes — see **[CHANGELOG.md](CHANGELOG.md)** for the complete list.

---

## ✅ Current Features

- **Full Stereo Rendering**  
  Custom left/right eye cameras with OpenVR projection matrices, dynamic resolution scaling, and native texture submission to the compositor.

- **Gamepad-first controls** *(default, and the primary supported way to play this fork)*  
  Plug in a physical Xbox controller and it drives the game directly through Sons Of The Forest's own native controller support — including smooth turning with the right stick, replacing the original mod's snap-turning.

- **Legacy VR-gesture mode** *(inactive by default; the underlying code is still present in this fork and can be restored by setting `GamepadOnlyMode = false` in `VRPlayer.cs`, though it hasn't been re-tested alongside this fork's other changes)*
    - Locomotion via left thumbstick, snap turning via right thumbstick, and gesture-based actions (jump, melee, interact, inventory, crouch) mapped to synthetic keyboard/mouse input — see the [original mod's documentation](https://github.com/iPowerTech/SonsVR_Mod) for the full gesture/key mapping.

- **Automatic Camera & Player Detection**  
  Dynamically finds the game’s `MainCameraFP` and `LocalPlayer` across scenes (main world, caves, interiors).

- **Compatibility**  
  Works with existing Sons of the Forest mods and saves. No modification of game files required.

---

## ⚙️ Requirements

- **Game**: *Sons of the Forest* (Steam, PC version)
- **VR Headset**: Any **OpenVR-compatible** device (Index, Vive, Quest via SteamVR, etc.)
- **Mod Loader**: [MelonLoader](https://melonwiki.xyz/) (latest stable release recommended)
- **Runtime**: .NET 6+ 

---

## 📥 Installation

1. Install **MelonLoader** into your *Sons of the Forest* folder.
2. Copy all files and folders into the root of the game folder.
3. Launch the game in **VR mode** (via SteamVR).

> 💡 **Note**: The game must be launched **through SteamVR**. Do not use desktop mode.

---

## 🎛️ Recommended Game Settings

For the best experience with this mod, apply these settings in the game's own options menu before playing:

**Headset Connection**
- **Use Virtual Desktop over Quest Link/Air Link** if your headset supports it — noticeably better visual quality for this mod's VR rendering pipeline.

**Display**
- **Fullscreen** selected (rather than windowed)
- **VSync**: Disabled

**Graphics**
- **Dynamic Resolution**: DLSS
- **Motion Blur**: Off
- **Chromatic Aberration**: Off
- **Film Grain**: Off

**Gameplay**
- **FOV**: 95 (max) — important for seeing UI items clearly and for cursor precision

---

## ⚠️ Known Limitations

- **Some menus still not in VR space**: most menus (title screen, Options, multiplayer lobby, pause) are now rendered properly in world-space VR in this fork, but modal popup windows (the quit/save confirmation dialog, and the crafting-mat "add items to the mat" tutorial) still only appear on the flat desktop mirror — see [CHANGELOG.md](CHANGELOG.md) for details.
- **Cutscenes & Vehicles**: Golf cart and hang glider camera tracking/free-look significantly improved in this fork — see [CHANGELOG.md](CHANGELOG.md). Cutscenes specifically may still break immersion or camera tracking (not addressed in this fork).
- **Performance**: Render resolution is high by default; may require supersampling adjustment in SteamVR.

---

## 🙌 Credits

- **Original Mod Author**: Antonio Mauriello (`Anthony`) — [iPowerTech/SonsVR_Mod](https://github.com/iPowerTech/SonsVR_Mod)
- **Based on**: MelonLoader, Il2CppInterop, SteamVR Unity Plugin
- **Special Thanks**: MelonLoader & Sons of the Forest modding communities
- **This Fork**: additional fixes and features — see [CHANGELOG.md](CHANGELOG.md)

---

## 📜 License

Copyright (C) 2025 Antonio Mauriello

This program is free software: you can redistribute it and/or modify  
it under the terms of the **GNU General Public License as published by**  
the Free Software Foundation, **version 2** of the License.

This program is distributed in the hope that it will be useful,  
but WITHOUT ANY WARRANTY; without even the implied warranty of  
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
GNU General Public License for more details.

You should have received a copy of the GNU General Public License  
along with this program.  If not, see <https://www.gnu.org/licenses/gpl-2.0.html>.

*Sons of the Forest* is a trademark of Endnight Games Ltd.  
This mod is **not affiliated** with Endnight Games, Steam, or Valve Corporation.
---

> 🌐 **Enjoy VR survival horror — now in full immersion!**  
> *"The forest remembers..." — now in stereo 3D.*