## v0.6.1 — Menus, Multiplayer, and Tarp Tutorial Fixes

This release finally cracks the mystery behind Save/Quit and the crafting-mat tutorial never rendering in VR, fixes the automated FPS trick to work reliably in multiplayer, and adds several tarp/tutorial refinements based on real playtesting.

### 🖥️ Menus You Can Finally See in VR

- **Save/Quit confirmation dialog** and the **crafting-mat "Add items to the mat..." tutorial** now both render correctly in VR. Both were previously invisible — visible only on the flat desktop mirror — because each draws through its own separate, never-before-touched canvas, entirely distinct from the main UI canvas this mod already converts to world-space elsewhere.
- Along the way, found and fixed a real, unrelated performance cost: the search for these canvases was doing a full-scene object scan on every single poll, forever, even long after the target had already been found — and both canvases were also being needlessly reconverted every time the game's active camera changed for any reason (including the tarp simply opening and closing). Both are now essentially free once found.

### 🎮 Multiplayer

- The automated pause-menu FPS fix (a workaround for a GPU-underutilization/low-FPS issue that's only ever been reliably fixed by a real menu open/close) previously worked reliably in single-player but could loop indefinitely in multiplayer, repeatedly reopening the menu — including menus the player had opened themselves. Root cause: the fix's "did it open" check relied on `Time.timeScale` dropping to 0, which never happens in multiplayer since the shared world can't pause for other connected players.
- Fixed with a more robust approach: `Time.timeScale` remains the trusted primary signal for single-player. For multiplayer, rather than trying to infer the menu's state from an unreliable signal, the fix now directly watches for the player's own genuine button press and hands off immediately the moment it sees one — letting the player take over cleanly at any point instead of fighting them.

### 🎨 Crafting-Mat Tutorial (Tarp)

- Reduced the tutorial's background flashing/flickering — it was being continuously repositioned to follow head movement every half-second, which produced a visible flash as a large panel snapped to a new position. Now placed once, at a fixed spot near the tarp, and left alone. This greatly reduced how often it happens, but it can still occasionally occur — dismissing the tutorial message ("E: OK") reliably clears it if so.
- Added a solid dark background panel behind the tutorial text (matching a flat-screen-only blur effect that never rendered in VR), making the white text much easier to read against the busy tarp contents behind it. Dynamically shows and repositions itself to match whichever of the tutorial's two popups is currently active.
- Added an optional one-time play-space recenter when the tarp opens, for cases where the VR camera had drifted out of alignment with the character's own body.

### 📥 Installation

1. Install [MelonLoader](https://melonwiki.xyz/) into your Sons Of The Forest folder.
2. Extract this release's contents into your Sons Of The Forest game folder, merging with the existing `Mods` and `UserLibs` folders.
3. Launch the game through SteamVR.

### 🎛️ Recommended Game Settings

For the best experience, apply these settings in the game's own options menu:

**Headset Connection**
- Use Virtual Desktop over Quest Link/Air Link if your headset supports it — noticeably better visual quality for this mod's VR rendering pipeline.

**Display**
- Fullscreen selected (rather than windowed)
- VSync: Disabled

**Graphics**
- Dynamic Resolution: DLSS
- Motion Blur: Off
- Chromatic Aberration: Off
- Film Grain: Off

**Gameplay**
- FOV: 95 (max) — important for seeing UI items clearly and for cursor precision

### ⚠️ Known Issues

- Tarp tutorial's black background can still occasionally flash, even after this release's fix greatly reduced how often it happens — dismissing the tutorial message ("E: OK") reliably clears it if so.

- Low frame rate during a **new game's** intro cutscenes specifically — the automated FPS fix can't take effect until real gameplay begins, since the game itself ignores pause input for most of the intro. Clears up as soon as the intro finishes; not an issue on subsequent loads/continues.
- Native loading screen (shown after picking a save or starting a new game) still doesn't render in VR — set aside for now, with a custom placeholder shown in the meantime. See `CHANGELOG.md` for the real leads worth following up on.
- Interaction-prompt icons can still overlap at beds and tents.
- The vitals status ring and toast-style notifications (e.g. "You are hungry") can still be occluded by held items.

Full details on every change, including the investigation trails behind each fix: see [CHANGELOG.md](CHANGELOG.md).
