# V47D — rebuilt AssetBundle THINGY

V47C proved that the IL2CPP bridge reaches Unity's native AssetBundle loader, but Unity rejected the original embedded bundle as incompatible. `Editor.log` revealed the secretary project's `AssetBundle` module had been disabled by the intentionally-minimal package manifest, while the build script still emitted a small output and incorrectly reported success.

V47D changes only the embedded shader bundle and test/log labels. The replacement bundle was rebuilt in the exact Unity 2022.2.16f1 editor after enabling `com.unity.modules.assetbundle`.

Replacement embedded resource:
- `Resources/sonsvr_depththingy`
- bytes: 6720
- SHA-256: `72619223df62c313cdc67b3a8a6e792e020a29ae706969415b09c4e1b7bd3dcf`
- UnityFS engine string: `2022.2.16f1`

No headset texture, AER scheduling, OpenVR submission, V36 reprojection, V44 telemetry, or V46 depth-tap logic is intentionally changed.
