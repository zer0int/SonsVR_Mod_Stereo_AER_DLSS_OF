## v0.5.0 — Visual Quality & Performance Update

This release focuses on making the game actually look and run better in VR — fixing missing anti-aliasing, getting DLSS genuinely working on the VR eye cameras (it wasn't before, despite the in-game setting being on), and adding real render-resolution scaling for meaningful FPS gains.

### 🖼️ Fixed: Missing Anti-Aliasing on VR Eye Cameras

Sons Of The Forest uses HDRP, which handles anti-aliasing through a different mechanism than the setting this mod's cameras were previously using — meaning the VR eye cameras have likely never had real anti-aliasing since this mod was written. This showed up as graininess, especially in the game's dense foliage. Temporal Anti-Aliasing is now properly enabled on both eyes, producing a visibly sharper image.

### ⚡ Fixed: DLSS Wasn't Actually Reaching the VR Cameras

The game's own in-game "Dynamic Resolution: DLSS" setting only ever configured the game's native (non-VR) camera. DLSS eligibility is a per-camera setting in HDRP, and the separate stereo eye cameras this mod creates for VR rendering were never explicitly opted in — so DLSS was very likely never active for what you actually see in the headset, regardless of your in-game setting. Now explicitly enabled on both eyes.

### 🚀 New: Genuine Render-Resolution Scaling

Both eyes now render at 80% of SteamVR's recommended resolution by default — actual fewer pixels shaded per frame, not just a permission flag — with OpenVR's compositor handling the upscale to your headset's native display, the same way the built-in resolution slider works in any SteamVR game. This is safe on any GPU brand. Combined with the two fixes above, this produced a real, measurable FPS improvement in testing (one case: roughly 27 → 42 fps) while keeping visual quality solid.

### 📥 Installation

1. Install [MelonLoader](https://melonwiki.xyz/) into your Sons Of The Forest folder.
2. Extract this release's contents into your Sons Of The Forest game folder, merging with the existing `Mods` and `UserLibs` folders.
3. Launch the game through SteamVR.

### 🎛️ Recommended Game Settings

For the best experience, apply these settings in the game's own options menu:

**Headset Connection**
- **Use Virtual Desktop over Quest Link/Air Link** if your headset supports it — noticeably better visual quality for this mod's VR rendering pipeline.

**Display**
- Fullscreen selected (rather than windowed)
- VSync: Disabled

**Graphics**
- Dynamic Resolution: DLSS
- Motion Blur: Off
- Chromatic Aberration: Off
- Film Grain: Off

**Gameplay**
- FOV: 95 (max) — important for seeing UI items clearly and for cursor precision

### ⚠️ Known Issues

- Modal-style popup windows (the Quit/Save confirmation dialog, and the crafting-mat "add items to the mat" tutorial) don't render in VR — visible on the flat desktop mirror only.
- Low frame rate during a NEW GAME's intro cutscenes specifically — clears up once the intro finishes and real gameplay starts.
- Interaction-prompt icons can still overlap at beds and tents.
- The vitals status ring and toast-style notifications (e.g. "You are hungry") can still be occluded by held items.

Full details on every change: see [CHANGELOG.md](CHANGELOG.md).
