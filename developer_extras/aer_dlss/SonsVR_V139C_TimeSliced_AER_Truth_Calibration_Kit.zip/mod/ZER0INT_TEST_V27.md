# ZER0INT TEST V27

Based directly on confirmed-good V25.

## Change
- While `InventoryCamera` / ground-tarp inventory is active, set `Renderer.forceRenderingOff=true` on every `SkinnedMeshRenderer` under `LocalPlayer`.
- Cache and restore each renderer's previous `forceRenderingOff` value on tarp close / VRPlayer disable / destroy.
- Re-scan every 0.5 s while the tarp is open to catch newly instantiated skinned clothing/body renderers.
- Do **not** disable GameObjects, Animators, colliders, CharacterController, crafting logic, or `Renderer.enabled`. The avatar should therefore keep doing all native crafting/equip animations while simply not being rendered.
- With the body invisible, suppress the old extra `TarpHeadExtraYOffsetMeters=0.55` while tarp mode is active. The proven `TarpElevationWorkaroundOffset=1.0` terrain-clearance lift remains unchanged.
- Horizontal tarp recenter remains 0.55 m and exact pre-tarp Origin restoration remains unchanged.

## Expected
- No torso/knees/hands/clothes blocking the lower inventory rows.
- Selection cursor remains visible because `SoftwareCursor` lives under `PlayerStandin/PlayerUI`, not `LocalPlayer`.
- Crafting/equip animations continue invisibly.
- Head is 0.55 m lower than V25 during tarp mode, reducing the indoor ceiling/selection-sphere problem.

Build:

```bat
build_test.bat test_v27_tarp_invisible_player
```
