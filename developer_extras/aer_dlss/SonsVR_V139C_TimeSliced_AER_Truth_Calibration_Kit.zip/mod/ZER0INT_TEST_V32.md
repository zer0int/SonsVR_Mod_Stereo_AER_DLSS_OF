# ZER0INT TEST V32

Based on V31/V28. V31 showed no perceived FPS change from hiding `InventoryFoodBoard`, so V32 restores it by default.

For the ground inventory, V27's broad `SkinnedMeshRenderer` suppression is still used for the player body/clothing and unrelated skinned renderers, but the entire existing `LocalPlayer/InventorySystem/Visuals/InventoryWrap/` subtree is exempted from *our* `forceRenderingOff` writes.

Important: V32 does **not** activate or enable any inventory child. Whatever Sons has inactive stays inactive; whatever Sons normally renders in its active inventory-wrap visual rig stays rendered. This restores the tarp/support rig without turning on the inactive duplicate crafting tree.

Purpose: cleanly test whether V27's speedup came from hiding the player versus hiding the active inventory-wrap support rig.

No V29/V30 census/timing/camera diagnostic spam is present.

Build with:

```bat
build_test.bat test_v32_tarp_surface_restore
```
