# ZER0INT TEST V43 — DEFERRED GAMEPLAY AER

Purpose: separate the fatal title/loading AER failure from the actual in-game AER visual problem.

Lineage: V40C (the proven perfect/static full-stereo control), itself derived directly from audited V38B.

## Behavior

- Startup/title/loading: AER **OFF**. Both HDRP eye cameras render every Unity frame and the conventional Melon `OnLateUpdate` `Submit_Default` path is used exactly as in V40C.
- Eye-camera diagnostic policy remains V40C/V37: AA=None, DLSS=OFF, dynamic resolution=OFF.
- Gameplay gate arms only when all three are true: scene `SonsMain`, camera `MainCameraFP`, and `LocalPlayer` was found.
- AER still does not switch immediately. `StereoRender.CopyHdrpDataFromNativeCamera()` must successfully copy the real `MainCameraFP` HDRP data first.
- After that success, activation is scheduled for **after the current frame's WaitForEndOfFrame**. The activation frame remains ordinary full stereo, avoiding a callback-order-dependent double/missing submit.
- The following Unity frame enters the unchanged V38B AER machinery: warmup, one HDRP eye per frame, same-frame EOF commit, 0f/1f ages, `Submit_Default`, V36 rotational stale-eye reprojection.
- The switch is one-way for this process. No tarp/input/runtime toggle exists.

## Expected markers

1. `[ZER0INT TEST V43 DEFERRED GAMEPLAY AER]`
2. Startup setup should say `AER=OFF rotational-reprojection=OFF`.
3. On actual gameplay entry: `[VRPlayer][AER V43] gameplay gate ARMED...`
4. Successful HDRP copy then: `[StereoRender][AER V43] ... scheduling ONE-WAY AER activation after this frame's EOF...`
5. At EOF: `[StereoRender][AER V43] ACTIVATED after EOF...`
6. Next frame V38B should log its normal resync/warmup and later 0f/1f EOF samples.

If the game crashes before markers 3–5, the failure is not caused by active AER in this build. If it passes loading and only becomes visually bad after marker 5, title/loading instability and gameplay AER reconstruction are cleanly separated.
