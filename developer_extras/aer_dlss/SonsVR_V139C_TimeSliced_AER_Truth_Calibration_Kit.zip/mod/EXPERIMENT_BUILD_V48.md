# V48 build

Use the top-level `BUILD_V48.bat` from the V48 kit. It:

1. invokes Unity 2022.2.16f1 in batch mode,
2. builds `sonsvr_depththingy` containing `Hidden/SonsVR/DepthStereoWarp`,
3. copies that bundle into `mod/Resources/sonsvr_depththingy`,
4. runs the normal `dotnet build` via `build_named.bat`, and
5. copies the resulting DLL to `OUTPUT/SonsVR_Mod.dll`.

V48 must not be built with the old V47D bundle.
