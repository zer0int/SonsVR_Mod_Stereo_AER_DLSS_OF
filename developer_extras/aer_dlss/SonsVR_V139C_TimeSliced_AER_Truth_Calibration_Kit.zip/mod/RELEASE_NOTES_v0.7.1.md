## v0.7.1 — Item Info Panel Readability

A small, focused update on top of v0.7.0: the item info/tooltip panel (durability, water level, weapon strength, etc.) is now easier to read against busy backgrounds and sits more naturally in view.

### 🎯 Item Info Panel

- **Added a solid dark background panel** behind the item info popup — the busy tarp/inventory contents behind it could make the white text hard to read.
- **Positioning now follows your full look direction**, including up/down pitch, not just left/right — so it stays properly in view when looking down at a ground tarp instead of only tracking where you're facing horizontally.
- **Added a slight backward tilt** so the panel doesn't sit bolt upright against a downward gaze, which previously made it read at close to a 90-degree mismatch when looking down at something on the ground.

No other functional changes since v0.7.0 — see [CHANGELOG.md](CHANGELOG.md) for full details, including notes on an extensive but ultimately inconclusive investigation into action-prompt visibility in VR (documented there under Known Issues for anyone picking that up later).

### 📥 Installation

1. Install [MelonLoader](https://melonwiki.xyz/) into your Sons Of The Forest folder.
2. Extract this release's contents into your Sons Of The Forest game folder, merging with the existing `Mods` and `UserLibs` folders.
3. Launch the game through SteamVR.

### 🎛️ Recommended Game Settings

For the best experience, apply these settings in the game's own options menu:

**Headset Connection**
- Use Virtual Desktop over Quest Link/Air Link if your headset supports it — noticeably better visual quality for this mod's VR rendering pipeline.

**Display**
- Fullscreen selected (rather than windowed)
- VSync: Disabled

**Graphics**
- Dynamic Resolution: DLSS setting has no effect on the VR view either way — leave at whatever default, it doesn't matter for VR
- Motion Blur: Off
- Chromatic Aberration: Off
- Film Grain: Off

**Gameplay**
- FOV: 95 (max) — important for seeing UI items clearly and for cursor precision

### ⚠️ Known Issues

- **Action-prompt icons (e.g. "A to pick up", "X to dismantle") don't show reliably in VR**, though the interaction itself always still works. See `CHANGELOG.md` for the full investigation trail if picking this back up.
- Tarp tutorial's black background can still occasionally flash — dismissing the tutorial message ("E: OK") reliably clears it if so.
- Low frame rate during a **new game's** intro cutscenes specifically — clears up as soon as the intro finishes; not an issue on subsequent loads/continues.
- Native loading screen (shown after picking a save or starting a new game) still doesn't render in VR — a custom placeholder is shown in the meantime.
- The vitals status ring and toast-style notifications (e.g. "You are hungry") can still be occluded by held items.

Full details on every change: see [CHANGELOG.md](CHANGELOG.md).
