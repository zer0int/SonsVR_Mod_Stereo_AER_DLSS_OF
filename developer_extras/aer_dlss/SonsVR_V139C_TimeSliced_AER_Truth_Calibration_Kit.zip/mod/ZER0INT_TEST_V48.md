# ZER0INT TEST V48 — GPU same-time depth stereo warp

V48 is the first build that replaces the retained stale eye during steady-state AER.

On each normal one-eye frame:

1. HDRP renders one fresh real eye exactly as V43/V38B already schedule it.
2. At EOF, V48 reads `_CameraDepthTexture` mip 0 by integer source pixel coordinates. HDRP's packed depth-pyramid mip 0 begins at atlas offset `(0,0)`.
3. The GPU reconstructs source camera-space XYZ with the inverse GPU projection matrix.
4. XYZ is transformed source-camera -> world -> current opposite-eye camera, then projected into the opposite eye.
5. A 256x256 source grid is forward-rasterized into a full-resolution synthetic opposite-eye RT with a depth buffer.
6. A same-time source-eye copy sits behind the warp as a conservative fill for small disocclusion holes. Fragment-stage depth-consistency rejection suppresses triangles stretched across strong depth discontinuities.
7. OpenVR receives the real fresh source eye plus the synthetic same-time opposite eye. If V48 fails on any frame, the old V36 stale-eye rotational reprojection remains the fallback.

The desktop mirror becomes a 2x2 board: real source / synthetic target / depth mip0 / old retained target (comparison only).
