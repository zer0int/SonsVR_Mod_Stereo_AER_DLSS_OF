# ZER0INT TEST V25

Based directly on the confirmed-working V24 build.

## Kept unchanged
- V24 campfire gaze supports both `GrabBagLayoutItem` ingredients and the native `CookingCog`; user confirmed cooking is fully functional.
- V24 `_cookingRecipeInfoView` remains 2.5x and readable.
- V16 readable enlarged minimap/vitals behavior remains as-is.
- Tarp, booklet, campfire 50m clip, and head positioning remain unchanged.

## New 2.5x HudGui targets
- `HudGui._availableRecipesView` — crafting-tarp recipe browser.
- `HudGui._toolTipInfoView` — generic tooltip/info popup; strong candidate for the remaining tiny world plant/mushroom information.
- `HudGui._quickSelectItemInfoView` — backpack quick-select item information.

Each target caches its original `RectTransform.localScale` per instance and reapplies `baseScale * 2.5` in LateUpdate, matching the proven V24 cooking recipe overlay strategy. `InventoryItemInfoView` is deliberately untouched because it has its own special world-space conversion and repeated scale writes are known to make it disappear.

Build with:

```bat
build_test.bat test_v25_more_info_ui
```
