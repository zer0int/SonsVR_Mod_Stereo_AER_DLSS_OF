## v0.7.0 — Real Performance Gains, and Cursors That Actually Work

This release delivers a genuine, substantial performance improvement (roughly **7-10 fps**) with no visual downside, alongside a major overhaul of every in-game menu cursor — the campfire cooking bag, construction booklet, tutorial book, and quick-select backpack cursors are all more accurate, more visible, and (for the cooking bag specifically) no longer randomly misbehave.

### ⚡ Performance

- **The native (non-VR) camera's GPU cost is now substantially reduced — confirmed 7-10fps gain.** This camera used to fully render every frame despite nobody ever actually looking through it (you only ever see through the VR eye cameras). It's now stripped down to render almost nothing, without the shadow-darkening bug a more aggressive version of this same idea caused in an earlier attempt — see `CHANGELOG.md` for the full technical story, including two other approaches that were tried and didn't pan out.
- **The desktop monitor mirror now copies a VR eye's own image directly**, instead of rendering through the native camera. This is what made the performance fix above safe to do without breaking what's shown on your monitor while playing.
- **DLSS clarified: it's hardcoded on for the VR eye cameras and isn't something the in-game setting controls.** If you've been toggling "Dynamic Resolution: DLSS" in the game's own options expecting a VR-specific effect, it's not doing anything either way — see Recommended Game Settings below and `CHANGELOG.md` for the full explanation.

### 🎯 Menu Cursors

- **Campfire cooking bag**: fixed the cursor intermittently jumping to nonsensical positions or snapping back to center when the joystick was released — both were the game's own systems fighting the mod's own cursor placement. Should now track smoothly and reliably.
- **All four menu cursors (campfire bag, construction booklet, tutorial book, quick-select backpack) are now larger and easier to see**, and the construction booklet/tutorial book specifically land accurately on the page instead of sometimes appearing to float behind it.
- **Quick-select backpack cursor recalibrated** for noticeably better accuracy, and fixed a case where your own hand (holding the bag) could block the cursor from reaching the item behind it.

### 🕐 Faster Startup

- **The automatic pause-menu flash (part of the startup FPS fix) is now much shorter** — roughly 0.65 seconds instead of over 2 — closer to a quick flash than a deliberate pause.

### 📥 Installation

1. Install [MelonLoader](https://melonwiki.xyz/) into your Sons Of The Forest folder.
2. Extract this release's contents into your Sons Of The Forest game folder, merging with the existing `Mods` and `UserLibs` folders.
3. Launch the game through SteamVR.

### 🎛️ Recommended Game Settings

For the best experience, apply these settings in the game's own options menu:

**Headset Connection**
- Use Virtual Desktop over Quest Link/Air Link if your headset supports it — noticeably better visual quality for this mod's VR rendering pipeline.

**Display**
- Fullscreen selected (rather than windowed)
- VSync: Disabled

**Graphics**
- Dynamic Resolution: DLSS setting has no effect on the VR view either way (see Performance above) — leave at whatever default, it doesn't matter for VR
- Motion Blur: Off
- Chromatic Aberration: Off
- Film Grain: Off

**Gameplay**
- FOV: 95 (max) — important for seeing UI items clearly and for cursor precision

### ⚠️ Known Issues

- Tarp tutorial's black background can still occasionally flash, even after a previous fix greatly reduced how often it happens — dismissing the tutorial message ("E: OK") reliably clears it if so.
- Low frame rate during a **new game's** intro cutscenes specifically — the automated FPS fix can't take effect until real gameplay begins, since the game itself ignores pause input for most of the intro. Clears up as soon as the intro finishes; not an issue on subsequent loads/continues.
- Native loading screen (shown after picking a save or starting a new game) still doesn't render in VR — set aside for now, with a custom placeholder shown in the meantime.
- Interaction-prompt icons can still overlap at beds and tents.
- The vitals status ring and toast-style notifications (e.g. "You are hungry") can still be occluded by held items.

Full details on every change, including the investigation trails behind each fix: see [CHANGELOG.md](CHANGELOG.md).
