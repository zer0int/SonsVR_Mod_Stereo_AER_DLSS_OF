# ZER0INT TEST V47B

## Goal
Load the secretary-compiled Unity 2022.2.16f1 shader bundle in the IL2CPP player using MelonLoader's dedicated `Il2CppAssetBundleManager`, after ordinary `AssetBundle.LoadFromFile` (V47) and `AssetBundle.LoadFromMemory(byte[])` (V47A) both returned null.

## Expected success marker
`[StereoRender][AER V47B][DepthShader] THINGY loaded through MelonLoader IL2CPP bridge ... Desktop-only depth board READY.`

Then the desktop mirror should show the four-cell V47 depth board. The headset path remains untouched.
