# ZER0INT TEST V16 — target the actual vitals RenderTexture display

V14/V15 proved that scaling `ToggleableHUD/PlayerVitalsUi` does not change the visible small status ring. Earlier diagnostics had already identified the vitals path as RenderTexture-composited (`PlayerVitalUiRenderTextureGroup/VitalsRenderTexture`) with `PlayerVitalsUiWorldSpace` as the source.

V16 therefore:
- leaves the old `PlayerVitalsUi` controller/root at native scale;
- finds the actual vitals `RawImage`/`VitalsRenderTexture` presentation quad;
- scales that display quad to x2.5 at end-of-frame;
- finds the actual visible minimap Graphic center at runtime;
- moves the vitals display quad so its visual center exactly matches the minimap visual center;
- copies the minimap plane rotation, keeping both at the same 0.50 m plane;
- leaves booklet/tutorial on the exact v11 known-good path.

Diagnostic markers: `[VitalsDisplayV16]`.

Build label: `test_v16_vitals_rendertexture`.
