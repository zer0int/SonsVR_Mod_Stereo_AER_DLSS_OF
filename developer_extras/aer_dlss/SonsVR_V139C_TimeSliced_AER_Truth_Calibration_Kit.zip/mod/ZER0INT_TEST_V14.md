# ZER0INT TEST V14 — map/ring same plane, book back to v11

This build starts from the exact known-good v11 source. It deliberately contains NONE of the v12 synthetic booklet gaze-plane code and NONE of the v13 booklet reflection diagnostics.

Changes:
- construction/tutorial books are exactly v11 again;
- minimap forward distance: 0.30 m -> 0.50 m, matching the main HUD/status-ring plane;
- GPS/minimap canvas physical height: x2.5;
- real character/status ring (`ToggleableHUD/PlayerVitalsUi`) local scale: x2.5;
- status-ring RectTransform pivot compensation keeps its visual center fixed while scaling.

The ring is a separate HUD system, not a child of `PlayerMiniMap`; v13's outer-root scaling could therefore never enlarge it.

If construction placement gets stuck after selecting a blueprint, note that this mod maps LEFT TRIGGER to right mouse button globally; try one left-trigger pull as the native mouse-style cancel. V14 does not add a new construction cancel binding yet.

Build label: `test_v14_map_ring_same_plane`.
