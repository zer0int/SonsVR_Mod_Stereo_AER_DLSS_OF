# ZER0INT TEST V37 — AER no-temporal-FX diagnostic

Based directly on V36. No gameplay/menu fixes are changed.

Purpose: isolate the strong *monocular* ghosting/wobble seen in V35/V36 from temporal rendering/history effects and finally log the actual AER pose ages/corrections plus HDRP's effective HDCamera state.

Changes:
- Eye HDAdditionalCameraData is explicitly forced to `antialiasing=None` while AER is enabled.
- Eye `allowDeepLearningSuperSampling=false` and `allowDynamicResolution=false` are explicitly written, even though V36 allowed them. This prevents DLSS/dynamic reconstruction from quietly participating in the diagnostic.
- Every 0.25 s, active runtime Volume profiles are scanned and the following components are forced inactive when present: MotionBlur, DepthOfField, ChromaticAberration, FilmGrain, Bloom, LensDistortion, PaniniProjection, Vignette, ScreenSpaceReflection, ScreenSpaceAmbientOcclusion, ContactShadows, MicroShadowing. This deliberately bypasses Sons' menu/settings layer.
- Every 0.5 s logs per-eye raw-render age and angular difference to the latest tracked HMD pose.
- Every 0.5 s logs the HDRP `HDCamera.antialiasing` readback, HDAdditionalCameraData AA/DLSS/dynamic settings, and aggregated effective FrameSettings for MotionBlur, DoF, Distortion, ChromaticAberration, SSR, SSAO, ContactShadows, Volumetrics, and volumetric reprojection.
- Logs whether MelonMod.OnLateUpdate submission executes before or after StereoRender.LateUpdate in the same frame.
- Logs OpenVR `Compositor_FrameTiming` per-frame counters/CPU-GPU timing plus `Compositor_CumulativeStats` for cumulative reprojected-frame counts. The original V37 draft incorrectly tried to read `m_nNumReprojectedFrames` from `Compositor_FrameTiming`; the bundled SteamVR wrapper correctly exposes that field only on `Compositor_CumulativeStats`.

This is intentionally a diagnostic build. Do not use its performance as a clean FPS benchmark: Volume scanning and logging are deliberately much heavier than the keeper build.
