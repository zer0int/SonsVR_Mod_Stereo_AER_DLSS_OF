# ZER0INT TEST V49 — GPU confidence-filled same-time stereo

Base: V48.

V49 preserves the proven one-real-eye + same-time GPU synthetic-opposite-eye path and changes only synthetic reconstruction quality:

- warp grid 256x256 -> 512x512;
- invalid vertices no longer get flung to clip (-2,-2); mixed-valid triangles are rejected with an interpolated-valid threshold of 0.999;
- direct warp confidence is stored in alpha;
- two confidence-aware spatial fill passes run at radius 1 then radius 2 pixels;
- V48's full-screen source-eye underlay is removed;
- one final composite blends low-confidence pixels toward the same-time source eye;
- confidence fades toward monoscopic source for very-near 0.45->0.80 m and very-far 40->120 m geometry;
- desktop bottom-left now shows confidence rather than raw depth.

V36 retained-eye rotational reprojection remains fallback-only if V49 synthesis cannot be prepared for a frame.
