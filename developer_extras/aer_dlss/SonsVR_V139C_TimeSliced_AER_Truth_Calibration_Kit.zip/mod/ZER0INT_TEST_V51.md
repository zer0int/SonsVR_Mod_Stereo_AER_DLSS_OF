# ZER0INT TEST V51 — TARGET-EYE HOLE FALLBACK

Base: V50A at 1.0 eye scale.

Changes only the remaining fallback/composite policy:

- Camera-local eye depth latch remains mandatory and exact-frame.
- 512x512 forward depth warp retained.
- V49/V50 near/far source-eye confidence fade is disabled in the shader.
- No source-eye color is ever used to complete the synthetic target eye.
- Any non-zero synthetic/fill coverage wins outright (no cross-eye lerp).
- True alpha==0 holes use the previous REAL TARGET eye.
- The old target eye is rotation-aligned to the fresh HMD pose through the existing V36 homography when possible; raw stale target is fallback-of-last-resort.

Hypothesis: V50's remaining close flat jittery "holo sheet" and doubled Kelvin/HUD are the source eye being inserted at the same screen UV wherever the forward warp has disocclusion holes or deliberately lowered confidence. V51 preserves target-eye geometry in those regions instead.
