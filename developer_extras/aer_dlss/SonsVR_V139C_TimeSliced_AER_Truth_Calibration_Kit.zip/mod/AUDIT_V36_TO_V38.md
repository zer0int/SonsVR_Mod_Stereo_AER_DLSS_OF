# Audit: V36 -> V37a -> V38 -> V38B

## Tree continuity

Across the supplied archives, gameplay/UI code is stable. Between V36 and V37a, only `StereoRender.cs`, `SonsVRMod.cs`, experiment documentation, and a new V37 note change. Between V37a and V38, the same pattern holds plus a new V38 note. `VRPlayer.cs`, `VRSystem.cs`, `VRUiToolkit.cs`, utilities, reflection helpers, release notes, and prior experiment notes remain byte-identical.

Approximate method inventory for `StereoRender.cs`:

- V36: 37 methods
- V37a: 41 methods; no V36 methods removed. Added diagnostics only.
- V38: 44 methods; no V37a methods removed. Added EOF submission/commit/telemetry only.

This does not show source-tree rollback or large-section loss.

## V37 compiler issue

The original V37 compiler failure came from reading `m_nNumReprojectedFrames` from `Compositor_FrameTiming`. The supplied V37a and V38 sources use `Compositor_CumulativeStats` + `GetCumulativeStats` for the cumulative reprojected counters. That fix is internally coherent and is retained.

## V38 compiler issue

The supplied V38 calls `MelonCoroutines.Start(...)` from a file importing both `MelonLoader` and `Valve.VR`, making the identifier ambiguous. V38B explicitly calls:

```csharp
MelonLoader.MelonCoroutines.Start(...)
```

No other AER behavior depends on this compile fix.

## 1f/2f timing issue

V37 telemetry established that `SonsVRMod.OnLateUpdate` runs before `StereoRender.LateUpdate`. The old pipeline therefore submitted before that frame's new AER eye was even scheduled/rendered. Its nominal fresh/stale pair was actually 1f/2f old at submission.

V38 correctly changed the architecture:

1. `StereoRender.LateUpdate`: `WaitGetPoses`, update HMD rotation, choose/enable one eye, store schedule+pose for current `Time.frameCount`.
2. Unity/HDRP renders that enabled eye.
3. `WaitForEndOfFrame`: commit the current schedule to the texture/pose bookkeeping.
4. Reproject the other eye using the existing V36 rotation-only warp.
5. `Submit_Default` both eyes.
6. `SonsVRMod.OnLateUpdate` suppresses its legacy submit while EOF AER submission is enabled.

V38B tightens this invariant further: EOF submission occurs only if the schedule's frame tag equals the current `Time.frameCount`. If not, it skips submission instead of falling back to an older pair. This prevents the EOF path from silently reintroducing 1f/2f behavior.

## Coherence issue found

`EXPERIMENT_BUILD.md` in V37a/V38 retained stale V36 build/startup instructions at the top and appended newer experiment sections. This is documentation/package hygiene failure, not renderer-source rollback. V38B replaces that file with one unambiguous current-build document and unique markers.
