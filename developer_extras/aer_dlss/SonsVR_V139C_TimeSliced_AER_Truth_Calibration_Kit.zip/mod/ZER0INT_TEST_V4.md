# zer0int test v4

Recovery/measurement build based on the original fork cursor path.

- Restores the original cursor code and original hard-coded cursor offsets unchanged.
- Adds a passive right-trigger probe only: trigger #1 while the visible cursor is on the target, trigger #2 when that same target is actually highlighted. Samples are logged to `UserData/SonsVR_CursorProbe.log` and MelonLoader.
- Keeps tarp-only far clip at 50 m, restoring 24 km outside inventory, without reallocating eye textures.
- Keeps horizontal tarp recenter at 0.55 m but disables the failed adaptive ray steering.
- Adds +0.55 m VR-head-only Y offset during tarp mode so the HMD is above the avatar torso rather than embedded in it.
- Keeps `InventoryItemInfoView` world height at 0.76 m (2x original 0.38 m).
