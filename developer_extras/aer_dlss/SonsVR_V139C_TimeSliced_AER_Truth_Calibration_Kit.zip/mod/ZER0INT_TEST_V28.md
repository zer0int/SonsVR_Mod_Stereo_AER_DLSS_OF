# ZER0INT TEST V28

Based directly on the user-confirmed V27 build where hiding LocalPlayer `SkinnedMeshRenderer`s during the tarp made both the avatar and tarp disappear while preserving interaction/animation state and dramatically improved VR performance.

## New behavior

The same `Renderer.forceRenderingOff` strategy now applies while these held 3D menus are active:

- `GrabBagHeld` / campfire cooking menu — **ON by default**
- `BackpackQuickSelect` — **ON by default**
- construction booklet — OFF by default (visible book/page geometry is the menu)
- tutorial book — OFF by default (same reason)

All native Animators, colliders, hover targets, cooking logic and input remain active. A 0.5 s rescan mirrors V27 so clothing/arm/held skinned renderers instantiated after menu-open are also suppressed. Renderer states are restored on menu close, VRPlayer disable, or destruction.

No tarp geometry, far-clip, cooking-gaze, recipe/HUD scaling, or booklet cursor behavior is changed from V27/V25.

Build with:

```bat
build_test.bat test_v28_handheld_invisible_player
```
