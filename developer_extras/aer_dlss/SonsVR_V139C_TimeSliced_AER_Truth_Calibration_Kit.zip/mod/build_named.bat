@echo off
setlocal
if "%~1"=="" (
  echo Usage: build_named.bat test_v1_fix_tarp_uisize
  exit /b 2
)

dotnet build -c Release -p:BuildLabel="%~1"
if errorlevel 1 exit /b %errorlevel%

echo.
echo Build archived at:
echo   %~dp0builds\%~1\SonsVR_Mod.dll
echo Copy that DLL into:
echo   D:\SteamLibrary\steamapps\common\Sons Of The Forest\Mods
