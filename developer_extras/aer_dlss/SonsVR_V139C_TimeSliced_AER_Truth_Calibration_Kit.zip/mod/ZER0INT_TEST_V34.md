# ZER0INT TEST V34 — AER IL2CPP injection fix

Based directly on V33/V32.

V33 failed before `StereoRender` could register with Il2CppInterop. The AER implementation added several **instance helper methods** whose signatures contained Valve/OpenVR structs, by-ref structs, and an unsafe native pose wrapper. `ClassInjector.RegisterTypeInIl2Cpp<StereoRender>()` attempts to convert injectable instance methods and failed in `ConvertMethodInfo`, aborting VR initialization.

V34 keeps the same AER behavior but moves all AER helper methods that use OpenVR-native types to **static managed helpers**. The injected `StereoRender` MonoBehaviour exposes only the ordinary Unity callback methods plus the string-only `RequestAerResyncV33` instance entry point. This mirrors the existing source pattern where complex reflection/HDRP helpers are static and therefore are not exposed as IL2CPP instance methods.

Install behavior is unchanged: replace only `Mods/SonsVR_Mod.dll`; keep the existing `Mods/Libs/openvr_api.dll` and `UserLibs/SonsSteamVR_IL2CPP.dll`.
