# ZER0INT TEST V11

V11 keeps the confirmed-working V10 campfire gaze interaction and makes two narrowly-scoped campfire-view changes:

1. While `GrabBagHeld` is active, VR eye far clip becomes **50 m** (same cheap projection-only far-clip change already proven useful for the tarp). It returns to the normal gameplay value when the bag closes.
2. While `GrabBagHeld` is active and `UsedCamera` is `MainCameraFP`, the VR `Origin.position` follows `MainCameraFP` every frame using the exact same `positionOffset` as ordinary gameplay. Orientation is not copied; HMD tracking still owns view rotation. This targets the V10 regression where the body/shoulder animation moves while generic menu handling freezes the VR Origin.

Unchanged: V10 gaze collider selection/native hover callbacks, tarp geometry and 50 m tarp far clip, 2.5x targeted HUD/item card, booklet original 460/460 cursor.
