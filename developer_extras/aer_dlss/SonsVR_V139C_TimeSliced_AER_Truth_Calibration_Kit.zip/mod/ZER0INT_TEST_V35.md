# ZER0INT TEST V35 — AER + Submit_Default baseline

Based directly on V34 (and therefore the V32 keeper).

## Why this build exists
V34 proved that the AER scheduler itself reaches runtime, but its per-eye `Submit_TextureWithPose` experiment produced a severely reprojected/bounded scene with the SteamVR compositor environment visible around the game image. The OpenVR compositor accepted the pose-submit calls without error, so this was a semantic/compositor-path failure rather than a missing SteamVR Home toggle.

Valve/OpenVR issue #1253 documents the relevant limitation: under SteamVR, distinct `VRTextureWithPose_t::mDeviceToAbsoluteTracking` values submitted separately for left/right AER frames are not reliably honored as independent eye poses; the later submitted pose can effectively be used for both eyes.

## V35 change
- `AlternateEyeRenderingEnabled = true`
- `AerPoseAwareSubmissionEnabled = false`
- Left/right HDRP cameras still alternate after the normal short stereo warmup.
- BOTH persistent eye textures are still submitted every application frame.
- Submission uses the original proven `Submit_Default` path only.
- No heavy diagnostics were added.

## Purpose
This is a clean A/B for the core question: does skipping one expensive HDRP eye render per Unity frame deliver a major performance gain while keeping the full-FOV scene visually normal?

Expected compromise: because the stale eye is one application frame older and SteamVR is no longer told a distinct render pose for it, fast head/world motion may show temporal stereo ghosting. If AER performance is strong, the next engineering step is custom stale-eye rotational reprojection/timewarp in the mod, not another attempt to rely on SteamVR storing two independent eye poses.
