# ZER0INT TEST V46 — HDRP depth tap feasibility probe

Base: exact V44 stable 0.8-scale deferred-gameplay AER + V44 spatial telemetry.

Only experimental addition: after a known single fresh eye has completed at V38B EOF, inspect HDRP's globally bound depth texture (`_CameraDepthTexture`, with diagnostic fallback names) and, about every two seconds, issue a **non-blocking** `AsyncGPUReadback` for only the center 64x64 region converted to `RFloat`.

The probe logs candidate texture metadata, readback success/error, raw device-depth statistics, approximate linear eye-depth statistics using `_ZBufferParams`, and PRE_TARP/POST_TARP validity.

It does not allocate or replace eye render targets, add a shader/custom pass, call OpenVR, alter AER scheduling/reprojection/submission, or call `WaitForCompletion`.
