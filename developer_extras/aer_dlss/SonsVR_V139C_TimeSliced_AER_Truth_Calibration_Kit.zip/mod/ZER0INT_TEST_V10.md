# ZER0INT TEST V10 — campfire gaze selection

This test keeps the known-good v9 tarp, 50 m tarp far clip, and x2.5 targeted HUD/item-card changes.

Campfire / GrabBag only:
- stops using VirtualMouse + 460/460 to position/select the visible cursor;
- head-forward gaze directly raycasts active `GrabBagLayoutItem` colliders;
- gaze target transition invokes the item's native `OnMouseExit` / `OnMouseEnter`, and `OnMouseOver` every frame;
- visible `SoftwareCursor` is placed on the same collider hit, so visual pointer and selected item share one ray;
- trigger input is untouched; activation is the experiment.

Construction booklet and other handheld menus retain v9 behavior, including original 460/460 booklet offset.

Build label: `test_v10_campfire_gaze`.
