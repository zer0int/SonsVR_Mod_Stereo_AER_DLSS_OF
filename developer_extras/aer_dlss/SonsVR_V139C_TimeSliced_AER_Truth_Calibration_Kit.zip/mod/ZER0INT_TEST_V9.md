# ZER0INT TEST V9

- Keeps the proven tarp behavior unchanged: temporary tarp transform, +0.55 m VR-head Y, and 50 m tarp-only far clip.
- Increases only the targeted small HUD subtrees (`WorldScreenSpaceElements` and `ToggleableHUD/MessageList`) from 2.0x to 2.5x. The root `ScreenSpaceCanvas` remains untouched to avoid the v7 loading hang.
- Increases the looked-at item information card from 0.76 m to 0.95 m world height (2.5x the original 0.38 m).
- Restores the campfire / construction-book cursor offsets to the original fork values: X=460 px, Y=460 px. The v6 half-offset experiment is fully reverted.
- Leaves the normal-world far clip at the fork's existing 24000 m. Only tarp inventory switches to 50 m.
