# ZER0INT TEST V31

Based directly on clean V28 (not V29/V30 diagnostics).

## Change

While `GrabBagHeld` / cooking is active, hide only the ordinary `Renderer` named `InventoryFoodBoard` using `forceRenderingOff`.

V29 showed this structural cooking tray is **not** a `SkinnedMeshRenderer`, so V28 did not hide it even though V27 hid the ground inventory support geometry. Ingredient renderers, `CookingCog`, colliders, animations and interaction logic remain untouched.

The board is restored on menu close, VRPlayer disable, or destruction.

Log marker: `[VRPlayer][GrabBagBoardV31]`.

Build with:

```bat
build_test.bat test_v31_grabbag_board_off
```
