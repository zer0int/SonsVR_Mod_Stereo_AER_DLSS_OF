# ZER0INT TEST V33 — Alternate Eye Rendering (AER)

Based directly on the user-confirmed V32 keeper. All tarp/cooking/UI fixes remain unchanged.

## What changes

V32 renders two independent full HDRP Unity cameras every application frame:

- `VRLeftEye -> LeftRT`
- `VRRightEye -> RightRT`

V33 keeps both RenderTextures persistent, but after a 4-frame two-eye warmup renders only one eye camera per Unity frame:

- frame N: left renders, right RT is retained
- frame N+1: right renders, left RT is retained
- repeat

Both textures are still submitted to OpenVR every frame.

### Pose-aware stale-eye reprojection

Each eye remembers the OpenVR HMD pose from the frame that actually rendered its current texture. Once both eyes have valid stored poses, V33 submits a native-layout `Texture_t + HmdMatrix34_t` payload with `EVRSubmitFlags.Submit_TextureWithPose` so SteamVR can independently reproject head motion for the fresh and retained eye.

This fork intentionally uses HMD **rotation only** for Unity rendering (`Head.localPosition` remains zero), so V33 also zeros tracking-pose translation before associating it with an eye texture. That makes the submitted pose describe the camera transform this mod actually rendered instead of claiming room-scale translation it ignored.

The bundled Valve C# wrapper always exposes `CVRCompositor.Submit(... ref Texture_t ...)`. Because generated C# representations of C++ `VRTextureWithPose_t : Texture_t` vary by OpenVR generation, V33 defines the native sequential layout locally, verifies that the pose begins exactly after `Texture_t`, and then uses the documented `Submit_TextureWithPose` flag. If pose-aware submission fails while old `Submit_Default` works, pose mode disables itself for the session but AER camera alternation remains active.

## Safety/resync behavior

- New eye RenderTextures: both eyes warm up again before alternating.
- Native source-camera change (e.g. `MainCameraFP <-> InventoryCamera`): both eyes render for 2 frames before alternating again, preventing an old camera-context texture from lingering in one eye.
- Invalid HMD tracking sample: render both eyes for that frame rather than generate a one-eye update from a bad pose.
- `AlternateEyeRenderingEnabled = false` restores original two-camera-per-frame rendering.

## What to look for

Primary question: does performance improve substantially during ordinary gameplay and especially the cooking/GrabBag menu?

Also deliberately stress:

- turn head slowly and rapidly;
- strafe/walk while looking at near geometry;
- watch moving NPCs/arms/items;
- open/close tarp and cooking menus;
- move from indoor to outdoor scenes.

Expected AER artifact if present: moving world objects can be one application frame newer in one eye than the other. Head rotation should be substantially helped by pose-aware compositor reprojection; object motion cannot be perfectly corrected without motion/depth data.

Useful one-time log markers:

- `[ZER0INT TEST V33 AER]`
- `[StereoRender][AER V33] warmup complete`
- `[StereoRender][AER V33] pose-submit layout check`
- any `[StereoRender][AER V33] ... fallback` warning

No V29/V30 heavy renderer/camera/frame-timing logging is reintroduced.
