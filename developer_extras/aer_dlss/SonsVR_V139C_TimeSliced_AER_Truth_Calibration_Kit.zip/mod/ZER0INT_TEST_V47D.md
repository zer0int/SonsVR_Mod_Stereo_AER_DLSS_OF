# ZER0INT TEST V47D

Purpose: re-run the V47C desktop-only depth shader board with a correctly built AssetBundle.

The original 6548-byte THINGY was produced while the Unity AssetBundle module was disabled. Unity's player therefore rejected it natively as incompatible. The replacement 6720-byte THINGY was rebuilt after enabling `com.unity.modules.assetbundle` in the exact Unity 2022.2.16f1 editor.

Expected success markers:

`[StereoRender][AER V47D][DepthShader] THINGY loaded through MelonLoader IL2CPP bridge ... Desktop-only depth board READY.`

Then the desktop mirror should show fresh-eye color plus three depth mapping candidates. Headset submission remains the V46/V38B path.
