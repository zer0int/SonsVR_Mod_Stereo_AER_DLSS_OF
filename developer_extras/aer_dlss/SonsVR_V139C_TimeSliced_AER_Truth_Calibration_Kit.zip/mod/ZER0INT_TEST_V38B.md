# ZER0INT TEST V38B — audited AER end-of-frame submission

Source trust chain: rebuilt directly from the user-supplied V38 archive after diffing V36 -> V37a -> V38. The discarded V38a package is not used.

Changes versus user-supplied V38:

- Fixes the compiler ambiguity by calling `MelonLoader.MelonCoroutines.Start(...)` explicitly.
- Keeps V38's structural fix: AER submission is suppressed in `SonsVRMod.OnLateUpdate` and moved to `WaitForEndOfFrame`.
- Tightens the 0f/1f invariant: the EOF loop submits only when the scheduled eye belongs to the current `Time.frameCount`; it no longer falls back to submitting an older 1f/2f pair from that path.
- Adds a duplicate-submit-per-frame guard and bounded warnings for missing same-frame schedules.
- Adds unmistakable `V38B AUDITED` startup/log markers.
- Updates stale V36 scheduling comments to describe the V38+ same-frame EOF commit path.

Expected steady-state telemetry alternates approximately:

```text
[AER V38B][EndOfFrame] ... completed=L Lage=0f Rage=1f ...
[AER V38B][EndOfFrame] ... completed=R Lage=1f Rage=0f ...
```

During warmup/resync, `completed=BOTH` with both ages 0f is expected.
