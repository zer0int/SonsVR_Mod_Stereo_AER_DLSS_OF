# ZER0INT TEST V15 — make the status ring scale actually stick

V14 proved the map and status ring are now on the same physical 0.50 m plane, but only the map visibly enlarged.

The likely cause is a same-frame transform race: `UpdateVitalsUiScaleV14()` writes `PlayerVitalsUi.localScale` during the normal Update path, but Sons can rewrite that RectTransform later. The existing vitals coroutine already runs at `WaitForEndOfFrame` specifically to beat native position resets, yet V14 only *computed* the target scale there for pivot compensation and never re-applied it.

V15 therefore:
- keeps the exact V14 map geometry and exact V11 booklet behavior;
- re-applies the x2.5 `PlayerVitalsUi` root scale at `WaitForEndOfFrame`;
- retains the existing pivot compensation so the ring center should stay where it was while the whole ring grows coherently;
- does **not** yet individually scale children. If the end-of-frame root scale still cannot affect the rendered ring, child-level scaling becomes the next fallback.
