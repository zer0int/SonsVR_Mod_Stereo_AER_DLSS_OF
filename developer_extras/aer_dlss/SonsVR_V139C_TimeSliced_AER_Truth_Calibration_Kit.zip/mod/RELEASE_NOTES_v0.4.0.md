## v0.4.0 — New-Game Intro Cutscenes Now Work Properly in VR

This release fixes the two remaining new-game intro issues: the "hold Y to skip" prompt and the laptop's "hold A to close" action. Both work correctly in VR now, so a new game's intro cutscenes (helicopter, laptop, crash) can be played through properly, start to finish, without needing to skip.

### 🎬 Fixed: "Hold Y to Skip" Prompt

Previously invisible in VR — the prompt existed and the skip itself still worked blind, but you'd have no on-screen indication of it. It's now shown as a clear on-screen message ("HOLD Y (controller) or S (keyboard) to skip") that appears and disappears at the same moments the native prompt normally would, confirmed working across all three skippable intro cutscenes.

### 💻 Fixed: Laptop "Hold A to Close"

Previously, pressing A while looking at the laptop's power button on the final page did nothing, with no way to actually close the laptop and proceed to the next cutscene in VR. This is now fixed — you can go through the full intro naturally, exactly as intended, instead of needing to skip past it.

### ⚠️ Known Issues

- **Low frame rate during a NEW GAME's intro cutscenes.** This clears up on its own once the intro finishes and real gameplay starts — it's a side effect of an existing FPS fix that can't run any earlier, since the game itself ignores pause input for most of the intro. No action needed; this only affects a fresh new game, not subsequent loads or continues.
- The quit/save confirmation dialog still doesn't render in VR (visible on the flat desktop mirror only).
- Interaction-prompt icons ("A to sleep" / "B to save") can still overlap at beds and tents.
- The vitals status ring (health/hunger/thirst/strength icons) can still be occluded by held items.

Full details on every change: see [CHANGELOG.md](CHANGELOG.md).

### 📥 Installation

1. Install [MelonLoader](https://melonwiki.xyz/) into your Sons Of The Forest folder.
2. Extract this release's contents into your Sons Of The Forest game folder, merging with the existing `Mods` and `UserLibs` folders.
3. Launch the game through SteamVR.

### 🎛️ Recommended Game Settings

For the best experience, apply these settings in the game's own options menu:

**Display**
- Fullscreen selected (rather than windowed)
- VSync: Disabled

**Graphics**
- Dynamic Resolution: DLSS
- Motion Blur: Off
- Chromatic Aberration: Off
- Film Grain: Off

**Gameplay**
- FOV: 95 (max) — important for seeing UI items clearly and for cursor precision
