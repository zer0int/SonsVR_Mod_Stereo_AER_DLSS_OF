# ZER0INT TEST V36 - AER rotational stale-eye reprojection

Base: exact V35 / V32 keeper behavior.

This build keeps V35's proven alternate-eye schedule: after a short stereo warmup, only one ordinary HDRP eye camera renders per Unity frame while both persistent eye textures are submitted every frame.

V36 changes only the temporal stereo correction step:

- SteamVR `Submit_TextureWithPose` stays OFF. V34 proved that path is not usable for this AER scheme under SteamVR.
- The one-frame-stale eye is reprojected in the mod before submission.
- The warp is rotation-only. It uses the stored HMD rotation that produced the stale texture and the stored HMD rotation that produced the fresh texture.
- Both eyes then go through ordinary `Submit_Default`, now approximately describing the same head orientation.
- The fresh eye is never resampled.
- Raw `LeftRT` / `RightRT` are never overwritten by the warp; separate reprojection RTs preserve the persistent-eye AER state.

## How the warp works

Pure camera rotation is a projective homography. V36 avoids a custom shader asset by unprojecting the four stale-eye image corners through that eye's exact OpenVR projection matrix, rotating that image plane into the fresh-eye HMD orientation, then drawing the textured plane back through the same perspective projection. Standard GPU perspective-correct interpolation performs the homography.

This is exact for rotation-only camera motion. It does **not** solve translation/parallax because there is no depth buffer in this first pass. The fork already ignores room-scale HMD translation, but the eye center still moves slightly around the head center as the head rotates, so very near geometry may retain some residual stereo error.

## Important startup/log markers

- `[ZER0INT TEST V36 AER ROTATIONAL REPROJECTION]`
- `rotational-reprojection=ON`
- `[StereoRender][AER V36] rotational reprojection resources ready ...`
- `[StereoRender][AER V36] rotational stale-eye reprojection ACTIVE ...`

The first ACTIVE line also reports the first correction angle in degrees.

If no compatible built-in textured shader is found, or if the GL warp throws, V36 falls back to the raw V35 eye texture for that frame/session path instead of breaking VR submission.

## First test

Compare directly against V35:

1. Stand still and slowly rotate head.
2. Fast head rotation.
3. Walk/strafe while looking at medium-distance geometry.
4. Inspect very near geometry/text for residual fusion conflict.
5. Try tarp.
6. Try cooking.

The primary success criterion is removal or major reduction of V35's whole-world alternating "tremor" / fusion-instability effect while retaining AER's apparent fluidity.
