ZER0INT TEST V47D — V47C with correctly rebuilt AssetBundle THINGY; renderer/submission behavior otherwise unchanged.
