# V47 experimental build

Build label: `test_v47_embedded_depth_shader_board`

This is V46 plus the user's Unity-compiled `sonsvr_depththingy` embedded into the DLL and a desktop-only GPU depth-visualization board. It deliberately does not modify OpenVR submission or headset eye textures.
