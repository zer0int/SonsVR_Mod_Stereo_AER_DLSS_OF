# ZER0INT TEST V44 — continuous gameplay AER spatial telemetry

Base: **V43 deferred gameplay AER**.

Rendering/submission behavior is intentionally unchanged from V43:

- title/loading: proven full-stereo V40C path,
- one-way activation only after `SonsMain + MainCameraFP + LocalPlayer + successful HDRP copy`,
- activation after EOF,
- then untouched V38B 0f/1f AER scheduling,
- V36 rotational stale-eye reprojection,
- `Submit_Default`.

## What V44 adds

Passive transform telemetry only, continuously once AER actually activates. It does **not** add another `WaitGetPoses`, query OpenVR, touch camera enablement, allocate render resources, change reprojection math, or alter compositor submission.

At each normal single-eye EOF commit, V44 compares the stale eye camera's transform from the last time that eye genuinely rendered against that same camera's current would-be transform. It accumulates RMS/max for:

- stale-eye age in milliseconds,
- same-eye camera-center translation,
- same-eye camera rotation,
- head world translation,
- StereoRender rig world translation,
- translation decomposed into lateral and forward components in current camera coordinates,
- first-order translation-only pixel disparity estimates at 0.5 / 1 / 2 / 5 / 10 metres.

Two summary lines are emitted approximately every 2 seconds:

- `[StereoRender][AER V44][GameplaySpatial]`
- `[StereoRender][AER V44][DepthPx]`

## Crafting-tarp validity marker

There is **no delayed telemetry start**. V44 records immediately when gameplay AER starts and keeps running.

The first real user-opened crafting tarp (`InventoryCamera` transition) is only a **validity marker**. It does not trigger or change AER. The log emits:

- `[VRPlayer][AER V44][VALIDITY MARKER] ...`
- `[StereoRender][AER V44][VALIDITY] ...`

At that point the telemetry accumulator is reset. Subsequent summary windows use `validity=POST_TARP`. Earlier windows remain in the log as `validity=PRE_TARP` diagnostic context. This makes it obvious that the run demonstrably reached ordinary interactive gameplay instead of only an under-map/pre-game phase.

Suggested run: move/hop around normally, open the crafting tarp once, do cooking/other normal interactions, then exit. No special timing is required.
