# ZER0INT TEST V24

Based directly on the restored V16 keeper build.

## Campfire cooking cog
- Keeps the proven V10/V11 ingredient gaze path (`GrabBagLayoutItem`).
- Adds `Sons.Gameplay.Cooking.CookingCog` as a second native gaze target.
- Gaze raycasts the cog's real colliders; if a cog prefab has no useful collider, renderer bounds are used as a spatial fallback.
- Drives the cog's own `OnMouseEnter` / `OnMouseExit` (and `OnMouseOver` if present), leaving trigger input untouched so the game's native interaction path can fire.
- The nearest real target (ingredient or cog) wins; the visible software cursor sits at that same target depth.

## Cooking recipe overlay
- `HudGui._cookingRecipeInfoView` is resolved from the generated IL2CPP wrapper.
- Its original local scale is cached and multiplied by `CookingRecipeOverlayScaleMultiplier = 2.5f`.
- Re-applied during LateUpdate so native menu animation/layout cannot silently restore the tiny scale.

Build with:

```bat
build_test.bat test_v24_cooking_cog_recipe_scale
```
