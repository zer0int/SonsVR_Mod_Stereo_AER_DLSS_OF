# Experiment build V49

Purpose: reduce the structured V48 artifacts while preserving its successful same-time GPU stereo synthesis.

Expected comparison:
- mid-range should remain sharp/stable;
- black/blocky depth-edge wedges should reduce from strict invalid-triangle rejection + 512 grid + small fills;
- near HUD/held-item and far foliage should become more stable through confidence-based same-time monoscopic blending;
- desktop confidence map should expose whether remaining failures are recognized by the warp confidence model.

No game-specific UI/NPC hooks and no temporal history were added.
