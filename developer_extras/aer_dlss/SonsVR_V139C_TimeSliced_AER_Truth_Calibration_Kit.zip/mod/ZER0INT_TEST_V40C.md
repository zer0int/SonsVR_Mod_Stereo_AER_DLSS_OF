# ZER0INT TEST V40C — static full-stereo control

Purpose: strict full-stereo control for V38B/V40A with the same temporal-feature policy.

Base: V38B lineage.

Changes: AER disabled from startup; both eye cameras render every frame; conventional OnLateUpdate Submit_Default path is used. AA=None, DLSS=OFF and dynamic resolution=OFF remain forced, so C isolates AER rather than also changing temporal reconstruction settings.

Build: `build_named.bat test_v40c_static_full_stereo_control`
