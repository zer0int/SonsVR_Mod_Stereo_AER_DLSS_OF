# V47B — IL2CPP AssetBundle bridge

V47 and V47A proved that the ordinary generated `UnityEngine.AssetBundle` wrappers return null in this IL2CPP game for the valid embedded UnityFS bundle. V47B keeps the bundle embedded and memory-only, but loads it through MelonLoader 0.7.3's `UnityEngine.Il2CppAssetBundleManager`.

Path: managed embedded bytes -> `Il2CppStructArray<byte>` -> `Il2CppAssetBundleManager.LoadFromMemory` -> shader asset.

No headset rendering/submission changes. The desktop depth board remains the only shader output.
