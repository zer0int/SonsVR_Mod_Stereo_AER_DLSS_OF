# ZER0INT TEST V47A — memory-only embedded depth shader board

V47A is a narrow fix over V47. The user-compiled Unity 2022.2.16f1 AssetBundle remains embedded byte-for-byte in `SonsVR_Mod.dll`, but it is no longer extracted to `%TEMP%`.

At gameplay AER activation, V47A reads the embedded `UnityFS` bytes into a managed `byte[]` and calls `AssetBundle.LoadFromMemory(...)`. The desktop-only 2x2 fresh-color/depth-mapping board is otherwise unchanged from V47; headset rendering, V38B scheduling, V36 reprojection, Submit_Default, V46 telemetry, and the 0.8 render scale remain unchanged.

Expected success marker:

`[StereoRender][AER V47A][DepthShader] THINGY loaded DIRECTLY FROM MEMORY ... magic='UnityFS' ... No temp file was created.`

If `LoadFromMemory` still returns null, the log now reports bundle byte count and UnityFS magic so the remaining failure is isolated to Unity accepting the bundle rather than filesystem extraction/path handling.
