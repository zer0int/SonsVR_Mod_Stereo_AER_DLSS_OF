# V47C — implicit conversion compile fix

V47B failed C# compilation with CS0571 because `Il2CppStructArray<byte>.op_Implicit(bundleData)` explicitly invoked an operator accessor. V47C uses normal C# implicit-conversion syntax instead. No runtime/rendering behavior was intentionally changed.
