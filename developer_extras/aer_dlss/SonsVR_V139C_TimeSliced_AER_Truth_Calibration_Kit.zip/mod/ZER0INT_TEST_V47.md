# ZER0INT TEST V47 — embedded depth-shader board

Base: exact V46 source tree at 0.8 render scale.

## Purpose

Prove that the Unity-2022.2.16f1 AssetBundle shader supplied in `THINGY_OUT/sonsvr_depththingy` can be embedded inside `SonsVR_Mod.dll`, loaded at runtime in Sons of the Forest, sample the live HDRP `_CameraDepthTexture`, and render GPU output — without touching the headset submission path.

## Safety boundary

V47 does **not** replace either headset eye. V38B/V36 `Submit_Default` happens first. Only after submit does V47 copy the just-fresh eye into a small debug RT and render three small grayscale depth RTs. They are displayed only in the desktop mirror.

## Desktop 2x2 board

Once the shader initializes, the desktop window becomes:

- top-left: same-frame fresh-eye color reference
- top-right: Depth A — active viewport assumed at lower-left of HDRP allocation
- bottom-left: Depth B — active viewport assumed centered in HDRP allocation
- bottom-right: Depth C — raw full depth allocation

The correct candidate should show scene geometry whose silhouettes/spatial layout best match the fresh color panel (allowing for grayscale depth and minor alternating-eye differences).

## Runtime loading

The 6548-byte AssetBundle is embedded as managed resource:

`SonsVRMod.Resources.sonsvr_depththingy`

V47 lazily extracts it to `%TEMP%/sonsvr_depththingy_v47_998d6dde3add461b.bundle` only after gameplay AER activation, then loads `Assets/DepthStereoDebug.shader` and creates the material. No shader/bundle work occurs during title/loading.

## Build

```bat
build_named.bat test_v47_embedded_depth_shader_board
```

Expected startup marker:

`[ZER0INT TEST V47 EMBEDDED DEPTH SHADER BOARD]`

Expected runtime success marker:

`[StereoRender][AER V47][DepthShader] THINGY loaded from embedded DLL resource...`

followed by a `live board:` line with eye/depth dimensions and candidate UV scale/bias.

## What to return

A screenshot/photo of the desktop 2x2 board plus the MelonLoader log is ideal. No cooking test is required.
