# ZER0INT TEST V38 — AER end-of-frame submission

V37's diagnostic log answered the timing question conclusively: every sampled `SonsVRMod.OnLateUpdate` submission happened before `StereoRender.LateUpdate`. The previous AER pipeline therefore submitted textures aged 1 frame (fresh eye) and 2 frames (stale eye). At low application FPS that is a huge amount of head/world motion.

V38 changes only the critical timing architecture plus diagnostic cleanup:

- keeps AER one-eye-per-frame scheduling;
- keeps V36 rotation-only stale-eye reprojection;
- keeps eye-camera HDRP AA forced to `None`;
- keeps DLSS permission and dynamic-resolution permission forced off for this diagnostic;
- disables V37's failed/aggressive runtime Volume rescan;
- moves OpenVR `Submit_Default` to a `WaitForEndOfFrame` loop, after the selected HDRP eye camera has rendered;
- commits the current frame's scheduled render pose at end-of-frame, targeting 0f/1f texture ages instead of 1f/2f;
- suppresses the old MelonMod `OnLateUpdate` submit while this path is enabled, preventing double submission;
- retains sparse telemetry (2 s) for verification.

Expected success marker: during AER, pose telemetry observed from the next frame should reflect the prior EOF commit, and visible head-motion lag/tremor should drop substantially. The key behavioral test is whether fast yaw no longer produces the same large whole-scene temporal displacement.
