"""Static checks only: confirms passive V129 additions and frozen V128 renderer.
Windows IL2CPP compilation and in-game behavior are NOT tested here.
"""
from pathlib import Path
import hashlib, subprocess, sys, re
R=Path(__file__).resolve().parent
M=R/'mod'
new=(M/'NativeDlssLiveResolutionTraceV129.cs').read_text(encoding='utf-8-sig')
trans=(M/'TransitionDlssAuditV117.cs').read_text(encoding='utf-8-sig')
entry=(M/'SonsVRMod.cs').read_text(encoding='utf-8-sig')
csproj=(M/'SonsVR_Mod.csproj').read_text(encoding='utf-8-sig')
base = subprocess.run([sys.executable,str(R/'static_audit_v128.py')],capture_output=True,text=True,cwd=R)
checks={
    'V116 + V128 inherited static audit': base.returncode==0,
    'V129 passive trace included': 'Compile Include="NativeDlssLiveResolutionTraceV129.cs"' in csproj,
    'V129 tick on main update': 'NativeDlssLiveResolutionTraceV129.Tick();' in entry,
    'V129 flush on application quit': 'NativeDlssLiveResolutionTraceV129.Shutdown();' in entry,
    'V129 samples existing camera callbacks, adds no native subscriptions': 'NativeDlssLiveResolutionTraceV129.OnEyeRenderBoundary("begin", cam)' in trans and 'NativeDlssLiveResolutionTraceV129.OnEyeRenderBoundary("end", cam)' in trans,
    'V129 NVIDIA query runs after menu transition': 'DumpLiveOptimalSettingsV129' in trans and 'V129_LIVE_NVIDIA_QUERY' in trans,
    'V129 native router unchanged': 'ROUTER ACTIVE: authored MainCameraFP receiver' in (M/'NativeDlssReceiverRouterV128.cs').read_text(),
    'V129 AER protected': 'StereoRender.UserGameplayAERV112 || !NativeDlssReceiverRouterV128.Routed' in new,
    'no scene searches': 'FindObjectsOfType' not in new and 'FindObjectsOfTypeAll' not in new,
    'no new receiver clones': 'new GameObject' not in new and 'AddComponent' not in new,
    'no scaler slot/policy writes': all(k not in new for k in ('SetActiveDynamicScalerSlot','SetDynamicResScaler','SetOverride(', 'SetCurrentCameraRequest', 'SetUpscaleFilter(', 'UpdateAndUseCamera(')),
    'buffered raw TSV samples': 'SonsVR_V129_DLSS_Live_' in new and '_writer.Flush();' in new,
    'transition-window samples': 'TransitionWindowSeconds = 4.0f' in new and 'FastIntervalSeconds = 0.25f' in new,
    'current HDCamera dimensions': 'hd.actualWidth' in new and 'hd.actualHeight' in new,
    'DRS handler begin/end snapshots': '"EYE_BEGIN" : "EYE_END"' in new,
    'HDRP asset effective-policy snapshots': 'CaptureAssetPolicy()' in new,
}
# These SHA256s refer to immutable V128 files present in BOTH kits.
EXPECTED = {
    'StereoRender.cs':'f87ca07cadfb1a4e4910a4a21ea8e1d6031cd114aee61e04cd146bba430abf7c',
    # V131 adds one narrowly scoped in-HMD cue visibility condition to VRPlayer.cs.
    # The V131 audit separately checks the exact changed file SHA256.
    'UnifiedHudWorldPlaneV116.cs':'bb2faf5ad30f6009acd7a493b381a62299055fa21aae7714b0e7a363a8553f52',
    'EyeDepthCaptureCustomPassV81.cs':'a3362c34e1a4ee8fa56d5551d967f111ddce7089a507ed157249a1b3bb583138',
    'EyeMotionCaptureCustomPassV89.cs':'93e7c4cc542b0f4292cd5ed0a8c3a899df3e7ad82f9d5a90f888bb196c028c56',
    'NvOpticalFlowV90.cs':'a897d1a9a463c1d9227b86a2b37e0af45e4405524d7269c40b48f6a77448241f',
    'NativeDlssReceiverRouterV128.cs':'b159d5196e48f422e9c4326ef2cfc1162c37c4f72458cc6418fbc9e1a0365366',
    'DlssRuntimeV91.cs':'39cec1c1eaef5e620d276485dece073e1593f0dfc704849cc6cb062e09cea882',
}
for filename,sha in EXPECTED.items():
    checks['untouched V128 baseline: '+filename] = hashlib.sha256((M/filename).read_bytes()).hexdigest()==sha
for k,v in checks.items(): print(('[PASS] ' if v else '[FAIL] ')+k)
print('V129 static audit: %d/%d passed' % (sum(checks.values()),len(checks)))
if not all(checks.values()): sys.exit(1)
