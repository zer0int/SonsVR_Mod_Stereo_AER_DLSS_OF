@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
set "OUT=%ROOT%V116_TRACE_RETURN.zip"
set "GAME=D:\SteamLibrary\steamapps\common\Sons Of The Forest"
if exist "%OUT%" del /q "%OUT%"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$files=@();" ^
  "$log=Join-Path '%GAME%' 'MelonLoader\Latest.log'; if(Test-Path $log){$files+=$log};" ^
  "$settings=Join-Path '%GAME%' 'Mods\SonsVR_Settings.ini'; if(Test-Path $settings){$files+=$settings};" ^
  "$perf=Get-ChildItem (Join-Path '%GAME%' 'Mods\SonsVR_Perf_*.csv') -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 8; $files += $perf.FullName;" ^
  "$player=Join-Path $env:USERPROFILE 'AppData\LocalLow\Endnight\SonsOfTheForest\Player.log'; if(Test-Path $player){$files+=$player};" ^
  "$steam=Join-Path ${env:ProgramFiles(x86)} 'Steam\logs'; foreach($n in @('vrcompositor.txt','vrserver.txt','vrmonitor.txt')){$p=Join-Path $steam $n; if(Test-Path $p){$files+=$p}};" ^
  "$files=$files | Where-Object {$_ -and (Test-Path $_)} | Select-Object -Unique;" ^
  "if($files.Count -eq 0){ throw 'No V116/log files found.' }; Compress-Archive -Path $files -DestinationPath '%OUT%' -Force"
if errorlevel 1 exit /b %errorlevel%
echo Packed: %OUT%
echo Note: retired V114 CameraCompositorAudit log is intentionally NOT packed; it is disabled in V116 and old copies are stale.
exit /b 0
