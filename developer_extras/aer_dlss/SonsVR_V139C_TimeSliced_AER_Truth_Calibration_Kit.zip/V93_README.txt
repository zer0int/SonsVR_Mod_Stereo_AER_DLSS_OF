# SonsVR V93 — Same-Fresh-Pose OpenVR Submit A/B/A

Purpose: isolate the remaining field-dependent upper/lower wobble at the compositor boundary.

V92 result:
- RenderResolutionScale 0.8 reduced GPU time substantially but did NOT improve application cadence
  or the upper/lower artifact. V93 restores scale 1.0.
- The active world reconstruction is still full per-pixel compute scatter. 768 grid is fail-soft only.
- NVOFA did not create the artifact; V93 keeps the useful half-res NVOFA residual active throughout.

One-load A/B/A:
- 0–30 s: Submit_Default
- 30–60 s: Submit_TextureWithPose for BOTH eyes using the SAME fresh-eye HMD render pose
- >60 s: return to Submit_Default

This is deliberately NOT V34's old experiment. V34 supplied different historical poses per eye.
V93 supplies one identical fresh pose to both submitted textures, which are already aligned to that
same time by modern same-eye temporal AER.

Everything else stays constant across the timed switches:
- RenderResolutionScale 1.0
- DLSS Quality
- half-res NVOFA, residual APPLIED throughout
- per-pixel same-eye temporal depth scatter
- render-boundary target matrices
- same HUD path

Build: BUILD_V93.bat
Install BOTH OUTPUT\SonsVR_Mod.dll and OUTPUT\SonsVR_NvOF_V90.dll
Pack result: PACK_V93_TRACE.bat

Test suggestion: hold a medium/far rigid object or detailed scene in the upper problematic field
for >70 seconds if practical. A genuine change at ~30 s followed by a reversal at ~60 s is strong
evidence for compositor implicit-pose mismatch. No change demotes that hypothesis sharply.
