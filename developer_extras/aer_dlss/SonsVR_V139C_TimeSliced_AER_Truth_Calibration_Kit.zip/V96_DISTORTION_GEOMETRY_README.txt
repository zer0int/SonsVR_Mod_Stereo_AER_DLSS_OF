SonsVR V96 — OpenVR Optical Distortion Geometry Probe
========================================================

Purpose
-------
V96 is a MEASUREMENT-ONLY build layered on V95b/V94b. It does not change rendering,
DLSS, NVOFA, AER reconstruction, resolution, projection matrices, or OpenVR Submit.

At startup, V96 samples IVRSystem::ComputeDistortion() on a 17x17 grid for each eye.
OpenVR defines the mapping as:

    DISPLAY eye-viewport UV  -->  SOURCE render-target UV

with display (0,0) at the upper-left and (1,1) at the lower-right. V96 finite-
differences that mapping to obtain J_ds = d(sourceUV)/d(displayUV), inverts the
2x2 Jacobian, and converts it to pixel-equivalent coordinates for the current eye
render target. This directly asks:

    If AER is wrong by one SOURCE pixel here, how large and in what direction does
    that error appear after the headset's optical distortion?

Measurements
------------
For every one of 17x17 cells per eye, the log includes:

  * display UV and green-channel source UV
  * Jds: local display->source distortion Jacobian
  * pixelInv: inverse source-pixel-error -> display-pixel-equivalent transform
  * gainH / gainV: magnification of horizontal / vertical 1-pixel source errors
  * gainMin / gainMax: singular values (min/max directional magnification)
  * angleH / angleV: resulting display direction of source X/Y errors
  * anisotropy
  * RGB-vs-green chromatic separation in source pixels

It also prints compact per-row maps and TOP/CENTER/BOTTOM summaries.

Expected markers
----------------

  [StereoRender][AER V96][DistortionProbeBegin]
  [StereoRender][AER V96][DistortionCell]
  [StereoRender][AER V96][DistortionRow]
  [StereoRender][AER V96][DistortionBand]
  [StereoRender][AER V96][DistortionProbeEnd]

Build / run
-----------

  BUILD_V96.bat

Copy BOTH OUTPUT DLLs into the Sons Of The Forest Mods folder. The visual output is
not the experiment; once the VR rig has initialized and the probe markers have been
logged, you can quit. Then run:

  PACK_V96_TRACE.bat

and return V96_TRACE_RETURN.zip.

Notes
-----
V96 intentionally preserves V95b/V94b's rendering state, including the existing
source-matrix experiment code and NVOFA residual behavior. The new optical probe is
startup-only and does not participate in the render loop after its one-time sample.
