SONSVR V75 - exact compiled HUD mesh Y flip
================================================

V74 result:
- exact compiled meshes loaded successfully
- disc/ring/text proxies were applied
- world/tree depth orientation was correct
- the asymmetric status ring silhouette was vertically upside down

Why:
The baked canonical ring has its marker appendages in +Y.
The private RFloat render target's raster Y convention placed mesh-local +Y
toward screen-down for this direct SV_POSITION path.

V75 changes exactly one transform coefficient:

    m.m11 = syClip;
to
    m.m11 = -syClip;

This flips each exact proxy around its projected center vertically.
The disc is symmetric, the text rectangle is symmetric, so the ring is the
only visually diagnostic shape.

No dense planar remap.
No HUD layout change.
No V51 world reconstruction change.
No proxy depth change.

Build:
  BUILD_V75.bat

Install only:
  OUTPUT\SonsVR_Mod.dll

Useful log:
  COMPILED exact meshes READY (V75 meshYFlip=True)
