SONSVR V76 - DENSE PLANAR HUD REMAP
===================================

WHY THIS IS THE NEXT REAL FIX
-----------------------------
V72/V74 proved that the HUD needs its own geometric treatment, but fake 0.5m
depth still sends HUD/background pixels through V51's sparse world warp. At
near-field stereo disparity that produces the horizontal "HUD lasagna" and the
flickering dark HUD plane.

V76 stops doing that.

PIPELINE
--------
REAL SOURCE EYE
    |
    +-- exact HUD silhouettes -> private depth is set INVALID (raw 0)
    |       HUD pixels therefore DO NOT enter V51 world forward warp
    |
    +-- ordinary world pixels -> unchanged V51 warp/fill/target fallback
                                      |
                                      v
                               synthetic target world
                                      |
                                      +-- exact dense HUD planar composite
                                          from CURRENT source eye
                                          into TARGET-eye geometry

No sparse HUD splats.
No 0.5m fake-depth world plane.
No old target HUD in the final exact target silhouettes.

EXACT GEOMETRY
--------------
disc  -> map
ring  -> status ring, with V75 vertical flip retained
rect  -> MessageList

TEXT
----
The user explicitly accepted a solid black backing for text. Since the eye RT
does not preserve a clean UI alpha channel, V76 intentionally makes the message
rectangle opaque black and copies bright neutral text/icons from the current
source eye. This avoids copying a rectangular chunk of source-eye forest into
the target eye.

NO TIMED PHASES
---------------
This is the normal path immediately after the existing 4-frame AER warmup.

BUILD
-----
  BUILD_V76.bat

Install only:
  OUTPUT\SonsVR_Mod.dll

VALIDITY LOGS
-------------
  [AER V76][HudMask] APPLIED ... depthMode=INVALID-CUTOUT-FOR-DENSE-HUD
  [AER V76][DenseHUD] DIRECT PLANAR HUD COMPOSITE IS ACTIVE
  [AER V51][DepthWarp] SYNTHETIC OPPOSITE EYE IS NOW IN THE HEADSET PATH

WHAT TO JUDGE
-------------
1. ring orientation/position (V75 Y flip included)
2. map/ring tearing and jitter
3. disappearance of the flickering dark 0.5m HUD plane
4. MessageList stability (expect deliberately boring black backing)

This is no longer a geometry-only probe; it is the intended architectural
separation of WORLD reconstruction from HUD reconstruction.
