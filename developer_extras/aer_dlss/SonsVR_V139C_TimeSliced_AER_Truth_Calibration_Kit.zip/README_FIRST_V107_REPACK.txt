﻿SONSVR V107 REPACK — VERIFIED PACKAGE
=====================================

This repack exists because the previous attachment surfaced a stale/wrong ZIP.

REQUIRED ROOT FILES VERIFIED PRESENT:
  - BUILD_V107.bat
  - PACK_V107_TRACE.bat
  - V107_PERFORMANCE_FIXES_README.txt
  - V107_STATIC_AUDIT.txt

BUILD:
  Run BUILD_V107.bat from this folder.

V107 source markers verified in mod/VRPlayer.cs and mod/StereoRender.cs.
