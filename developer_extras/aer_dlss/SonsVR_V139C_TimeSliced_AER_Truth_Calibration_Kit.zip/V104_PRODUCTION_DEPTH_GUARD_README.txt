SonsVR V104 -- PRODUCTION DEPTH-GUARDED AER BASELINE
=====================================================

Status
------
V103 perceptual testing found that the depth-coherence guarded hole fill removed the
long-standing visible AER wobble in the tested forest/tarp view. V104 promotes that
exact guarded fill policy to the permanent normal-play renderer.

Production renderer
-------------------
1. Same-eye temporal 6DoF AER remains the primary synthetic-eye reconstruction.
2. Real DLSS Quality remains enabled.
3. NVIDIA Optical Flow / NVOFA residual use is restored for normal rendering.
4. R1/R2 spatial hole fill is ALWAYS depth guarded:
     - candidates come only from ORIGINAL direct-scatter pixels;
     - every candidate must have a valid winning target-depth key;
     - the dominant mutually-consistent depth cluster is selected;
     - defaults: max(0.30 m, 6% relative) depth agreement;
     - at least 2 neighbors and 60% of available valid neighbors must support it;
     - R1 fabricated colors NEVER become evidence for R2.
5. Ambiguous/unfilled pixels fall through to V100's rotation-only/infinite-depth
   true-hole fallback.
6. If the guard's direct-scatter depth-key resource is unexpectedly unavailable,
   V104 FAILS SAFE TO NO SPATIAL FILL + V100 fallback. It never resurrects the old
   unguarded cross-depth HoleFill.
7. Heavy V99/V102 truth readbacks and V103 HMD A/B/C cues are OFF in production.
8. V36 whole-eye rotational reprojection remains HARD-OFF.

Why this fixes the wobble
-------------------------
The historical HoleFill averaged any occupied neighbor around a reconstruction hole,
regardless of depth layer, then allowed R1-generated pixels to seed the R2 pass. At
foliage/treelines/disocclusions this could mix near leaf cards, farther rock/trees,
and background into one synthetic patch. Head motion then made that patch behave like
a moving cardboard depth slice. The depth guard refuses to invent a pixel unless its
neighbors agree on one geometric layer.

Build / install
---------------
1. Run BUILD_V104.bat
2. Copy BOTH OUTPUT\SonsVR_Mod.dll and OUTPUT\SonsVR_NvOF_V90.dll to:
     D:\SteamLibrary\steamapps\common\Sons Of The Forest\Mods
3. Play normally. There is no scripted HMD protocol in V104.

Suggested normal-play validation
--------------------------------
Try a broad mix rather than one forensic pose:
- dense layered forest / treelines / sky silhouettes
- close grass and feet
- rapid head rotation and normal locomotion
- jumping / crouching / turning
- combat / swinging tools
- swimming and water surfaces
- caves / interiors / fire / particles
- tarp inventory, crafting/cooking and other historically expensive menus

The crafting/cooking lag is known to predate this graphics fix and should be treated
as a separate bug if it persists.

If a visual regression appears
------------------------------
Run PACK_V104_LOG.bat after leaving VR and send V104_LOG_RETURN.zip. A future targeted
experiment can reuse the retained in-HMD cue infrastructure for precise reproduction.
