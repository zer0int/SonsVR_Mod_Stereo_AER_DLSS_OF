# V133: passive, native DLSS per-eye state inspection

This is a **read-only diagnostic**, based on the V132B source but with the V132 two-stage mutations disabled. V128 native DLSS receiver routing, V116 HUD/renderer/depth shader and AER remain unchanged.

## What we learned from your offline V133 wrapper bundle

- `DynamicResolutionHandler.m_MinScreenFraction`, `s_ScalerContainers` and `s_ActiveScalerSlot` are generated IL2CPP **properties**, not ordinary CLR fields. V132's `GetField` discovery was therefore insufficient.
- The scaler containers hold both `PerformDynamicRes method` and `DynamicResScalePolicyType type`.
- `HDRenderPipeline.m_DLSSPass` exposes `DLSSPass.m_CameraStates` (dictionary keyed by camera ID), with per-camera `ScaleDelegate` and per-view states.
- `ViewState` contains `m_Data` (actual `DlssViewData.perfQuality/inputRes/outputRes`), `m_OptimalSettingsRequest`, `m_UsingOptimalSettings`, `m_UseAutomaticSettings`, and `DLSSContext` (which may expose actual initialized NVIDIA quality).
- The *managed IL2CPP wrappers* cannot prove what the compiled native implementation does; this runtime probe queries its **live data objects** without intercepting ExecuteDLSS.

## Build

1. Extract the complete V133 kit into a separate folder, e.g. `C:\Users\zer0int\Sons_of_the_Forest_VR\v133`.
2. Run `BUILD_V133.bat` (Windows, Unity Editor 2022.2.16f1 at the same configured path as previous kits).
3. Install generated mod files from `OUTPUT`, backing up the working V128/V129 ones.

## Test

Enter 2E gameplay (not AER). Select Quality ~6 sec, Ultra Performance ~6 sec, then Quality ~6 sec. If convenient, try Off once. No HMD cues or exact timing necessary. **Stop if the game becomes unstable.** Run `PACK_V133_TRACE.bat` and return the ZIP.

Look for `[V133 DLSS-FEATURE]` in `Latest.log`. Read-only sampling occurs at 2-second intervals only when the native V128 route is active. V129 render-boundary TSV measurements remain enabled.

If `states=NOT_FOUND` or `ctxQ=NA`, the probe has not resolved that metadata; **that is not evidence that DLSS did not execute**. The complete log will identify the next exact accessor to adjust offline. No reflection setter, slot mutation, callback invocation or NVIDIA feature call is used.

## Limitations

Static audit runs on Linux; **Windows compilation and in-game runtime have not been verified here**. The generated nested IL2CPP objects may not expose every property in runtime reflection. The test is designed to fail passively if a property is unreadable.
