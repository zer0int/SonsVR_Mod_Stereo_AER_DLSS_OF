SONSVR V68 - CLEAN AER CAUSALITY A/B
====================================

WHY V68 EXISTS
--------------
V67 was accidentally confounded:

  FULL-STEREO CONTROL:
      AER = OFF
      safe pre-render HUD transform sync = OFF

  AFTER AER ACTIVATION:
      AER = ON
      safe pre-render HUD transform sync = ON

The user observed that the map locomoted in full stereo and became "stapled" to
a fixed head-relative plane after AER switched on. The V67 log confirms the
first safe HudTiming callback did not occur until AFTER the AER warmup ended.

V68 fixes ONLY that experiment design.

During the 15-second full-stereo control:
  - AER is OFF
  - safe transform-only HUD/minimap sync is ALREADY ON
  - sync runs once per Unity frame before the first VR eye renders

After 15 seconds:
  - AER turns ON
  - the exact same HUD sync remains ON

Therefore the boundary now isolates AER itself.

NO:
  - Canvas.ForceUpdateCanvases
  - raw UGUI capture/replay
  - CanvasRenderer culling
  - manual UI drawing
  - extra HUD camera
  - mask/material changes
  - HUD geometry changes

TEST
----
Move/turn/jump continuously throughout both phases.

Watch:
  1) map/ring coarse locomotion or depth pumping
  2) high-frequency map/ring jitter
  3) message/objective text jitter

Critical logs:
  [AER V68][HudTiming] SAFE PRE-RENDER HUD SYNC ACTIVE IN FULL-STEREO + AER
  [AER V68][AB] FULL-STEREO + PRE-RENDER-SYNC CONTROL WINDOW START
  [AER V68][AB] CONTROL WINDOW END -> ACTIVATING AER
  [AER V51][DepthWarp] SYNTHETIC OPPOSITE EYE IS NOW IN THE HEADSET PATH

Build:
  BUILD_V68.bat

Install only:
  OUTPUT\SonsVR_Mod.dll
