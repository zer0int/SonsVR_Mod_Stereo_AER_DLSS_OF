from pathlib import Path
import subprocess, sys, hashlib
R=Path(__file__).resolve().parent; M=R/'mod'
r=subprocess.run([sys.executable,str(R/'static_audit_v129.py')],cwd=str(R),capture_output=True,text=True)
checks={
    "V129 inherited static audit":r.returncode==0,
    "new V130 source included":'Compile Include="NativeDlssOptimalOverrideV130.cs"' in (M/'SonsVR_Mod.csproj').read_text(),
    "new V130 tick hooked":'NativeDlssOptimalOverrideV130.Tick();' in (M/'SonsVRMod.cs').read_text(),
    "post-copy gate":'_hdrpDataCopiedOnce' in (M/'NativeDlssOptimalOverrideV130.cs').read_text(),
    "single logical policy experiment":'deepLearningSuperSamplingUseCustomAttributes = true' in (M/'NativeDlssOptimalOverrideV130.cs').read_text() and 'deepLearningSuperSamplingUseOptimalSettings = true' in (M/'NativeDlssOptimalOverrideV130.cs').read_text(),
    "AER bypass":'StereoRender.UserGameplayAERV112' in (M/'NativeDlssOptimalOverrideV130.cs').read_text(),
    "no global DRS or receiver mutation":all(t not in (M/'NativeDlssOptimalOverrideV130.cs').read_text() for t in ['SetDynamicResScaler(', 'SetActiveDynamicScalerSlot(', 'SetDynamicResolutionOption(', 'SetOverride(', 'SetUpscaleFilter(', 'new GameObject(', 'Register(', 'ApplyDlssSetting(', 'FindObjectsOfType(']),
    "V129 live input trace plus V131 durable-flush helper verified":hashlib.sha256((M/'NativeDlssLiveResolutionTraceV129.cs').read_bytes()).hexdigest()=="4129a0205c0ca419a409a2f7bd625fa794dc4ff6d24724816c25c79120c71b8f",
    "V128 native router preserved":hashlib.sha256((M/'NativeDlssReceiverRouterV128.cs').read_bytes()).hexdigest()=="b159d5196e48f422e9c4326ef2cfc1162c37c4f72458cc6418fbc9e1a0365366",
    "V116 renderer/HUD/depth preserved; V131 cue extension verified":all(hashlib.sha256((M/f).read_bytes()).hexdigest()==v for f,v in {
        "StereoRender.cs":"f87ca07cadfb1a4e4910a4a21ea8e1d6031cd114aee61e04cd146bba430abf7c",
        "VRPlayer.cs":"80b47a626ba418c659f873521d3f7d1c615d81cad297161222cf04c45ed20e61",
        "UnifiedHudWorldPlaneV116.cs":"bb2faf5ad30f6009acd7a493b381a62299055fa21aae7714b0e7a363a8553f52",
        "EyeDepthCaptureCustomPassV81.cs":"a3362c34e1a4ee8fa56d5551d967f111ddce7089a507ed157249a1b3bb583138",
        "EyeMotionCaptureCustomPassV89.cs":"93e7c4cc542b0f4292cd5ed0a8c3a899df3e7ad82f9d5a90f888bb196c028c56",
        "NvOpticalFlowV90.cs":"a897d1a9a463c1d9227b86a2b37e0af45e4405524d7269c40b48f6a77448241f",
    }.items()),
}
for k,v in checks.items(): print(('[PASS] ' if v else '[FAIL] ')+k)
print(f"V130 audit: {sum(checks.values())}/{len(checks)} passed")
if not all(checks.values()): print(r.stdout[-1000:]); sys.exit(1)
