SonsVR V127 - passive DLSS/DRS contract probe; V116 RENDERER BASELINE
================================================================

Source modification: only mod/SonsVRMod.cs (one Tick() call), mod/SonsVR_Mod.csproj
(one Compile Include), and new mod/NativeDlssContractTraceV127.cs.
The complete rest of the source tree, HUD, AER reconstruction and shaders are V116.
This is NOT a new DLSS reroute; it is a controlled observation designed to isolate
which native subsystem actually resets the apparent DLSS quality.

BUILD:
1. Edit UNITY_EXE in BUILD_V127.bat only if necessary.
2. Run BUILD_V127.bat (builds Unity shader bundle + native bridge + C# mod).
3. Back up the currently installed mod. Replace it with OUTPUT/SonsVR_Mod.dll
   and OUTPUT/SonsVR_NvOF_V90.dll per existing V116 build instructions.
4. Start in whichever render mode you last selected. For the DLSS test use 2E.
5. Select game graphics menu DLSS Quality, wait ~5s; Ultra Performance,
   wait ~5s; Quality, wait ~5s. No forced timed HMD action or log watching.
6. Run PACK_V116_TRACE.bat and send the trace ZIP. Share Latest.log even if
   the packer errors.

OBSERVATIONS:
* [V127 DLSS-CONTRACT] logs manager native option/quality, the game's
  DynamicResolutionScaler.GetCurrentScale(), stereo camera HDRP DLSS flags,
  custom quality enum, optimal flag, and target texture dynamic sizing.
* [V127 DLSS-RECEIVERS] logs the registered native receivers (only every 4s).
* Sampling is 20Hz, but logs are change-only + low-rate heartbeat; it cannot
  guarantee catching an exactly one-frame transient. The V116 HDRP trace is
  preserved and may capture additional changes.
* There are NO writes to any quality, scaler, camera or receiver by the NEW
  telemetry. Existing V116 DLSS init code remains unchanged, including its
  known one-time game-quality policy and per-eye custom settings.
* No FindObjectsOfType, GameObject creation, or per-frame IL2CPP list walk.

POSSIBLE INTERPRETATIONS:
A. managerQuality itself reverts -> native menu/settings/preset owner.
B. managerQuality stable, native receiver quality changes -> receiver refresh.
C. native receiver stable, camera QCode/Optimal changes -> HDRP camera config.
D. QCode stable, scaler.CurrentScale changes -> resolution scaler / HDRP DRS.
E. all stable but input dims change -> investigate HDRP DynamicResolutionHandler
   and optimal lattice / target scaling, not the DLSS menu preset.

CAVEAT: C# compilation/runtime behavior cannot be verified in this Linux analysis
sandbox because the Windows game/Unity and its full MelonLoader runtime are absent.
If compilation fails, send the compiler output; do not change the game config.
