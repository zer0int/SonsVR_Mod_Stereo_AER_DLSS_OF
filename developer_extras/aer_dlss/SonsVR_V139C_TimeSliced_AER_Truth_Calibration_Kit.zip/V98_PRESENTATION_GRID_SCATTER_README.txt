SonsVR V98 - DLSS PRESENTATION-GRID SCATTER A/B/A
==================================================

V97 proved that HDRP COLOR/DEPTH/MOTION all share the same RTHandle viewport:
  active viewport: 1572x1660
  final historical/post-DLSS color: 3141x3317
  physical RTHandle allocation: 3840x3317

The important consequence is in V88/V90 scatter itself.  After real DLSS was
introduced, scatter still dispatched one source thread per DEPTH pixel.  That is
only about 2.61 M direct source samples for a 10.42 M presentation raster (~25%).
The radius-1 HoleFill therefore manufactures most final pixels even in a simple
identity/no-motion case.

V98 tests ONLY this lattice choice:

  A  0..30s : INTERNAL-DEPTH-GRID source dispatch (current V97 behavior)
               source grid = 1572x1660

  B 30..60s : PRESENTATION-GRID source dispatch
               source grid = historical post-DLSS color size (3141x3317)
               depth remains the SAME 1572x1660 camera-local texture
               every source/color pixel fetches nearest depth by normalized UV

  A2 >60s   : return to INTERNAL-DEPTH-GRID

No extra depth detail is invented in B.  The experiment only stops throwing away
3/4 of the post-DLSS historical color sampling lattice before reprojection.

NVOFA hardware continues to execute at the same half-resolution workload/history,
but its residual is ignored throughout V98 so the original pre-OF jitter remains
visible.  V94 source-matrix A/B is disabled (it was a perceptual null).

Watch medium/far rigid detail in the troublesome upper field through both 30 s and
60 s transitions.  The decisive pattern would be bad -> substantially quieter ->
bad again.  Also note whether the top/bottom boundary or directional character moves.

Build:
  BUILD_V98.bat

Install BOTH DLLs from OUTPUT into the game Mods directory.

Pack after the run:
  PACK_V98_TRACE.bat
