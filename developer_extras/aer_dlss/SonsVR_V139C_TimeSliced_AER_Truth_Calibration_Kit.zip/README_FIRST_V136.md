# V136 — Camera-scoped native DLSS ScaleFn experiment

**Source base:** V133B (known-good passive renderer), NOT V135. Keeps V116 HUD, V103 depth fill, AER, and V128 native receivers unchanged.

## What the offline source inspection PROVED

Unity Graphics `2022.2/staging` HDRP `DLSSPass.cs`:
- `InternalNVIDIASetupDRSScaling` registers `cameraState.ScaleDelegate` in the **System** scaler and activates that slot.
- `CameraState.ScaleFn()` computes `min(optimalWidth/viewportWidth, optimalHeight/viewportHeight)*100`.
- `InternalNVIDIARender` builds the actual `DlssViewData` from HDRP's live input/output dimensions and selected quality.
- The game's collected IL2CPP wrapper exposes `CameraState.ScaleFn():float`, `CameraState.ScaleDelegate`, and `DLSSPass.m_CameraStates`.

Thus V135's global User/System slot wrestling is unnecessary for the new experiment.

## V136 single intervention

Harmony-prefix only the private `DLSSPass.CameraState.ScaleFn()` method, returning `66.7f` **only** when its native `CameraState` instance matches the left or right VR eye registered in `m_CameraStates`. All other cameras execute their original ScaleFn. No global slot setters, no handler-fraction/minimum writes, no camera-optimal flag changes, and no feature-create/destroy calls.

**Important remaining uncertainty:** Harmony/IL2CPP may intercept only the generated wrapper while Unity invokes the native method via its stored delegate. In that case the `PATCH_INSTALLED` message is not sufficient; there will be no `HOOK_HITS`. This is a test of the callback interception path. It is NOT a proven fix.

## Build and single test

1. Run `BUILD_V136.bat` (standalone kit), and install two DLLs and shader bundle from `OUTPUT` after backing up V128/V133B.
2. Start in **2E** with native game-menu DLSS **Quality**; no mode/quality sweep required. Let gameplay render 10–15 seconds; exit.
3. Run `PACK_V136_TRACE.bat`, send the ZIP. If left/right output freezes, kill the process and pack before relaunch.

Success requires BOTH nonzero `[V136 DLSS-SCALEFN] HOOK_HITS L=... R=...` AND stable real per-eye `~2095x2212` input dimensions in the V129 TSV, plus acceptable stereo. A `PATCH_INSTALLED` log without `HOOK_HITS` means the native delegate bypassed this patch; do not claim success. If target/pointer resolution fails, V136 leaves the renderer at V133B behavior.

If this works, later builds can map the return percentage to Endnight's menu quality and test 33%. No automatic sweep in V136.

**Known risk:** even a correctly scoped 67% callback can trigger DLSS input-size resource rebuilds. V132/V135 demonstrated stereo instability when scale changes occur. This build is experimental.

Offline source reference: https://raw.githubusercontent.com/Unity-Technologies/Graphics/2022.2/staging/Packages/com.unity.render-pipelines.high-definition/Runtime/RenderPipeline/RenderPass/DLSSPass.cs
