SONSVR V78 — PASSIVE HDRP / DLSS / RTHandle RUNTIME TRACE
========================================================

OFFLINE FORENSICS FOUND
-----------------------
Game-side:
  Sons.Dlss.DynamicResUpscaleManager
  DynamicResolutionSettingReceiver
  DlssSettingChanged
  DynamicResolutionSettingChanged
  Fsr3SettingChanged
  _dynamicResUpscaleActive
  MipMapLimit
  _mipMapLimitBudgets

Unity Core/HDRP:
  RTHandles.rtHandleProperties
  DynamicResolutionHandler.finalViewport
  DynamicResolutionHandler.filter
  runUpscalerFilterOnFullResolution
  hardware/software DRS state
  SetUpscaleFilter
  CalculateMipBias
  mipMapBias / m_UseMipBias
  ScalableBufferManager width/height scale
  XR eyeTextureResolutionScale / renderViewportScale
  HDRP InternalNVIDIASetupDRSScaling
  HDRP PushCameraGlobalMipBiasPass
  HDRP GenerateDepthPyramid

V78 IS PASSIVE ONLY
-------------------
The V77 renderer is unchanged. The tracer only reads state and writes a TSV.

It captures:
  - RTHandles current/previous viewport and allocation properties
  - DynamicResolutionHandler filter/final viewport/DRS flags
  - ScalableBufferManager
  - XR render scaling
  - MainCameraFP / VRLeftEye / VRRightEye dimensions and HDRP camera state
  - Sons.Dlss manager active options / quality
  - SettingsWrappers mip/upscale state
  - Sons.Quality screen-percentage state
  - pipeline-asset DRS/mip fields
  - _CameraDepthTexture / color / motion / depth-pyramid allocation + mip count
  - _RTHandleScale, _ScreenSize, _DynamicResolutionScreenSize, _ZBufferParams

It captures the full setting surface change-only at 2 Hz, and a lightweight exact render-state snapshot ~4 Hz at:
  SRP_BEGIN
  SRP_END_PRE_DEPTH

SRP_END_PRE_DEPTH is the exact callback where V50 reads _CameraDepthTexture.

ONE SESSION
-----------
No visual judgement required.

Once gameplay/AER is active:
  1. Current normal setting: wait ~3 sec.
  2. Set DLSS / superscaling fully OFF: wait ~3 sec.
  3. Set ONE DLSS mode (Quality is fine): wait ~3 sec.
  4. Set it fully OFF again: wait ~3 sec.
  5. Quit normally.

Build:
  BUILD_V78_TRACE.bat

Install only:
  OUTPUT\SonsVR_Mod.dll

After the run:
  PACK_V78_TRACE.bat

Send:
  V78_TRACE_RETURN.zip

The dedicated trace lives at:
  <game>\MelonLoader\Logs\SonsVR_HDRP_DLSS_TRACE_YYYYMMDD_HHMMSS.tsv

WHAT WOULD BE THE SMOKING GUN?
------------------------------
For example:

DLSS ON:
  currentViewportSize = A x B
  currentRenderTargetSize = 3840 x 4976
  depth allocation stays 3840 x 4976

DLSS OFF:
  currentViewportSize = C x D
  allocation still 3840 x 4976

while V50 blindly copies 3141 x 3317 integer pixels in both cases.

If C/D or A/B are smaller/differently scaled than the V50 copy, then part of
V50 is reading outside active mip-0 and into the packed depth-pyramid atlas /
stale allocation contents. That would neatly explain why the failure rectangle
moves when DLSS/superscaling state changes.


PERFORMANCE NOTE
----------------
Reflection type discovery is cached once at startup; SRP boundary tracing is throttled and does not scan all assemblies per frame.
