SONSVR V83 — SAME-EYE TEMPORAL AER + DEPTH TRUTH BOARD
=========================================================

THIS IS NOT V36
---------------
V36 rotation-only stale-eye homography is HARD-DISABLED.

V83 does full matrix/depth reprojection:

  RIGHT(t-1) color
+ RIGHT(t-1) camera-local depth
+ RIGHT render pose/projection(t-1)
+ desired RIGHT pose/projection(t)
-> predicted RIGHT(t)

and vice versa.

The fresh eye is always the real eye rendered by HDRP this frame.

NO CROSS-EYE WORLD SYNTHESIS
----------------------------
V82:
  LEFT(t) + LEFT depth(t) -> try to manufacture RIGHT(t)

V83:
  RIGHT(t-1) + RIGHT depth(t-1) -> predict RIGHT(t)

So the permanent binocular-disocclusion problem is removed.
Any remaining holes are genuinely TEMPORAL: newly exposed surfaces caused by
motion since that same eye last rendered.

DEPTH SOURCE
------------
V83 intentionally starts with the camera-local source identified in V81f:

  CustomPassContext.cameraDepthBuffer

Temporal history is accepted only if its latch says:
  UsedCustomPassDepthV82 == true

There is NO silent mipmap-depth fallback in the V83 temporal renderer.

V47 DEPTH TRUTH COMPARISON
--------------------------
The desktop board now has 2 rows x 3 columns:

  [ fresh real eye ]
  [ predicted stale eye from same-eye history ]
  [ raw same-eye history color ]

  [ temporal coverage ]
  [ LOCAL ctx.cameraDepthBuffer ]
  [ GLOBAL old V47 lower-left mip0 ]

The two depth panels are captured on the SAME rendered eye/frame before the
HUD depth proxies modify the V50/V82 latch.

Both use the same ZBufferParams and identical grayscale log-depth visualization:
  white   = near valid depth
  gray    = farther valid depth
  black   = zero / invalid / > max distance

The GLOBAL panel deliberately reproduces the OLD V47 candidate A:
  packed _CameraDepthTexture mip0 begins at pixel offset (0,0)

This gives a visual A/B against cameraDepthBuffer without changing what drives
the headset warp.

HUD
---
The latest HUD work is RETAINED.

Historical HUD regions are cut out by the existing private depth-latch proxy
machinery, and the current HUD is composited after the world temporal warp using
the existing V76 dense/exact target-eye path.

FALLBACK
--------
Remaining temporal holes fall back to RAW SAME-EYE history at the same UV.

V36 is never called.

If V83 prediction cannot be prepared (warmup / missing history / error),
StereoRenderPass submits the raw retained LeftRT/RightRT pair. It still does
NOT call V36.

EXPECTED LOG
------------
Look for:

  [AER V83][Temporal] SAME-EYE TEMPORAL READY
  [AER V83][Temporal] HEADSET PATH ACTIVE
  [AER V83][TemporalTelemetry]

Normal history age should usually be about 1 Unity frame.

WHAT TO LOOK FOR VISUALLY
-------------------------
The V82 giant cross-eye jagged/frustum-hole disaster should change dramatically
if the diagnosis is right.

Things that MAY remain:
  - moving hands / axe / NPC temporal double edges
  - newly revealed geometry after fast translation
  - small hole-fill/fallback seams
  - HUD-specific quirks

Those are the next temporal-motion problem, not permanent binocular holes.

BUILD
-----
  BUILD_V83.bat

If shader validation or C# compilation fails, do not launch; send the output.

RUN
---
This one is worth wearing the headset for, because the expected difference from
V82 is visually dramatic.

No formal DLSS protocol is required for the first impression.

Useful quick checks:
  1. stand mostly still, rotate head
  2. translate / lean / walk
  3. wave axe / look at hands
  4. glance at HUD
  5. optionally toggle DLSS after establishing baseline

Also grab one desktop screenshot of the 6-panel board if convenient.

PACK
----
  PACK_V83_TRACE.bat

Send:
  V83_TRACE_RETURN.zip
