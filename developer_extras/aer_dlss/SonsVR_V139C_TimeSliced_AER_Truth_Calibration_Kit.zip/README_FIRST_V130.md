# V130 — controlled 2E-only HDRP optimal-settings A/B

**Finding from V129:** The actual HDRP input resolution is exactly 1572x1660 (50%) for Quality, Balanced, and Ultra Performance; DLSS Off renders at 3141x3317 (100%). V128 native quality routing is working. The player's gameplay HUD camera-copy operation also changes the eye camera's Optimal flag True->False. All actual quality sweep samples had CustomAttrs=False, so the per-eye Optimal flag was not in control.

**What V130 tests:** After `_hdrpDataCopiedOnce` becomes true and V128's native 2E receivers are confirmed routed, V130 sets ONLY `deepLearningSuperSamplingUseCustomAttributes=true` and `deepLearningSuperSamplingUseOptimalSettings=true` on BOTH eye cameras. That activates HDRP's per-camera optimal-settings policy without modifying native quality, registration, NVIDIA features, RTs, global handler, scaler slot, or viewport. No changes to AER, V116 HUD, shader, renderer, or V103 depth guard. V129 render-boundary telemetry is retained. If another component resets these flags, V130 logs OVERRIDE LOST and does not fight it.

The two boolean writes are one logical HDRP policy switch: enabling camera-specific attributes and choosing the optimal setting. They are not separate upscale-filter/scaler-slot overrides.

## Build
1. Back up V129/V128 Mods DLLs.
2. Run `BUILD_V130.bat` in the extracted folder. As before the script invokes the Unity shader-bundle builder and native OF-bridge compiler before building the mod DLL. Ensure `UNITY_EXE`/game paths are correct.
3. Copy `OUTPUT\SonsVR_Mod.dll` and `OUTPUT\SonsVR_NvOF_V90.dll` to the game's Mods folder.

## Minimum test (no HMD prompts required)
- Enter actual gameplay in **2E**, not AER.
- Confirm in `Latest.log` *afterwards* there was a `[V130 DLSS-OPT] APPLIED after gameplay native HDRP CopyTo` marker. No in-HMD log reading is required.
- In the normal game's graphics menu, use **Quality (~8s) -> Ultra Performance (~8s) -> DLSS Off (~8s) -> Quality (~8s)**. No need to prevent NPCs from wandering around; we measure input dimensions, not GPU timings.
- Exit normally, run `PACK_V130_TRACE.bat`, send `V130_TRACE_RETURN.zip`.

## Outcomes
- If active inputs now differ according to preset, the missing per-eye optimal policy was the cause, and we can carry it forward guarded behind the verified gameplay-camera-copy gate.
- If the attributes remain True/True but all presets still render at 50%, the limitation lies farther downstream (global HDRP asset's forced resolution/min-max policy, Unity NVIDIA optimal-query behavior, or the actual DLSS feature path). Crucially do NOT start forcing scaler slots or dynamic-resolution callbacks from that alone.
- If V130 logs OVERRIDE LOST, something else is rewriting these fields; inspect the exact transition time instead of escalating with a per-frame write battle.
- If OFF/2E rendering breaks or instability occurs, abort and revert to V129 (then V128 if necessary). AER is unmodified; avoid testing AER with a newly altered DLSS lattice in the same experiment.

## Limitations
This is a source/build kit. Linux-side static checks are available; cannot compile against your Windows Unity/MelonLoader install or run the game here. The V129 HDRP asset-policy reflection reports NOT_FOUND, so the global asset policy is still unknown.
