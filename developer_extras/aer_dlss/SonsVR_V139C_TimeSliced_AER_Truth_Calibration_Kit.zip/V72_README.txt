SONSVR V72 - INVISIBLE HUD DEPTH PROXIES
=========================================

WHAT THIS DOES
--------------
The normal HUD color render is untouched.

After each real VR eye has finished rendering, V50 already copies HDRP's exact
eye-local depth into its own RFloat texture. V72 then paints three crude support
surfaces ONLY into that private AER depth texture:

  1) GPS ScreenMask -> filled circle/ellipse
  2) visible VitalsRenderTexture -> filled circle/ellipse
  3) active MessageList child Graphics -> one rectangular union

Their depth is measured from the actual world-space HUD transforms in the
current source eye (normally ~0.5 m).

The proxy shader never touches the game's visible color target and never writes
to the camera's normal scene depth buffer. It is literally metadata/support
geometry for AER reconstruction only.

WHY THIS IS DIFFERENT FROM V69
------------------------------
V69 special-cased broad rectangles inside the warp shader. V72 instead modifies
the actual owned depth texture BEFORE V51 samples it, so the normal V51
discontinuity / confidence / hole logic sees the proxies as ordinary near
geometry. Circle edges also behave like real depth discontinuities.

EXPECTED VISUAL SIDE EFFECT
---------------------------
The proxies are intentionally coarse. Background pixels inside a filled proxy
can also inherit the nearby HUD depth in the synthetic eye, so there may be a
flat-looking patch behind the HUD. Ignore that for this test. The question is:

  DOES THE FAMILIAR HUD JITTER REDUCE / DISAPPEAR?

No timed A/B phases. No waiting for a phase change. Just enter gameplay and look.

BUILD
-----
  BUILD_V72.bat

Install only:
  OUTPUT\SonsVR_Mod.dll

CRITICAL LOGS
-------------
  [AER V72][HudDepthProxy] secondary depth-only shader loaded
  [AER V50][DepthLatch] CAPTURED eye=L/R
  [AER V72][HudDepthProxy] APPLIED eye=L/R count=...
  [AER V51][DepthWarp] SYNTHETIC OPPOSITE EYE IS NOW IN THE HEADSET PATH

If SetPass(4) ever fails, STOP: the run is invalid (the main V51 path broke).
