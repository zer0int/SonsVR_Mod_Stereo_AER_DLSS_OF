from pathlib import Path
import re, sys

root = Path(__file__).resolve().parent
mod = root / 'mod'
paths = {
    'hud': mod/'NativeHudCompositorV114.cs',
    'audit': mod/'CameraCompositorAuditV114.cs',
    'vr': mod/'VRPlayer.cs',
    'stereo': mod/'StereoRender.cs',
    'settings': mod/'RuntimeSettingsV105.cs',
    'main': mod/'SonsVRMod.cs',
    'proj': mod/'SonsVR_Mod.csproj',
}
files = {k:p.read_text(encoding='utf-8-sig') for k,p in paths.items()}
checks=[]
def add(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
def has(k,s): return s in files[k]

add('V114 compositor source registered', has('proj','<Compile Include="NativeHudCompositorV114.cs" />'))
add('V114 camera audit source registered', has('proj','<Compile Include="CameraCompositorAuditV114.cs" />'))
add('Old V113 compositor source not registered', 'NativeHudCompositorV113.cs' not in files['proj'])
add('No live V113 compositor class references', not any('NativeHudCompositorV113' in files[k] for k in files if k != 'proj'))
add('HUD RT remains 1920x1080 ARGB32', has('hud','TextureWidth = 1920') and has('hud','TextureHeight = 1080') and has('hud','RenderTextureFormat.ARGB32'))
add('HUD plane narrowed to 60 degrees', has('hud','OverlayHorizontalFovDegrees = 60.0f'))
add('HUD plane stays finite at 1.20m', has('hud','OverlayDistanceMeters = 1.20f'))
add('HUD capture camera moved away from 100000 precision trap', has('hud','new Vector3(1000f, 1000f, 1000f)') and '100000f' not in files['hud'])
add('HUD camera has tight 0.5..1.5 clip interval', has('hud','HudNearClip = 0.50f') and has('hud','HudFarClip = 1.50f'))
add('HUD camera starts with zero culling mask', has('hud','_hudCamera.cullingMask = 0;'))
add('HUD production mask is computed from native canvas trees', has('hud','ComputeCanvasUiLayerMask(_screenCanvas)') and has('hud','ComputeCanvasUiLayerMask(_minimapCanvas)'))
add('HUD production mask inspects CanvasRenderer layers', has('hud','GetComponentsInChildren<CanvasRenderer>(true)'))
add('V113 full HUD culling mask removed', '_hudCamera.cullingMask = ~0' not in files['hud'] and '_hudCamera.cullingMask = -1' not in files['hud'])
add('HUD camera uses transparent constant clear', has('hud','HDAdditionalCameraData.ClearColorMode.Color') and has('hud','new Color(0f, 0f, 0f, 0f)'))
add('HUD camera volume influence is zero', has('hud','_hudHd.volumeLayerMask = 0'))
add('Hidden empty-mask preflight present', has('hud','EMPTY_MASK0_VOLUME0') and has('hud','_hudCamera.cullingMask = 0'))
add('Hidden HUD-only preflight present', has('hud','HUD_ONLY_MASK') and has('hud','_hudCamera.cullingMask = _hudLayerMask'))
add('Preflight downscales before CPU readback', has('hud','const int w = 64') and has('hud','const int h = 36') and has('hud','Graphics.Blit(_hudRt, small)'))
add('Preflight records RGB + alpha statistics', has('hud','meanRGBA=') and has('hud','alpha[min=') and has('hud','nonTransparent='))
add('V113 stale OpenVR overlay cleanup present', has('hud','sons_vr.native_hud.v113') and has('hud','STALE_OPENVR_OVERLAY_CLEANUP'))
add('Current OpenVR overlay key is V114', has('hud','sons_vr.native_hud.v114'))
add('Held physical GPS remains untouched by compositor', has('hud','physically-held GPS') or has('hud','physically-held GPS'))

add('VRPlayer imports HDRP camera-data namespace', has('vr','using UnityEngine.Rendering.HighDefinition;'))
add('Loading eyes use dedicated layer 31', has('vr','PreGameplayLoadingLayerV114 = 31'))
add('Loading eyes use layer31-only culling', has('vr','PreGameplayLoadingCullingMaskV114 = 1 << PreGameplayLoadingLayerV114'))
add('Loading eyes force black constant clear', has('vr','cam.clearFlags = CameraClearFlags.SolidColor;') and has('vr','cam.backgroundColor = Color.black;'))
add('Loading eyes zero HDRP volume layer mask', has('vr','hd.volumeLayerMask = 0;'))
add('Loading state restores exact saved eye visual state', has('vr','RestorePreGameplayEyeV114') and has('vr','_preGameplayLeftEyeCullingMaskV114') and has('vr','_preGameplayRightEyeCullingMaskV114') and has('vr','_preGameplayLeftEyeHdVolumeLayerMaskV114') and has('vr','_preGameplayRightEyeHdVolumeLayerMaskV114'))
add('V114d removes injected VRPlayer custom eye-state struct', 'private struct PreGameplayEyeVisualStateV114' not in files['vr'])
add('V114d removes ref custom-struct parameters from injected VRPlayer', not re.search(r'\b(?:public|private|protected|internal)\s+[^\n(]+\([^)]*\bref\s+PreGameplayEyeVisualStateV114\b', files['vr']))
add('Black loading state reasserts after HDRP native-camera copy', has('vr','UpdateHdrpDataCopyFromNativeCamera();\n            ConfigureNativeCameraAsTrashV107();\n            ReassertPreGameplayBlackEyesV114();'))
add('Synthetic loading overlay itself is on layer31', has('vr','_preGameplayLoadingOverlayV108.layer = PreGameplayLoadingLayerV114') and has('vr','mainGo.layer = PreGameplayLoadingLayerV114'))
add('Original native-camera 7-10fps dummy-layer optimization preserved', has('vr','NeutralizeNativeCameraCullingMask = 1 << 31'))
add('Native camera Preview regression remains disabled', has('vr','NeutralizeNativeCameraChangeCameraType = false'))

add('Camera audit initialized at startup', has('main','CameraCompositorAuditV114.Initialize();'))
add('Camera audit ticked each frame only for sparse scheduling', has('main','CameraCompositorAuditV114.Tick();'))
add('Camera audit shutdown wired', has('main','CameraCompositorAuditV114.Shutdown();'))
add('SRP begin render activity hook wired', has('stereo','CameraCompositorAuditV114.OnCameraBegin(camera);'))
add('SRP end render activity hook wired', has('stereo','CameraCompositorAuditV114.OnCameraEnd(camera);'))
add('Audit enumerates loaded cameras including inactive', has('audit','Resources.FindObjectsOfTypeAll<Camera>()'))
add('Audit records actual render counts', has('audit','s.RenderCount++') and has('audit','RENDERED_THIS_WINDOW'))
add('Audit labels SRP timing as CPU/not GPU', has('audit','NOT GPU timing'))
add('Audit records camera GameObject component types', has('audit','DescribeCameraComponents') and has('audit','components=['))
add('Audit treats binocular cameras as feature-scoped rather than automatically suspicious', has('audit','BINOCULAR_FEATURE_CAMERA') and 'suspiciousActiveNonEye' not in files['audit'])
add('Audit inventories large render textures', has('audit','WriteRenderTextureCensus()') and has('audit','LARGE_RT'))
add('Audit inventories LoadingCameraBacking renderers', has('audit','LoadingCameraBacking') and has('audit','LOADING_BACKING_SUMMARY'))
add('Expensive renderer census is transition-only', has('audit','LOADING_BACKING_CENSUS skipped (transition-only'))
add('Audit inventories HDRP CustomPassVolumes', has('audit','WriteCustomPassVolumeCensus()') and has('audit','CUSTOM_PASS_VOLUMES'))
add('Audit inventories known OpenVR V113/V114 overlay keys', has('audit','sons_vr.native_hud.v114') and has('audit','sons_vr.native_hud.v113'))
add('Audit probes active HDRP pipeline/color-buffer settings', has('audit','colorBufferFormat') and has('audit','PIPELINE_CURRENT'))

# Source-level known old paths: present for archaeology, but hard-off / fallback-only.
add('Old letter-by-letter custom loader hard-off', has('vr','CustomLoadingScreenEnabled = false'))
add('Binocular second camera hard-off by default', has('vr','EnableBinocularsZoomCamera = false'))
add('UI Toolkit capture hard-off', has('vr','UiToolkitCaptureEnabled = false'))
add('Always-on-top extra cameras compositor-fallback only', has('vr','if (!NativeHudCompositorV114.Enabled)') and has('vr','EnsureAlwaysOnTopLayerAndCameras();'))
add('Legacy HUD child transform mutation stops under compositor', has('vr','if (NativeHudCompositorV114.Enabled) return;') and has('vr','private void UpdateMinimapPositionEndOfFrame()'))
add('Old HUD depth catcher hard-off', has('stereo','AerHudDepthCatchersExperimentalEnabled = false'))
add('Old HUD depth proxy hard-off', has('stereo','AerHudDepthProxyV72Enabled = false'))
add('Old dense HUD remap hard-off', has('stereo','AerHudDensePlanarRemapV76Enabled = false'))
add('V103/V104 depth-guard production path remains enabled', has('stereo','AerV104DepthGuardedFillPermanentEnabled = true'))

# Static inventory of camera construction sites. We expect exactly the two eyes + HUD + two dormant/fallback families.
all_cs='\n'.join(p.read_text(encoding='utf-8-sig') for p in mod.rglob('*.cs'))
constructors=[]
for p in mod.rglob('*.cs'):
    txt=p.read_text(encoding='utf-8-sig')
    for m in re.finditer(r'(?:AddComponent|GetOrAddComponent)<Camera>\s*\(', txt):
        line=txt.count('\n',0,m.start())+1
        constructors.append(f'{p.name}:{line}')
add('Static camera construction-site count is exactly 6', len(constructors)==6, ', '.join(constructors))
overlay_creators=[p.name for p in mod.rglob('*.cs') if 'CreateOverlay(' in p.read_text(encoding='utf-8-sig')]
add('Only NativeHudCompositor creates an OpenVR Overlay', overlay_creators == ['NativeHudCompositorV114.cs'], str(overlay_creators))

# Crude lexical brace audit on the modified/critical files. It is not a compiler, but catches botched edits.
def strip_comments_strings(t):
    t=re.sub(r'/\*.*?\*/','',t,flags=re.S)
    t=re.sub(r'//.*','',t)
    # ordinary/interpolated/verbatim strings, good enough for brace balancing
    t=re.sub(r'\$?@"(?:""|[^"])*"','""',t,flags=re.S)
    t=re.sub(r'\$?"(?:\\.|[^"\\])*"','""',t)
    t=re.sub(r"'(?:\\.|[^'\\])'", "''", t)
    return t
for k in ['hud','audit','vr','stereo','main']:
    t=strip_comments_strings(files[k])
    bal=0; minbal=0
    for ch in t:
        if ch=='{': bal+=1
        elif ch=='}':
            bal-=1; minbal=min(minbal,bal)
    add(f'{paths[k].name} lexical brace balance', bal==0 and minbal>=0, f'bal={bal}, min={minbal}')

passed=sum(ok for _,ok,_ in checks)
for i,(name,ok,detail) in enumerate(checks,1):
    suffix=f' ({detail})' if detail else ''
    print(f'[{"PASS" if ok else "FAIL"}] {i:02d}. {name}{suffix}')
print(f'\nV114 static audit: {passed}/{len(checks)} passed')
if passed != len(checks): sys.exit(1)
