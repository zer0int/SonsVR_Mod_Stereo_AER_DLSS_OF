SONSVR V87 — FAR FIELD + 768 GRID + SAME-RUN POSE-TIMING A/B
==============================================================

One headset load, three tightly related changes:

1) FAR FIELD
   Temporal warp accepts valid depth out to the actual eye-camera far clip minus 1 m.
   The old 300 m rejection is gone from this path. Raw zero/sky depth remains invalid.

2) 768x768 FORWARD DEPTH MESH
   V86 was 512x512. V87 is 768x768 (~2.25x geometry). The code clamp is raised to
   1024 so 768 is really used. Watch FPS and distant foliage.

3) POSE TIMING A/B WITHOUT RESTART
   First 30 s of actual temporal rendering: V86 EOF-LATE target matrices.
   Then automatic switch: BEGIN-RENDER-FROZEN matrices captured for BOTH eyes at
   beginCameraRendering of the fresh real eye.

   Marker:
   [AER V87][PoseAB] AUTO SWITCH ... EOF-LATE ... -> ... BEGIN-RENDER-FROZEN

   If a current-frame snapshot is missing, V87 stays on EOF-LATE. It does not crash
   or submit a guessed matrix.

UNCHANGED ON PURPOSE
- render scale 1.0
- no real DLSS yet
- no motion-vector capture/use yet
- no optical flow
- no shadow/AO matrix freezing yet
- HUD depth catchers OFF
- HUD x1.00
- heavy diagnostics/readbacks OFF
- V36 HARD-OFF

TEST
1. Reach gameplay and look at distant foliage/far backdrop.
2. First ~30 s: judge far field + FPS (poseTiming=EOF-LATE).
3. Keep playing; no restart. After the automatic switch, judge another ~30 s
   (poseTiming=BEGIN-FROZEN).
4. Compare near bush vs distant trees if convenient.

Do NOT change render resolution scale for this experiment.

BUILD: BUILD_V87.bat
PACK:  PACK_V87_TRACE.bat
