SonsVR V115 - native HUD safe recovery / unified world plane
=============================================================

Why V114 is retired
-------------------
The returned V114 trace answered the two key questions conclusively:

1) EMPTY compositor capture, with cullingMask=0 and volumeLayerMask=0:
   RGB=(0,0,0) but alpha=1.0 everywhere.
   The game's active HDRP camera-color buffers are RGB111110Float/B10G11R11,
   so the extra HDRP HUD camera does not preserve transparent alpha for OpenVR.

2) V114 converted the entire PlayerUI/ScreenSpaceCanvas to ScreenSpaceCamera.
   That root also owns interactive tarp/cooking/pickup UI and its GraphicRaycaster
   semantics. The HUD-only layer union even contained layer 28 PickUp. This is why
   world interaction/cursors disappeared.

The V114 HUD camera also averaged ~5.9 ms CPU wall time between SRP begin/end in
that run. It is therefore retired, not patched again.

What V115 does
--------------
- No V114 HUD Camera.
- No 1920x1080 HUD RenderTexture.
- No SteamVR HUD overlay.
- Returns the native gameplay HUD to WorldSpace, the interaction-preserving path
  used by older working builds.
- Unlike the old metre-space HUD, both native HUD systems now share ONE pixel
  contract:
    distance = 1.20 m
    horizontal angular width = 60 deg
    main logical screen = live RectTransform (normally 1920x1080)
    native row y=153 is placed at eye height (same successful V114 placement)
- Minimap uses the exact same world-units-per-native-pixel as ScreenSpaceCanvas.
- The minimap's actual ScreenBounds center is translated onto the actual visible
  VitalsRenderTexture center. The ring itself is not moved. No +/- metre guesses.
- Old minimap offset/recenter code, V16 ring mover, child HUD scale hacks and
  always-on-top HUD cameras are inactive in the V115 path.
- The held physical GPS is untouched.
- Black layer-31 loading suppression from V114 is retained.
- The sparse V114 camera census is retained for one more verification run.

Build
-----
Run:
    BUILD_V115.bat

Then copy BOTH generated DLLs from OUTPUT to the game's Mods directory, exactly
as the build script prints.

First test priorities
---------------------
1. Tarp cursor/interactions and cooking interaction MUST be back. If not, stop.
2. There must be NO opaque black HUD rectangle.
3. Check map/ring center alignment.
4. Check whether the 60deg/1.20m placement still feels like V114.
5. Move/strafe/jump/head-translate and report HUD stability.
6. Held GPS remains ordinary 3D.

After the run:
    PACK_V115_TRACE.bat

The camera-audit filename inside UserData intentionally still says V114 for
continuity with the existing logger; the V115 packer includes it.
