SonsVR V60 — STABLE HUD LAYOUT + DIRECT UGUI STEREO
====================================================

Base:
  V59 / V51 known-good 1.0-scale world renderer.
  V50 camera-local exact depth latch.
  512x512 V51 same-time world warp.
  V51 target-eye fallback for true world disocclusions.
  Existing HUD enlargement retained at 1.75x.

A) HUD layout cleanup
---------------------
V16's minimap-center heuristic was selecting:
  GPSTrackerSystem/Canvas/ScreenMask/ScreenBounds/GPSLocator(Clone)/IconOnly/Icon

That object is moving map content. GPSTrackerSystem intentionally updates locator/map
content with player heading, so centering VitalsRenderTexture on it made the ring orbit
the map like a planet.

V60:
  - removes the fuzzy RawImage/Image "map/gps" center hunt
  - anchors to the stable RectTransform:
      GPSTrackerSystem/Canvas/ScreenMask/ScreenBounds
  - falls back only to the minimap Canvas rect, never a moving child
  - keeps map and visible VitalsRenderTexture on one 0.50m plane
  - scales the visible VitalsRenderTexture, NOT PlayerVitalsUiWorldSpace/HudCamera source
  - keeps every explicit HUD enlargement at 1.75x
  - uses Canvas RectTransform logical height when converting minimap world scale

B) AER rendering fix — direct UGUI stereo
-----------------------------------------
Transparent UGUI color exists in the eye RT but generally does NOT write useful scene
depth. V51 therefore treated UI pixels as if they belonged to whatever tree/rock/sky
depth was behind them.

V60 changes the rendering path:

  RenderPipelineManager.beginCameraRendering(active VR eye)
      -> refresh HUD layout using freshest HMD pose
      -> ask Unity Graphic.DoMeshGeneration() for actual generated UGUI geometry
      -> snapshot mesh, final CanvasRenderer material, world transform, absoluteDepth
      -> cull ONLY successfully snapshotted Graphics

  HDRP renders active eye
      -> world only
      -> V50 captures world-only camera-local depth

  endCameraRendering
      -> restore normal CanvasRenderer cull state

  EOF
      -> V51 synthesizes opposite WORLD eye from world-only color+depth
      -> clear only depth buffers
      -> redraw the SAME captured UGUI meshes into:
           real/source eye using source eye matrices
           synthetic/target eye using target eye matrices
      -> submit pair

No extra Camera.
No V56 depth proxy.
No V55 monocular UI camera.
No source-eye HUD color enters the scene-depth warp.

BUILD
-----
  BUILD_V60.bat

Install ONLY:
  OUTPUT\SonsVR_Mod.dll

Expected log markers:
  [ZER0INT TEST V60 HUD LAYOUT + DIRECT UGUI STEREO]
  [VRPlayer][AER V60][HudLayout] STABLE minimap anchor=...
  [StereoRender][AER V60][UGUI] reflection: ...
  [StereoRender][AER V60][UGUI] WORLD-ONLY eye capture armed...
  [StereoRender][AER V60][UGUI] DIRECT SAME-TIME HUD STEREO IS IN HEADSET PATH...

FIRST TEST
----------
Normal outdoor gameplay only.

Look at:
  - minimap + status ring: ring should remain centered on map through physical/body rotation
  - YOU ARE TIRED / ordinary message HUD
  - map/ring/text binocular stability during small head translations and rotations
  - world: should remain V51-smooth

Do not use cooking/tarp as the first verdict; ordinary HUD is the high-information test.

KNOWN IMPLEMENTATION RISK
-------------------------
This is the first direct-draw prototype. Unity exposes the required mesh/material APIs in
this game's generated assemblies, but CanvasRenderer has native services such as RectMask2D
clipping and per-renderer texture state that may need explicit reproduction for some widgets.
Per-Graphic capture is fail-partial: unsupported Graphics are not intentionally culled.
