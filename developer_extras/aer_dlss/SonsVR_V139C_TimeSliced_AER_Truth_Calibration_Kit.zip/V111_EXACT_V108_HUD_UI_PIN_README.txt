SonsVR V111 — EXACT V108 HUD RESTORE + LOADING/SETTINGS RETAIN + SAFE MENU UI PIN TEST
=====================================================================================

BASE
----
V108 production HUD/gameplay path is authoritative again.
V110 loading/title-eye-lift/settings UX changes are retained only where they do not alter V108 HUD layout.

HUD ABORT / RESTORE
-------------------
The following V108 HUD methods are byte-for-byte restored from V108 source:
  ConvertMinimapCanvasToWorldSpace()
  UpdateVitalsPositionEndOfFrame()
  UpdateMinimapPositionEndOfFrame()

The V108 active UpdateVitalsUiScaleV14() call and these constants are restored exactly:
  MinimapForwardDistance
  MinimapScaleMultiplier
  VitalsUiScaleMultiplier

No V109/V109B frozen-rect/peripheral-HUD behavior is present.

HUD DEPTH CATCHERS / BAKED PRIMITIVES
------------------------------------
Hard retired:
  AerHudDepthProxyV72Enabled = false
  AerHudDensePlanarRemapV76Enabled = false
  AerHudDensePlanarTextBlackBackingV76 = false
  EnsureExactHudProxyMeshesV74() cannot allocate meshes
  HudProxyMeshesV74.cs is absent and not compiled

LOADING / TITLE
---------------
Retained from V110:
  LOADING
  <spinner on its own line>
  SOTF VR

Native LoadingIndictor renderers/graphics are suppressed while the replacement is active.
Title/loading EYE cameras only are lifted +0.30m world-Y; menu/head transforms are not lifted.
V107 fast layer-5 loading remains.

SETTINGS / PERF UX
------------------
V110 bordered two-column settings table and native pause-menu input isolation remain.
Settings panel apparent size: 2x V110.
Perf panel apparent size: 2x V110 and moved to upper-right.
Perf panel remains dynamic statistics only, yellow.

SAFE UI PIN TEST
----------------
When gameplay AER is active AND either the native pause menu or SonsVR settings panel is open:
  - both eye cameras render genuinely every frame
  - AER synthetic-eye generation is bypassed for that UI state
  - on close, both eyes warm up/resync before normal AER alternation resumes

This is intentionally NOT triggered by the always-on FPS overlay, because that would turn AER into full stereo for all gameplay and destroy the performance win.

Important: the title screen occurs before gameplay AER activation, so title-menu blur cannot be caused by alternate-eye synthesis. If title text remains temporally soft/jittery, the next target is the world-space UI -> HDRP TAA/DLSS path, not AER scheduling.

BUILD
-----
  BUILD_V111.bat

PACK IF NEEDED
--------------
  PACK_V111_TRACE.bat
