SONSVR V108 — LOADING UX + PAGE-AWARE COOKING CACHE
====================================================

WHY V108 EXISTS
---------------
V107 fixed the sustained cooking-menu 4 FPS collapse by removing two full-scene
FindObjectsOfType(Type) calls from every Update. V107 trace confirms ordinary cooking
frames returned to roughly normal gameplay cost, but it exposed a functionality regression:
only the ingredient page active when the cache was first built remained selectable.

The trace makes the mechanism explicit:
  - V107 initial cooking cache: 7 GrabBagLayoutItems.
  - On later native ingredient sheets those 7 cached objects become inactive: activeItems=0/7.
  - Returning to the known page makes activeItems return to 7/7.
Therefore later pages contain different GrabBagLayoutItem instances outside V107's initial cache.

V108 COOKING FIX
----------------
V108 keeps V107's fast per-frame cached path. It does NOT restore global searches every frame.
Instead, when a previously-populated cached ingredient page transitions >0 -> 0 active cached
items, V108 performs ONE global ACTIVE GrabBagLayoutItem refresh for that page transition.
Newly discovered items are unioned into the session cache and stay cached thereafter.

Expected behavior:
  - first cooking-menu frame can still hitch (same as V107 initial discovery);
  - first visit to a previously unseen ingredient sheet may hitch once (~100ms-class on the
    measured machine) while that page is discovered;
  - sustained cooking remains fast;
  - revisiting an already-discovered page should not rescan;
  - all ingredient sheets become gaze-selectable again.

Relevant log marker:
  [VRPlayer][V108 CookingPages]

V108 LOADING UX
---------------
V107's pre-game performance fix deliberately gives both VR eyes the game's own cheap loading
culling mask 0x20 (layer 5) until MainCameraFP + LocalPlayer are ready. This can leave the HMD
showing only clouds / sky / partially-streamed artifacts while the native LOADING UI itself is
not visible.

V108 leaves the fast loading render policy unchanged and adds a synthetic, head-locked overlay
on layer 5 itself:

    LOADING  | / - \
    GAME IS STILL LOADING - PLEASE WAIT

The spinner advances every ~0.16 s. There is NO fullscreen black panel and no capture camera.
The overlay is hidden automatically when V107 restores the normal gameplay culling mask.

AER / RENDERER
--------------
No AER algorithm change in V108. Permanent V103 depth guard, V100 true-hole rotation fallback,
DLSS/NVOFA runtime settings, V107 native-camera trashing, and V107 loading suppression remain.

TEST
----
1. BUILD_V108.bat
2. Load a save. Confirm the large LOADING spinner is clearly visible over the cloud/sky loading view.
3. Open cooking. Visit EVERY ingredient sheet/page and gaze/select at least one item from each.
4. Note whether a new page has at most a one-frame hitch and then remains fast.
5. Progress to the CookingCog if practical and verify it remains selectable.
6. Exit and run PACK_V108_TRACE.bat.
