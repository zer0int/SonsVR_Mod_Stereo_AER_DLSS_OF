SonsVR V91 — REAL HDRP DLSS QUALITY + HALF-RES NVOFA
=====================================================

GOAL
----
Recover application cadence first, then see what the already-proven optical-flow residual
looks like when it is no longer extrapolating a ~130 ms motion history at ~15 FPS.

V91 reuses Sons Of The Forest's OWN HDRP/NVIDIA DLSS integration. There is no second NGX
integration and no DLSS SDK in the mod.

REAL-EYE PIPELINE
-----------------
For each persistent physical-eye camera (VRLeftEye / VRRightEye):

    HDRP internal lower-resolution render
        + depth / HDRP motion / temporal history
        -> Sons/Unity HDRP DLSS Quality (MaxQuality), optimal settings
        -> full SteamVR-size LeftRT / RightRT

Each eye keeps its own HDCamera + persistent temporal history.

The skipped/synthetic eye is NOT passed through DLSS again in V91. It is still reconstructed
by AER from the previous same-eye DLSS output plus camera-local depth and optional NVOFA.
That is intentional for this first cadence experiment.

DRS-AWARE AER
-------------
V90 assumed camera-local depth had the same pixel dimensions as final color. V91 removes
that obsolete invariant:

    final DLSS color:     full SteamVR target size
    camera-local depth:   HDCamera.actualWidth x actualHeight
    NVOFA:                0.5 x final width/height by default

All three are joined in normalized UV space. The exact lower-resolution HDRP depth is kept;
it is NOT upscaled merely to satisfy the old code.

HALF-RES NVOFA
--------------
V90d proved full-resolution 1x1 NVOFA gives a large stationary quality win but destroyed
cadence (~24 -> ~15 FPS). V91 runs NVOFA at 0.50 linear resolution = 0.25 the pixels.
The compute shader samples that lower-resolution vector field by normalized UV and converts
its S10.5 flow-pixel vectors into UV before applying them to the final target.

The 96-pixel residual safety clamp remains defined in FINAL presentation pixels, so reducing
flow resolution cannot secretly double the permitted deformation.

SAME-RUN PHASES
---------------
NVOFA executes from the beginning in BOTH phases.

    first ~30 s:
        DLSS Quality + depth/camera same-eye AER
        NVOFA generated but residual ignored

    after automatic switch:
        identical DLSS + DRS + NVOFA workload
        + camera-subtracted optical-flow residual applied

This means the switch itself does not add NVOFA cost.

WHAT SUCCESS LOOKS LIKE IN THE LOG
----------------------------------
Look for:

    [AER V91][DLSS] GLOBAL REAL-DLSS REQUEST APPLIED ...
    [AER V91][DLSS][EyeStatus] ... DLSSallow=True dynAllow=True ... dynScale=True ...
    [AER V91][CustomDepth][EXEC-SEEN] ... hdrpActual=<smaller> target=3141x3317 ...
    [AER V91][NVOFA] FLOW READY ... size~1570x1658 ...

The critical proof of useful DLSS/DRS is NOT merely DLSSallow=True. It is:

    hdrpActual width/height < full eye target width/height

If actual stays full-size, the global DRS/upscaler did not engage and the logs should be sent
back rather than judged visually.

BUILD
-----
Run:

    BUILD_V91.bat

Copy BOTH files from OUTPUT into the game's Mods folder:

    SonsVR_Mod.dll
    SonsVR_NvOF_V90.dll

The NVOFA native DLL keeps its V90 filename/API because its ABI did not change.

TEST
----
First: watch performance / general world motion. We specifically care whether the awful
15-FPS pudding regime disappears and whether SteamVR frame reuse drops.

Then use the rigid taxidermy/deadbirb test if convenient:
  - same object upper vs lower field
  - stationary quality
  - move around it, then stop and watch how long any jelly persists

Across the ~30 s NVOFA-residual switch, keep a comparable view if possible.

Pack afterward with:

    PACK_V91_TRACE.bat

Send V91_TRACE_RETURN.zip.

FAIL-SOFT
---------
If the Sons DLSS manager cannot be found or reports unsupported, V91 logs that and continues.
If lower-resolution camera-local depth is unavailable, the old global-depth fallback remains.
If NVOFA fails, AER remains depth-only. No CPU image readbacks were added.
