SonsVR V99 - ONE-LAUNCH GROUND-TRUTH MEGA FORENSICS
========================================================

PURPOSE
-------
Stop spending one ~5-minute headset launch per tiny hypothesis. V99 keeps the normal
scale=1.0 / real-DLSS AER path, deliberately exposes the original pre-NVOFA jitter,
and automatically performs six sparse same-frame ground-truth measurements in one run.

IMPORTANT DISPLAY BEHAVIOR
--------------------------
- Normal displayed AER: same-eye temporal, internal-depth-grid scatter, DLSS Quality.
- NVOFA STILL RUNS, but its residual is deliberately NOT applied to the displayed eye.
  This exposes the ancestral raw jitter instead of smoothing it into jelly.
- HDRP motion vectors are CAPTURED FOR TELEMETRY but are NOT applied to displayed AER.
- V98 timed scatter A/B and V94 matrix A/B are disabled.
- Every ~90 frames, one diagnostic frame renders BOTH eyes genuinely. This is intentional.
  The truth frame submits real L+R; offline synthetic variants are NEVER shown in headset.

WHAT EACH TRUTH FRAME MEASURES
------------------------------
Before the dual-real frame, each eye's stale REAL history is snapshotted:
  post-DLSS color, camera-local depth, HDRP motion, NVOFA flow,
  exact matrices/pose/timestamps and previous-real camera state.

After both current genuine eyes render, V99 reconstructs the stale eye offline as:
  1. RAW_HISTORY
  2. SPARSE_DEPTH
  3. PRESENTATION_DEPTH
  4. PRESENTATION_HDRP_MOTION_TIMESCALED
  5. PRESENTATION_NVOFA
  6. PRESENTATION_BOTH

Each candidate is compared against same-frame real truth on a 16x12 field. Logged data:
  - local synthetic->truth dx/dy via +/-8 px block registration
  - dx/dy converted through the exact asymmetric eye projection to yaw/pitch degrees
  - luma MAE, RMSE, edge-weighted MAE and synthetic coverage
  - direct-scatter coverage BEFORE hole filling for each reconstruction variant
  - geometric stale->current warp field
  - HDRP exact same-interval total motion, reconstructed camera-only motion, residual
  - predictive historical NVOFA total/camera/residual
  - best-effort exact current->stale NVOFA truth flow for the SAME measured interval
  - HDRP-vs-exact-NVOFA disagreement where exact flow is ready by EOF
  - history/truth depth statistics
  - scene luma variance, high-frequency gradient energy and depth-edge fraction
  - one-pixel angular gain field of the asymmetric projection
  - stale->truth camera translation and rotation
  - OpenVR eye-to-head calibration vs the mod's Unity eye offsets / separation
  - HDRP/DLSS/RTHandle/TAA/DRS global raster state
  - existing V95 resolution provenance, V96 OpenVR distortion and V97 RTHandle probes remain.

HOW TO RUN
----------
1. Run BUILD_V99.bat
2. Copy OUTPUT\SonsVR_Mod.dll and OUTPUT\SonsVR_NvOF_V90.dll to the game Mods folder.
3. Load a representative world view containing close + medium/far rigid/high-frequency detail.
4. You do NOT need to hit timed A/B transitions. Just stay in-game long enough for six samples.
   Some natural head movement / a little walking is useful; also spend some time fairly still.
5. Watch Latest.log if convenient. The completion marker we want is:

     [StereoRender][AER V99][ReadbackEnd] sample=6 eye=R complete.

   (Both L and R sample=6 should appear. If R happens first, wait for L too.)
6. Quit and run PACK_V99_TRACE.bat
7. Send V99_TRACE_RETURN.zip.

MOTION-VECTOR ANSWER
--------------------
The displayed renderer does NOT currently use HDRP object-motion residuals. V89's old
visual experiment was a null, and V90 disabled that correction. V99 re-enables the
BeforePreRefraction motion CustomPass for measurement only, and also builds an offline
properly time-scaled HDRP-motion candidate against real ground truth. Thus this one run
will tell us whether motion vectors were useless, mis-scaled, or useful only in certain tiles.

NOTES
-----
Truth frames are intentionally expensive and may briefly perturb cadence/history. They are
sparse, tagged, and their exact timestamps/ages are logged. Normal frames remain the current
renderer. The forensic atlas is tiny (16 x 12 x 27 RGBAFloat bands) and read back asynchronously.
Full eye images are never CPU-read back.
