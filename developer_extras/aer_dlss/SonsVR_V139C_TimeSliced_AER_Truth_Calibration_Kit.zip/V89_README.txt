SONSVR V89 — FULL-RES DEPTH vs DEPTH + HDRP OBJECT-MOTION A/B
===============================================================

ONE HEADSET LOAD. ONE AUTOMATIC SWITCH.

WHY NO EXTRA MOTION-CAPTURE PROBE FIRST?
-----------------------------------------
The required API/ordering is now known from both the game's IL2CPP HDRP wrapper
and Unity HDRP 14 documentation:

  CustomPassContext.cameraMotionVectorsBuffer exists.

At AfterOpaqueDepthAndNormal (where V81 correctly captures depth), the motion
buffer is not yet a complete read source. At BeforePreRefraction HDRP documents
it as complete for opaque object + camera motion. Therefore V89 adds a SECOND,
per-eye camera-mode CustomPass at BeforePreRefraction and copies that exact
buffer into a persistent full-resolution RGHalf texture.

No CPU readback. No truth board. No debug markers in the headset.

WHAT V88 PROVED
----------------
V88's 768-grid -> full-resolution per-pixel compute switch was a perceptual
null, while the 4090 absorbed the compute cost. Therefore V89 uses the
full-resolution compute scatter from the start. The 768 mesh remains only a
fail-soft emergency path.

THE IMPORTANT MOTION-VECTOR TRAP
---------------------------------
HDRP's motion texture is TOTAL screen-space motion:

  camera/head motion + object/animation motion

But V88/V89 already handles camera motion by reconstructing each historical
pixel from depth and transforming the 3D point through the desired current
same-eye camera matrices.

So this would be WRONG:

  targetUV += HDRP_motion

because camera motion would be applied twice.

V89 instead does, per historical source pixel:

  captured HDRP total motion
      -
  camera-only motion reconstructed from
    previous REAL same-eye camera -> current REAL same-eye camera
      =
  object / animation residual

Then only that residual is extrapolated one Unity tick into the predicted eye.
Static geometry should therefore be essentially unchanged by the switch.

PHASE A — FIRST ~30 SECONDS
----------------------------
Exactly the successful V88 full-resolution compute path:

  old SAME-EYE color
  + exact old SAME-EYE cameraDepthBuffer
  + old/current camera matrices
  -> full-resolution per-source-pixel scatter

Motion capture is already running/warmed, but object residual is NOT applied.
Telemetry:

  motion=OFF

PHASE B — AUTOMATIC, NO RESTART
--------------------------------
After ~30 seconds:

  same exact full-resolution compute scatter
  + camera-subtracted HDRP object/animation residual

Default prediction scale:

  1.0 x object residual

Safety clamp:

  96 pixels maximum residual magnitude per source sample

The clamp is only to stop corrupt/pathological vectors from throwing pixels
across the display; ordinary foliage motion should be far below it.

Expected switch log:

  [AER V89][MotionAB] AUTO SWITCH ...
  DEPTH/CAMERA ONLY -> DEPTH + CAMERA-SUBTRACTED OBJECT MOTION

Successful pairing also logs once:

  [AER V89][MotionPair] READY ...
  motionFrame=... depthFrame=... prevRealFrame=...

and the capture pass logs the actual HDRP source texture dimensions/format for
the first few real eye renders.

FAIL-SOFT
---------
If complete motion capture is unavailable/stale/mismatched, V89 does NOT feed
it to the headset. Phase B stays on the exact V88 depth-only compute path and
logs once.

If the compute scatter itself fails, the old 768 grid remains the emergency
fallback and the log explicitly says the run is not a valid motion A/B.

UNCHANGED ON PURPOSE
--------------------
- two persistent physical-eye cameras
- same-eye temporal AER
- camera-local full-resolution RFloat depth
- V86 projective-coordinate fix
- V87 far-field fix (valid depth to camera far clip)
- render-boundary target-pose freeze
- render scale 1.0
- 1px + 2px hole fill
- raw SAME-EYE history for remaining true holes
- HUD depth catchers OFF
- heavy readbacks / forensic boards OFF
- no real DLSS yet
- V36 HARD-OFF

WHAT TO LOOK AT
---------------
Distant wind-animated foliage is still the best victim.

1. Reach gameplay and look at the same distant leaves/branches for ~30 sec.
2. Keep looking through the automatic switch. No buttons/reload needed.
3. Report whether micro-jitter becomes:
     - clearly better,
     - clearly worse,
     - spatially different,
     - or indistinguishable.
4. Also note any obvious FPS change.

A useful secondary target is a moving hand/held item or moving NPC/animal,
because those should carry explicit object motion too. Do NOT spend another
load doing elaborate diagnostics; ordinary observation is enough.

INTERPRETATION
--------------
If distant foliage improves after the switch:
  object/animation motion was a material missing term. Keep V89 motion and
  proceed to real DLSS/cadence work on top of it.

If the switch is again a perceptual null:
  we have removed both spatial depth fidelity and per-pixel scene velocity as
  dominant causes. The remaining ~41 ms / ~24 Hz temporal raster/resampling
  mismatch becomes the main target -> DA REAL DLSS / temporal supersampling.

If static geometry globally shifts/wobbles after the switch:
  that would indicate a camera-vector convention/subtraction mismatch. The
  fail-soft architecture still leaves Phase A as the clean baseline.

LATER DLSS NOTE
---------------
The new complete per-eye motion capture is intentionally useful for DLSS too.
When real dynamic resolution is enabled later, this capture path must become
RTHandle active-viewport/DRS aware; V89 is intentionally native-resolution only.

BUILD: BUILD_V89.bat
PACK:  PACK_V89_TRACE.bat
