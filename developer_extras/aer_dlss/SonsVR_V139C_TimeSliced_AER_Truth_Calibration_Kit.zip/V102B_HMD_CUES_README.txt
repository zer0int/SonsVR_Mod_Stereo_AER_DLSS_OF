SonsVR V102b -- IN-HMD MILESTONE CUES
=========================================

Why this exists
---------------
The V102 instructions incorrectly required the tester to watch MelonLoader log milestones
while physically inside the HMD. V102b fixes the protocol rather than asking the tester to
guess from capture lag.

Rendering / measurement changes
-------------------------------
NONE. V102b keeps V102's live renderer, forensic candidates, shaders, truth scheduling,
occlusion classes, depth/color-risk fields, and capture counts unchanged.

The only new behavior is a small head-locked green status card shown at SAFE milestones:

  1. After BOTH eye readbacks of GAMEPLAY_24000M sample 6 are completely processed:

       V102 GAMEPLAY CAPTURE COMPLETE
       OPEN TARP NOW

     There are no further gameplay truth captures after this point, so the card cannot
     contaminate that bank.

  2. The instant the tarp's <=100 m far clip is detected, the card DISAPPEARS.
     Its disappearance is the tester's confirmation that TARP_50M armed. The card remains
     hidden throughout the settling delay and ALL tarp truth captures.

  3. After BOTH eye readbacks of TARP_50M sample 6 are completely processed:

       V102 CAPTURE COMPLETE
       DONE - YOU CAN PACK THE TRACE

     No further truth captures occur after this point.

Protocol
--------
1. Build with BUILD_V102B.bat and install BOTH DLLs as usual.
2. Enter ordinary outdoor gameplay and use/rotate the view normally. DO NOT open tarp yet.
3. When the GREEN card says OPEN TARP NOW, open the tarp.
4. Confirm the green card disappears. Keep the tarp open.
5. Rotate across the problematic rock / dense stacked-foliage slice; also include cleaner
   isolated silhouettes when practical.
6. Wait until the GREEN card says DONE - YOU CAN PACK THE TRACE.
7. Run PACK_V102_TRACE.bat and return V102_TRACE_RETURN.zip.

No desktop/log inspection is required during the run.
