V95 — PASSIVE RESOLUTION / TEXTURE-BOUNDS PROVENANCE PROBE

Base: V94b. Rendering behavior intentionally unchanged.

New logs only:
  [AER V95][ResolutionProvenance]
  [AER V95][ProjectionRaw]
  [AER V95][ValveClassicBounds]
  [AER V95][ActualSubmitBounds]

Purpose:
- Query raw OpenVR GetRecommendedRenderTargetSize.
- Compare it to SteamVR.instance.sceneWidth/sceneHeight used by SonsVR.
- Reconstruct Valve classic SteamVR.cs shared-scene expansion from GetProjectionRaw.
- Compare that predicted expanded size to SteamVR.instance.sceneWidth/sceneHeight.
- Record the nontrivial per-eye bounds implied by that expansion.
- Record that SonsVR currently submits each entire eye texture with 0..1 bounds (Y flipped).

NO texture size, projection, submit bounds, DLSS, AER, or NVOFA behavior is changed.

Build: BUILD_V95.bat
Pack:  PACK_V95_TRACE.bat
