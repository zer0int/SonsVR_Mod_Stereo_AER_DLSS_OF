SonsVR V100 - ROTATION-ONLY TRUE-HOLE FALLBACK A/B/A + CORRECTED FORENSICS
============================================================================

WHY THIS EXISTS
---------------
V99 finally measured same-frame real ground truth. After accounting for OpenVR's V flip,
the physical HMD TOP is the diagnostic raw-BOTTOM band. That region has dramatically less
usable history depth than the physical HMD bottom:

  history finite-depth validity (both eyes, approximate V99 averages):
    physical HMD bottom : ~100%
    center              : ~99%
    physical HMD top    : ~32-36%

The normal sparse scatter directly covers only ~7% of the physical top before hole filling.
Even presentation-grid scatter reaches only ~29% there because missing depth, not thread
density, is the limiting factor. After radius-1 and radius-2 fills, roughly half of the
physical HMD top can still be a TRUE hole. V51 fills those final holes with stale SAME-EYE
color at the unchanged UV: no rotational correction at all.

That behavior predates DLSS and NVOFA and therefore fits the ancient top-heavy jitter.

VISUAL A/B/A - ONLY ONE THING CHANGES
-------------------------------------
The timer starts when usable same-eye temporal history exists:

  A   0..15 s : existing stale SAME-UV true-hole fallback
  B  15..30 s : ROTATION-ONLY / INFINITE-DEPTH inverse-gather fallback
  A2 >30 s    : return to stale SAME-UV fallback

The B phase changes ONLY pixels still uncovered after:
  finite-depth compute scatter -> radius-1 fill -> radius-2 fill.

For those true holes it maps the CURRENT target pixel ray into the STALE same-eye camera by
rotation only (translation deliberately ignored) and samples stale same-eye color there.
This is appropriate for sky/infinite-distance pixels and is a much better approximation for
far/alpha/LOD color without usable depth than pasting the old UV unchanged.

V36 IS NOT RESURRECTED GLOBALLY. Valid-depth pixels continue using the modern full 6DoF
same-eye temporal warp. The old whole-eye homography remains hard-off.

V99 FORENSICS RETAINED / IMPROVED
---------------------------------
- Six dual-real truth samples remain.
- Candidate 6 is now PRESENTATION_ROTATION_HOLE_FALLBACK, directly comparable against
  PRESENTATION_DEPTH on the same genuine truth frame.
- The V99 HDRP motion telemetry bug is fixed: EyeMotionCaptureCustomPassV89 is now registered
  whenever V99 forensic motion capture is requested, even though motion remains NOT applied
  to the displayed renderer.
- Diagnostic logs now explicitly state the raw-vs-HMD vertical mapping:
    raw TOP    = physical HMD BOTTOM
    raw BOTTOM = physical HMD TOP
  because OpenVR submission flips V.

WHAT TO WATCH
-------------
Keep troublesome medium/far detail in the physical HMD TOP if practical.

Expected if the hypothesis is correct:
  first 15 s  : familiar raw top jitter
  next 15 s   : top region becomes substantially more stable
  after 30 s  : familiar jitter returns

The physical HMD bottom should change little because V99 showed that it already has nearly
complete finite depth/warp coverage.

The log announces exact transitions:
  [AER V100][HoleFallbackAB] phase=A ...
  [AER V100][HoleFallbackAB] phase=B ...
  [AER V100][HoleFallbackAB] phase=A2 ...

HOW LONG
--------
About 35-40 seconds of representative in-world viewing after AER is active is enough to see
A -> B -> A2 and complete the forensic samples under normal ~24 FPS cadence.

BUILD / RUN
-----------
1. Run BUILD_V100.bat
2. Copy OUTPUT\SonsVR_Mod.dll and OUTPUT\SonsVR_NvOF_V90.dll to the game Mods folder.
3. Test ~35-40 s after AER settles.
4. Quit and run PACK_V100_TRACE.bat
5. Send V100_TRACE_RETURN.zip.
