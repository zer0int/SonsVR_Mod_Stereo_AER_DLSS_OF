from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parent
mod=ROOT/'mod'
files={p.name:p.read_text(encoding='utf-8-sig', errors='replace') for p in mod.glob('*.cs')}
files['KeyboardHack.cs']=(mod/'Input'/'KeyboardHack.cs').read_text(encoding='utf-8-sig', errors='replace')
perf=files['PerformanceForensicsV106.cs']
stereo=files['StereoRender.cs']
vr=files['VRPlayer.cs']
main=files['SonsVRMod.cs']
run=files['RuntimeSettingsV105.cs']
kh=files['KeyboardHack.cs']
csproj=(mod/'SonsVR_Mod.csproj').read_text(encoding='utf-8-sig', errors='replace')
build=(ROOT/'BUILD_V106.bat').read_text(encoding='utf-8-sig', errors='replace')
pack=(ROOT/'PACK_V106_TRACE.bat').read_text(encoding='utf-8-sig', errors='replace')
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))

ck('new source compiled', '<Compile Include="PerformanceForensicsV106.cs" />' in csproj)
ck('logger initializes before gameplay', 'PerformanceForensicsV106.Initialize();' in main)
ck('logger shutdown', 'PerformanceForensicsV106.Shutdown();' in main)
ck('logger tick wired', 'PerformanceForensicsV106.Tick(stereo, player);' in run)
ck('global SRP begin camera hook', 'PerformanceForensicsV106.OnCameraBegin(camera);' in stereo)
ck('global SRP end camera hook', 'PerformanceForensicsV106.OnCameraEnd(camera);' in stereo)
ck('waitgetposes wall-clock timing', 'RecordWaitGetPoses' in stereo and 'Stopwatch.GetTimestamp' in stereo)
ck('submit begin marker', 'PerformanceForensicsV106.MarkSubmitBegin();' in stereo)
ck('second submit end marker', 'PerformanceForensicsV106.MarkSecondSubmitCompleted(errorL, errorR);' in stereo)
ck('mirror capture timing', 'MarkMirrorBegin' in stereo and 'MarkMirrorEnd' in stereo)
ck('IMGUI mirror timing', 'MarkGuiMirrorBegin' in stereo and 'MarkGuiMirrorEnd' in stereo)
ck('pause ritual exact breadcrumb', 'AUTO_PAUSE_FIX_COMPLETE' in kh and 'NotifyExternalEvent' in kh)
ck('cooking item FindObjects timed', 'itemFindMsV106' in vr and 'itemScanMsV106' in vr)
ck('cooking cog FindObjects timed', 'cogFindMsV106' in vr and 'cogScanMsV106' in vr and 'cogRenderersV106' in vr)
ck('cooking timings exported', 'PerformanceForensicsV106.RecordCookingGaze' in vr)
ck('camera ring buffer exists', 'CameraRingMax = 160' in perf and 'DumpCameraRing' in perf)
ck('non-eye cameras continuously logged', 'if (!isEye || Time.unscaledTime < _burstUntil' in perf)
ck('pre/post/total compositor fields', 'm_flPreSubmitGpuMs' in perf and 'm_flPostSubmitGpuMs' in perf and 'm_flTotalRenderGpuMs' in perf)
ck('cadence settings logged', 'Application.targetFrameRate' in perf and 'QualitySettings.vSyncCount' in perf and 'renderFrameInterval' in perf and 'hmd_DisplayFrequency' in perf)
ck('camera census snapshot', 'CAMERAS count=' in perf and 'HDAdditionalCameraData' in perf)
ck('volume census snapshot', 'VOLUMES count=' in perf and 'FindObjectsOfType<Volume>()' in perf)
ck('post-gpu begin/recovery triggers', 'POST_GPU_PATHOLOGY_BEGIN' in perf and 'POST_GPU_RECOVERED' in perf)
ck('guided HMD cooking protocol', 'V106 PERFORMANCE LOGGER READY' in perf and 'V106 COOKING CAPTURED' in perf and 'V106 CAPTURE COMPLETE' in perf)
ck('V106 cue infrastructure enabled', 'PerformanceForensicsV106.CueEnabled' in vr)
ck('pack includes V106 logs', 'SonsVR_V106_*' in pack)
ck('pack includes Unity Player.log', 'Player.log' in pack)
ck('pack includes SteamVR logs', 'vrcompositor.txt' in pack and 'vrserver.txt' in pack)
ck('build label V106', 'LABEL=v106_perf_forensics' in build)

# Ensure production renderer survives this instrumentation build.
ck('depth guard still permanent', 'AerV104DepthGuardedFillPermanentEnabled = true' in stereo)
ck('V100 true-hole fallback still permanent', 'bool useRotationHoleFallbackV100 = true;' in stereo)
ck('V102 heavy occlusion forensics off', 'AerV102OcclusionForensicsEnabled = false' in stereo)
ck('V103 perceptual ABC off', 'AerV103DepthGuardFillPerceptualTestEnabled = false' in stereo)
ck('V36 globally hard off', 'V36 remains globally HARD-OFF' in stereo and 'TryGetSubmissionTextures' in stereo)

# The forensics helper itself must be passive wrt camera policy: no assignments to key render knobs.
forbidden=[r'\.cullingMask\s*=', r'\.enabled\s*=', r'\.targetTexture\s*=', r'allowDeepLearningSuperSampling\s*=', r'allowDynamicResolution\s*=']
ck('forensics class does not mutate camera render policy', not any(re.search(p, perf) for p in forbidden))

# Raw brace balance catches accidental edit truncation; the existing source contains many
# interpolated strings that make regex-based lexical stripping less reliable than this simple check.
for name in ['PerformanceForensicsV106.cs','StereoRender.cs','VRPlayer.cs','SonsVRMod.cs','RuntimeSettingsV105.cs']:
    t=files[name]
    ck(name+' raw brace balance', t.count('{')==t.count('}'))

failed=[n for n,v in checks if not v]
for n,v in checks: print(('PASS ' if v else 'FAIL ')+n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed.')
if failed:
    print('FAILED:', ', '.join(failed))
    sys.exit(1)
