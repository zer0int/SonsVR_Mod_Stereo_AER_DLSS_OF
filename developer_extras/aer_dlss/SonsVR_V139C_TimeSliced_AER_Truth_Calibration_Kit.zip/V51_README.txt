V51 experiment: remove the source-eye fallback layer.

Primary diagnostic:
- If the close flat/jittery holo-sheet and doubled characters/HUD disappear or shrink
  dramatically, the V49/V50 monoscopic source fallback was the remaining dominant artifact.
- Remaining localized holes/stale patches are then genuine disocclusion completion work.
