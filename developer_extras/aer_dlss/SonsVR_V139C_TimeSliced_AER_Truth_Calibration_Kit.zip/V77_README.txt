SONSVR V77 - FULL VIEWPORT SANITIZER
====================================

WHAT V76 PROVED
---------------
The near-field HUD "protruding hole" became a flat cutout/dense-remap result,
so the new HUD architecture is doing real work.

BUT:
A huge flashing rectangle still covers most of the synthetic eye even with the
HUD disabled entirely. Therefore that rectangle is NOT a HUD object.

WHY DLSS CHANGES ITS POSITION
-----------------------------
The custom VR eye cameras explicitly have:
  DLSSallow=False
  dynAllow=False

However HDRP still maintains global RTHandle/dynamic-resolution state. Immediate
mode GL viewport state is global too.

V36 already protected itself:
  Set target
  GL.Viewport(0,0,target.width,target.height)
  draw
  restore viewport

V50/V51 did NOT.

So if HDRP/DLSS leaves a smaller/offset viewport active, our warp/fill/fallback
passes render only into that rectangle of a 3141x3317 synthetic target. The
remaining pixels are cleared/stale. Alternating eyes then makes that rectangle
flash like a strobe. Changing the game's DLSS mode changes the leaked viewport,
which moves/resizes the seizure zone even though DLSS itself is disabled on the
custom eye cameras.

V77 FIX
-------
Every relevant private off-screen draw now explicitly forces a full viewport:
  V50 depth latch
  V76 HUD depth cutout
  V51 warp target
  V51 fill pass 1
  V51 fill pass 2
  V51 target fallback composite
  V76 dense HUD target composite

Then the previous render target + viewport are restored.

NO HUD ARCHITECTURE CHANGE FROM V76.
NO DLSS ENABLEMENT ON EYE CAMERAS.
NO TIMED PHASES.

BUILD
-----
  BUILD_V77.bat

Install only:
  OUTPUT\SonsVR_Mod.dll

CRITICAL LOG
------------
  [AER V77][Viewport] FULL-TARGET VIEWPORT SANITIZER ACTIVE

Expected target dimensions in the current setup:
  3141 x 3317

WHAT TO JUDGE
-------------
The first question is now simply:
  DID THE GIANT FLASHING RECTANGLE DISAPPEAR?

Then:
  ring/map jitter
  text slab
  overall V76 dense HUD result
