SonsVR V105c — safe render-scale persistence + crash-resilient perf breadcrumbs
===============================================================================

Why this exists
---------------
V105b successfully hot-applied most settings, but changing VR render scale from
1.00 to 0.80 while the game was live caused a hard hang. The final managed log
showed that the new 2513x2654 eye targets were created, the Apply routine returned,
NVOFA reconfigured to the matching 628x664 size, and then the process stopped with
no managed exception. This is consistent with a render-thread/native/HDRP resource
lifetime hazard, not a bad numeric 0.80 scale. Static/startup 0.80 had already been
used safely in earlier builds.

V105c policy
------------
* VR render-scale edits are SAVED but are NEXT-LAUNCH ONLY.
* Applying 0.80 while live at 1.00 keeps the current session at 1.00, writes 0.80
  to SonsVR_Settings.ini, and shows an in-HMD RESTART REQUIRED message.
* On the next launch LoadEarly() applies 0.80 before StereoRender allocates eye
  targets, avoiding live HDRP/AER/NVOFA target replacement.
* Other runtime settings remain live-applicable.
* The performance overlay and CSV report the ACTUAL live scale, not merely the
  saved next-launch value.

Logging hardening
-----------------
* WARNING rows now Flush() immediately. Normal SAMPLE rows remain buffered and
  only flush on the existing 5-second cadence, so steady-state logging stays cheap.
* Every explicit settings apply writes + flushes an EVENT SETTINGS_APPLY_BEGIN row
  BEFORE touching runtime state and EVENT SETTINGS_APPLY_END afterwards.
* BEGIN flush also commits any preceding buffered SAMPLE rows. Therefore a native
  hang immediately after Apply still leaves the pre-hang timeline on disk.
* Existing perf logs are still never overwritten (millisecond name + CreateNew +
  unique suffix fallback from V105b).

Build
-----
Run BUILD_V105C.bat and copy BOTH output DLLs into the game's Mods folder.

Note
----
If SonsVR_Settings.ini already contains RenderResolutionScale=0.80 from the V105b
hang attempt, V105c will intentionally start at 0.80. Change it in the HMD menu and
restart again if you want another scale.
