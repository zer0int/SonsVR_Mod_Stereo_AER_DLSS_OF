SonsVR V50 - CAMERA-LOCAL EYE DEPTH LATCH

Base: exact V49-R100 full SteamVR-recommended-resolution control (RenderResolutionScale=1.0).

Change: the headset synthesis path no longer reads Shader.GetGlobalTexture("_CameraDepthTexture") at EOF.
RenderPipelineManager.endCameraRendering identifies VRLeftEye/VRRightEye immediately after rendering, copies mip-0 raw depth into an owned full-resolution RFloat RT, and snapshots that exact eye/frame source projection, cameraToWorld, Z-buffer params, RTHandle scale, and screen size. EOF synthesis refuses stale/wrong-camera latches and falls back to V36 for that frame.

Build: BUILD_V50.bat
Output: OUTPUT\SonsVR_Mod.dll

Keep the game's superscaling setting in your normal DLSS state. No setting-toggle torture is needed for this run.
