from pathlib import Path
import hashlib
R=Path(__file__).resolve().parent;M=R/'mod'
def get(name):return (M/name).read_text(encoding='utf-8-sig')
checks={
  'calibrator integrated in mod': 'AerCalibrationV139.Tick();' in get('SonsVRMod.cs'),
  'calibrator included in explicit csproj sources': '<Compile Include="AerCalibrationV139.cs" />' in get('SonsVR_Mod.csproj'),
  'desktop progress display': 'AerCalibrationV139.DrawDesktopStatus();' in get('SonsVRMod.cs'),
  'auto AER mode selection': 'AUTO_SELECT_AER' in get('AerCalibrationV139.cs'),
  'AER restore on finish': 'RestoreCalibrationMode();' in get('AerCalibrationV139.cs'),
  'waiting status visible': '_phase == Phase.WaitingForGameplay) return' not in get('AerCalibrationV139.cs'),
  'calibration BOOT visible': 'AerCalibrationV139.Initialize();' in get('SonsVRMod.cs'),
  'late motion pass injection': '(AerCalibrationV139.Enabled && StereoRender.AerV99CaptureHdrpMotionVectors)' in get('SonsVRMod.cs'),
  'pack BAT exists': (R/'PACK_V139_TRACE.bat').exists(),
  '180 second countdown': 'SetupSeconds = 180f' in get('AerCalibrationV139.cs'),
  'native quality setter': 'ApplyDlssSetting' in get('AerCalibrationV139.cs'),
  'native quality verified': 'MatchesQuality(Quality(), Qualities[_bank])' in get('AerCalibrationV139.cs'),
  '3 unique effective scales': '"Performance", "Balanced", "Quality"' in get('AerCalibrationV139.cs'),
  'V99 real truth reused': 'TryScheduleTruthFrameV99' in get('StereoRender.cs'),
  'readback barrier': '_v99Readbacks[0].Pending || _v99Readbacks[1].Pending' in get('StereoRender.cs'),
  'V139 five guarded candidates': 'V103_GUARD_HIGH_SUPPORT' in get('StereoRender.cs'),
  'V103 original direct depth source': '"_DirectWarpInputV103"' in get('StereoRender.cs'),
  'V105 correct shader cap name': '"_V105FillDepthMaxToleranceMeters"' in get('StereoRender.cs'),
  'guard measured only offscreen': 'if (AerCalibrationV139.ActiveCapture)' in get('StereoRender.cs'),
  'CSV integrated': 'RecordTile(p.SampleId' in get('StereoRender.cs'),
  'readback signal': 'OnReadbackComplete(p.SampleId, p.Eye)' in get('StereoRender.cs'),
  'HMD cues activated': 'AerCalibrationV139.Enabled' in get('VRPlayer.cs'),
  'no V135 global forcing': 'Aggressive67' not in get('AerCalibrationV139.cs'),
  'no live V103 params touched': 'AerV103FillDepthAbsToleranceMeters =' not in get('AerCalibrationV139.cs'),
  'offline analysis available': (R/'analyze_v139.py').exists(),
  'trace pack available': (R/'pack_v139_trace.py').exists()
}
# Frozen known-good source SHA-256. Standalone; no dependencies on prior versions.
FROZEN = {'NativeDlssCameraScaleV136.cs': '7741b565f2710e5d18b53b8c58aade24acdbb3c68e86399024904d10bc848120', 'NativeDlssReceiverRouterV128.cs': 'e648c5247201c21e55408fe16ca93abb8eba9bb91d09d86c1484679d126aa83b', 'DlssRuntimeV91.cs': '0e8d504ba8426a2137f75db657e14c9804eb56a0c46b5a451b4fa584f452dd60', 'UnifiedHudWorldPlaneV116.cs': 'bb2faf5ad30f6009acd7a493b381a62299055fa21aae7714b0e7a363a8553f52', 'EyeDepthCaptureCustomPassV81.cs': 'a3362c34e1a4ee8fa56d5551d967f111ddce7089a507ed157249a1b3bb583138'}
for f,digest in FROZEN.items():
 checks['frozen '+f] = hashlib.sha256((M/f).read_bytes()).hexdigest()==digest
for k,v in checks.items():print('[PASS]' if v else '[FAIL]',k)
print(f"{sum(checks.values())}/{len(checks)} checks")
raise SystemExit(0 if all(checks.values()) else 1)
