# V139B HOTFIX — 2E wait-state + missing pack BAT repaired

Previous trace: `GameplayAerEnabled=False` and `mode=2E` for the entire 10-minute session. The original V139 controller waited silently for AER and suppressed its desktop overlay while waiting. No V139 markers and no calibration CSV existed.

V139B logs `BOOT`, shows desktop `WAITING` continuously, selects AER temporarily at the existing gameplay gate (without changing the saved INI), restores the original mode when finished/aborted, and includes the missing `PACK_V139_TRACE.bat`. It also registers the late V99 camera-motion capture type during mod startup so the calibration's motion telemetry isn't silently omitted.

**Before waiting on the ladder, verify desktop or Latest.log displays `[V139 CAL] SETUP_180_SECONDS`.** If you don't see that, the setup clock has not started; don't wait ten minutes.

# V139 — one-launch AER/2E-truth calibration campaign

**Experimental build. Back up V137.** This is not a production fix, and it does not change the live V103 depth-guard parameters. The previous 2E DLSS baseline and AER V138 path are otherwise preserved.

## Physical setup and 3-minute delay

1. Build using `BUILD_V139.bat` (Unity 2022.2.16f1), then put both DLLs from `OUTPUT` in the Sons Of The Forest `Mods` folder.
2. Start the game with **native DLSS enabled**, then enter gameplay. **V139B automatically selects AER for the calibration** even if your saved settings request 2E; it restores your prior gameplay-mode preference afterward and never edits the INI. You can see `WAITING` on the desktop before the experiment starts. When gameplay, AER, and the native receivers are ready, V139B begins a **180-second UNscaled-time countdown**. Desktop progress appears throughout, and the HMD receives brief cues during setup.
3. During these three minutes, type console commands (`cheatstick` → F1; `settimeofday 12`, `locktimeofday on`, `forcerain sunny`, `aipause on`; optionally `cloudenable off`, `cloudshadowsenable off`, `animalsenabled off`), reach your prepared rooftop sight line, and clamp the headset to your stable ladder mount. Point toward the wooden crossbar/trunks, foliage, lake. Exit the console.
4. Do not move the headset once the countdown ends. The capture begins after the system sees stable tracking and after the overlays have been cleared and resolution changes have settled.
5. V139 attempts to change the **actual native DLSS quality** automatically: **Performance (50%) → Balanced (58%) → Quality (66.7%)**, collecting **four genuine both-eye 2E reference frames per bank**. Ultra Performance is omitted because V137 measured the same 50% actual raster, and thus adds no distinct resolution. The normal AER display is unchanged except for sparse truth frames.
6. Wait for `V139 CALIBRATION COMPLETE`. If the native manager cannot be controlled or confirmed, the experiment aborts with a clear log message and tries to restore the original quality. There is no automatic invasive fallback.
7. Exit the game. **V139B includes `PACK_V139_TRACE.bat`**; run it to archive the tile CSV and logs, run `analyze_v139.py`, and include its report. It prints an explicit `NO_CALIBRATION_CSV` warning if the campaign did not begin. Send the ZIP back.

## What this test actually does

- Reuses V99's stale same-eye history, sporadic actual dual-eye truth, 16x12 GPU block-registration and 2E reference comparison.
- Adds **five offscreen V103 guarded-fill profiles** while retaining the six historical geometry/fill candidates plus raw history. They are evaluated on the **same truth frame**; none are submitted to SteamVR.
- Scores angular image-displacement errors by physical-top/center/bottom ROIs, edge error and coverage. Reports results per input-resolution bank, and holds out samples for verification.
- Stores a machine-readable `SonsVR_V139_CalibrationTiles_*.csv` in `Mods`. Output and logs are flushed after each bank. No full frames are CPU-read back.
- Checks whether the headset's reported pose is steady; records truth-frame pose intervals. This does not synthesize matching ground-truth camera movements.
- Does NOT modify DLSS scaler callbacks, matrices, guard values, SteamVR submission, or the production V103 path.

## Critical limitations

1. **Stationary-headset data cannot establish a moving-head jitter correction.** If ground truth has negligible motion, the report will explicitly say that calibration may be under-excited. The winning profile is a research recommendation, not auto-promoted to live AER.
2. Some moving weather/water/foliage remains. Distinct candidate errors and holdout validation are needed to reject spurious results.
3. Native `ApplyDlssSetting(string)` exists in the supplied IL2CPP wrapper, but its runtime effect must be confirmed. V139 aborts rather than guessing if it is unavailable or does not update the manager's active quality.
4. On some builds, game developer-console commands may differ or affect gameplay. Do NOT use `timescale 0` during this calibration, because it can corrupt temporal/motion cues.
5. Calibration GPU work is **not free**: each real-2E truth frame has 11 offscreen reconstruct-and-score candidates. Occasional frame hitches are expected. This is why V139 is for a stationary headset and not ordinary play.
6. If the calibration does not reach `COMPLETE` or reports GPU readback errors, pack the logs before relaunching; do not interpret a partially captured bank as successful.

## Intended follow-up

We will evaluate the field signature (especially physical TOP_CENTER), the depth bands and the held-out samples. If the regression is *geometric* rather than fill-related, the next experiment must vary the warp or pose calibration with **matched reference renders under controlled virtual motion**; this version does not claim to solve that harder problem.
