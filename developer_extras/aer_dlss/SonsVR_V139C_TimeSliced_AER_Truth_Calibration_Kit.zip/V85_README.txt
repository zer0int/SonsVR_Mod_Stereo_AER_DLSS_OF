SONSVR V85 — CLEAN SAME-EYE TEMPORAL TEST
=============================================

V84 recovered the ~26-30 FPS-ish regime. V83's same-eye run was contaminated by ~5 FPS / ~200 ms
history age plus the forensic GPU/readback stack.

V85 keeps the V84 fast substrate and changes only the world reconstruction family:
  fresh LEFT(t)  + previous REAL RIGHT + previous RIGHT camera-local depth/pose -> predicted RIGHT(t)
  fresh RIGHT(t) + previous REAL LEFT  + previous LEFT camera-local depth/pose  -> predicted LEFT(t)

Depth source: CustomPassContext.cameraDepthBuffer -> full-res RFloat. CustomPass diagnostics,
AsyncGPUReadback, truth board, V78/V79/V80/V81 tracing are OFF.

HUD depth catchers/dense remap remain in source but are default OFF through:
  AerHudDepthCatchersExperimentalEnabled = false
The normal HUD scale/position/timing fixes stay.

Expected:
  [AER V85][DepthLatch] ... DEPTH-SOURCE=CUSTOMPASS-cameraDepthBuffer
  [AER V85][Temporal] SAME-EYE TEMPORAL READY
  [AER V85][Temporal] HEADSET PATH ACTIVE
  [AER V85][TemporalTelemetry] ... age=1f/...ms ...

First judge performance. If fluid-ish, test rotation, translation/walking, hands/axe/moving objects, HUD.
If it immediately returns to <10 FPS hell, stop: the minimal temporal+camera-local-depth addition is implicated.

BUILD_V85.bat
PACK_V85_TRACE.bat
The packer includes only the CURRENT Latest.log, avoiding stale TSV contamination.
