SonsVR V102 - OCCLUSION / DEPTH-ASSOCIATION FORENSICS
======================================================

WHY V102
--------
V101 substantially weakened the simple "sky is infinite, therefore sky is the whole bug"
hypothesis:

  * treating every rawDepth==0 source pixel as an infinite layer massively increased direct
    physical-top coverage but did not reduce NO_DEPTH/SKYLIKE truth error;
  * the worst finite error lives in the mixed horizon/foliage rows rather than the purest
    no-depth row;
  * full finite translation scale ~= 1 remains approximately optimal.

The user's independent far-clip experiment is much more diagnostic. With normal ~24000 m view,
the upper mixed sky/forest zone wobbles. With the tarp forcing farClip ~= 50 m, isolated trees
near sky become stable while a nearer occluded rock/tree "slice" wobbles as one cutout.

V101 unfortunately collected ALL six dual-real truth samples BEFORE the tarp was opened, so it
never objectively measured that 50 m state. V102 does.

LEADING RASTER HYPOTHESIS
-------------------------
This is now a visibility/depth-association problem until disproven, especially at stacks of
alpha-tested tree cards and depth discontinuities:

  post-DLSS history color : ~3141 x 3317
  paired camera depth     : ~1572 x 1660 in the observed V101 run

The current presentation-grid scatter gives every post-DLSS color pixel its own ray but assigns
it the nearest lower-resolution depth sample. Around a thin leaf/card silhouette, several
post-DLSS output pixels can therefore inherit one depth value belonging to another surface/layer.
The spatial HoleFill passes are also color/confidence weighted, not depth-aware, so they can bridge
holes across an occlusion boundary. Finally, temporal history contains only the previously visible
front layer; a newly revealed layer behind an alpha card simply was not in that stale image.

V102 does NOT claim that a specific material is alpha-tested. It measures the raster signatures
expected from layered/occluding foliage and tests the two implementation choices directly.

NO LIVE VISUAL A/B
------------------
The displayed image is held fixed on the V100 baseline:

  finite depth -> full 6DoF reprojection
  -> radius-1 fill
  -> radius-2 fill
  -> remaining true holes use rotation-only/infinite-depth stale same-eye gather

V101's rawDepth==0 pre-scatter is OFF. NVOFA still executes for telemetry but is not applied to
the displayed PRE-NVOFA image. V36 remains hard-off.

This build is deliberately measurement-only so the 24000 m and 50 m truth banks are directly
comparable without a live renderer phase changing under them.

TWO TRUTH EPOCHS IN ONE LAUNCH
------------------------------
1) GAMEPLAY_24000M
   The existing initial six dual-real truth samples run in ordinary gameplay.

2) TARP_50M
   The FIRST SetFarClipDistance transition to <=100 m automatically rearms a fresh six-sample
   bank. There is a 30-frame warmup so both same-eye histories belong to the 50 m state.
   If the tarp closes early, scheduling pauses; reopening the tarp resumes the unfinished bank.

Every log line is tagged with epoch, epochSample and actual camera farClip.

OFFLINE CANDIDATE FACTORIAL
---------------------------
Candidate 0:
  RAW_HISTORY

Candidates 1..6 use exactly the same full 6DoF finite geometry and V100 rotation-only final-hole
fallback. Only these two factors change:

  source lattice:
    PRESENTATION = one scatter thread per post-DLSS color pixel, nearest low-res depth by UV
    DEPTHGRID     = one scatter thread per low-res depth cell / corresponding color sample

  spatial fill:
    FILL_R1_R2
    FILL_R1
    NO_FILL

Thus:
  PRESENTATION_FILL_R1_R2
  PRESENTATION_FILL_R1
  PRESENTATION_NO_FILL
  DEPTHGRID_FILL_R1_R2
  DEPTHGRID_FILL_R1
  DEPTHGRID_NO_FILL

Interpretation:
  * DEPTHGRID beating PRESENTATION specifically at mixed silhouettes implicates high-res
    post-DLSS color being assigned insufficiently resolved depth.
  * less/no fill beating R1+R2 specifically at those boundaries implicates cross-layer HoleFill.
  * neither factor helping, while temporal visibility-change classes remain terrible, implicates
    the fundamental one-layer stale-history/disocclusion problem instead.

TEMPORAL VISIBILITY / OCCLUSION CLASSES
---------------------------------------
For every candidate, each truth sample is also scored by:

  STABLE_NO_DEPTH
  CURRENT_NO_HISTORY_FINITE
  CURRENT_FINITE_HISTORY_NO
  FINITE_AGREE
  HISTORY_NEARER_DISOCCLUSION
  HISTORY_FARTHER_NEW_OCCLUDER

For current finite pixels, V102 reconstructs the truth world point, projects it into the stale
same-eye camera, and compares the stale ray's actual historical depth with the expected depth of
that world point. This is a raster visibility test, not a semantic object/material classifier.

SPATIAL OCCLUSION COMPLEXITY FIELD
----------------------------------
Per 16x12 tile V102 logs:
  no-depth fraction
  valid <-> no-depth neighbor-boundary fraction
  finite depth-edge fraction (> max(0.25 m, 5%))
  severe finite layer-jump fraction (> max(2 m, 20%))

POST-DLSS COLOR / DEPTH-ASSOCIATION RISK FIELD
----------------------------------------------
For low-res depth cells V102 samples several high-res truth color points inside the corresponding
cell and logs:
  mean within-cell luma range
  fraction with high color range (>0.08)
  fraction whose local depth neighborhood changes validity/layer
  fraction with BOTH high color variation and a depth discontinuity

That last channel is the direct raster proxy for "fine leaf/card color detail represented by a
coarser, mixed depth neighborhood."

DEPTH CLASSES RETAINED
----------------------
NEAR_0_2M
MID_2_10M
FAR_10_50M
DISTANT_50M_PLUS
NO_DEPTH_SKYLIKE

RUN - IMPORTANT ORDER
---------------------
1. BUILD_V102.bat
2. Copy OUTPUT\SonsVR_Mod.dll and OUTPUT\SonsVR_NvOF_V90.dll to the game Mods folder.
3. Launch outdoors in the same/similar forest scene.
4. DO NOT open the tarp immediately. Let GAMEPLAY_24000M reach:
       epoch=GAMEPLAY_24000M epochSample=6/6
5. Open the tarp. Keep it open for ~35-45 seconds to be safe.
   While it is open, rotate your head across the same central rock/trees and stacked foliage
   that visibly wobble as one depth slice.
6. Wait for:
       epoch=TARP_50M epochSample=6/6
   and preferably both corresponding ReadbackEnd lines.
7. Close tarp if desired.
8. PACK_V102_TRACE.bat
9. Send V102_TRACE_RETURN.zip.

There is no A/B/A perceptual report required for V102. A one-line note saying whether the same
central cutout slice still wobbled under the fixed baseline is useful, but the truth banks are the
main experiment.
