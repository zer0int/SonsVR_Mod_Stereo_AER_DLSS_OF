SonsVR V101 - SKY / INFINITY + DEPTH-CLASS FORENSICS
====================================================

WHY V101
--------
V99/V100 discovered that the troublesome PHYSICAL HMD TOP has very poor finite historical
camera-depth coverage. V100 proved that the ancient same-UV final-hole fallback is a real
contributor, but it only rotation-corrected pixels that were STILL holes after two fill passes.

Important blind spot: the old V99/V100 TileStats and block matcher intentionally skipped current
truth pixels with rawDepth==0. Thus the thing most likely to be literal HDRP SKY was never directly
included in the objective image-error score.

V101 tests the user's observation directly:
  - close feet/grass look much more stable
  - upper/far/sky field is much worse
  - sky is effectively infinite and owns no opaque camera depth

LIVE A/B/A - ONE NEW VARIABLE
-----------------------------
V100's rotation-only/infinite-depth FINAL true-hole fallback is ON in every V101 phase.

  A   0..15 s : rawDepth==0 source pixels are dropped from scatter (old behavior)
  B  15..30 s : rawDepth==0 source pixels are rotation-scattered as INFINITE background
                BEFORE radius-1/radius-2 hole fill
  A2 >30 s    : return to dropping rawDepth==0 source pixels

Finite-depth 6DoF reprojection is identical in all phases. DLSS, NVOFA workload, fill radii,
resolution and HUD path are unchanged.

The B scatter uses a background depth key of 0xFFFFFFFE, so any real finite geometry wins the
atomic z arbitration in front of sky/background.

WHAT TO LOOK AT
---------------
Put actual sky / horizon / treetops in the PHYSICAL UPPER HALF and rotate your head. Also spend
some time looking downward at close grass/feet for contrast.

Report simply:
  A : ?
  B : ?
  A2: ?

If B specifically stabilizes sky/upper field and A2 brings the defect back, that is a very clean
causal confirmation.

OFFLINE TRUTH MEASUREMENT
-------------------------
Six dual-real truth frames are retained. V101 candidates are:

  RAW_HISTORY
  TRANS_0.00_ROT_HOLE
  TRANS_0.25_ROT_HOLE
  TRANS_0.50_ROT_HOLE
  TRANS_0.75_ROT_HOLE
  TRANS_1.00_ROT_HOLE       <- current finite 6DoF translation magnitude
  TRANS_1.25_ROT_HOLE
  TRANS_1.00_SKYSCATTER_ROT_HOLE

All reconstructed candidates use presentation-grid scatter offline to remove source-thread density
as a confound and keep V100's rotation-only final-hole fallback.

Every candidate is scored separately on CURRENT truth pixels belonging to:
  NEAR_0_2M
  MID_2_10M
  FAR_10_50M
  DISTANT_50M_PLUS
  NO_DEPTH_SKYLIKE

The NO_DEPTH class is the one previous TileStats never measured.

GPU "STAR WARS LASER" CENSUS
-----------------------------
V101 also projects a grid of current camera rays through the actual HDRP camera depth and rotates
each ray into the stale same-eye camera. It logs, per 16x12 tile:
  current no-depth fraction
  stale no-depth fraction at unchanged UV
  stale no-depth fraction at rotation-mapped ray
  current-no-depth AND rotation-mapped-stale-no-depth overlap

This is deliberately based on the rendered camera depth rather than Physics.Raycast. A physics ray
would answer what colliders exist; we need to know what the exact raster/depth input consumed by AER
calls "no surface" (sky, alpha/LOD holes, etc.).

INTERPRETATION
--------------
1) If NO_DEPTH_SKYLIKE is concentrated in physical HMD TOP and SKYSCATTER strongly wins there:
   sky/infinity handling is a dominant defect. The likely production fix is not a literal giant
   sphere; it is to treat no-depth background as an infinite-depth layer before fill.

2) If finite DISTANT_50M_PLUS also improves as translation scale approaches 0 while NEAR prefers 1:
   finite far geometry is being over-translated / depth-calibrated badly.

3) If NEAR/MID/FAR all prefer scale=1 but only NO_DEPTH improves with SKYSCATTER:
   the finite 6DoF math is basically right and the missing sky layer is the main remaining bug.

4) If classes disagree spatially, the detailed class rows + scene/depth fields let us separate sky,
   treeline boundaries, alpha vegetation and genuine finite distant geometry.

RUN
---
1. BUILD_V101.bat
2. Copy OUTPUT\SonsVR_Mod.dll and OUTPUT\SonsVR_NvOF_V90.dll to the game Mods folder.
3. After AER activates, test at least ~40 seconds. A little longer is fine; wait for:
     [StereoRender][AER V99][ReadbackEnd] sample=6 eye=L complete.
     [StereoRender][AER V99][ReadbackEnd] sample=6 eye=R complete.
4. PACK_V101_TRACE.bat
5. Send V101_TRACE_RETURN.zip.
