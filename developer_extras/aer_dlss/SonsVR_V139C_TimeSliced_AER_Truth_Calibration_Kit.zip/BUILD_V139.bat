@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
if not defined UNITY_EXE set "UNITY_EXE=C:\Program Files\Unity 2022.2.16f1\Editor\Unity.exe"
set "UNITY_PROJECT=%ROOT%shader_project"
set "BUNDLE=%UNITY_PROJECT%\THINGY_OUT\sonsvr_depththingy"
set "MOD_DIR=%ROOT%mod"
set "MOD_RESOURCE=%MOD_DIR%\Resources\sonsvr_depththingy"
set "LABEL=v139c_timesliced_truth_calibration"
set "FINAL_DLL=%MOD_DIR%\builds\%LABEL%\SonsVR_Mod.dll"
set "NATIVE_DLL=%ROOT%native_nvof\build\SonsVR_NvOF_V90.dll"
set "OUT_DIR=%ROOT%OUTPUT"

if not exist "%UNITY_EXE%" (echo ERROR: Missing Unity 2022.2.16f1: %UNITY_EXE% & exit /b 2)
echo [1/5] Verifying standalone V139C source / frozen V137 core...
python "%ROOT%static_audit_v139c.py" > "%ROOT%V139_STATIC_AUDIT.txt"
set "AUDIT_RC=%ERRORLEVEL%"
type "%ROOT%V139_STATIC_AUDIT.txt"
if not "%AUDIT_RC%"=="0" exit /b %AUDIT_RC%

echo [2/5] Native NVIDIA Optical Flow bridge...
call "%ROOT%native_nvof\BUILD_NATIVE_V90.bat"
if errorlevel 1 exit /b %errorlevel%
if not exist "%NATIVE_DLL%" exit /b 3

if exist "%BUNDLE%" del /q "%BUNDLE%"
if exist "%MOD_RESOURCE%" del /q "%MOD_RESOURCE%"
echo [3/5] Compile unchanged depth shader bundle...
"%UNITY_EXE%" -batchmode -quit -projectPath "%UNITY_PROJECT%" -executeMethod BuildDepthThingy.BuildBatch -logFile "%ROOT%shader_build.log"
if errorlevel 1 exit /b %errorlevel%
if not exist "%BUNDLE%" exit /b 4
copy /y "%BUNDLE%" "%MOD_RESOURCE%" >nul
if errorlevel 1 exit /b %errorlevel%

echo [4/5] Build managed mod...
pushd "%MOD_DIR%"
call build_named.bat "%LABEL%"
set "BUILD_RC=%ERRORLEVEL%"
popd
if not "%BUILD_RC%"=="0" exit /b %BUILD_RC%
if not exist "%FINAL_DLL%" exit /b 5

if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"
copy /y "%FINAL_DLL%" "%OUT_DIR%\SonsVR_Mod.dll" >nul
copy /y "%NATIVE_DLL%" "%OUT_DIR%\SonsVR_NvOF_V90.dll" >nul
copy /y "%ROOT%V139_STATIC_AUDIT.txt" "%OUT_DIR%\V139_STATIC_AUDIT.txt" >nul

echo [5/5] Done. Copy both DLLs in OUTPUT to the game's Mods folder.
echo V139C automatically selects AER with native DLSS enabled. 180-second setup countdown starts after gameplay/receiver ready.
echo Then V139 automatically samples Performance 50%%, Balanced 58%%, Quality 67%%.
echo Once complete, run PACK_V139C_TRACE.bat (included) and return its ZIP and report.
exit /b 0
