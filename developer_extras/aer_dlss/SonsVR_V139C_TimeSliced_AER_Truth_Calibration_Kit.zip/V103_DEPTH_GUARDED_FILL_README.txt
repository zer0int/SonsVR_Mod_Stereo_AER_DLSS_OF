SonsVR V103 -- DEPTH-GUARDED HOLE FILL / HMD-GUIDED A-B-C-A2
================================================================

Purpose
-------
V102 showed that the historical spatial HoleFill can increase truth error around
layered foliage / finite-depth discontinuities, while globally disabling fill also
hurts otherwise-good coherent geometry. V103 tests a selective replacement live.

This is a CLEAN PERCEPTUAL TEST:
- V99/V102 heavy dual-real truth readbacks are OFF.
- No desktop/log watching is required.
- Green head-locked HMD cues announce each mode for ~3 s, then DISAPPEAR during the actual visual comparison so they do not become a head-locked perceptual anchor.
- NVOFA hardware may still execute, but its residual is intentionally ignored during
  the test so you see the old raw pre-NVOFA wobble rather than smoothed jelly.
- V100 rotation-only FINAL true-hole fallback remains enabled in every phase.

Fill modes
----------
A / A2 = BASELINE
  Historical HoleFill pass, radius 1 then radius 2. Every occupied neighbor may
  contribute, and radius-1 filled pixels can seed radius 2.

B = DEPTH-GUARDED
  Still radius 1 then radius 2, but NEW fill candidates come only from ORIGINAL
  direct-scatter pixels that have a valid target-depth key. A hole is filled only
  when a dominant neighboring depth cluster exists.

  Defaults:
    absolute depth tolerance = 0.30 m
    relative tolerance       = 6%
    dominant support fraction= 60%
    minimum support neighbors= 2

  Ambiguous layer boundaries remain holes and fall through to V100's rotation-only
  final fallback. Radius-1 filled colors can be preserved at their own pixels but
  NEVER become candidate colors for radius 2.

C = NO SPATIAL FILL
  Direct scatter goes straight to the V100 final-hole fallback. This is deliberately
  aggressive and mainly tells us how much of the remaining wobble is caused by fill.

Protocol
--------
1. BUILD_V103.bat and install BOTH DLLs as usual.
2. Load the same forest/tarp area. Leave tarp CLOSED until ready.
3. Follow the GREEN HMD cues.
4. Open tarp when the cue says READY.
5. TREE/ROCK test: each phase card appears briefly; when it VANISHES, do the sweep.
     A  baseline      -- slow head sweep over the known wobbling rock/tree slice
     B  depth-guard   -- repeat the SAME sweep
     C  no fill       -- repeat the SAME sweep
     A2 baseline      -- repeat once more
6. The cue gives ~10 s to look down at CLOSE GRASS/FEET.
7. Repeat A / B / C / A2 with the same slow head sweep over close coherent geometry.
8. At TEST COMPLETE, report:

   TREE/ROCK:
     A  =
     B  =
     C  =
     A2 =

   CLOSE GRASS:
     A  =
     B  =
     C  =
     A2 =

Expected discriminant
---------------------
Ideal result for the hypothesis:
- TREE/ROCK: B approaches C and is clearly better than A/A2.
- CLOSE GRASS: B stays close to A/A2, while C may get worse / show more fallback.

That would mean the fix is not "turn fill off"; it is "fill only when neighboring
samples agree on a geometric layer."

If B is no better than A but C is much better, the depth-key guard is too permissive
or the problem is recursive fill independent of layer mismatch.

If all four modes look identical, fill is not the dominant perceptual mechanism and
we go after direct-scatter/depth ownership next.

Optional log
------------
No trace is required for the intended result. If anything behaves unexpectedly, run
PACK_V103_LOG.bat after leaving VR and send V103_LOG_RETURN.zip.
