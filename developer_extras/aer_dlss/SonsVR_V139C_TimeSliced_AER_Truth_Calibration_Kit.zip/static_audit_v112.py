from pathlib import Path
import re, sys
root=Path(__file__).resolve().parent
mod=root/'mod'
issues=[]

def chk(cond,msg):
    print(('PASS ' if cond else 'FAIL ')+msg)
    if not cond: issues.append(msg)

vr=(mod/'VRPlayer.cs').read_text(encoding='utf-8-sig')
st=(mod/'StereoRender.cs').read_text(encoding='utf-8-sig')
rs=(mod/'RuntimeSettingsV105.cs').read_text(encoding='utf-8-sig')
son=(mod/'SonsVRMod.cs').read_text(encoding='utf-8-sig')
csproj=(mod/'SonsVR_Mod.csproj').read_text(encoding='utf-8-sig')

# Production renderer / catcher rollback invariants
chk('AerHudDepthCatchersExperimentalEnabled = false' in st,'HUD catcher master hard-off')
chk('AerHudDepthProxyV72Enabled = false' in st,'HUD depth proxy hard-off')
chk('AerHudDensePlanarRemapV76Enabled = false' in st,'HUD dense remap hard-off')
chk('AerHudDensePlanarTextBlackBackingV76 = false' in st,'HUD text backing hard-off')
chk('HudProxyMeshesV74.cs' not in csproj,'compiled HUD proxy source excluded')
chk(not (mod/'HudProxyMeshesV74.cs').exists(),'compiled HUD proxy source absent')
chk('AerV103FillDepthMaxToleranceMeters' in st or 'AerV105FillDepthMaxToleranceMeters' in st,'production depth guard still present')

# V108 HUD geometry preserved, with only Y correction after outer placement
chk('public static float MinimapForwardDistance = 0.5f;' in vr,'V108 minimap forward distance preserved')
chk('public static float MinimapScaleMultiplier = 1.00f;' in vr,'V108 minimap scale preserved')
chk('public static float VitalsUiScaleMultiplier = 1.00f;' in vr,'V108 vitals scale preserved')
chk('float MinimapOffsetRight = 0.20f;' in vr,'V108 horizontal HUD offset preserved')
chk('float MinimapOffsetUp = -0.16f;' in vr,'V108 legacy vertical offset preserved as base')
chk('_PlayerMiniMapTransf.SetPositionAndRotation(finalPosition, minidesiredRotation);' in vr,'V108 outer-container placement preserved')
chk('UpdateVitalsRenderTextureV16();' in vr,'V108 ring centering path retained')
chk('CenterMinimapVerticallyV112 = true' in vr,'projection-aware HUD Y center defaults on')
chk('WorldToViewportPoint(worldPoint)' in vr and 'ViewportToWorldPoint(new Vector3(vp.x, 0.5f, vp.z))' in vr,'HUD Y correction solves normalized viewport centre')
chk('ApplyProjectionAwareMinimapVerticalCenterV112();' in vr,'HUD Y correction inserted after V108 base placement')
chk('V108 LEGACY Y' in rs,'live rollback to exact V108 Y exposed')

# AER/2E mode control and actual backend reporting
chk('public static bool UserGameplayAERV112 = true;' in st,'persisted gameplay mode preference defaults AER')
chk('AlternateEyeRenderingEnabled = UserGameplayAERV112;' in st,'gameplay activation honors requested AER/2E mode')
chk('StereoRender.AlternateEyeRenderingEnabled = next.GameplayAerEnabled;' in rs,'live settings apply drives actual backend mode')
chk('GetActualRenderModeV112()' in st,'backend actual-mode reporter exists')
chk('return "2E/UI";' in st and 'return "2E/WARM";' in st and 'return "AER";' in st,'actual mode distinguishes UI pin/warmup/AER')
chk('Gameplay render mode' in rs and '[actual {actualModeV112}]' in rs,'settings table shows configured plus actual mode')
chk('actualModeV112' in rs and '~{fps:F1} FPS' in rs,'perf HUD reports actual mode beside FPS')
chk('GameplayAerEnabled=' in rs,'AER/2E preference persisted to INI')
chk('render_mode' in rs,'lightweight perf CSV records actual mode')

# V111 2E-stuck risk correction
chk('VRPlayer.IsTimeScalePausedV112 || RuntimeSettingsV105.IsPanelOpenV111' in st,'UI 2E pin uses strict timeScale pause + own panel')
chk('VRPlayer.IsPauseMenuOpenConfirmed || RuntimeSettingsV105.IsPanelOpenV111' not in st,'broad/sticky pause-root signal no longer forces 2E')
chk('IsTimeScalePausedV112 => Time.timeScale <= 0.0001f' in vr,'strict pause truth exposed')

# Deterministic custom overlay placement
chk('PlaceWorldCanvasAtStereoViewportV112(_statsGo, stereo, 0.82f, 0.84f, 0.28f, 1.25f)' in rs,'perf HUD target is normalized top-right with explicit distance/width')
chk('PlaceWorldCanvasAtStereoViewportV112(_settingsGo, stereo, 0.50f, 0.52f, 0.66f, 1.25f)' in rs,'settings panel target is normalized viewport center')
chk('ViewportToWorldPoint' in rs and 'worldWidth / pxWidth' in rs,'custom overlay placement derives both position and angular size from eye projections')
chk('RowCount = 15' in rs,'settings rows expanded for mode + HUD Y control')

# Retained loading/performance fixes
chk('LOADING\\n" + frame + "\\nSOTF VR' in vr,'clean three-line loading UI retained')
chk('SetNativeLoadingVisualsSuppressedV110(true)' in vr,'native loading animation remains suppressed')
chk('ApplyTitleLoadingEyeLiftV110' in vr,'title/loading eye lift retained')
chk('V108 CookingPages' in vr or '[V108 CookingPages]' in vr,'V108 cooking page cache retained')

# Version/build surface
chk('[SonsVR V112]' in son,'startup marker V112')
chk((root/'BUILD_V112.bat').exists(),'BUILD_V112.bat exists')
chk((root/'PACK_V112_TRACE.bat').exists(),'PACK_V112_TRACE.bat exists')

# Crude structural sanity on changed C# files
for name,text in [('VRPlayer.cs',vr),('StereoRender.cs',st),('RuntimeSettingsV105.cs',rs)]:
    chk(text.count('{') == text.count('}'), f'{name} raw brace counts balanced')

print(f'\nRESULT: {len(issues)} failure(s)')
if issues:
    for x in issues: print(' -',x)
    sys.exit(1)
