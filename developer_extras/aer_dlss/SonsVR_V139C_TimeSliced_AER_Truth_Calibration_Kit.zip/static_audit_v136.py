#!/usr/bin/env python3
from pathlib import Path
import sys,subprocess,hashlib
p=Path(__file__).resolve().parent
r=subprocess.run([sys.executable,str(p/'static_audit_v133b.py')],cwd=p,text=True)
if r.returncode:raise SystemExit(r.returncode)
m=p/'mod'; s=(m/'NativeDlssCameraScaleV136.cs').read_text(encoding='utf8'); e=(m/'SonsVRMod.cs').read_text(encoding='utf8');proj=(m/'SonsVR_Mod.csproj').read_text(encoding='utf8')
checks={
 'V136 source compiled':'<Compile Include="NativeDlssCameraScaleV136.cs" />' in proj,
 'patches one private ScaleFn method':'GetMethod("ScaleFn", Flags)' in s and '_harmony.Patch(method, prefix:' in s,
 'scope uses both eye camera IDs':'_leftCamId = stereo.LeftCam.GetInstanceID()' in s and '_rightCamId = stereo.RightCam.GetInstanceID()' in s,
 'IL2CPP object state identity match':'Il2CppObjectBase' in s and 'Interlocked.Read(ref _leftStatePointer)' in s,
 'no global DRS writes':all(x not in s for x in ('SetDynamicResScaler(', 'SetSystemDynamicResScaler(', 'SetActiveDynamicScalerSlot(', '.m_CurrentFraction =', '.m_MinScreenFraction =', '.m_MaxScreenFraction =')),
 'no camera optimal attr writes':'deepLearningSuperSamplingUseOptimalSettings =' not in s,
 'no NVIDIA feature mutation':all(x not in s for x in ('CreateFeature(', 'DestroyFeature(', 'ExecuteDLSS(')),
 'AER/route gate': 'StereoRender.UserGameplayAERV112 || !NativeDlssReceiverRouterV128.Routed' in s,
 'logs hook execution':'HOOK_HITS L=' in s and 'ARMED leftState=' in s,
 'startup hook':'NativeDlssCameraScaleV136.Initialize();' in e,
 'per-update scoping':'NativeDlssCameraScaleV136.Tick();' in e,
 'shutdown cleanup':'NativeDlssCameraScaleV136.Shutdown();' in e,
 'renderer unchanged': hashlib.sha256((m/'StereoRender.cs').read_bytes()).hexdigest() == 'f87ca07cadfb1a4e4910a4a21ea8e1d6031cd114aee61e04cd146bba430abf7c',
 'V116 HUD unchanged': hashlib.sha256((m/'UnifiedHudWorldPlaneV116.cs').read_bytes()).hexdigest() == 'bb2faf5ad30f6009acd7a493b381a62299055fa21aae7714b0e7a363a8553f52',
 'V128 router unchanged': hashlib.sha256((m/'NativeDlssReceiverRouterV128.cs').read_bytes()).hexdigest() == 'b159d5196e48f422e9c4326ef2cfc1162c37c4f72458cc6418fbc9e1a0365366',
 'standalone build and pack': (p/'BUILD_V136.bat').exists() and (p/'PACK_V136_TRACE.bat').exists(),
}
for k,v in checks.items():print(('[PASS]' if v else '[FAIL]')+' '+k)
print('V136 audit: %d/%d'%(sum(checks.values()),len(checks)))
raise SystemExit(0 if all(checks.values()) else 2)
