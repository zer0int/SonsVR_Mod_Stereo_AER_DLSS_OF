SonsVR V62 — SAFE HUD BASELINE (V60 ROLLBACK + V61 LAYOUT LESSONS)
==================================================================

WHY THIS EXISTS
---------------
V61 finally activated the direct-UGUI experiment, and immediately demonstrated that replaying
raw Graphic/TMP meshes with Graphics.DrawMeshNow is not equivalent to Unity CanvasRenderer.
The desktop capture exposed the full GPS surface map outside its mask plus large white mask/clip
geometry, followed by severe compositor/GPU timing collapse and a hang.

V62 deliberately returns to the proven V51/V50 AER WORLD renderer and native Unity UGUI path.
This is a recovery/baseline build, not the final jitter fix.

WHAT CHANGED FROM THE ATTACHED V60 BASE
----------------------------------------
1. HudStereoReprojectV60.Enabled = false. No UGUI culling, rebuilding, or manual DrawMeshNow replay.
2. V60's render-boundary Canvas.ForceUpdateCanvases() mutation is removed.
3. Minimap world-scale conversion is restored to the previously proven Screen.height basis.
4. The visible 1.75x VitalsRenderTexture is centered on the native stationary
   GPSTrackerSystem/Canvas/VitalsBackingCircle. Stable fallbacks: ScreenBounds, then Canvas.
5. V51/V50 AER depth warp, hole fill/fallback, tarp/body/menu fixes, etc. are otherwise untouched.

EXPECTED FIRST TEST
-------------------
- No giant full-island map.
- No giant white polygons / white boxes from mask graphics.
- No V61 direct-UGUI hang.
- HUD spread should be back to the normal pre-V60 layout (no Mystery Column).
- Ring should use VitalsBackingCircle rather than a moving locator or merely ScreenBounds.
- HUD wobble is EXPECTED to remain; this build intentionally does not claim to fix it.

The next jitter architecture should keep native CanvasRenderer color completely intact and instead
feed the AER warp a HUD mask / HUD-depth override. That avoids reimplementing UGUI clipping, stencil,
RectMask2D, TMP per-renderer state, and GPS masks.

BUILD
-----
Run BUILD_V62.bat and install only OUTPUT\SonsVR_Mod.dll.

Useful startup lines:
  [ZER0INT TEST V62 SAFE HUD BASELINE]
  [VRPlayer][AER V62][HudLayout] RING anchor=.../VitalsBackingCircle
  [StereoRender][AER V62] GPU same-time WORLD synthesis ARMED...

There should be NO:
  [AER V61][UGUI] WORLD-ONLY eye capture armed
  [AER V61][UGUI] DIRECT SAME-TIME HUD STEREO IS IN HEADSET PATH
