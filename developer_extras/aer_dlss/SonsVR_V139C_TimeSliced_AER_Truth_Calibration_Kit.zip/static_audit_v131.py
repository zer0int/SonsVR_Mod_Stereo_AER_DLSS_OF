from pathlib import Path
import hashlib, subprocess, sys
R=Path(__file__).resolve().parent; M=R/'mod'
# V131 fix: all inherited auditors ship within the same extracted V131 kit.
r=subprocess.run([sys.executable,str(R/'static_audit_v130.py')], cwd=R, capture_output=True, text=True)
new=(M/'NativeDlssForceActivationV131.cs').read_text()
checks={
'V130 baseline inherited checks':r.returncode==0,
'one-shot experimental class included':'Compile Include="NativeDlssForceActivationV131.cs"' in (M/'SonsVR_Mod.csproj').read_text(),
'gameplay readiness gate':all(x in new for x in ('NativeDlssReceiverRouterV128.Routed','_hdrpDataCopiedOnce','UserGameplayAERV112')),
'30-second baseline and 5-second warning':all(x in new for x in ('BaselineSeconds = 30f','WarningSeconds = 5f','Time.frameCount < _cueClearedFrame + 2')),
'HDRP activation bit written to local value copy': 'drs.enableDLSS = newValue;' in new and 'TryWriteAssetDlss(true, out detail)' in new,
'no compile-time writes to getter-only HDRP properties': all(x not in new for x in ('settings.dynamicResolutionSettings.enableDLSS = true;', '_asset.currentPlatformRenderPipelineSettings = settings;', 's.dynamicResolutionSettings.enableDLSS = _originalEnableDlss;', '_asset.currentPlatformRenderPipelineSettings = s;')),
'unsupported writer fails explicitly': 'NO_WRITE_UNSUPPORTED' in new and 'verified.enableDLSS != newValue' in new,
'no invented DLSS filter enum': 'DynamicResUpscaleFilter.DLSS' not in '\n'.join(line for line in new.splitlines() if not line.strip().startswith('//') and 'do not invent' not in line),
'no scaler slot writes': all(x not in '\n'.join(line for line in new.splitlines() if not line.strip().startswith('//')) for x in ('SetDynamicResScaler(', 'SetActiveDynamicScalerSlot(', 'DynamicResolutionHandler.SetUpscaleFilter(', 'FindObjectsOfType(')),
'V129 truth TSV durable prewrite': 'V131FlushMarker("PRE_FORCE_FLUSHED")' in new and '_writer.Flush();' in (M/'NativeDlssLiveResolutionTraceV129.cs').read_text(),
'V131 timed Tick':'NativeDlssForceActivationV131.Tick();' in (M/'SonsVRMod.cs').read_text(),
'VRPlayer reused old cue, no new canvas':'NativeDlssForceActivationV131.CueActive' in (M/'VRPlayer.cs').read_text() and 'new GameObject(' not in new,
'VRPlayer differs only by audited V131 cue gate': hashlib.sha256((M/'VRPlayer.cs').read_bytes()).hexdigest()=='80b47a626ba418c659f873521d3f7d1c615d81cad297161222cf04c45ed20e61',
'V128 router unchanged':hashlib.sha256((M/'NativeDlssReceiverRouterV128.cs').read_bytes()).hexdigest()=='b159d5196e48f422e9c4326ef2cfc1162c37c4f72458cc6418fbc9e1a0365366',
'unchanged V116 renderer/HUD/depth':all(hashlib.sha256((M/f).read_bytes()).hexdigest()==v for f,v in {
'StereoRender.cs':'f87ca07cadfb1a4e4910a4a21ea8e1d6031cd114aee61e04cd146bba430abf7c',
'UnifiedHudWorldPlaneV116.cs':'bb2faf5ad30f6009acd7a493b381a62299055fa21aae7714b0e7a363a8553f52',
'EyeDepthCaptureCustomPassV81.cs':'a3362c34e1a4ee8fa56d5551d967f111ddce7089a507ed157249a1b3bb583138',
'EyeMotionCaptureCustomPassV89.cs':'93e7c4cc542b0f4292cd5ed0a8c3a899df3e7ad82f9d5a90f888bb196c028c56',
'NvOpticalFlowV90.cs':'a897d1a9a463c1d9227b86a2b37e0af45e4405524d7269c40b48f6a77448241f'
}.items())
}
if r.returncode != 0:
    print('Inherited V130 audit failed:')
    print(r.stdout)
    print(r.stderr)
for name,ok in checks.items():print(('[PASS]' if ok else '[FAIL]'),name)
print('V131 static audit:',sum(checks.values()),'/',len(checks));sys.exit(0 if all(checks.values()) else 1)
