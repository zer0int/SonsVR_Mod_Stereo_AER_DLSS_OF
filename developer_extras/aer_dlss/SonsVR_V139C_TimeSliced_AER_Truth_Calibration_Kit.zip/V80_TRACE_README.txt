SONSVR V80 — PASSIVE RAW DEPTH INPUT FORENSICS
================================================

WHAT V79 PROVED
---------------
This is the important fork result:

When game DLSS is ON (Ultra Performance / Quality):
  V51 synthetic fallback holes are much smaller.

When game DLSS is OFF:
  V51 fallback holes explode to roughly 85-90% of the synthetic image.

The change happens immediately with the Sons.Dlss state transition.

Meanwhile:
  - VRLeftEye/VRRightEye HDCamera history remains isolated at 3141x3317.
  - Per-eye history RTHandle scale stays 1,1,1,1.
  - Eye SRP_END RTHandle/DRS state does not change with DLSS.
  - OpenVR submission size stays 3141x3317.
  - OpenVR UV bounds stay u=0..1 / v=1..0.
  - SteamVR recommended scene size stays 3141x3317.

So the moving "seizure rectangle" is genuinely created UPSTREAM inside V51.
It is not a compositor crop and not per-eye HDRP history contamination.

WHY V80
-------
V51 coverage can collapse for several different reasons. The strongest remaining
candidate is the actual CONTENT of _CameraDepthTexture, not its allocation.

V80 samples the exact global depth texture at the exact endCameraRendering
callback immediately before V50 latches it.

It uses a tiny 256x256 PASSIVE diagnostic map. It never changes the renderer.

RGBA diagnostic meaning:
  R = raw depth valid for V51 (nonzero, positive, <=300m)
  G = raw depth nonzero
  B = local depth discontinuity exceeds the SAME V51 tolerance
  A = log-compressed linear eye depth

The async CPU summary records:
  zeroFrac
  nonzeroFrac
  validFrac
  tooFarFrac
  discontinuity fraction
  approximate median valid depth
  valid fractions for top/middle/bottom thirds
  valid fractions for left/center/right thirds
  largest connected invalid-depth component bbox/centroid

It also records source/target projection matrices and GPU projection matrices
change-only.

DECISION TREE
-------------
A) validFrac / invalid region changes massively with DLSS
   -> _CameraDepthTexture CONTENT itself is changing/broken for the custom eye.
   -> then inspect HDRP GenerateDepthPyramid / singleton DRS timing and fix V50
      provenance at a lower level.

B) depth validity stays stable but discontinuity fraction changes
   -> depth values/gradient construction changes with upscaler state.

C) depth input + discontinuity stay stable but V51 coverage still changes
   -> projection/rasterization or another shader input is changing.
   Projection matrix trace should then narrow it immediately.

ONE SESSION
-----------
Same protocol:
  1. Current normal DLSS/superscale state ~3 sec.
  2. Fully OFF ~3 sec.
  3. DLSS Quality ~3 sec.
  4. Fully OFF ~3 sec.
  5. Quit.

No visual judgement required.

BUILD
-----
  BUILD_V80_TRACE.bat

Install only:
  OUTPUT\SonsVR_Mod.dll

PACK
----
  PACK_V80_TRACE.bat

Send:
  V80_TRACE_RETURN.zip

KEY TSV ROWS
------------
  DEPTH_V80
  PROJECTION_V80
  COVERAGE_V79
  sons.dlss.*
  hdhistory.*
  SUBMIT_V79
