from pathlib import Path
import re

root = Path(__file__).resolve().parent
stereo = (root / 'mod' / 'StereoRender.cs').read_text(encoding='utf-8')
vrplayer = (root / 'mod' / 'VRPlayer.cs').read_text(encoding='utf-8')
shader = (root / 'shader_project' / 'Assets' / 'DepthStereoWarp.shader').read_text(encoding='utf-8')
build = (root / 'BUILD_V104.bat').read_text(encoding='utf-8')
readme = (root / 'V104_PRODUCTION_DEPTH_GUARD_README.txt').read_text(encoding='utf-8')

checks = []
def check(name, cond):
    checks.append((name, bool(cond)))

check('V104 permanent guard enabled', 'public static bool AerV104DepthGuardedFillPermanentEnabled = true;' in stereo)
check('V103 perceptual A/B/C disabled', 'public static bool AerV103DepthGuardFillPerceptualTestEnabled = false;' in stereo)
check('V103 pre-NVOFA exposure disabled', 'public static bool AerV103ExposePreOpticalFlowJitter = false;' in stereo)
check('NVOFA globally enabled', 'public static bool AerTemporalOpticalFlowV90Enabled = true;' in stereo)
check('V94 source-matrix A/B disabled', 'public static bool AerV94HdrpSourceMatrixABEnabled = false;' in stereo)
check('V98 presentation-grid A/B disabled', 'public static bool AerV98PresentationGridScatterABEnabled = false;' in stereo)
check('V99 heavy forensics disabled', 'public static bool AerV99ForensicsEnabled = false;' in stereo)
check('V102 heavy forensics disabled', 'public static bool AerV102OcclusionForensicsEnabled = false;' in stereo)
check('Production default fill mode is guard', 'int fillModeV103 = AerV104DepthGuardedFillPermanentEnabled ? 1 : 2;' in stereo)
check('Historical phase override gated by opt-in V103 flag', 'if (AerV103DepthGuardFillPerceptualTestEnabled)\n                        fillModeV103 = UpdateV103PerceptualPhase();' in stereo)
check('Guard requires per-pixel scatter', 'usedPerPixelScatterV88 &&' in stereo)
check('Guard requires depth-key RT', '_scatterDepthKeyRTV88 != null &&' in stereo and '_scatterDepthKeyRTV88.IsCreated();' in stereo)
check('Guard-resource failure fails to NO FILL', 'fillModeV103 = 2;' in stereo)
check('Guard-resource failure never advertises legacy fallback', 'FAIL-SAFE = NO spatial fill + V100 rotation fallback' in stereo)
check('Guard shader pass lookup present', '_material.FindPass("HoleFillDepthGuardV103")' in stereo)
check('Guard samples original direct scatter', '_material.SetTexture("_DirectWarpInputV103", warpRT);' in stereo)
check('Guard samples winning depth keys', '_material.SetTexture("_ScatterDepthKeyV103", _scatterDepthKeyRTV88);' in stereo)
check('Production thresholds preserved: abs 0.30m', 'AerV103FillDepthAbsToleranceMeters = 0.30f;' in stereo)
check('Production thresholds preserved: relative 6%', 'AerV103FillDepthRelativeTolerance = 0.06f;' in stereo)
check('Production thresholds preserved: support fraction 60%', 'AerV103FillMinSupportFraction = 0.60f;' in stereo)
check('Production thresholds preserved: support count 2', 'AerV103FillMinSupportCount = 2;' in stereo)
check('V100 final true-hole rotation fallback permanently ON', 'bool useRotationHoleFallbackV100 = true;' in stereo)
check('V104 startup announces NVOFA active', 'NVOFA residual ACTIVE when available' in stereo)
check('V104 startup announces permanent guard', 'hole fill is PERMANENT' in stereo)
check('VR cue infrastructure dormant when V102/V103 tests are off', '!global::SonsVRMod.StereoRender.AerV102OcclusionForensicsEnabled &&\n                !global::SonsVRMod.StereoRender.AerV103DepthGuardFillPerceptualTestEnabled' in vrplayer)
check('Shader exposes depth-guard pass', 'Name "HoleFillDepthGuardV103"' in shader)
check('Shader guard reads only direct input', '_DirectWarpInputV103.Load' in shader)
check('Shader guard reads depth key', '_ScatterDepthKeyV103.Load' in shader)
check('Shader rejects invalid depth key sentinels', 'key == 0xFFFFFFFFu || key == 0xFFFFFFFEu' in shader)
check('Shader uses depth agreement predicate', 'V103DepthsAgree' in shader)
check('Shader enforces minimum support', 'bestSupport < minSupport' in shader)
check('Shader enforces support fraction', 'supportFraction < saturate(_V103FillMinSupportFraction)' in shader)
check('R2 cannot use R1 invented pixels as candidates', 'sampleColor = _DirectWarpInputV103.Load' in shader)
check('Build label is V104 production', 'LABEL=v104_depth_guard_production' in build)
check('README explicitly says old unguarded fill never returns', 'never resurrects the old\n   unguarded cross-depth HoleFill' in readme)

# Lightweight delimiter sanity checks; not a compiler.
def balanced(text, left, right):
    return text.count(left) == text.count(right)
check('StereoRender brace counts balanced', balanced(stereo, '{', '}'))
check('VRPlayer brace counts balanced', balanced(vrplayer, '{', '}'))
check('Shader brace counts balanced', balanced(shader, '{', '}'))

failed = [name for name, ok in checks if not ok]
for i, (name, ok) in enumerate(checks, 1):
    print(f'{i:02d}. {"PASS" if ok else "FAIL"}: {name}')
print(f'\n{sum(ok for _, ok in checks)}/{len(checks)} checks passed.')
if failed:
    print('FAILED:')
    for name in failed:
        print(' -', name)
    raise SystemExit(1)
