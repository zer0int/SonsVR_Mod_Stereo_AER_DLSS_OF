#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys, hashlib
p=Path(__file__).resolve().parent
r=subprocess.run([sys.executable,str(p/'static_audit_v136.py')],cwd=p,text=True)
if r.returncode:raise SystemExit(r.returncode)
m=p/'mod'; scale=(m/'NativeDlssCameraScaleV136.cs').read_text(encoding='utf8'); overlay=(m/'RuntimeSettingsV105.cs').read_text(encoding='utf8')
checks={
 'native manager quality is authoritative':'_activeDlssQualitySetting' in scale and 'GetDynamicResolutionOption' in scale,
 'quality is 66.7':'case "quality":' in scale and '66.7f' in scale,
 'balanced is 58':'case "balanced": percentage = 58.0f;' in scale,
 'performance is 50':'case "maximumperformance": percentage = 50.0f;' in scale,
 'ultra performance is 33.3':'case "ultraperformance": percentage = 33.3f;' in scale,
 'unknown/off cannot force a scale':'_menuDlssActive = valid;' in scale and 'if (!UpdateNativeMenuTarget())' in scale,
 'hot callback uses cached value':'__result = _targetPercentage;' in scale and 'ScaleFnPrefix' in scale,
 'stereo gate still present':'StereoRender.UserGameplayAERV112 ||' in scale and '!NativeDlssReceiverRouterV128.Routed' in scale,
 'no global DRS writes':all(x not in scale for x in ['SetDynamicResScaler(', 'SetSystemDynamicResScaler(', 'SetActiveDynamicScalerSlot(', '.m_CurrentFraction =', '.m_MinScreenFraction =']),
 'overlay widened inward, outer edge fixed':'0.620f, 0.727f, 0.276f' in overlay and '1380f, 470f' in overlay,
 'overlay avoids wrapped timings':'HorizontalWrapMode.Overflow' in overlay,
 'overlay uses measured HDCamera':'HDCamera.GetOrCreate(eye, 0)' in overlay and 'hd.actualWidth' in overlay and 'hd.actualHeight' in overlay,
 'overlay adds fourth line':'_statsResolutionText;' in overlay and 'DLSS OFF:' in overlay,
 'V137 build/pack included':(p/'BUILD_V137.bat').exists() and (p/'PACK_V137_TRACE.bat').exists(),
 'V116 HUD frozen':hashlib.sha256((m/'UnifiedHudWorldPlaneV116.cs').read_bytes()).hexdigest()=='bb2faf5ad30f6009acd7a493b381a62299055fa21aae7714b0e7a363a8553f52',
 'V128 router frozen':hashlib.sha256((m/'NativeDlssReceiverRouterV128.cs').read_bytes()).hexdigest()=='b159d5196e48f422e9c4326ef2cfc1162c37c4f72458cc6418fbc9e1a0365366',
}
for k,v in checks.items():print(('[PASS]' if v else '[FAIL]')+' '+k)
print('V137 audit: %d/%d'%(sum(checks.values()),len(checks)))
raise SystemExit(0 if all(checks.values()) else 2)
