# V139C — time-sliced AER real-2E truth calibration

## Why this build exists

The V139B capture-2 trace contains two completed genuine-stereo truth samples, then a ~744 ms compositor frame / ~716 ms post-submit GPU interval around a calibration batch. The old V99 matcher launches all 12 candidates for both eyes on the same truth frame, with 17x17 displacement hypotheses per tile. V139C reduces the diagnostic GPU burst and adds disk-backed stage tracing. It does **not** establish that the old stall was definitively caused by Windows TDR; earlier pre-capture hangs remain unexplained.

## Build

1. Extract this standalone ZIP into a fresh folder.
2. Run `BUILD_V139C.bat` (or `BUILD_V139.bat`, same actions).
3. Install the two DLLs from `OUTPUT` into the game's `Mods` folder, backing up your last working DLLs first.
4. Start normal gameplay with the native DLSS option enabled. V139C selects AER for this session, just as V139B did.
5. The **180-second** setup countdown starts after AER and native receiver routing become ready. Mount the headset on the ladder and leave it there. You do not need the game's developer console. The desktop progress panel stays visible.
6. Wait for `COMPLETE` or `ABORTED` on the desktop. If SteamVR shows a frozen `Waiting...` image, kill the process and pack the trace **before relaunching**.
7. Run `PACK_V139C_TRACE.bat` and return `V139_TRACE_RETURN.zip`.

## Exact diagnostic changes

- Freeze both current real eye color/depth/motion and their metadata at each genuine 2E truth frame.
- After the normal SteamVR stereo submission, queue only **one** candidate for **one** eye at a time.
- A tiny asynchronous readback of the atlas is a GPU-completion fence. No next candidate is queued before that readback completes. This is real GPU queue backpressure, not just an Update timer.
- Run the field metrics once per eye afterward, then issue the two final full-atlas readbacks.
- Decrease matcher radius from 8 to 6 pixels for the calibration campaign. Registration candidates at the search boundary are *censored* by the CSV analyzer rather than scored as if correct.
- Produce `SonsVR_V139C_GpuStages_*.log` in game `Mods` with `STAGE_BEGIN`, `GPU_SUBMITTED`, `GPU_CONFIRMED`, `GPU_WAIT`, `STAGES_DONE`, `ATLAS_READBACK_REQUEST`, `TRUTH_READBACK_COMPLETE`, and `FATAL` markers. FileOptions.WriteThrough minimizes data loss after hangs.
- Print a sparse `EOF_SUBMIT_HEARTBEAT` every five seconds, including during the setup countdown. CPU staging times are **not** GPU kernel timings; fence latency measures queue progress and includes frame scheduling.
- Parse the small atlas readback into compact CSV instead of emitting thousands of redundant row logs on Unity's main thread. The original V99 method stays available for other probes.

## Unchanged and limitations

- Preserves V103 displayed depth-guarded AER reprojection, rotation fallback, V116 unified HUD, V128 native receiver routing, V137 menu-driven camera DLSS scaling, NVOFA, SteamVR submission, and the quality-bank protocol.
- The candidate scoring is against a stationary rooftop reference. It cannot by itself prove motion-induced jitter is fixed. Nothing is automatically promoted into live AER.
- Native source C# and shader bundle compile are **not** validated in this Linux environment. The static audit and package extraction test pass, but Windows compilation and actual GPU/SteamVR runtime remain the final checks.
- One diagnostic candidate still performs full-resolution offscreen reconstruction; a sufficiently expensive *single* shader could still stall. V139C makes that visible and lets us narrow the specific stage.

## Crash-hang investigation

The most useful file is `SonsVR_V139C_GpuStages_*.log` in the ZIP. `GPU_SUBMITTED` with no subsequent `GPU_CONFIRMED` identifies the last queued GPU stage. Conversely, regular `EOF_SUBMIT_HEARTBEAT` without `GPU_SUBMITTED` points toward a controller/scheduling issue; neither proves Windows TDR. Inspect Windows Reliability Monitor (`perfmon /rel`) separately if a device reset is suspected. Avoid changing TdrDelay or registry watchdogs for this test.
