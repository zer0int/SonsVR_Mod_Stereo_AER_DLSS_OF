# V132B – Harmony namespace compile fix

The V132 build stopped at `NvidiaFeatureTraceV132.cs(18,24): CS0118: Harmony is a namespace but is used like a type`. The two unqualified references to the `Harmony` class now use `HarmonyLib.Harmony`, matching `TransitionDlssAuditV117.cs` in the existing project.

## If you already extracted V132

Extract `V132B_Harmony_Compile_Hotfix.zip` into your existing `v132` directory, overwriting:

- `mod/NvidiaFeatureTraceV132.cs`
- `static_audit_v132.py`

Then run `BUILD_V132.bat` as usual. No other changes are required.

## Scope

This is a **compile-only hotfix**. There are no modifications to render geometry, shader code, DLSS routing, the NVIDIA instrumentation logic, event timings, cue behavior, Unity 2022.3 workaround or AER. The Python audit has been updated to accept the fully qualified constructor.

Static audit is run against this standalone tree. The Windows game/toolchain is unavailable in this environment, so C# compilation against the installed game assemblies remains unverified.
