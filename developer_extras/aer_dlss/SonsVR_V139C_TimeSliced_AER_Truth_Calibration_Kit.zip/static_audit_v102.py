from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parent
stereo = (ROOT / 'mod' / 'StereoRender.cs').read_text(encoding='utf-8-sig')
compute = (ROOT / 'shader_project' / 'Assets' / 'AerForensicsV99.compute').read_text(encoding='utf-8-sig')
builder = (ROOT / 'shader_project' / 'Assets' / 'Editor' / 'BuildDepthThingy.cs').read_text(encoding='utf-8-sig')

checks = []
def ck(name, cond):
    checks.append((name, bool(cond)))

def strip_c_like(src):
    out=[]; i=0; n=len(src); state='code'
    while i<n:
        c=src[i]; d=src[i+1] if i+1<n else ''
        if state=='code':
            if c=='/' and d=='/': state='line'; out.extend('  '); i+=2; continue
            if c=='/' and d=='*': state='block'; out.extend('  '); i+=2; continue
            if c=='"': state='str'; out.append(' '); i+=1; continue
            if c=="'": state='char'; out.append(' '); i+=1; continue
            out.append(c); i+=1
        elif state=='line':
            if c=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i+=1
        elif state=='block':
            if c=='*' and d=='/': state='code'; out.extend('  '); i+=2
            else: out.append('\n' if c=='\n' else ' '); i+=1
        elif state in ('str','char'):
            term='"' if state=='str' else "'"
            if c=='\\': out.extend('  '); i+=2
            elif c==term: state='code'; out.append(' '); i+=1
            else: out.append('\n' if c=='\n' else ' '); i+=1
    return ''.join(out), state

clean_cs, cs_state = strip_c_like(stereo)
clean_hlsl, hlsl_state = strip_c_like(compute)
ck('C# lexical state returns to code', cs_state == 'code')
ck('HLSL lexical state returns to code', hlsl_state == 'code')
for label, text in [('C#', clean_cs), ('HLSL', clean_hlsl)]:
    ck(f'{label} braces balanced', text.count('{') == text.count('}'))
    ck(f'{label} parentheses balanced', text.count('(') == text.count(')'))
    ck(f'{label} brackets balanced', text.count('[') == text.count(']'))

ck('V101 live sky scatter disabled', 'AerV101SkyInfinityScatterABEnabled = false' in stereo)
ck('V102 occlusion forensics enabled', 'AerV102OcclusionForensicsEnabled = true' in stereo)
ck('far-clip change notifies V102 bank', 'NotifyFarClipChangeV102(clipEnd)' in stereo)
ck('TARP_50M epoch present', 'TARP_50M' in stereo)
ck('GAMEPLAY_24000M epoch present', 'GAMEPLAY_24000M' in stereo)
ck('candidate count is 7', 'private const int V99CandidateCount = 7;' in stereo)
for name in [
    'RAW_HISTORY','PRESENTATION_FILL_R1_R2','PRESENTATION_FILL_R1','PRESENTATION_NO_FILL',
    'DEPTHGRID_FILL_R1_R2','DEPTHGRID_FILL_R1','DEPTHGRID_NO_FILL']:
    ck(f'candidate {name}', f'"{name}"' in stereo)
for name in [
    'STABLE_NO_DEPTH','CURRENT_NO_HISTORY_FINITE','CURRENT_FINITE_HISTORY_NO','FINITE_AGREE',
    'HISTORY_NEARER_DISOCCLUSION','HISTORY_FARTHER_NEW_OCCLUDER']:
    ck(f'occlusion class {name}', f'"{name}"' in stereo)
for k in ['OcclusionClassStatsV102','OcclusionComplexityFieldV102','DepthColorRiskFieldV102']:
    ck(f'compute pragma {k}', f'#pragma kernel {k}' in compute)
    ck(f'C# FindKernel {k}', f'FindKernel("{k}")' in stereo)
    ck(f'asset builder validates {k}', f'"{k}"' in builder)
ck('V102 fill sweep contains 2/1/0 twice', re.search(r'V102FillPasses\s*=\s*new int\[\]\s*\{\s*2,\s*1,\s*0,\s*2,\s*1,\s*0\s*\}', stereo, re.S) is not None)
ck('V102 grid sweep contains presentation then depth', re.search(r'V102PresentationGrid\s*=\s*new bool\[\]\s*\{\s*true,\s*true,\s*true,\s*false,\s*false,\s*false\s*\}', stereo, re.S) is not None)
ck('diagnostic max warp follows camera far clip', 'ResolveMaxWarpMetersV87(truthCameraV102, truthCameraV102)' in stereo)
ck('two-fill fallback avoids RT alias', 'object.ReferenceEquals(preFallbackV102, _v99FinalRT)' in stereo)
ck('occlusion stats dispatch every candidate', 'LogOcclusionClassSummariesV102(d,p,ci);' in stereo)
ck('occlusion complexity logged', 'V102_OCCLUSION_COMPLEXITY' in stereo)
ck('depth-color risk logged', 'V102_DEPTH_COLOR_RISK' in stereo)
ck('stale translation-sweep symbols removed', 'V101TranslationScales' not in stereo and 'TRANS_1.00_SKYSCATTER_ROT_HOLE' not in stereo)

print('SonsVR V102 static audit')
print('='*72)
failed=0
for name, ok in checks:
    print(('[PASS] ' if ok else '[FAIL] ') + name)
    failed += 0 if ok else 1
print('-'*72)
print(f'{len(checks)-failed}/{len(checks)} checks passed')
if failed:
    sys.exit(1)
