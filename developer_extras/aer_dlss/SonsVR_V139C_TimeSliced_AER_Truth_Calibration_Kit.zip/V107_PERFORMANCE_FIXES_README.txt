SONSVR V107 — PERFORMANCE FIXES FOUND BY V106
==============================================

V106 FOUND TWO CONCRETE PATHOLOGIES
-----------------------------------

1) COOKING MENU 4 FPS: root cause identified.

Across 147 instrumented cooking updates in V106:
  mean Unity frame time          ~= 282.68 ms
  mean UpdateGrabBagGazeHover    ~= 232.26 ms
  mean global GrabBag item find  ~= 115.75 ms
  mean global CookingCog find    ~= 115.86 ms

The two UnityEngine.Object.FindObjectsOfType(Type) calls alone consumed ~=231.61 ms,
~99.7% of the cooking gaze update and ~81.9% of the entire Unity frame.
The actual cached-object work AFTER each search was tiny:
  ingredient collider scan after find ~= 0.22 ms mean
  cog traversal after find             ~= 0.02 ms mean

V107 FIX:
  - no full-scene FindObjectsOfType in the per-frame cooking gaze path.
  - candidates are cached from GrabBagHeld's local hierarchy including inactive children.
  - cheap hierarchy refresh every 0.5 s preserves native item activation/deactivation.
  - at most a tiny session-budgeted global fallback is retained for an out-of-tree CookingCog.
    This can cause ONE ~100 ms-class hitch when the menu/cog first appears, but never the old
    sustained ~116 ms search cost every frame.
  - Latest.log reports [CampfireGazeV24][V107] gazeCpu=... so the fix is directly visible.

2) TWO-MINUTE LOADING: a large avoidable render mistake was observed.

During SonsMainLoading / early BlankScene, the game's OWN loading camera consistently rendered
only culling mask 0x00000020 (layer 5), while BOTH 3141x3317 VR eyes rendered 0xFFFFFFFF.
In other words, pancake was showing a cheap loading view while the mod rendered the partially
streamed world twice in the HMD. That is exactly the kind of thing that can make world streaming,
shader compilation, and asset initialization much more expensive than pancake loading.

V107 FIX:
  - during SonsMainLoading/BlankScene, until MainCameraFP+LocalPlayer gameplay gate is ready,
    both VR eyes use the observed native loading mask 0x20.
  - as soon as gameplay becomes ready, eye culling restores to the normal gameplay mask.
  - Latest.log records start/end and the suppressed duration.

NATIVE DESKTOP CAMERA
---------------------

V106 snapshots also proved MainCameraFP remained a 3840x2160 HDRP camera carrying
TemporalAntialiasing + DLSS/DRS + persistent history even after its culling mask was reduced to
the dummy layer 31.

V107 keeps MainCameraFP ALIVE because Camera.main / native OnMouse / screen-coordinate interaction
semantics depend on it, but AFTER its correct HDRP profile has been copied to the VR eye cameras:
  - AA -> None
  - DLSS -> OFF
  - dynamic resolution -> OFF
  - persistent history -> OFF
  - known optional camera/screen-space/volumetric FrameSettings -> OFF best-effort

Optical Flow was never attached to MainCameraFP; NVOFA is an AER eye-reprojection path.

FRAME-CAP RESULT
----------------

V106 measured:
  title menu: Application.targetFrameRate = 60
  SonsMainLoading / early BlankScene:      = 30
  later loading + gameplay:                = -1 (uncapped)
  QualitySettings.vSyncCount               = 0
  OnDemandRendering.renderFrameInterval    = 1
  HMD display frequency                    = 72 Hz

Therefore normal ~25 FPS is NOT explained by a simple hard 25 FPS Unity cap.

V106 UBER LOGGER
----------------

The V106 timeline/snapshot logger did its job and is DISABLED by default in V107. It generated
~17 MB timeline + ~8 MB snapshots in one short run and should not live in a normal performance
baseline. The existing lightweight SonsVR_Perf_*.csv logger remains available.

TEST V107
---------

1. BUILD_V107.bat
2. Start from title/load a save normally.
   Note whether total loading time changes materially versus the historical ~2 minutes.
3. Play normally for a bit.
4. Open the cooking/grab-bag menu and move gaze across ingredients.
   If practical, progress far enough for the start-cooking cog to appear and verify gaze/trigger
   interaction still works.
5. Observe FPS/frame-time overlay. The old sustained ~250-290 ms cooking frames should be gone if
   V106's measured culprit has been correctly removed.
6. Exit and run PACK_V107_TRACE.bat.

Useful Latest.log markers:
  [VRPlayer][V107 LoadingPerf]
  [VRPlayer][V107 CookingCache]
  [VRPlayer][CampfireGazeV24][V107]
  [StereoRender][V107 NativeCamera]

IMPORTANT
---------

The AER renderer itself is unchanged from the V105c/V106 production baseline:
  - permanent V103 depth-coherence guard
  - V100 true-hole rotation fallback
  - DLSS/NVOFA according to runtime settings

V107 is aimed at old mod-level performance pathologies, not the now-fixed AER wobble.
