# V137 — Native menu DLSS scales + wider HUD performance overlay

Source baseline: **V136**, with its headset-confirmed stereo-correct camera-scoped ScaleFn hook.

## Changes

- Native Sons graphics menu is the *sole* quality selector for the V136 hook:
  - Quality: 66.7% (the V136 verified scale)
  - Balanced: 58.0%
  - Performance: 50.0%
  - Ultra Performance: 33.3% (experimental: reported NVIDIA minimum was ~50%)
  - DLSS Off / TAAU / unknown quality: bypass the hook, preserve native behavior
- No global DRS scaler/slot changes, no handler minimum/current fraction writes, no modifications to V116 HUD compositor or AER renderer.
- FPS overlay extends leftward toward center; previous right edge unchanged, with 3-digit ms not wrapping.
- Added fourth overlay line `DLSS: NNNN X MMMM`, read from live HDCamera.actualWidth/actualHeight; when disabled, `DLSS OFF: ...`. `-- X --` means input not available yet. Overlay text is sampled 4 Hz.
- Endnight native routing and original left/right camera identity logic unchanged.

## BUILD

Run `BUILD_V137.bat`. Copy the OUTPUT mod DLL, native bridge DLL and shader bundle per script. Back up V136 before replacing.

## ONE TEST

Start in **2E**, DLSS **Quality** (verify normal stereo). Then use the **native game menu**: Balanced ~5 s -> Performance ~5 s -> Ultra Performance ~5 s -> Quality ~5 s -> Off ~5 s -> Quality ~5 s. No synchronized actions. Quit and run `PACK_V137_TRACE.bat`; send ZIP.

Expected HDRP input per eye at 3141x3317 output (dimensions approximate due HDRP rounding):
- Quality ~2096x2214
- Balanced ~1822x1924
- Performance ~1572x1660
- Ultra Performance ~1046x1105
- Off 3141x3317

Expected marker: `[V137 DLSS-SCALEFN] MENU_SCALE ... requested=...%`, and V129 TSV `hdActual` and V133 feature `viewIn` must match measured resolution.

**The 33.3% mode is explicitly outside NVIDIA's reported ~50% minimum; it may clamp, fail, freeze, or crash.** Pack trace before any relaunch if it does. A working hook doesn't guarantee that NVIDIA will successfully reconstruct below its reported minimum. Restore V136 if needed.

## Verification

Static audit is not a substitute for compiling against local IL2CPP assemblies, and does not establish headset safety or that NVIDIA accepts the new sizes. V136 was empirically stable at fixed 66.7%; live menu-driven scaling is new.
