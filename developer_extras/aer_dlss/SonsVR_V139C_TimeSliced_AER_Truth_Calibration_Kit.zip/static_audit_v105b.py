from pathlib import Path
import sys
root=Path(__file__).resolve().parent
p=root/'mod'/'RuntimeSettingsV105.cs'
s=p.read_text(encoding='utf-8-sig',errors='replace')
checks=[
    ('Unity Mathf alias present', 'using Mathf = UnityEngine.Mathf;' in s),
    ('no static LeftCam reference in settings', 'StereoRender.LeftCam' not in s),
    ('no static RightCam reference in settings', 'StereoRender.RightCam' not in s),
    ('instance readiness check', 'stereo.LeftCam != null && stereo.RightCam != null' in s),
    ('perf logger uses CreateNew', 'FileMode.CreateNew' in s),
    ('perf filenames include milliseconds', 'yyyyMMdd_HHmmss_fff' in s),
    ('unique path helper', 'MakeUniquePerfPath' in s),
    ('warning rows retained', 'WritePerfRow("WARNING"' in s),
    ('2 Hz sample rows retained', '_nextPerfSample = now + 0.50f' in s),
    ('flush is non-destructive', '_perfWriter.Flush()' in s),
]
for n,ok in checks: print(('PASS' if ok else 'FAIL'),n)
if not all(ok for _,ok in checks): sys.exit(1)
print(f'PASS {len(checks)}/{len(checks)}')
