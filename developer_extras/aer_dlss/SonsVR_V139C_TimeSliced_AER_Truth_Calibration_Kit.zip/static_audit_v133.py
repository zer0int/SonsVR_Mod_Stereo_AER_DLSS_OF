#!/usr/bin/env python3
"""Standalone V133 static audit. Does not claim C# compile or runtime verification."""
from pathlib import Path
import hashlib
R=Path(__file__).resolve().parent
mod=R/'mod'
text=lambda s:(mod/s).read_text(encoding='utf8')
tick=text('SonsVRMod.cs')
probe=text('NativeDlssFeatureStateV133.cs')
project=text('SonsVR_Mod.csproj')
checks={
 'V133 probe in project': '<Compile Include="NativeDlssFeatureStateV133.cs" />' in project,
 'V133 runs from mod update': 'NativeDlssFeatureStateV133.Tick();' in tick,
 'V132 staged intervention not ticking': 'NativeDlssForensicsV132.Tick();' not in tick,
 'V131 forced activation not ticking': 'NativeDlssForceActivationV131.Tick();' not in tick,
 'V130 optimal override not ticking': 'NativeDlssOptimalOverrideV130.Tick();' not in tick,
 'No V132 shutdown intervention': 'NativeDlssForensicsV132.Shutdown();' not in tick,
 'Probe gated to 2E native route': 'StereoRender.UserGameplayAERV112 || !NativeDlssReceiverRouterV128.Routed' in probe,
 'Camera state introspection': '"m_CameraStates"' in probe,
 'Native view state introspection': '"m_OptimalSettingsRequest"' in probe and '"m_Data"' in probe,
 'Native feature-context metadata probe': '"DLSSContext"' in probe and '"initData"' in probe,
 'Native scaler delegate read only': '"ScaleDelegate"' in probe and 'scaleDelegate=' in probe,
 'No scaler overwrite in V133 probe': all(x not in probe for x in ['SetDynamicResScaler(', 'SetSystemDynamicResScaler(', 'm_MinScreenFraction =', 'SetValue(', 'SetActiveDynamicScalerSlot(', 'CreateFeature(', 'ExecuteDLSS(', 'DestroyFeature(', 'ScaleFn(']),
 'Existing receiver router unchanged': (mod/'NativeDlssReceiverRouterV128.cs').exists(),
 'Existing V129 render boundary telemetry retained': 'NativeDlssLiveResolutionTraceV129.Tick();' in tick,
 'Two second sampling, no scene-search': '_next = now + 2.0f;' in probe and 'FindObjectsOfType' not in probe,
 'Build and pack scripts included': (R/'BUILD_V136.bat').exists() and (R/'PACK_V136_TRACE.bat').exists(),
 'Frozen V128 HUD/renderer/player/router intact': all(hashlib.sha256((mod/name).read_bytes()).hexdigest()==digest for name,digest in {
   'StereoRender.cs':'f87ca07cadfb1a4e4910a4a21ea8e1d6031cd114aee61e04cd146bba430abf7c',
   'VRPlayer.cs':'cd8240b986b3823571bab830f8a9269f0b3d6b947367b0c54461355c3bd15244',
   'UnifiedHudWorldPlaneV116.cs':'bb2faf5ad30f6009acd7a493b381a62299055fa21aae7714b0e7a363a8553f52',
   'NativeDlssReceiverRouterV128.cs':'b159d5196e48f422e9c4326ef2cfc1162c37c4f72458cc6418fbc9e1a0365366',
 }.items()),
}
for k,v in checks.items():print(('[PASS]' if v else '[FAIL]')+' '+k)
for name in ['StereoRender.cs','VRPlayer.cs','UnifiedHudWorldPlaneV116.cs','NativeDlssReceiverRouterV128.cs','NativeDlssLiveResolutionTraceV129.cs']:
 p=mod/name
 if p.exists(): print('FROZEN '+name+' sha256='+hashlib.sha256(p.read_bytes()).hexdigest())
print('V133 static audit:',sum(checks.values()),'/',len(checks))
raise SystemExit(0 if all(checks.values()) else 2)
