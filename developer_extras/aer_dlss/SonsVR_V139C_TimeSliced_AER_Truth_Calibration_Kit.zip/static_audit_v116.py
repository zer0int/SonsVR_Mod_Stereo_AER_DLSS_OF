from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parent
MOD=ROOT/'mod'
files={p.name:p.read_text(errors='ignore') for p in MOD.glob('*.cs')}
vr=files['VRPlayer.cs']
hud=files['UnifiedHudWorldPlaneV116.cs']
comp=files['CameraCompositorAuditV114.cs']
settings=files['RuntimeSettingsV105.cs']
dlss=files['DlssRuntimeV91.cs']
depth=files['EyeDepthCaptureCustomPassV81.cs']
stereo=files['StereoRender.cs']
sons=files['SonsVRMod.cs']
perf=files['PerformanceForensicsV106.cs']
proj=(MOD/'SonsVR_Mod.csproj').read_text(errors='ignore')
checks=[]
def ck(desc, cond): checks.append((desc,bool(cond)))

ck('01. V116 HUD source exists', 'internal static class UnifiedHudWorldPlaneV116' in hud)
ck('02. V116 HUD source registered in csproj', 'Compile Include="UnifiedHudWorldPlaneV116.cs"' in proj)
ck('03. V115 HUD source no longer registered', 'UnifiedHudWorldPlaneV115.cs' not in proj and 'UnifiedHudWorldPlaneV115' not in vr)
ck('04. Unified world plane remains enabled', 'internal const bool Enabled = true' in hud)
ck('05. HUD distance remains 1.20m', 'DistanceMeters = 1.20f' in hud)
ck('06. HUD width remains 60deg', 'HorizontalFovDegrees = 60.0f' in hud)
ck('07. authored y=153 eye-height row retained', 'NativeReferenceRowY = 153.0f' in hud)
ck('08. HUD remains WorldSpace', 'canvas.renderMode = RenderMode.WorldSpace' in hud)
ck('09. HUD path creates no Camera', 'AddComponent<Camera>' not in hud and 'new Camera' not in hud)
ck('10. HUD path creates no RenderTexture', 'new RenderTexture' not in hud)
ck('11. HUD path creates no OpenVR overlay', 'OpenVR' not in hud and 'CVROverlay' not in hud)
ck('12. ring authored anchor is PlayerVitalUiRenderTextureGroup', 'PlayerVitalUiRenderTextureGroup' in hud)
ck('13. map authored anchor is ScreenMask', 'GPSTrackerSystem/Canvas/ScreenMask' in hud)
ck('14. map alignment uses anchoredPosition delta', '_mapAnchorRt.anchoredPosition - _ringAnchorRt.anchoredPosition' in hud)
ck('15. map alignment uses RectTransform pivot world points', 'GetPivotWorld(_ringAnchorRt)' in hud and 'GetPivotWorld(_mapAnchorRt)' in hud)
ck('16. V115 rect-center correction removed', 'minimapRoot.position += ringCenter - mapCenter' not in hud)
ck('17. map still moves only outer minimap root', 'minimapRoot.position += desiredMapPivotWorld - mapPivotWorld' in hud)
ck('18. map pivot residual telemetry present', 'pivotResidual=' in hud and 'nativeDeltaPx=' in hud)
ck('19. visible-center separation retained as diagnostic only', 'visualCenterSeparation=' in hud)
ck('20. old minimap/vitals mutators remain blocked under V116', vr.count('if (UnifiedHudWorldPlaneV116.Enabled || NativeHudCompositorV114.Enabled) return;') >= 2)
ck('21. old always-on-top HUD cameras remain blocked under V116', 'if (!UnifiedHudWorldPlaneV116.Enabled && !NativeHudCompositorV114.Enabled)' in vr)

# Item-info nested world-space workaround must exit BEFORE lookup/add-component work.
item_method=vr[vr.index('private void ConvertItemInfoPanelToWorldSpace()'):vr.index('public static bool ItemInfoPanelBackgroundEnabled')]
ck('22. legacy item-info nested world canvas bypassed under V116', 'if (UnifiedHudWorldPlaneV116.Enabled) return;' in item_method)
ck('23. item-info bypass occurs before GameObject.Find', item_method.index('if (UnifiedHudWorldPlaneV116.Enabled) return;') < item_method.index('GameObject.Find('))

ck('24. tarp LayoutItem cache has explicit session reset', 'ResetTarpLayoutItemCacheV116' in vr and 'tarp-open' in vr and 'tarp-close' in vr)
ck('25. tarp LayoutItem cache builds on session first use', 'RefreshTarpLayoutItemCacheV116("session-first-use")' in vr)
ck('26. tarp cache refreshes only on targeted cache miss', 'gaze-target-cache-miss:' in vr and 'TarpLayoutCacheContainsV116' in vr)
ck('27. old 0.2s periodic LayoutItem scan removed', '_lastLayoutItemScanTime' not in vr and 'Time.time - _lastLayoutItemScanTime > 0.2f' not in vr)
ck('28. global LayoutItem scan isolated inside V116 cache builder', vr.count('UnityEngine.Object.FindObjectsOfType<LayoutItem>()') == 1)
ck('29. tarp cache build cost telemetry present', '[VRPlayer][V116 TarpCache]' in vr and 'cost=' in vr)
ck('30. tarp per-frame interaction cost telemetry present', '[VRPlayer][V116 TarpPerf]' in vr and 'RecordTarpInteractionCostV116' in vr)

ck('31. stats overlay moved to v=0.727', '0.66f, 0.727f, 0.196f, 1.25f' in settings)
ck('32. stats overlay width is 70 percent of prior 0.28', '0.196f' in settings)
ck('33. settings telemetry says WORLD_PLANE not COMPOSITOR', 'nativeHUD=COMPOSITOR' not in settings and 'nativeHUD=WORLD_PLANE' in settings)

ck('34. fatal camera/compositor audit disabled', re.search(r'internal static bool Enabled\s*=\s*false',comp) is not None)
ck('35. unsafe CustomPass name dereference removed', '+ pass.name' not in comp and 'pass.enabled' not in comp)
ck('36. CustomPass census explicitly no-op', 'CUSTOM_PASS_CENSUS disabled in V116' in comp)
ck('37. old broad performance forensic logger remains disabled', 'internal static bool Enabled = false' in perf)

# DLSS truth probe.
ck('38. eye state stores passive observed HDRP viewport', 'ObservedActualWidthV116' in depth and 'ObservedActualHeightV116' in depth and 'ObservedFrameV116' in depth)
obs_idx=depth.find('observedStateV116.ObservedActualWidthV116')
aer_return_idx=depth.find('if (!StereoRender.AlternateEyeRenderingEnabled)')
ck('39. viewport observed before AER-only early return', obs_idx >= 0 and aer_return_idx >= 0 and obs_idx < aer_return_idx)
ck('40. observed viewport accessor exists', 'TryGetObservedViewportV116' in depth)
ck('41. DLSS EyeStatus reads observed viewport', 'TryGetObservedViewportV116' in dlss and 'hdActual=' in dlss)
ck('42. DLSS EyeStatus reports active-to-target ratio', 'activeToTarget=' in dlss)
ck('43. DLSS config logs immediate post-write dynamic flags', 'postWrite(camDyn=' in dlss)
ck('44. eye target creation logs requested/actual dynamic-scale state', '[AER V116][DLSS][TargetBuild]' in stereo and 'requestedDynamic=' in stereo and 'leftDyn=' in stereo)
ck('45. DLSS quality change remains measurement-only (no forced quality texture rebuild)', 'bool rebuild = forceRebuild || dlssStateChanged;' in settings)

ck('46. old binocular zoom camera remains disabled for this pass', 'public static bool EnableBinocularsZoomCamera = false;' in vr)
ck('47. V116 startup message registered', '[SonsVR V116] Loaded:' in sons)
ck('48. V116 startup message records audit retirement', 'Fatal V114 camera/CustomPass audit retired' in sons)

for fn in ['UnifiedHudWorldPlaneV116.cs','VRPlayer.cs','RuntimeSettingsV105.cs','CameraCompositorAuditV114.cs','DlssRuntimeV91.cs','EyeDepthCaptureCustomPassV81.cs','StereoRender.cs','SonsVRMod.cs']:
    t=files[fn]
    bal=0; mn=0
    for ch in t:
        if ch=='{': bal+=1
        elif ch=='}': bal-=1; mn=min(mn,bal)
    ck(f'brace balance {fn} (bal={bal}, min={mn})', bal==0 and mn==0)

for desc,ok in checks:
    print(f"[{'PASS' if ok else 'FAIL'}] {desc}")
failed=[d for d,o in checks if not o]
print(f"\nV116 static audit: {len(checks)-len(failed)}/{len(checks)} passed")
if failed:
    print('Failed checks:')
    for d in failed: print(' -',d)
    sys.exit(1)
