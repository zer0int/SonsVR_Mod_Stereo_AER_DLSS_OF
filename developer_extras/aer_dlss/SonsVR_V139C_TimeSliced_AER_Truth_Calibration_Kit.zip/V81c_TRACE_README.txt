SONSVR V81c — CAMERA-LOCAL DEPTH PROBE HARNESS FIX
===================================================

V81b DID NOT ACTUALLY TEST CAMERA-LOCAL DEPTH.

The runtime log proved:
  - injected type registered
  - CustomPass frame setting was enabled on both eyes
  - volumes were installed
BUT:
  - zero Execute() logs
  - zero LOCALDEPTH_V81 rows

Additionally V80's diagnostic pass failed:
  Material.SetPass(3) returned false
and the secondary shader reported an empty name.

Static inspection found an actual harness bug:
the V81 shared HLSL declarations/functions had been placed directly in
ShaderLab SubShader scope. They are now inside HLSLINCLUDE/ENDHLSL.

V81c also:
  - uses one ordinary GLOBAL CustomPassVolume
  - filters VRLeftEye/VRRightEye inside Execute()
  - logs first Execute() calls as [EXEC-SEEN]
  - emits a hard warning if Execute() never happens within 3 seconds
  - uses named pass lookup instead of numeric pass indices
  - aborts the Unity shader build if either shader has compiler errors
    or any required pass is missing

So if BUILD_V81c_TRACE.bat succeeds, we know the shader bundle itself is sane
before spending another headset/loading cycle.

MICRO-EXPERIMENT NOTE
---------------------
The sky -> mountains -> feet -> tarp sequence was useful.

Near depth is NOT automatically invalid for V51. V51 accepts positive finite
depth up to 300m. Near geometry creates larger stereo displacement/disocclusion,
but a large continuous nearby surface can still reproject densely.

In the V81b run, the crafting tarp marker occurred around 05:17:23. The center
depth was genuinely ~1.5-3m, while V51 coverage sometimes rose above 60-70%.
So "closest possible" does not imply "all invalid".

BUILD
-----
  BUILD_V81c_TRACE.bat

If shader validation or C# compile fails:
  DO NOT LOAD THE GAME.
  Send the build output.

RUNTIME
-------
A valid run MUST show:
  [AER V81c][CustomDepth][EXEC-SEEN]

and the TSV MUST contain:
  LOCALDEPTH_V81

Then do the same:
  current DLSS ~3s -> OFF ~3s -> Quality ~3s -> OFF ~3s -> quit

PACK
----
  PACK_V81c_TRACE.bat

Send:
  V81c_TRACE_RETURN.zip
