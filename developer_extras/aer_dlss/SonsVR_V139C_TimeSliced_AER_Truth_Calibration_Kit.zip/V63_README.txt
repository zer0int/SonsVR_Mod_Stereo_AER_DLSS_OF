SonsVR V63 — HUD GEOMETRY PROBE + SCREENBOUNDS ANCHOR RESTORE
=================================================================

WHY THIS EXISTS
---------------
V62 was stable, but exposed two clean facts:

1. VitalsBackingCircle is NOT a stable visual-map anchor. When the player moves right or jumps,
   the visible GPS/map content moves right/up relative to a ring centered on VitalsBackingCircle.
   V60's ScreenBounds anchor kept map + ring locked (with only a static vertical offset).

2. The broad HUD remains squeezed into a central column even though V60's camera-boundary
   Canvas.ForceUpdateCanvases() is gone. Therefore that earlier diagnosis was wrong.

V63 is deliberately a measurement build, not another renderer experiment. Native CanvasRenderer
output remains untouched and the V51/V50 AER world path is unchanged.

WHAT V63 CHANGES
-----------------
- Ring anchor preference is reverted to:
    PlayerMiniMap/GPSTrackerSystem/Canvas/ScreenMask/ScreenBounds
  with VitalsBackingCircle and Canvas only as fallbacks.
- V61 direct raw-mesh UGUI replay remains HARD-DISABLED.
- Adds low-rate runtime telemetry (0.5 s) for:
    * LocalPlayer motion delta
    * ScreenBounds / VitalsBackingCircle / ScreenMask
    * Map / SurfaceMap / MapRoot / MapRotator / PlayerArrow if present
    * each node's world position, minimap-canvas local position, and left-eye viewport position
    * the main ScreenSpaceCanvas rect/scale and its exact projected left-eye viewport span
    * MessageList and WorldScreenSpaceElements projected centers
- Adds a one-time minimap RectTransform census for names containing map/screen/vital/arrow/player/root.

WHAT TO DO
----------
Run BUILD_V63.bat and install only OUTPUT\SonsVR_Mod.dll.

Then reproduce the simplest sequence:
  1. stand still ~2 s
  2. move right ~2 s
  3. stand still ~1 s
  4. jump once
  5. stand still ~2 s

Send the MelonLoader log. Screenshots are optional but still useful.

The log lines we care about are:
  [AER V63][PlayerMotion]
  [AER V63][MinimapMotion]
  [AER V63][HudFrustum]
  [AER V63][HudNode]
  [AER V63][ProbeTree]

INTERPRETATION
--------------
If ScreenBounds stays locked to the visible map while VitalsBackingCircle diverges with movement,
we have the ring anchor issue solved.

If [HudFrustum] reports the root canvas occupying only a central fraction of x=[0,1], that proves
the Mystery Column is simply a world-space frustum/scale mismatch. The next build can then size the
HUD plane from the actual VR eye projection instead of Screen.width/Screen.height or guessed UI
logical dimensions.

No hex editor/native detour is needed yet: MelonLoader gives us the live Unity transforms and
projection mapping directly. If a native GPSTracker field turns out invisible through the hierarchy,
then the supplied Il2CppAssemblies give us the exact wrapper surface for the next-level probe.
