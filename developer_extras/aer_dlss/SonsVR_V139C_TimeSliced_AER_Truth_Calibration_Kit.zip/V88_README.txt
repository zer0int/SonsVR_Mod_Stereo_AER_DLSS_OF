SONSVR V88 — 768 GRID vs FULL-RES PER-PIXEL COMPUTE A/B
=========================================================

ONE HEADSET LOAD. ONE AUTOMATIC SWITCH.

PURPOSE
-------
V87 strongly suggested the remaining micro-jitter has a spatial-granularity
component: 512 -> 768 made the "CRT units" finer (whole treetop -> individual
leaves) without changing the overall impression.

V88 directly tests whether the triangle mesh itself is the limiting
representation.

PHASE A — FIRST 30 SECONDS OF SAME-EYE TEMPORAL AER
----------------------------------------------------
Exactly the proven V87 world reconstruction geometry:

  previous REAL same-eye color
  + previous same-eye cameraDepthBuffer depth
  + old/new same-eye matrices
  -> 768x768 forward triangle warp

Far-field fix remains ON (valid finite depth out to camera far clip).
Render-boundary target-pose snapshot is used throughout the entire run.

PHASE B — AUTOMATIC, NO RESTART
--------------------------------
After ~30 seconds of actual temporal reconstruction, V88 switches to:

  FULL-RES PER-SOURCE-PIXEL COMPUTE SCATTER

For every historical source depth pixel (~3141x3317):

  source pixel + exact full-res depth
      -> unproject to 3D
      -> old camera -> world -> current same-eye camera
      -> target pixel

A R32_UInt atomic depth-key UAV performs per-target-pixel nearest-surface
arbitration. A second compute dispatch records the winning SOURCE pixel XY.
A normal fullscreen shader then samples historical color at those winning
coordinates.

There are NO triangles in Phase B.

Downstream processing is IDENTICAL in both phases:
  - 1 px hole fill
  - 2 px hole fill
  - remaining holes use raw SAME-EYE history
  - latest HUD handling

This makes the visual A/B specifically about:

  768 triangle approximation
    vs
  full-resolution depth-sample reprojection

SWITCH LOG
----------
Look for:

  [AER V88][ReprojectionAB] AUTO SWITCH ...
  768x768 TRIANGLE MESH -> FULL-RES PER-PIXEL COMPUTE SCATTER

Telemetry says either:

  reprojection=GRID-768
or
  reprojection=PER-PIXEL-COMPUTE

FAIL-SOFT
---------
If the compute shader/resource path is unavailable or throws, V88 DOES NOT
submit garbage. It stays/falls back to the proven 768 mesh and logs once.

UNCHANGED ON PURPOSE
--------------------
- two dedicated eye cameras
- same-eye temporal reconstruction
- cameraDepthBuffer is the depth source
- far-field fix ON (~camera far clip, not 300 m)
- V86 projective-coordinate fix ON
- render-boundary pose snapshot ON throughout
- render scale 1.0
- no real DLSS yet
- no motion vectors yet
- no optical flow
- HUD depth catchers OFF
- HUD x1.00
- heavy diagnostics/readbacks OFF
- no GPU timing markers / no sync stalls
- V36 HARD-OFF

TEST
----
1. Reach gameplay.
2. Spend first ~30 s looking at distant foliage / thin branches / high-frequency
   geometry. This is GRID-768.
3. Keep looking through the automatic switch. No restart, no keypress.
4. Judge:
   - Does the leaf-sized CRT shimmer become substantially finer or disappear?
   - Does the character of the micro-jitter change at all?
   - Any obvious FPS hit after the switch?

If Phase B looks the same, tessellation is no longer the main suspect and the
next branch should be motion/cadence/DLSS rather than more triangles.

BUILD: BUILD_V88.bat
PACK:  PACK_V88_TRACE.bat
