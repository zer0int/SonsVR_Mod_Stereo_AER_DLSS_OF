@echo off
setlocal EnableExtensions

rem ============================================================================
rem SonsVR V137 - GAME-MENU QUALITY-DEPENDENT DLSS RESOLUTION
rem ============================================================================

set "ROOT=%~dp0"
if not defined UNITY_EXE set "UNITY_EXE=C:\Program Files\Unity 2022.2.16f1\Editor\Unity.exe"
set "UNITY_PROJECT=%ROOT%shader_project"
set "BUNDLE=%UNITY_PROJECT%\THINGY_OUT\sonsvr_depththingy"
set "MOD_DIR=%ROOT%mod"
set "MOD_RESOURCE=%MOD_DIR%\Resources\sonsvr_depththingy"
set "LABEL=v137_native_menu_dlss_resolutions"
set "FINAL_DLL=%MOD_DIR%\builds\%LABEL%\SonsVR_Mod.dll"
set "NATIVE_DLL=%ROOT%native_nvof\build\SonsVR_NvOF_V90.dll"
set "OUT_DIR=%ROOT%OUTPUT"

if not exist "%UNITY_EXE%" (
  echo ERROR: Unity 2022.2.16f1 not found at:
  echo   %UNITY_EXE%
  exit /b 2
)

echo.
echo [1/5] Running V116/V128 baseline + V136 camera-scoped scaling audit...
python "%ROOT%static_audit_v137.py" > "%ROOT%V137_STATIC_AUDIT.txt"
set "AUDIT_RC=%ERRORLEVEL%"
type "%ROOT%V137_STATIC_AUDIT.txt"
if not "%AUDIT_RC%"=="0" exit /b %AUDIT_RC%

echo.
echo [2/5] Building native D3D11 NVIDIA Optical Flow bridge...
call "%ROOT%native_nvof\BUILD_NATIVE_V90.bat"
set "NATIVE_RC=%ERRORLEVEL%"
if not "%NATIVE_RC%"=="0" exit /b %NATIVE_RC%
if not exist "%NATIVE_DLL%" exit /b 3

if exist "%BUNDLE%" del /q "%BUNDLE%"
if exist "%MOD_RESOURCE%" del /q "%MOD_RESOURCE%"

echo.
echo [3/5] Building production AER/depth-guard shader bundle (renderer path unchanged)...
"%UNITY_EXE%" -batchmode -quit -projectPath "%UNITY_PROJECT%" -executeMethod BuildDepthThingy.BuildBatch -logFile "%ROOT%shader_build.log"
set "UNITY_RC=%ERRORLEVEL%"
if not "%UNITY_RC%"=="0" exit /b %UNITY_RC%
if not exist "%BUNDLE%" exit /b 4
for %%F in ("%BUNDLE%") do set "BUNDLE_BYTES=%%~zF"
if %BUNDLE_BYTES% LSS 1024 exit /b 5
copy /y "%BUNDLE%" "%MOD_RESOURCE%" >nul
if errorlevel 1 exit /b %errorlevel%

echo.
echo [4/5] Building SonsVR_Mod.dll...
pushd "%MOD_DIR%"
call build_named.bat "%LABEL%"
set "BUILD_RC=%ERRORLEVEL%"
popd
if not "%BUILD_RC%"=="0" exit /b %BUILD_RC%
if not exist "%FINAL_DLL%" exit /b 6

if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"
copy /y "%FINAL_DLL%" "%OUT_DIR%\SonsVR_Mod.dll" >nul
copy /y "%NATIVE_DLL%" "%OUT_DIR%\SonsVR_NvOF_V90.dll" >nul
copy /y "%BUNDLE%" "%OUT_DIR%\sonsvr_depththingy" >nul
copy /y "%ROOT%V137_STATIC_AUDIT.txt" "%OUT_DIR%\V137_STATIC_AUDIT.txt" >nul

for %%F in ("%OUT_DIR%\SonsVR_Mod.dll") do set "MOD_BYTES=%%~zF"
for %%F in ("%OUT_DIR%\SonsVR_NvOF_V90.dll") do set "NATIVE_BYTES=%%~zF"

echo.
echo [5/5] DONE.
echo   %OUT_DIR%\SonsVR_Mod.dll [%MOD_BYTES% bytes]
echo   %OUT_DIR%\SonsVR_NvOF_V90.dll [%NATIVE_BYTES% bytes]
echo.
echo Copy BOTH DLLs to:
echo   D:\SteamLibrary\steamapps\common\Sons Of The Forest\Mods
echo.
echo V137 CHECKS: V128 router / V116 renderer unchanged.
echo   No timed interventions, scaler changes, or GPU hook installation.
echo   V137 maps native game-menu quality to a camera-scoped DLSS scale (Q/B/P/UP).
echo   See README_FIRST_V137.md. Run PACK_V137_TRACE.bat after test.
echo.
exit /b 0
