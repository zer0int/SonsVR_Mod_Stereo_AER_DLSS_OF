SONSVR V86 — PROJECTIVE SAME-EYE TEMPORAL STABILIZATION
======================================================

V85 RESULT
----------
V85 was the first genuinely encouraging same-eye temporal result:
- catastrophic shredding/tearing disappeared
- DLSS blockiness disappeared
- DLSS and supersampling OFF looked broadly similar
- HUD was stable with experimental HUD depth catchers disabled
- V84-class ~30 FPS-ish performance survived

Remaining artifact:
a globally visible CRT-like micro-tremor / tiny up-down nod, especially
obvious on distant detail and foliage.

V86 TARGETS ONE SPECIFIC SHADER-MATH ERROR
------------------------------------------
V48-V85 passed SOURCE UV after source perspective divide as a normal
perspective-correct interpolant across the TARGET-space warp triangle.

That is not projectively correct when vertices have different target clip W.
The target rasterizer applies perspective correction to something that was
already perspective-divided in source camera space.

Because each physical eye alternates:
    REAL
    PREDICTED
    REAL
    PREDICTED
a stable subpixel distortion in predicted frames can appear as a high-rate
micro-tremor.

V86 carries homogeneous SOURCE clip coordinates through the target rasterizer
and divides source XY by source W only in FragWarp. That is the correct
projective target->source mapping for the reconstructed triangle.

A/B SWITCH
----------
    AerTemporalProjectiveSourceCoordinatesV86Enabled = true

Set false to restore V85 interpolation math.

UNCHANGED
---------
- current two-camera architecture
- SAME-EYE temporal reconstruction
- cameraDepthBuffer full-resolution RFloat history depth
- 512x512 forward warp mesh
- 1px + 2px tiny hole fill
- raw SAME-EYE history only for genuine temporal holes
- HUD depth catchers OFF
- heavy diagnostics/readbacks OFF
- V36 HARD OFF

HUD SIZE
--------
All explicit historical x1.75 HUD enlargement multipliers are x1.00 in V86.
Rendering/timing is otherwise unchanged.

LIGHTWEIGHT TELEMETRY
---------------------
TemporalTelemetry adds:
    targetLocalDeltaMm=(right, up, forward)

No GPU readback is introduced.

BUILD
-----
    BUILD_V86.bat

TEST
----
Primary questions:
1. V85-class fluidity preserved?
2. CRT-like micro-tremor smaller / gone / unchanged?
3. Distant detail and foliage improved?
4. HUD still stable, now sane-sized at x1.00?
5. DLSS ON vs OFF if convenient.

PACK
----
    PACK_V86_TRACE.bat
