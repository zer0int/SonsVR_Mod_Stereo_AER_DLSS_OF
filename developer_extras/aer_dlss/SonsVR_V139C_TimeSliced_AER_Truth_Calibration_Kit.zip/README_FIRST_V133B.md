# V133B — typed-HDRP passive feature-state probe fix

## What V133 actually found
V133's native router stayed healthy, with both VR eyes receiving the selected quality; live HDRP input remained 1572 x 1660 for Quality and Ultra Performance. The new feature-state probe logged `NO_DLSS_PASS pipeline=UnityEngine.Rendering.RenderPipeline enabled=NA`. This was a wrapper-type mistake: `RenderPipelineManager.currentPipeline` returns a base IL2CPP wrapper, and V133 reflected HDRP-specific properties on that base type.

## What V133B changes
In `mod/NativeDlssFeatureStateV133.cs`, cast the base pipeline to the *actual* HDRenderPipeline wrapper with `TryCast<HDRenderPipeline>()`; then use verified generated IL2CPP property getters `m_DLSSPass` and `m_DLSSPassEnabled`. Add one read-only census of the internal DLSS camera-state dictionary keys (at most 16), to detect an incorrect camera-ID lookup independently of the wrapper-type issue. All other source files (VR rendering, V128 routing, HUD, depth guard, NVOFA, etc.) are unchanged.

This remains a PASSIVE measurement. No in-game warnings, no timed manipulation, no scaler or NVIDIA native feature interception.

## Use
If V133 is already extracted: apply the V133B small hotfix, overwriting `mod/NativeDlssFeatureStateV133.cs` and `BUILD_V133.bat`, and adding `static_audit_v133b.py`. Rerun `BUILD_V133.bat`. Alternatively extract the full V133B kit and run `BUILD_V133.bat`.

In genuine 2E gameplay: Quality ~6 seconds -> Ultra Performance ~6 seconds -> Quality ~6 seconds; exit and run `PACK_V133_TRACE.bat`. Send the return ZIP.

## Expected markers
`[V133 DLSS-FEATURE] SURFACE pipeline=UnityEngine.Rendering.HighDefinition.HDRenderPipeline ...` (typed access succeeded)
`[V133 DLSS-FEATURE] CAMERA_STATE_KEYS ...` (if DLSS has camera state entries)
`[V133 DLSS-FEATURE] SAMPLE #...` (per-eye state)

If `NOT_HDRP_PIPELINE`, `NO_DLSS_PASS_ON_TYPED_HDRP`, or `state=NOT_FOUND` occurs, the trace will distinguish the failure stage rather than asserting DLSS is absent.

## Limitations
C# compilation and runtime behavior against the user's local Windows assemblies have not been performed in this environment. The typed getters and public HDRenderPipeline type were verified from the user's generated HDRP wrapper metadata. Reflection over nested `ViewState` values may reveal a further IL2CPP representation issue; those reads are guarded. The static audit is not proof of compilation.
