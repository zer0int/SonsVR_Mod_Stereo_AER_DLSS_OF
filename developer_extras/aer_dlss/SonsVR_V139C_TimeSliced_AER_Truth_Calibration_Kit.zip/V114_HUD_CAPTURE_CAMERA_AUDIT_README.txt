SonsVR V114 - HUD CAPTURE REPAIR + CAMERA / COMPOSITOR AUDIT
===========================================================

WHAT V114 IS TESTING
--------------------
V113's architecture remains: keep SOTF's native HUD in its authored 2D screen
coordinate system, render the finished native HUD sheet to one 1920x1080 RT, and
present that RT as one finite-distance OpenVR overlay. Do not convert the map,
ring, MessageList, etc. independently into metre-space. The physically-held GPS
is genuine world-space content and remains untouched.

V114 repairs the capture plumbing and adds a runtime census so one launch can
answer both the HUD problem and the "what other cameras/render paths are still
alive?" question.

CHANGES VS V113
---------------
1) HUD capture camera precision repair
   V113 placed its ScreenSpaceCamera at (100000,100000,100000). At that magnitude
   float32 position spacing is large enough to quantize tiny UI/glyph geometry by
   multiple pixels. V114 uses (1000,1000,1000) plus near/far 0.50/1.50 around the
   canvas plane at distance 1.0.

2) HUD camera no longer uses cullingMask=-1 / ~0
   V114 computes the union of layers actually used by Canvas / CanvasRenderer
   objects below ScreenSpaceCanvas and the minimap canvas. The mask is refreshed
   only every 5 seconds, not by a hierarchy scan every frame.

3) HDRP background isolation
   HUD camera uses constant transparent clear and volumeLayerMask=0. The existing
   cheap-camera helper still disables AA/DLSS/DRS/history best-effort; V114 owns
   clear/volume state directly.

4) Hidden two-stage compositor preflight
   Before the HUD overlay is shown:
     A. cullingMask=0 + volumeLayerMask=0 -> sample actual RT
     B. HUD-only culling mask             -> sample actual RT
   Each 1920x1080 RT is first blitted to 64x36, then one tiny CPU readback records
   RGB, alpha, opaque/nontransparent fraction, luminance variance, top/bottom.

   Interpretation:
     EMPTY sample has visible RGB variation:
       -> something outside ordinary scene-object culling is drawing.
     EMPTY sample RGB~0 but alpha~1:
       -> transparency is being lost/forced opaque before OpenVR presentation.
     EMPTY clean (RGB~0,A~0), HUD_ONLY has cloud/background:
       -> contamination is on one of the HUD-visible scene layers or comes with
          captured UI content itself.
     EMPTY clean, HUD_ONLY clean apart from UI:
       -> capture texture is sane; any remaining presentation issue is later.

5) HUD angular width 90deg -> 60deg
   Native child coordinates remain untouched. Only the finished sheet gets a
   smaller angular footprint so edge-authored pancake HUD items are not thrown
   ~40 degrees into peripheral vision.

6) Stale V113 overlay cleanup
   V114 checks its own historical V113 key once and asks OpenVR to hide/destroy
   it before creating/reusing the V114 HUD overlay.

7) Loading is now deliberately boring
   During SonsMainLoading/BlankScene before the gameplay-ready gate, BOTH VR eyes:
     - render only dedicated layer 31
     - constant black clear
     - HDRP volumeLayerMask=0
   The tiny synthetic "LOADING / SOTF VR" canvas is placed on layer 31.
   Native layer-5 loading sky/backing is no longer requested in the headset.
   Exact previous eye state is restored at the gameplay gate.

   IMPORTANT: the existing native non-VR camera performance optimization is NOT
   removed or weakened. Its own culling mask remains the single dummy layer 31;
   cullingMask=0 is still not used for that native camera; CameraType.Preview is
   still disabled.

8) Camera / compositor census
   UserData/SonsVR_V114_CameraCompositorAudit.log records:
     - every loaded Camera, even inactive ones
     - which cameras actually render between snapshots
     - scene/hierarchy/layer/tag
     - target RT and dimensions
     - camera GameObject component type list
     - culling/clear/clipping/stereo/display
     - HDRP clear/volume/probe/AA/DLSS/history fields
     - CPU-side SRP begin->end wall interval (NOT GPU timing)
     - top RenderTextures by area
     - LoadingCameraBacking renderers at semantic transitions
     - all loaded HDRP CustomPassVolumes and pass types
     - active/default/quality HDRP pipeline reflection including colorBufferFormat
     - known V113/V114 OpenVR HUD overlay keys/visibility

   The global Renderer census is transition-only so the diagnostic does not become
   a periodic level-wide scan tax.

STATIC SOURCE RESULT
--------------------
V114 static source audit: 62/62 checks passed.
See V114_STATIC_AUDIT.txt and V114_CAMERA_SOURCE_AUDIT.txt.

The source contains exactly six Camera construction sites:
  - VRLeftEye
  - VRRightEye
  - V114 HUD capture camera
  - binocular zoom camera (default OFF)
  - two legacy always-on-top HUD cameras (only called if native HUD compositor OFF)

Only NativeHudCompositorV114.cs creates an OpenVR Overlay. Normal eye presentation
still uses the existing OpenVR.Compositor.Submit path.

BUILD
-----
Run:

  BUILD_V114.bat

It runs the static audit first, then builds the unchanged native NVOF bridge,
shader bundle, and managed mod.

Copy from OUTPUT:

  SonsVR_Mod.dll
  SonsVR_NvOF_V90.dll

to:

  D:\SteamLibrary\steamapps\common\Sons Of The Forest\Mods

TEST - ONE REPRESENTATIVE RUN
-----------------------------
No log-watching in the HMD is required. The diagnostic samples itself.

Observe only:
  1. Loading should be black + the synthetic LOADING / SOTF VR text. No native
     cloud/world/background should be necessary in the headset.
  2. When gameplay HUD appears, check whether text glyphs are now geometrically
     stable rather than letters resizing/scrambling against each other.
  3. Check map/ring alignment and HUD stability during head rotation/walking.
  4. Check whether 60deg width makes messages/map comfortably visible.
  5. Sanity-check the physically held GPS remains ordinary 3D content.
  6. Play for long enough to reach normal gameplay so the camera census gets a
     post-gameplay-gate snapshot. Opening the tarp/inventory once is also useful
     because the game intentionally changes source cameras there.

Then exit normally and run:

  PACK_V114_TRACE.bat

Send back V114_TRACE_RETURN.zip.

The most important file inside is:

  UserData\SonsVR_V114_CameraCompositorAudit.log

NOTES / LIMITS
--------------
This package was source-audited in the generation environment, but cannot be
actually compiled there because the build depends on your local Windows dotnet,
Unity 2022.2.16f1, and game-specific MelonLoader Il2CppAssemblies. BUILD_V114.bat
therefore remains the authoritative compile check. If the compiler reports an
interop/API signature mismatch, send the exact error; no game-specific behavior
should be guessed around it.
