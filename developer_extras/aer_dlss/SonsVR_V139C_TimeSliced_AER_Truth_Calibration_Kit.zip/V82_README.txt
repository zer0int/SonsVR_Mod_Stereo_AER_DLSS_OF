SONSVR V82 — CAMERA-LOCAL HDRP DEPTH IS NOW THE V51 SOURCE
==============================================================

V81f FOUND THE SMOKING GUN
--------------------------
In the same gameplay scene, HDRP's camera-local base depth:

  CustomPassContext.cameraDepthBuffer
  CameraDepthStencil_3840x3317_None_Tex2DArray

was essentially completely healthy after warmup:

  validFrac ≈ 0.9999 - 1.0000
  zeroFrac  ≈ 0.0000
  median depth ≈ 2-3 m

At the same time, the old global packed mip-chain sampled by V50 was:

  validFrac ≈ 0.3477
  zeroFrac  ≈ 0.6523

with one giant connected invalid region covering the lower ~65.2% of the image:

  global validRows (top, middle, bottom)
    ≈ 1.000, 0.035, 0.000

whereas camera-local depth was:

    ≈ 1.000, 1.000, 1.000

That spatial shape is the exact kind of giant slab the visual artifact has
been presenting.

WHAT V82 CHANGES
----------------
V82 is the first rendering-change build since this forensics branch.

At endCameraRendering for the completed VR eye:

1. The AfterOpaqueDepthAndNormal CustomPass has already copied
   ctx.cameraDepthBuffer into an eye-local full-resolution RFloat RT.

2. V82 requires:
     correct eye
     exact current Time.frameCount
     exact 3141x3317 source dimensions

3. If all match, V82 uses Graphics.CopyTexture to copy that RFloat depth
   literally into the existing V50/V51 owned depth latch.

4. The old global _CameraDepthTexture path is retained ONLY as a safety fallback
   if the local source is missing/stale.

5. V80 continues to diagnose the global texture passively for A/B evidence,
   but the global packed mip-chain no longer drives V51 when the local source
   is available.

6. Existing V72/V76 HUD depth/private-latch operations happen AFTER the new
   camera-local copy exactly as before.

NO OTHER V51 MATH CHANGED
-------------------------
Same:
  warp grid
  projections
  max distance
  discontinuity threshold
  confidence
  1px + 2px hole fill
  stale target-eye fallback
  V76 dense HUD handling
  OpenVR submission

So this is a clean source substitution.

EXPECTED LOG
------------
You want:

  [AER V82][DepthLatch] ... DEPTH-SOURCE=CUSTOMPASS-cameraDepthBuffer

and:

  [AER V51][DepthWarp] ... depthSource=CUSTOMPASS ...

If it says GLOBAL-FALLBACK, do not interpret the visual result as the intended
V82 test.

EXPECTED VISUAL RESULT
----------------------
If the giant flashing rectangle really came from the packed-global depth slab,
it should disappear or change radically.

Normal small stereo forward-warp disocclusions can still exist. V82 does not
magically make forward warping perfect; it removes the catastrophic false
~65% zero-depth region.

BUILD
-----
  BUILD_V82.bat

RUN
---
For the first test, keep the scene/settings simple. You do NOT need a long
DLSS protocol before judging the primary result.

Once the real spawn occurs and AER activates:
  - check whether the giant rectangle is gone / radically changed
  - try normal DLSS and OFF if useful

PACK
----
  PACK_V82_TRACE.bat

Send:
  V82_TRACE_RETURN.zip
