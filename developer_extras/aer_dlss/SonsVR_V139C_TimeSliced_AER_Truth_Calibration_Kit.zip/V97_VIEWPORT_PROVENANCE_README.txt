SonsVR V97 - HDRP RTHandle / active viewport provenance probe
===============================================================

PURPOSE
-------
V96 proved that OpenVR ComputeDistortion is identity on this Quest/SteamVR path;
the physical Quest lens warp is therefore downstream and hidden from OpenVR.

V97 changes NO rendering behavior. It logs, once per eye during the existing
AfterOpaqueDepthAndNormal CustomPass:

  * HDCamera.actualWidth/actualHeight
  * Camera pixel/scaledPixel dimensions and target texture dimensions
  * ScalableBufferManager width/height scale
  * cameraColorBuffer RTHandle properties
  * cameraDepthBuffer RTHandle properties
  * cameraMotionVectorsBuffer RTHandle properties
  * reference size, scaled size, physical allocation, scaleFactor/useScaling
  * current/previous viewport and render-target sizes
  * RTHandleScale (including history zw)
  * HDRP globals: _RTHandleScale, _RTHandleScaleHistory, _ScreenSize,
    _PostProcessScreenSize, _DynamicResolutionScreenSize,
    _ScreenCoordScaleBias, _ScreenSizeOverride, _GlobalMipBias
  * diagnostic mapping of internal pixel centers to the final 3141x3317 eye RT

WHY
---
HDRP's RTHandle API explicitly supports per-handle custom properties for DLSS/TAAU.
The current trace shows camera depth allocated at 3840x3317 while the active
HDCamera viewport is 1572x1660 and the final eye target is 3141x3317. V97 measures
the exact coordinate domains instead of assuming normalized 0..1 means the same
thing for all of them.

BUILD / RUN
-----------
Run BUILD_V97.bat. Copy OUTPUT\SonsVR_Mod.dll and OUTPUT\SonsVR_NvOF_V90.dll
to the game Mods folder. Start the game until the VR eye cameras render at least
once. No visual A/B is required. Then run PACK_V97_TRACE.bat and send
V97_TRACE_RETURN.zip.
