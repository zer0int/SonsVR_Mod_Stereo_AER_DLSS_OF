SONSVR V81e — POST-SPAWN CAMERA-LOCAL HDRP DEPTH PROBE
========================================================

WHY THIS VERSION EXISTS
-----------------------
The user's startup description exposed a critical lifecycle fact already visible
in this fork's own comments/logs:

The VR rig can exist for a substantial time BEFORE the real gameplay spawn.
During that interval the user may see a temporary under-map / fallback-camera
view. Later the game switches to:

  SonsMain + MainCameraFP + LocalPlayer

and only then does the mod arm AER and copy the real MainCameraFP
HDAdditionalCameraData onto the two VR eye cameras.

Earlier V81 probes were installed during StereoRender.Setup(), i.e. potentially
during that transient pre-spawn phase.

V81e NO LONGER DOES THAT.

INSTALL GATE
------------
The camera-local CustomPass probe may exist ONLY after BOTH are true:

  AerGameplayReadyForActivation == true
    -> SonsMain + MainCameraFP + LocalPlayer confirmed

  _hdrpDataCopiedOnce == true
    -> real MainCameraFP HDAdditionalCameraData copied to VRLeftEye/VRRightEye

This is the same known-good milestone used by deferred AER activation.

PERSISTENCE
-----------
Each probe GameObject is parented directly to its VR eye camera.

The VR eye rig lives under the persistent [VROrigin], so the probe no longer
depends on the lifetime of a loading/fallback scene.

StereoRender also re-runs EnsureVolumes() once per second after gameplay is
ready. If Unity destroys/replaces a probe object, it is recreated.

PASS CREATION
-------------
V81e keeps V81d's stronger lifecycle construction:

  volume.AddPassOfType(typeof(EyeDepthCaptureCustomPassV81))

and explicit camera mode:

  volume.targetCamera = VRLeftEye / VRRightEye

LIVENESS LADDER
---------------
A valid run should show:

  [AER V81e][CustomDepth] POST-SPAWN probe ensure ACTIVE
  [AER V81e][CustomDepth][SETUP-SEEN]
  [AER V81e][CustomDepth][EXEC-SEEN]
  LOCALDEPTH_V81 rows

The first marker should appear only AFTER the real spawn transition.

BUILD
-----
  BUILD_V81e2_TRACE.bat

If the shader/C# build fails, don't launch.

RUN
---
For the first few seconds after the REAL spawn (avatar/hands present), you do
not need to change DLSS. We first need proof that SETUP/EXEC occurs after the
post-spawn gate.

If it does, use the fixed-view sequence:
  current DLSS ~4s
  OFF ~4s
  Quality ~4s
  OFF ~4s

PACK
----
  PACK_V81e_TRACE.bat

Send:
  V81e_TRACE_RETURN.zip


V81e2 COMPILE HOTFIX
--------------------
Only the AddPassOfType argument conversion changed.

The generated IL2CPP HDRP wrapper expects:
  Il2CppSystem.Type

not:
  System.Type

So:
  typeof(EyeDepthCaptureCustomPassV81)

became:
  Il2CppInterop.Runtime.Il2CppType.From(
      typeof(EyeDepthCaptureCustomPassV81))

No runtime/render/diagnostic logic changed.
