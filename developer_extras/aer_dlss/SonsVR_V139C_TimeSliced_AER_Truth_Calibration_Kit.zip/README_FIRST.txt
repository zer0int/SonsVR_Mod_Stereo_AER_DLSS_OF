SONSVR V104 -- PRODUCTION DEPTH-GUARDED AER BASELINE
=====================================================

1. Run BUILD_V104.bat
2. Copy BOTH OUTPUT\SonsVR_Mod.dll and OUTPUT\SonsVR_NvOF_V90.dll into the game's Mods folder.
3. Launch and PLAY NORMALLY. No HMD experiment sequence or log watching is required.
4. Depth-guarded R1/R2 fill is permanent; normal NVOFA residual use is restored.
5. If anything looks wrong, run PACK_V104_LOG.bat and send V104_LOG_RETURN.zip.

Read V104_PRODUCTION_DEPTH_GUARD_README.txt for the promoted fix and validation notes.
