import os,struct,zipfile,sys,json,collections
U8=lambda b,o:b[o]
U16=lambda b,o:struct.unpack_from('<H',b,o)[0]
U32=lambda b,o:struct.unpack_from('<I',b,o)[0]
U64=lambda b,o:struct.unpack_from('<Q',b,o)[0]
CODES={
'ResolutionScope':(2,[0,26,35,1]), 'TypeDefOrRef':(2,[2,1,27]),
'HasConstant':(2,[4,8,23]),
'HasCustomAttribute':(5,[6,4,1,2,8,9,10,0,14,23,20,17,26,27,32,35,38,39,40,42,43,44]),
'HasFieldMarshal':(1,[4,8]), 'HasDeclSecurity':(2,[2,6,32]),
'MemberRefParent':(3,[2,1,26,6,27]), 'HasSemantics':(1,[20,23]),
'MethodDefOrRef':(1,[6,10]), 'MemberForwarded':(1,[4,6]),
'Implementation':(2,[38,35,39]), 'CustomAttributeType':(3,[None,None,6,10,None]),
'TypeOrMethodDef':(1,[2,6]),
}
T={
0:['u2','str','guid','guid','guid'],1:['ResolutionScope','str','str'],
2:['u4','str','str','TypeDefOrRef','idx4','idx6'],3:['idx4'],4:['u2','str','blob'],5:['idx6'],
6:['u4','u2','u2','str','blob','idx8'],7:['idx8'],8:['u2','u2','str'],
9:['idx2','TypeDefOrRef'],10:['MemberRefParent','str','blob'],11:['u2','HasConstant','blob'],
12:['HasCustomAttribute','CustomAttributeType','blob'],13:['HasFieldMarshal','blob'],14:['u2','HasDeclSecurity','blob'],
15:['u2','u4','idx2'],16:['u4','idx4'],17:['blob'],18:['idx2','idx20'],19:['idx20'],
20:['u2','str','TypeDefOrRef'],21:['idx2','idx23'],22:['idx23'],23:['u2','str','blob'],
24:['u2','idx6','HasSemantics'],25:['idx2','MethodDefOrRef','MethodDefOrRef'],26:['str'],27:['blob'],
28:['u2','MemberForwarded','str','idx26'],29:['u4','idx4'],30:['u4','u4'],31:['u4'],
32:['u4','u2','u2','u2','u2','u4','blob','str','str'],33:['u4'],34:['u4','u4','u4'],
35:['u2','u2','u2','u2','u4','blob','str','str','blob'],36:['u4','idx35'],37:['u4','u4','u4','idx35'],
38:['u4','str','blob'],39:['u4','u4','str','str','Implementation'],40:['u4','u4','str','Implementation'],
41:['idx2','idx2'],42:['u2','u2','TypeOrMethodDef','str'],43:['MethodDefOrRef','blob'],44:['idx42','TypeDefOrRef']}
class Cli:
 def __init__(self,b):
  self.b=b
  pe=U32(b,0x3c); assert b[pe:pe+4]==bytes([80,69,0,0])
  nsect=U16(b,pe+6); osize=U16(b,pe+20); opt=pe+24
  dd=opt+(96 if U16(b,opt)==0x10b else 112)
  cli_rva=U32(b,dd+14*8)
  sect=opt+osize
  self.sections=[(U32(b,sect+i*40+12),U32(b,sect+i*40+8),U32(b,sect+i*40+20),U32(b,sect+i*40+16)) for i in range(nsect)]
  mo=self.rva(U32(b,self.rva(cli_rva)+8)); assert b[mo:mo+4]==b'BSJB'
  verlen=U32(b,mo+12); off=(mo+16+verlen+3)&~3; off+=2; cnt=U16(b,off);off+=2
  streams={}
  for i in range(cnt):
   so=U32(b,off);sz=U32(b,off+4);p=off+8;end=b.index(0,p);name=b[p:end].decode('utf8');off=(end+4)&~3
   streams[name]=(mo+so,sz)
  self.streams=streams
  st,sz=streams.get('#~',streams.get('#-')); self.st=st
  self.sstr=streams['#Strings'][0];self.sblob=streams['#Blob'][0]
  heaps=U8(b,st+6); self.szstr=4 if heaps&1 else 2;self.szblob=4 if heaps&4 else 2
  valid=U64(b,st+8); off=st+24
  self.rows={i:U32(b,off+j*4) for j,i in enumerate([i for i in range(64) if valid>>i&1])}
  off+=4*len(self.rows)
  self.tables={}
  for t,n in self.rows.items():
   if t not in T: raise Exception(('unknown table',t))
   schema=T[t];out=[]
   for row in range(n):
    vals=[]
    for c in schema:
     l=self.size(c)
     v=int.from_bytes(b[off:off+l],'little');off+=l
     vals.append(v)
    out.append(vals)
   self.tables[t]=[None]+out
  self._trefs={}
 def rva(self, r):
  for v,vs,raw,rs in self.sections:
   if v<=r<v+max(vs,rs):return raw+(r-v)
  return r
 def size(self,c):
  if c=='u2':return 2
  if c=='u4':return 4
  if c=='str':return self.szstr
  if c=='blob':return self.szblob
  if c=='guid':return 2
  if c.startswith('idx'):return 4 if self.rows.get(int(c[3:]),0)>=65536 else 2
  bits,targets=CODES[c];return 4 if max(self.rows.get(x,0) for x in targets if x is not None)>=(1<<(16-bits)) else 2
 def str(self,i):
  if not i:return ''
  x=self.sstr+i
  return self.b[x:self.b.index(0,x)].decode('utf-8','replace')
 def unsigned(self,x):
  val=self.b[x];
  if val<0x80:return val,x+1
  if val<0xc0:return ((val&0x3f)<<8)|self.b[x+1],x+2
  return ((val&0x1f)<<24)|(self.b[x+1]<<16)|(self.b[x+2]<<8)|self.b[x+3],x+4
 def blob(self,i):
  if not i:return b''
  a=self.sblob+i;n,a=self.unsigned(a);return self.b[a:a+n]
 def coded(self,v,key):
  bits,targets=CODES[key]; tag=v&((1<<bits)-1); idx=v>>bits;return (targets[tag] if tag<len(targets) else None,idx)
 def typeref(self,table,idx):
  if not idx:return '<null>'
  if table in [1,2]:
   row=self.tables[table][idx];return '.'.join(filter(None,[self.str(row[2]),self.str(row[1])]))
  if table==27:return 'typespec('+self.blob(self.tables[27][idx][0]).hex()+')'
  return '?'+str((table,idx))
 def sigtype(self,b,o=0):
  if o>=len(b):return ('?',o)
  flags=[]
  while b[o] in [0x1f,0x20,0x45]:
   if b[o] in [0x1f,0x20]:
    flag='modreq' if b[o]==0x1f else 'modopt';tok,o=self.unsigned_blob(b,o+1);flags.append(flag+'('+str(tok)+')')
   else:flags.append('pinned');o+=1
  c=b[o];o+=1
  simple={0x01:'void',0x02:'bool',0x03:'char',0x04:'sbyte',0x05:'byte',0x06:'short',0x07:'ushort',0x08:'int',0x09:'uint',0x0a:'long',0x0b:'ulong',0x0c:'float',0x0d:'double',0x0e:'string',0x16:'typedref',0x18:'IntPtr',0x19:'UIntPtr',0x1c:'object'}
  if c in simple:out=simple[c]
  elif c in (0x0f,0x10,0x1d):
   sub,o=self.sigtype(b,o);out=('*' if c==0xf else 'ref ' if c==0x10 else '')+sub+('[]' if c==0x1d else '')
  elif c in (0x11,0x12):
   tok,o=self.unsigned_blob(b,o);out=self.typeref(*self.coded(tok,'TypeDefOrRef'))
  elif c in (0x13,0x1e):
   n,o=self.unsigned_blob(b,o);out=('T' if c==0x13 else 'M')+str(n)
  elif c==0x15:
   kind=b[o];o+=1;tok,o=self.unsigned_blob(b,o);cnt,o=self.unsigned_blob(b,o)
   args=[]
   for i in range(cnt):
    arg,o=self.sigtype(b,o);args.append(arg)
   out=self.typeref(*self.coded(tok,'TypeDefOrRef'))+'<'+', '.join(args)+'>'
  elif c==0x14:
   sub,o=self.sigtype(b,o);rank,o=self.unsigned_blob(b,o);cnt,o=self.unsigned_blob(b,o)
   for _ in range(cnt):_,o=self.unsigned_blob(b,o)
   cnt,o=self.unsigned_blob(b,o)
   for _ in range(cnt):_,o=self.unsigned_blob(b,o)
   out=sub+'['+(','*(max(rank-1,0)))+']'
  else:out='0x%02X'%c
  return (' '.join(flags+[out]),o)
 def unsigned_blob(self,b,o):
  val=b[o];
  if val<0x80:return val,o+1
  if val<0xc0:return ((val&0x3f)<<8)|b[o+1],o+2
  return ((val&0x1f)<<24)|(b[o+1]<<16)|(b[o+2]<<8)|b[o+3],o+4
 def methodsig(self,i):
  b=self.blob(i)
  if not b:return '?'
  try:
   off=1
   if b[0]&0x10:_,off=self.unsigned_blob(b,off)
   n,off=self.unsigned_blob(b,off); ret,off=self.sigtype(b,off);args=[]
   for j in range(n):
    if b[off]==0x41:off+=1
    a,off=self.sigtype(b,off);args.append(a)
   return ret,args
  except Exception as e:return '?'+repr(e),[b.hex()]
 def fieldsig(self,i):
  b=self.blob(i)
  try:return self.sigtype(b,1)[0]
  except:return '??'+b.hex()
 def types(self):
  defs=self.tables.get(2,[None])
  for idx,td in enumerate(defs[1:],1):
   name=self.typeref(2,idx)
   ne=defs[idx+1][4] if idx+1<len(defs) else len(self.tables.get(4,[None]))
   me=defs[idx+1][5] if idx+1<len(defs) else len(self.tables.get(6,[None]))
   flds=[];methods=[]
   for fi in range(td[4],ne):
    v=self.tables[4][fi];flds.append({'name':self.str(v[1]),'type':self.fieldsig(v[2]),'static':bool(v[0]&0x10),'private':bool(v[0]&1),'flags':v[0]})
   for mi in range(td[5],me):
    v=self.tables[6][mi];ret,args=self.methodsig(v[4]);methods.append({'name':self.str(v[3]),'return':ret,'args':args,'static':bool(v[2]&0x10),'access':v[2]&7,'rva':v[0]})
   yield {'name':name,'fields':flds,'methods':methods,'extends':self.typeref(*self.coded(td[3],'TypeDefOrRef')),'type_idx':idx}
if __name__=='__main__':
 path=sys.argv[1] if len(sys.argv)>1 else '/mnt/data/SonsVR_DLSS_Wrapper_Contract_20261013_201201.zip'
 selected=['DynamicResUpscaleManager','DynamicResolutionSettingReceiver','DynamicResolutionScaler','DlssOptionGui','DynamicResUpscaleOptionGui','DynamicResolutionTargetOptionGui','OptionsManager','GraphicsOptions','GraphicOptions']
 report={}
 with zipfile.ZipFile(path) as z:
  for n in z.namelist():
   if not n.endswith('.dll'):continue
   p=Cli(z.read(n));details=[x for x in p.types() if any(z.lower() in x['name'].lower() for z in selected)]
   report[n]=details
   print('\nDLL',n,'Types:',p.rows.get(2),'Methods:',p.rows.get(6))
   for x in details:
    print('\n###',x['name'],'extends',x['extends'])
    print('fields',len(x['fields']))
    for f in x['fields']:
     print('  ', 'static ' if f['static'] else '', f['type'], f['name'])
    print('methods',len(x['methods']))
    for m in x['methods']:
     print('  ', 'static ' if m['static'] else '',m['return'],m['name'],'(', ', '.join(m['args']),')')
 with open('/mnt/data/dlss_contract_followup/wrapper_contract_parsed.json','w') as f:json.dump(report,f,indent=2)
