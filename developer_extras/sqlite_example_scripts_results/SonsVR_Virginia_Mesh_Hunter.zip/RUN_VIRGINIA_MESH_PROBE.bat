@echo off
setlocal
set "DB=D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"
python "%~dp0find_virginia_mesh_candidates.py" "%DB%"
pause
