#!/usr/bin/env python3
import csv, datetime as dt, sqlite3, sys, zipfile
from pathlib import Path

DEFAULT_DB = r"D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"
TERM = "virginia"


def cols(con, table):
    try:
        return [str(r[1]) for r in con.execute(f"PRAGMA table_info({table})")]
    except Exception:
        return []


def write_csv(path, rows):
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8-sig")
        return
    keys = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k); keys.append(k)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)


def rows(con, sql, params=()):
    return [dict(r) for r in con.execute(sql, params).fetchall()]


def main():
    db = Path(sys.argv[1] if len(sys.argv) > 1 else DEFAULT_DB)
    if not db.exists():
        raise SystemExit(f"DB not found: {db}")

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = Path.cwd() / f"virginia_mesh_probe_{stamp}"
    out.mkdir(parents=True, exist_ok=True)

    uri = "file:" + db.resolve().as_posix() + "?mode=ro&immutable=1"
    con = sqlite3.connect(uri, uri=True)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("PRAGMA temp_store=MEMORY")

    ocols = cols(con, "objects")
    ecols = cols(con, "edges")
    acols = cols(con, "aliases")

    searchable = [c for c in (
        "name", "script_class", "script_decl", "hierarchy", "source_file",
        "serialized_file", "asset_key", "type"
    ) if c in ocols]
    if not searchable:
        raise SystemExit("objects table does not expose expected searchable columns")

    where = " OR ".join([f"lower(COALESCE({c},'')) LIKE ?" for c in searchable])
    params = [f"%{TERM}%"] * len(searchable)
    virginia = rows(con, f"SELECT * FROM objects WHERE {where} ORDER BY source_file,hierarchy,type,name,path_id", params)
    write_csv(out / "01_virginia_object_hits.csv", virginia)

    # Alias search is deliberately schema-agnostic.
    alias_hits = []
    if acols:
        awhere = " OR ".join([f"lower(CAST(COALESCE({c},'') AS TEXT)) LIKE ?" for c in acols])
        try:
            alias_hits = rows(con, f"SELECT * FROM aliases WHERE {awhere}", [f"%{TERM}%"] * len(acols))
        except Exception as ex:
            alias_hits = [{"error": str(ex)}]
    write_csv(out / "02_virginia_alias_hits.csv", alias_hits)

    keys = {(r.get("asset_key"), r.get("path_id")) for r in virginia if r.get("asset_key") is not None and r.get("path_id") is not None}
    asset_keys = sorted({r.get("asset_key") for r in virginia if r.get("asset_key") is not None})
    source_files = sorted({r.get("source_file") for r in virginia if r.get("source_file")})

    # Direct graph neighborhood around literal Virginia hits.
    direct_edges = []
    if {"source_asset_key","source_path_id","target_asset_key","target_path_id"}.issubset(set(ecols)):
        seen = set()
        for ak, pid in keys:
            for direction, sql in (
                ("FORWARD", "SELECT * FROM edges WHERE source_asset_key=? AND source_path_id=?"),
                ("REVERSE", "SELECT * FROM edges WHERE target_asset_key=? AND target_path_id=?"),
            ):
                for rr in rows(con, sql, (ak, int(pid))):
                    k = (direction,) + tuple(rr.get(c) for c in ecols)
                    if k in seen: continue
                    seen.add(k)
                    rr["direction"] = direction
                    rr["virginia_seed_asset_key"] = ak
                    rr["virginia_seed_path_id"] = pid
                    direct_edges.append(rr)
    write_csv(out / "03_virginia_direct_edges.csv", direct_edges)

    # Character meshes are usually easiest to find through SkinnedMeshRenderer -> m_Mesh,
    # not by hoping the Mesh object itself is literally named Virginia.
    renderer_candidates = []
    renderer_types = ("SkinnedMeshRenderer", "MeshRenderer", "MeshFilter")
    if "type" in ocols:
        scope_clauses, scope_params = [], []
        if asset_keys:
            ph = ",".join("?" for _ in asset_keys)
            scope_clauses.append(f"asset_key IN ({ph})")
            scope_params.extend(asset_keys)
        if source_files and "source_file" in ocols:
            ph = ",".join("?" for _ in source_files)
            scope_clauses.append(f"source_file IN ({ph})")
            scope_params.extend(source_files)
        # Also catch renderer hierarchy/source names containing Virginia directly.
        text_scope = " OR ".join([f"lower(COALESCE({c},'')) LIKE ?" for c in searchable])
        scope_clauses.append(f"({text_scope})")
        scope_params.extend([f"%{TERM}%"] * len(searchable))
        tph = ",".join("?" for _ in renderer_types)
        sql = f"SELECT * FROM objects WHERE type IN ({tph}) AND ({' OR '.join(scope_clauses)}) ORDER BY source_file,hierarchy,type,name,path_id"
        renderer_candidates = rows(con, sql, (*renderer_types, *scope_params))
    write_csv(out / "04_candidate_renderers.csv", renderer_candidates)

    # Follow renderer edges to Mesh objects, prioritizing field paths containing 'mesh'.
    mesh_edges = []
    mesh_objects = []
    mesh_seen = set()
    if renderer_candidates and {"source_asset_key","source_path_id","target_asset_key","target_path_id"}.issubset(set(ecols)):
        for r in renderer_candidates:
            ak, pid = r.get("asset_key"), r.get("path_id")
            if ak is None or pid is None: continue
            for e in rows(con, "SELECT * FROM edges WHERE source_asset_key=? AND source_path_id=?", (ak, int(pid))):
                tak, tpid = e.get("target_asset_key"), e.get("target_path_id")
                target = None
                if tak is not None and tpid is not None:
                    tr = rows(con, "SELECT * FROM objects WHERE asset_key=? AND path_id=?", (tak, int(tpid)))
                    target = tr[0] if tr else None
                fp = str(e.get("field_path", ""))
                target_type = str((target or {}).get("type", ""))
                if "mesh" in fp.lower() or target_type == "Mesh":
                    rec = dict(e)
                    rec.update({
                        "renderer_type": r.get("type"),
                        "renderer_name": r.get("name"),
                        "renderer_hierarchy": r.get("hierarchy"),
                        "renderer_source_file": r.get("source_file"),
                        "target_type": target_type,
                        "target_name": (target or {}).get("name"),
                        "target_hierarchy": (target or {}).get("hierarchy"),
                        "target_source_file": (target or {}).get("source_file"),
                    })
                    mesh_edges.append(rec)
                    if target:
                        mk = (target.get("asset_key"), target.get("path_id"))
                        if mk not in mesh_seen:
                            mesh_seen.add(mk); mesh_objects.append(target)
    write_csv(out / "05_renderer_to_mesh_edges.csv", mesh_edges)
    write_csv(out / "06_mesh_objects.csv", mesh_objects)

    # Same-asset Mesh inventory can catch meshes connected indirectly through prefabs/LODs.
    same_asset_meshes = []
    if asset_keys and "type" in ocols:
        ph = ",".join("?" for _ in asset_keys)
        same_asset_meshes = rows(con, f"SELECT * FROM objects WHERE type='Mesh' AND asset_key IN ({ph}) ORDER BY source_file,name,path_id", asset_keys)
    write_csv(out / "07_same_asset_mesh_inventory.csv", same_asset_meshes)

    summary = []
    summary.append("Virginia mesh SQL probe")
    summary.append("=======================")
    summary.append(f"DB: {db}")
    summary.append(f"literal Virginia object hits: {len(virginia)}")
    summary.append(f"alias hits: {len(alias_hits)}")
    summary.append(f"direct dependency edges: {len(direct_edges)}")
    summary.append(f"candidate renderers: {len(renderer_candidates)}")
    summary.append(f"renderer -> mesh edges: {len(mesh_edges)}")
    summary.append(f"unique mesh targets: {len(mesh_objects)}")
    summary.append(f"same-asset Mesh objects: {len(same_asset_meshes)}")
    summary.append("")
    summary.append("Start with 05_renderer_to_mesh_edges.csv and 06_mesh_objects.csv.")
    summary.append("For a character, SkinnedMeshRenderer -> m_Mesh is usually more useful than searching Mesh names directly.")
    summary.append("Expect body/clothes/hair/etc. to be split across multiple mesh objects and possibly LODs.")
    summary.append("This probe only identifies assets/path IDs; it does not extract Unity mesh bytes.")
    (out / "README.txt").write_text("\n".join(summary) + "\n", encoding="utf-8")

    zpath = Path.cwd() / f"virginia_mesh_probe_{stamp}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.iterdir()):
            z.write(p, arcname=p.name)

    print("\n".join(summary))
    print(f"\nOutput: {zpath}")

if __name__ == "__main__":
    main()
