SONSVR HUD ARCHAEOLOGY RUN KIT
==============================

Put these BAT files in the directory that directly contains:

  unity_dependency_extractor_kit\slice_unity_dependency_db.py
  unity_dependency_monobehavior_resolver_kit\resolve_stripped_monobehaviours.py

Primary run:
  RUN_CURRENT_HUD_ARCHAEOLOGY.bat

It performs a targeted read-only SQLite slice around the current HUD/GPS/vitals
suspects, then optionally reruns the stripped-MonoBehaviour resolver.

Expected local inputs:
  D:\unity_dependency_hunter_out\unity_dependency_index.sqlite
  D:\SteamLibrary\steamapps\common\Sons Of The Forest

Target path IDs:
  52635, 50300, 57805, 55855, 24878, 15344, 54514, 50046, 9969

Target terms:
  GPSTrackerSystem, GpsLocatorVisualsHookup, GPSLocator, PlayerMiniMap, ScreenMask, ScreenBounds, MapRotatorGroup, MapRoot, PlayerArrow, SurfaceMap, ScreenStatic, VitalsBackingCircle, VitalsRenderTexture, PlayerVitalsUiWorldSpace, HudCamera, VitalsGuiManager, VitalsGui, RenderVitalsGui, ShapesDiscSync, ScreenSpaceCanvas, ToggleableHUD, PlayerVitalUiRenderTextureGroup, MessageList, WorldScreenSpaceElements, MainCameraFP

Why these:
- GPS controller + exact map transform/mask hierarchy.
- Separate vitals HudCamera -> VitalsRenderTexture path.
- Main ScreenSpaceCanvas / ToggleableHUD / MessageList common render path.
- MainCameraFP, because camera references/timing are now a prime suspect.

Output:
  hud_archaeology_output\YYYYMMDD_HHMMSS\evidence_slice.zip
  hud_archaeology_output\YYYYMMDD_HHMMSS\stripped_mb_evidence.zip   (optional)

Send the ZIP(s) back.

About *.bank:
Sons of the Forest .bank files are FMOD sound banks. They matter for audio
events/samples, not this HUD transform/render-path problem, so this run ignores
them deliberately.
