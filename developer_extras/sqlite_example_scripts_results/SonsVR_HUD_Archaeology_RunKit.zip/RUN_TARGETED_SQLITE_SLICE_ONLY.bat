@echo off
setlocal EnableExtensions
title SonsVR - HUD Archaeology

set "PY=C:\Program Files\Python310\python.exe"
if not exist "%PY%" set "PY=python"

set "GAME=D:\SteamLibrary\steamapps\common\Sons Of The Forest"
set "DB=D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"

set "SLICE=%~dp0unity_dependency_extractor_kit\slice_unity_dependency_db.py"
set "RESOLVER=%~dp0unity_dependency_monobehavior_resolver_kit\resolve_stripped_monobehaviours.py"

for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%I"
set "OUTROOT=%~dp0hud_archaeology_output\%STAMP%"
mkdir "%OUTROOT%" >nul 2>nul

echo.
echo ============================================================
echo  SonsVR CURRENT HUD ARCHAEOLOGY - TARGETED SQLITE SLICE
echo ============================================================
echo.
echo DB:
echo   %DB%
echo.
echo Output:
echo   %OUTROOT%
echo.
echo This is READ-ONLY / IMMUTABLE against the big SQLite DB.
echo.

if not exist "%SLICE%" (
  echo ERROR: slicer not found:
  echo   %SLICE%
  echo.
  echo Put this BAT beside these folders:
  echo   unity_dependency_extractor_kit
  echo   unity_dependency_monobehavior_resolver_kit
  pause
  exit /b 2
)

if not exist "%DB%" (
  echo ERROR: dependency DB not found:
  echo   %DB%
  pause
  exit /b 3
)

"%PY%" "%SLICE%" ^
  --db "%DB%" ^
  --out "%OUTROOT%\evidence_slice" ^
  --depth 5 ^
  --max-nodes 25000 ^
  --max-roots-per-term 35 ^
  --path-id 52635 ^
  --path-id 50300 ^
  --path-id 57805 ^
  --path-id 55855 ^
  --path-id 24878 ^
  --path-id 15344 ^
  --path-id 54514 ^
  --path-id 50046 ^
  --path-id 9969 ^
  --term "GPSTrackerSystem" ^
  --term "GpsLocatorVisualsHookup" ^
  --term "GPSLocator" ^
  --term "PlayerMiniMap" ^
  --term "ScreenMask" ^
  --term "ScreenBounds" ^
  --term "MapRotatorGroup" ^
  --term "MapRoot" ^
  --term "PlayerArrow" ^
  --term "SurfaceMap" ^
  --term "ScreenStatic" ^
  --term "VitalsBackingCircle" ^
  --term "VitalsRenderTexture" ^
  --term "PlayerVitalsUiWorldSpace" ^
  --term "HudCamera" ^
  --term "VitalsGuiManager" ^
  --term "VitalsGui" ^
  --term "RenderVitalsGui" ^
  --term "ShapesDiscSync" ^
  --term "ScreenSpaceCanvas" ^
  --term "ToggleableHUD" ^
  --term "PlayerVitalUiRenderTextureGroup" ^
  --term "MessageList" ^
  --term "WorldScreenSpaceElements" ^
  --term "MainCameraFP"

if errorlevel 1 (
  echo.
  echo ERROR: targeted SQLite slice failed.
  pause
  exit /b 10
)

echo.
echo SQLITE SLICE COMPLETE.
echo Expected upload:
echo   %OUTROOT%\evidence_slice.zip
echo.

echo.
pause
