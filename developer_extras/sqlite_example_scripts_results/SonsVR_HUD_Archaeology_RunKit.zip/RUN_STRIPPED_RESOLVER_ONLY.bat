@echo off
setlocal EnableExtensions
title SonsVR - HUD Archaeology

set "PY=C:\Program Files\Python310\python.exe"
if not exist "%PY%" set "PY=python"

set "GAME=D:\SteamLibrary\steamapps\common\Sons Of The Forest"
set "DB=D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"

set "SLICE=%~dp0unity_dependency_extractor_kit\slice_unity_dependency_db.py"
set "RESOLVER=%~dp0unity_dependency_monobehavior_resolver_kit\resolve_stripped_monobehaviours.py"

for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%I"
set "OUTROOT=%~dp0hud_archaeology_output\%STAMP%"
mkdir "%OUTROOT%" >nul 2>nul

echo.
echo ============================================================
echo  SonsVR STRIPPED MONOBEHAVIOUR RESOLVER
echo ============================================================
echo.
echo This is mostly a confirmation rerun: the previous pass already
echo resolved the important live PlayerUI classes.
echo.

if not exist "%RESOLVER%" (
  echo ERROR: resolver not found:
  echo   %RESOLVER%
  pause
  exit /b 2
)

"%PY%" "%RESOLVER%" ^
  --game "%GAME%" ^
  --db "%DB%" ^
  --out "%OUTROOT%\stripped_mb_evidence"

if errorlevel 1 (
  echo.
  echo ERROR: resolver failed.
  pause
  exit /b 10
)

powershell -NoProfile -Command ^
  "Compress-Archive -Path '%OUTROOT%\stripped_mb_evidence\*' -DestinationPath '%OUTROOT%\stripped_mb_evidence.zip' -Force"

echo.
echo DONE. Send back:
echo   %OUTROOT%\stripped_mb_evidence.zip
echo.
pause
