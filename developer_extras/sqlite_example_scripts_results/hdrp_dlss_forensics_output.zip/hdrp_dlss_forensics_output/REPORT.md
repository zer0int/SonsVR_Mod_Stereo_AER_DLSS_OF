# SonsVR HDRP / DLSS offline forensics

- DB: `D:\unity_dependency_hunter_out\unity_dependency_index.sqlite`
- Game: `D:\SteamLibrary\steamapps\common\Sons Of The Forest`
- Assemblies: `D:\SteamLibrary\steamapps\common\Sons Of The Forest\MelonLoader\Il2CppAssemblies`

## Counts

### sqlite
- matched_objects: 741
- focus_objects: 741
- outgoing_edges: 1664
- incoming_edges: 1665
- neighbor_objects: 405
- pipeline_candidates: 658

### dll
- dlls_reported: 31
- keyword_hits: 2192

### plain_configs
- plain_config_hits: 730

## Inspect first

1. `dll_callable_surface.txt`
2. `sqlite_pipeline_settings_candidates.csv`
3. `sqlite_focus_objects.csv`
4. `dll_keyword_context.txt`
5. incoming/outgoing edge CSVs

This run is intentionally OFFLINE. Runtime state comes next, after exact type/settings names are known.