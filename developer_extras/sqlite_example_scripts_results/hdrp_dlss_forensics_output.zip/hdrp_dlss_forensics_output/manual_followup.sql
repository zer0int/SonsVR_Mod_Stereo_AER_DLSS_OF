-- Manual follow-up queries for DB Browser for SQLite / sqlite3.exe.
-- Run against D:\unity_dependency_hunter_out\unity_dependency_index.sqlite

.headers on
.mode column

SELECT source_file, serialized_file, path_id, type, name, script_class, hierarchy
FROM objects
WHERE lower(search_blob) LIKE '%dlss%'
   OR lower(search_blob) LIKE '%dynamicresolution%'
   OR lower(search_blob) LIKE '%dynamic resolution%'
   OR lower(search_blob) LIKE '%upscal%'
   OR lower(search_blob) LIKE '%fsr%'
ORDER BY source_file, path_id
LIMIT 1000;

SELECT source_file, serialized_file, path_id, type, name, script_class, hierarchy,
       substr(search_blob,1,4000) AS blob
FROM objects
WHERE lower(search_blob) LIKE '%renderpipeline%'
   OR lower(name) LIKE '%renderpipeline%'
   OR lower(script_class) LIKE '%renderpipeline%'
   OR lower(search_blob) LIKE '%frame settings%'
ORDER BY source_file, path_id
LIMIT 1000;

SELECT source_file, serialized_file, path_id, type, name, script_class, hierarchy,
       substr(search_blob,1,4000) AS blob
FROM objects
WHERE lower(search_blob) LIKE '%mip%bias%'
   OR lower(search_blob) LIKE '%screen%percentage%'
   OR lower(search_blob) LIKE '%resolution%scale%'
   OR lower(search_blob) LIKE '%render%scale%'
ORDER BY source_file, path_id
LIMIT 1000;
