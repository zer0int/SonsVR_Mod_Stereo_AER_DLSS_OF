SonsVR — Native Pancake HUD Contract Probe
==========================================

WHY
---
Stop guessing world-space HUD offsets. This probe asks what the unmodified game
actually authored for the pancake HUD before the VR mod converts anything.

It compares the live level7 objects for:
  PlayerMiniMap / GPSTrackerSystem / Canvas / ScreenMask / ScreenBounds
  GPS-side VitalsBackingCircle
  ScreenSpaceCanvas / ToggleableHUD
  PlayerVitalUiRenderTextureGroup / VitalsRenderTexture
  MessageList / WorldScreenSpaceElements
  PlayerVitalsUiWorldSpace / HudCamera

It also resolves stripped MonoBehaviour script identities and inventories
GPSTrackerSystem/vitals identifiers exposed by Il2CppSons.dll.

RUN
---
Put these three files together anywhere:
  RUN_NATIVE_HUD_CONTRACT.bat
  probe_native_hud_contract.py
  README_NATIVE_HUD_CONTRACT.txt

Double-click RUN_NATIVE_HUD_CONTRACT.bat.

Expected inputs:
  D:\unity_dependency_hunter_out\unity_dependency_index.sqlite
  D:\SteamLibrary\steamapps\common\Sons Of The Forest

Needs UnityPy (same dependency as the earlier archaeology kits).

OUTPUT
------
A folder and ZIP named like:
  native_hud_contract_YYYYMMDD_HHMMSS
  native_hud_contract_YYYYMMDD_HHMMSS.zip

Send the ZIP back.

READ-ONLY GUARANTEE
-------------------
SQLite is opened mode=ro&immutable=1. Unity assets and Il2Cpp assemblies are read
only. Nothing in the game install or dependency DB is modified.
