@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PY=C:\Program Files\Python310\python.exe"
if not exist "%PY%" set "PY=python"
set "GAME=D:\SteamLibrary\steamapps\common\Sons Of The Forest"
set "DB=D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"
echo.
echo ============================================================
echo  SonsVR - NATIVE PANCAKE HUD CONTRACT PROBE
echo ============================================================
echo.
echo This is READ-ONLY. It does not modify the DB or game assets.
echo.
"%PY%" "%~dp0probe_native_hud_contract.py" --game "%GAME%" --db "%DB%"
if errorlevel 1 (
  echo.
  echo Probe failed with errorlevel %errorlevel%.
  pause
  exit /b %errorlevel%
)
echo.
echo DONE. Send the newest native_hud_contract_*.zip back to ChatGPT.
pause
