#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
SonsVR Native Pancake HUD Contract Probe
========================================

Read-only archaeology probe for the *unmodified pancake game's authored HUD layout*.
It is deliberately NOT a VR-placement experiment.

Inputs:
  D:\unity_dependency_hunter_out\unity_dependency_index.sqlite
  D:\SteamLibrary\steamapps\common\Sons Of The Forest

Outputs a small folder + ZIP describing:
  - exact live level7 Canvas / RectTransform state for the native HUD/GPS
  - attached components and stripped MonoBehaviour script identities
  - forward/reverse dependency edges around the HUD objects
  - authored screen-space alignment of GPS aperture vs vitals output
  - GPSTrackerSystem / vitals-camera clues from Il2CppSons.dll strings

The big SQLite DB is opened mode=ro&immutable=1 and is never modified.
Game assets are read only through UnityPy.
"""
from __future__ import annotations

import argparse, csv, datetime as dt, json, os, re, sqlite3, struct, sys, zipfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    import UnityPy
except Exception as exc:
    print("UnityPy is required. Install with:")
    print(f'  "{sys.executable}" -m pip install -U UnityPy')
    raise SystemExit(2) from exc

DEFAULT_GAME = r"D:\SteamLibrary\steamapps\common\Sons Of The Forest"
DEFAULT_DB = r"D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"

LEVEL7_AK = "SonsOfTheForest_Data/level7::level7"
LEVEL7_SRC = "SonsOfTheForest_Data/level7"

# Exact high-information objects. Additional MessageList/WorldScreenSpaceElements matches
# are discovered dynamically by name because their intermediate hierarchy changed across builds.
EXACT_HIERARCHIES = [
    "PlayerStandin/PlayerUI/PlayerMiniMap",
    "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem",
    "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas",
    "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas/ScreenMask",
    "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas/ScreenMask/ScreenBounds",
    "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas/VitalsBackingCircle",
    "PlayerStandin/PlayerUI/ScreenSpaceCanvas",
    "PlayerStandin/PlayerUI/ScreenSpaceCanvas/ToggleableHUD",
    "PlayerStandin/PlayerUI/ScreenSpaceCanvas/ToggleableHUD/PlayerVitalUiRenderTextureGroup",
    "PlayerStandin/PlayerUI/ScreenSpaceCanvas/ToggleableHUD/PlayerVitalUiRenderTextureGroup/MaskVitals",
    "PlayerStandin/PlayerUI/ScreenSpaceCanvas/ToggleableHUD/PlayerVitalUiRenderTextureGroup/MaskVitals/VitalsRenderTexture",
    "PlayerStandin/PlayerUI/PlayerVitalsUiWorldSpace",
    "PlayerStandin/PlayerUI/PlayerVitalsUiWorldSpace/HudCamera",
]

DYNAMIC_NAMES = [
    "MessageList",
    "WorldScreenSpaceElements",
    "ToggleableHUD",
    "PlayerVitalsUiWorldSpace",
    "HudCamera",
    "VitalsRenderTexture",
    "ScreenMask",
    "ScreenBounds",
    "VitalsBackingCircle",
]

IMPORTANT_COMPONENT_PIDS = {
    52635: "live GPSTrackerSystem",
    54514: "live minimap CanvasScaler candidate",
    50046: "live minimap GraphicRaycaster candidate",
    57805: "live VitalsRenderTexture RawImage",
    55855: "live MessageList layout component",
    51832: "live ScreenSpaceCanvas CanvasScaler candidate",
    49351: "live ScreenSpaceCanvas GraphicRaycaster candidate",
}

SCALAR_KEYS = (
    # GameObject / Component basics
    "m_IsActive", "m_Enabled",
    # RectTransform
    "m_AnchorMin", "m_AnchorMax", "m_AnchoredPosition", "m_SizeDelta", "m_Pivot",
    "m_LocalPosition", "m_LocalRotation", "m_LocalScale",
    # Canvas
    "m_RenderMode", "m_PixelPerfect", "m_OverrideSorting", "m_OverridePixelPerfect",
    "m_SortingLayerID", "m_SortingOrder", "m_TargetDisplay", "m_PlaneDistance",
    # CanvasScaler
    "m_ReferencePixelsPerUnit", "m_ScaleFactor", "m_UiScaleMode", "m_ReferenceResolution",
    "m_ScreenMatchMode", "m_MatchWidthOrHeight", "m_PhysicalUnit", "m_FallbackScreenDPI",
    "m_DefaultSpriteDPI", "m_DynamicPixelsPerUnit", "m_PresetInfoIsWorld",
    # Camera / RT
    "m_Depth", "m_CullingMask", "m_TargetTexture", "m_Orthographic", "m_OrthographicSize",
    "m_NearClipPlane", "m_FarClipPlane", "m_FieldOfView", "m_Rect",
    # Graphic-ish
    "m_Maskable", "m_ShowMaskGraphic", "m_CullTransparentMesh",
)


def open_db(path: Path) -> sqlite3.Connection:
    uri = "file:" + path.resolve().as_posix() + "?mode=ro&immutable=1"
    con = sqlite3.connect(uri, uri=True)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("PRAGMA temp_store=MEMORY")
    con.execute("PRAGMA cache_size=-65536")
    return con


def assets_name(af) -> str:
    for a in ("name", "file_name"):
        x = getattr(af, a, None)
        if x:
            return str(x).replace("\\", "/")
    return "<serialized-file>"


def obj_pid(obj) -> int:
    return int(getattr(obj, "path_id", getattr(obj, "m_PathID", 0)))


def obj_type(obj) -> str:
    t = getattr(obj, "type", None)
    return str(getattr(t, "name", t))


def raw_data(obj) -> bytes:
    fn = getattr(obj, "get_raw_data", None)
    if callable(fn):
        return bytes(fn())
    raise RuntimeError("UnityPy ObjectReader exposes no get_raw_data()")


def parse_obj(obj):
    last = None
    for meth in ("parse_as_dict", "read_typetree"):
        fn = getattr(obj, meth, None)
        if callable(fn):
            try:
                d = fn()
                if isinstance(d, dict):
                    return d, None
            except Exception as exc:
                last = exc
    return None, last or RuntimeError("no typetree parser")


def clean(v: Any, depth=0):
    if depth > 12:
        return "<max-depth>"
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    if isinstance(v, bytes):
        return {"__bytes__": len(v), "hex_prefix": v[:32].hex()}
    if isinstance(v, dict):
        return {str(k): clean(x, depth + 1) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [clean(x, depth + 1) for x in v[:128]]
    d = getattr(v, "__dict__", None)
    if isinstance(d, dict) and d:
        return {"__type__": type(v).__name__, **{str(k): clean(x, depth + 1) for k, x in d.items()}}
    attrs = {}
    for k in ("m_FileID", "m_PathID", "file_id", "path_id", "x", "y", "z", "w"):
        if hasattr(v, k):
            try: attrs[k] = clean(getattr(v, k), depth + 1)
            except Exception: pass
    if attrs:
        attrs["__type__"] = type(v).__name__
        return attrs
    return repr(v)


def vec_xy(v) -> Optional[Tuple[float, float]]:
    if isinstance(v, dict):
        try: return float(v.get("x", 0.0)), float(v.get("y", 0.0))
        except Exception: return None
    for a in (("x", "y"),):
        if all(hasattr(v, k) for k in a):
            try: return float(v.x), float(v.y)
            except Exception: pass
    return None


def clean_external_name(path: str) -> str:
    s = (path or "").replace("\\", "/").strip()
    if s.lower().startswith("archive:/"): s = s[9:]
    if s.lower().startswith("assets/"): s = s[7:]
    return s.rsplit("/", 1)[-1].lower()


def externals(assets_file) -> List[str]:
    out = []
    for x in list(getattr(assets_file, "externals", []) or []):
        p = getattr(x, "path", None)
        if p is None: p = getattr(x, "name", None)
        out.append(str(p or ""))
    return out


def parse_mb_base(raw: bytes, endian="<"):
    if len(raw) < 32:
        raise ValueError(f"raw MonoBehaviour only {len(raw)} bytes")
    return {
        "go_file_id": struct.unpack_from(endian + "i", raw, 0)[0],
        "go_path_id": struct.unpack_from(endian + "q", raw, 4)[0],
        "enabled": raw[12],
        "script_file_id": struct.unpack_from(endian + "i", raw, 16)[0],
        "script_path_id": struct.unpack_from(endian + "q", raw, 20)[0],
    }


def resolve_script(con, current_asset_key: str, script_fid: int, script_pid: int, ext_list: List[str]):
    if not script_pid:
        return [], ""
    if script_fid == 0:
        rows = con.execute(
            "SELECT * FROM objects WHERE asset_key=? AND path_id=? AND type='MonoScript'",
            (current_asset_key, script_pid),
        ).fetchall()
        return rows, "same-file"
    hint = ""
    idx = script_fid - 1
    candidates = []
    if 0 <= idx < len(ext_list):
        hint = clean_external_name(ext_list[idx])
        aks = [r["asset_key"] for r in con.execute("SELECT asset_key FROM aliases WHERE alias=?", (hint,))]
        for ak in aks:
            candidates.extend(con.execute(
                "SELECT * FROM objects WHERE asset_key=? AND path_id=? AND type='MonoScript'", (ak, script_pid)
            ).fetchall())
    if not candidates:
        candidates = con.execute(
            "SELECT * FROM objects WHERE path_id=? AND type='MonoScript'", (script_pid,)
        ).fetchall()
    return candidates, hint


def owner_components(con, asset_key: str, go_pid: int):
    return con.execute("""
        SELECT e.field_path,e.target_asset_key,e.target_path_id,
               o.type,o.name,o.script_decl,o.script_class,o.hierarchy,o.parse_ok,o.parse_error
        FROM edges e
        LEFT JOIN objects o ON o.asset_key=e.target_asset_key AND o.path_id=e.target_path_id
        WHERE e.source_asset_key=? AND e.source_path_id=?
          AND e.field_path LIKE 'm_Component[%].component'
        ORDER BY e.field_path
    """, (asset_key, go_pid)).fetchall()


def exact_go(con, hierarchy: str):
    return con.execute("""
        SELECT * FROM objects
        WHERE asset_key=? AND type='GameObject' AND hierarchy=?
        ORDER BY path_id
    """, (LEVEL7_AK, hierarchy)).fetchall()


def dynamic_gos(con, name: str):
    return con.execute("""
        SELECT * FROM objects
        WHERE asset_key=? AND type='GameObject' AND name=?
          AND hierarchy LIKE 'PlayerStandin/PlayerUI/%'
        ORDER BY hierarchy,path_id
    """, (LEVEL7_AK, name)).fetchall()


def local_edges(con, asset_key: str, pid: int):
    fwd = con.execute("""
        SELECT e.field_path,e.file_id,e.target_path_id,e.target_hint,e.target_asset_key,e.resolution,
               o.type AS target_type,o.name AS target_name,o.script_class AS target_script,o.hierarchy AS target_hierarchy
        FROM edges e LEFT JOIN objects o
          ON o.asset_key=e.target_asset_key AND o.path_id=e.target_path_id
        WHERE e.source_asset_key=? AND e.source_path_id=?
        ORDER BY e.field_path,e.id
    """, (asset_key, pid)).fetchall()
    rev = con.execute("""
        SELECT e.field_path,e.source_asset_key,e.source_path_id,
               o.type AS source_type,o.name AS source_name,o.script_class AS source_script,o.hierarchy AS source_hierarchy
        FROM edges e LEFT JOIN objects o
          ON o.asset_key=e.source_asset_key AND o.path_id=e.source_path_id
        WHERE e.target_asset_key=? AND e.target_path_id=?
        ORDER BY o.hierarchy,e.field_path,e.id
    """, (asset_key, pid)).fetchall()
    return fwd, rev


def find_parseable_class_examples(con, script_class: str, limit=20):
    if not script_class:
        return []
    return con.execute("""
        SELECT asset_key,source_file,serialized_file,path_id,type,name,script_class,hierarchy,parse_ok,parse_error
        FROM objects
        WHERE script_class=? AND parse_ok=1
        ORDER BY CASE WHEN hierarchy LIKE '%GPSTracker%' THEN 0
                      WHEN hierarchy LIKE '%ScreenSpaceCanvas%' THEN 1 ELSE 2 END,
                 source_file,hierarchy,path_id
        LIMIT ?
    """, (script_class, limit)).fetchall()


def load_unity_source(game: Path, source_file: str):
    p = game / Path(source_file.replace("/", os.sep))
    if not p.exists():
        p = game / Path(source_file)
    if not p.exists():
        raise FileNotFoundError(p)
    env = UnityPy.load(str(p))
    by_key, by_pid = {}, {}
    for obj in env.objects:
        ser = assets_name(obj.assets_file)
        pid = obj_pid(obj)
        by_key[(ser.lower(), pid)] = obj
        by_pid.setdefault(pid, []).append(obj)
    return p, env, by_key, by_pid


def find_reader(by_key, by_pid, serialized_file: str, pid: int):
    o = by_key.get((str(serialized_file).lower(), int(pid)))
    if o is not None: return o
    hits = by_pid.get(int(pid), [])
    return hits[0] if len(hits) == 1 else None


def extract_scalars(d: Optional[dict]) -> Dict[str, Any]:
    if not isinstance(d, dict): return {}
    return {k: clean(d[k]) for k in SCALAR_KEYS if k in d}


def ascii_strings(data: bytes, min_len=4) -> List[str]:
    # Generated Il2Cpp assemblies contain useful identifier strings as ASCII.
    out = []
    cur = bytearray()
    for b in data:
        if 32 <= b <= 126:
            cur.append(b)
        else:
            if len(cur) >= min_len:
                out.append(cur.decode("ascii", "ignore"))
            cur.clear()
    if len(cur) >= min_len:
        out.append(cur.decode("ascii", "ignore"))
    return out


def write_csv(path: Path, rows: List[dict], fieldnames: Optional[List[str]]=None):
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    if fieldnames is None:
        keys = []
        seen = set()
        for r in rows:
            for k in r:
                if k not in seen:
                    seen.add(k); keys.append(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--game", default=DEFAULT_GAME)
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    game = Path(a.game)
    db = Path(a.db)
    if not db.exists():
        print("ERROR DB missing:", db); return 2
    level7 = game / "SonsOfTheForest_Data" / "level7"
    if not level7.exists():
        print("ERROR level7 missing:", level7); return 3

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = Path(a.out) if a.out else Path.cwd() / f"native_hud_contract_{stamp}"
    out.mkdir(parents=True, exist_ok=True)

    con = open_db(db)
    print("Loading level7 with UnityPy (read-only)...")
    _, env, by_key, by_pid = load_unity_source(game, LEVEL7_SRC)
    level7_af = None
    for obj in env.objects:
        if assets_name(obj.assets_file).lower() == "level7":
            level7_af = obj.assets_file; break
    ext_list = externals(level7_af) if level7_af is not None else []

    targets = []
    seen = set()
    for h in EXACT_HIERARCHIES:
        for r in exact_go(con, h):
            k = (r["asset_key"], int(r["path_id"]))
            if k not in seen:
                seen.add(k); targets.append(dict(r))
    for n in DYNAMIC_NAMES:
        for r in dynamic_gos(con, n):
            k = (r["asset_key"], int(r["path_id"]))
            if k not in seen:
                seen.add(k); targets.append(dict(r))

    # Also include exact important components even if their owners weren't found by hierarchy.
    important_objs = []
    for pid, label in IMPORTANT_COMPONENT_PIDS.items():
        rows = con.execute("SELECT * FROM objects WHERE asset_key=? AND path_id=?", (LEVEL7_AK, pid)).fetchall()
        for r in rows:
            d = dict(r); d["important_label"] = label; important_objs.append(d)

    object_rows: List[dict] = []
    edge_rows: List[dict] = []
    script_rows: List[dict] = []
    scalar_rows: List[dict] = []
    rect_rows: List[dict] = []
    class_examples: List[dict] = []

    report = []
    report.append("SONSVR NATIVE PANCAKE HUD CONTRACT PROBE")
    report.append("=" * 100)
    report.append("This report describes the game's authored pancake HUD coordinate system BEFORE VR placement hacks.")
    report.append("")

    def inspect_component(comp_row, owner_hierarchy=""):
        comp = dict(comp_row)
        pid = int(comp.get("target_path_id") or comp.get("path_id") or 0)
        ak = comp.get("target_asset_key") or comp.get("asset_key") or LEVEL7_AK
        typ = comp.get("type") or ""
        script_class = comp.get("script_class") or ""
        resolved_class = script_class
        resolution_note = "db"
        obj = None
        if ak == LEVEL7_AK:
            obj = find_reader(by_key, by_pid, "level7", pid)
        d = None; parse_err = None
        if obj is not None:
            d, parse_err = parse_obj(obj)
        if typ == "MonoBehaviour" and not resolved_class and obj is not None:
            try:
                raw = raw_data(obj)
                dec = parse_mb_base(raw, "<")
                cands, hint = resolve_script(con, LEVEL7_AK, int(dec["script_file_id"]), int(dec["script_path_id"]), ext_list)
                if len(cands) == 1:
                    rr = dict(cands[0])
                    resolved_class = rr.get("script_class") or rr.get("name") or rr.get("script_decl") or ""
                    resolution_note = f"raw m_Script via {hint or 'fallback'}"
                else:
                    resolution_note = f"raw m_Script ambiguous={len(cands)} hint={hint}"
            except Exception as exc:
                resolution_note = f"raw m_Script failed: {exc!r}"
        script_rows.append({
            "component_pid": pid, "owner_hierarchy": owner_hierarchy, "type": typ,
            "db_script_class": script_class, "resolved_script_class": resolved_class,
            "resolution": resolution_note,
        })
        if d is not None:
            scal = extract_scalars(d)
            if scal:
                scalar_rows.append({
                    "path_id": pid, "owner_hierarchy": owner_hierarchy, "type": typ,
                    "resolved_script_class": resolved_class,
                    **{k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict,list)) else v for k,v in scal.items()}
                })
            if typ == "RectTransform":
                rect_rows.append({
                    "path_id": pid, "hierarchy": owner_hierarchy,
                    "anchorMin": json.dumps(clean(d.get("m_AnchorMin"))),
                    "anchorMax": json.dumps(clean(d.get("m_AnchorMax"))),
                    "anchoredPosition": json.dumps(clean(d.get("m_AnchoredPosition"))),
                    "sizeDelta": json.dumps(clean(d.get("m_SizeDelta"))),
                    "pivot": json.dumps(clean(d.get("m_Pivot"))),
                    "localPosition": json.dumps(clean(d.get("m_LocalPosition"))),
                    "localScale": json.dumps(clean(d.get("m_LocalScale"))),
                })
        if resolved_class:
            for ex in find_parseable_class_examples(con, resolved_class, 12):
                class_examples.append(dict(ex))
        return resolved_class, d, parse_err

    for go in sorted(targets, key=lambda x: x.get("hierarchy", "")):
        h = go.get("hierarchy", "")
        gpid = int(go["path_id"])
        report.append("-" * 100)
        report.append(h)
        report.append(f"  GameObject pathID={gpid} source={go.get('source_file')} asset={go.get('asset_key')}")
        object_rows.append(dict(go))
        comps = owner_components(con, go["asset_key"], gpid)
        for c in comps:
            cd = dict(c)
            resolved, d, perr = inspect_component(cd, h)
            report.append(f"  component {cd.get('target_path_id')} type={cd.get('type')} script={resolved or cd.get('script_class') or ''}")
            if d is not None:
                for k,v in extract_scalars(d).items():
                    report.append(f"    {k} = {json.dumps(v, ensure_ascii=False)}")
            elif perr is not None:
                report.append(f"    typetree unavailable: {perr!r}")
            fwd, rev = local_edges(con, cd.get("target_asset_key") or go["asset_key"], int(cd.get("target_path_id") or 0))
            for e in fwd:
                er = dict(e); er.update(direction="FORWARD", owner_hierarchy=h, component_pid=cd.get("target_path_id")); edge_rows.append(er)
            for e in rev:
                er = dict(e); er.update(direction="REVERSE", owner_hierarchy=h, component_pid=cd.get("target_path_id")); edge_rows.append(er)

    # Inspect exact important components not already reached.
    reached = {int(r.get("component_pid") or 0) for r in script_rows}
    for comp in important_objs:
        pid = int(comp["path_id"])
        if pid in reached: continue
        owner = comp.get("hierarchy", "")
        inspect_component({**comp, "target_path_id": pid, "target_asset_key": comp["asset_key"]}, owner)

    # Coordinate contract: fixed-anchor elements are meaningful in native screen-space UI.
    # Use 1920x1080 as the reference ONLY for normalized illustrative coordinates. The report
    # also emits raw anchor/offset values so no inference depends on this fallback.
    ref_w, ref_h = 1920.0, 1080.0
    coord = []
    for rr in rect_rows:
        try:
            amin = json.loads(rr["anchorMin"]); amax = json.loads(rr["anchorMax"]); apos = json.loads(rr["anchoredPosition"])
            if isinstance(amin, dict) and isinstance(amax, dict) and isinstance(apos, dict):
                if abs(float(amin.get("x",0))-float(amax.get("x",0))) < 1e-6 and abs(float(amin.get("y",0))-float(amax.get("y",0))) < 1e-6:
                    x = float(amin.get("x",0))*ref_w + float(apos.get("x",0))
                    y = float(amin.get("y",0))*ref_h + float(apos.get("y",0))
                    coord.append({
                        "hierarchy": rr["hierarchy"], "path_id": rr["path_id"],
                        "x_ref1920": x, "y_ref1080": y, "u_ref": x/ref_w, "v_ref": y/ref_h,
                        "note": "illustrative fixed-anchor position assuming 1920x1080 reference canvas",
                    })
        except Exception:
            pass
    write_csv(out / "fixed_anchor_coordinates.csv", coord)

    report.append("")
    report.append("=" * 100)
    report.append("FIXED-ANCHOR COORDINATE CONTRACT (illustrative 1920x1080 reference)")
    report.append("Raw authored anchors above are authoritative; this section only converts fixed anchors to normalized coordinates.")
    for c in coord:
        h = c["hierarchy"]
        if any(k in h for k in ("ScreenMask", "VitalsBackingCircle", "PlayerVitalUiRenderTextureGroup", "MessageList", "WorldScreenSpaceElements")):
            report.append(f"  {h}: x={c['x_ref1920']:.2f} y={c['y_ref1080']:.2f} u={c['u_ref']:.5f} v={c['v_ref']:.5f}")

    # Explicitly highlight the known authored map/vitals anchors if found.
    def coord_by(substr):
        return next((c for c in coord if c["hierarchy"].endswith(substr)), None)
    sm = coord_by("GPSTrackerSystem/Canvas/ScreenMask")
    vb = coord_by("GPSTrackerSystem/Canvas/VitalsBackingCircle")
    vg = coord_by("ToggleableHUD/PlayerVitalUiRenderTextureGroup")
    report.append("")
    report.append("HIGH-INFORMATION ALIGNMENT CHECK")
    for label,c in (("GPS ScreenMask",sm),("GPS VitalsBackingCircle",vb),("main HUD vitals group",vg)):
        if c: report.append(f"  {label}: ({c['x_ref1920']:.2f},{c['y_ref1080']:.2f})")
    if sm and vg:
        report.append(f"  delta ScreenMask -> main vitals group: dx={vg['x_ref1920']-sm['x_ref1920']:.2f}px dy={vg['y_ref1080']-sm['y_ref1080']:.2f}px")
    if vb and vg:
        report.append(f"  delta GPS VitalsBackingCircle -> main vitals group: dx={vg['x_ref1920']-vb['x_ref1920']:.2f}px dy={vg['y_ref1080']-vb['y_ref1080']:.2f}px")

    # Graph clues for core scripts / render texture producer.
    report.append("")
    report.append("=" * 100)
    report.append("DEPENDENCY GRAPH CLUES")
    for term in ("GPSTrackerSystem", "GpsLocatorVisualsHookup", "VitalsRenderTexture", "PlayerVitalsUiWorldSpace", "HudCamera", "MessageList", "WorldScreenSpaceElements"):
        rows = con.execute("""
            SELECT asset_key,source_file,serialized_file,path_id,type,name,script_class,hierarchy,parse_ok,parse_error
            FROM objects WHERE lower(name) LIKE ? OR lower(script_class) LIKE ? OR lower(hierarchy) LIKE ?
            ORDER BY CASE WHEN asset_key=? THEN 0 ELSE 1 END, hierarchy,source_file,path_id LIMIT 80
        """, (f"%{term.lower()}%",f"%{term.lower()}%",f"%{term.lower()}%",LEVEL7_AK)).fetchall()
        report.append(f"\n[{term}] matches={len(rows)}")
        for r in rows[:30]:
            report.append(f"  pid={r['path_id']} type={r['type']} name={r['name']} script={r['script_class']} hierarchy={r['hierarchy']} source={r['source_file']}")

    # Il2Cpp generated wrapper clues. This does not decompile native IL2CPP code; it inventories
    # exposed class/field/method identifiers so we know which gameplay methods manipulate map internals.
    il2cpp = game / "MelonLoader" / "Il2CppAssemblies" / "Il2CppSons.dll"
    if il2cpp.exists():
        data = il2cpp.read_bytes()
        ss = ascii_strings(data, 4)
        pats = re.compile(r"(?i)(GPSTrackerSystem|GpsLocator|UpdateMapRotation|UpdateMapPosition|UpdateGPSLocationsOnMap|_rootCanvas|_mapRoot|_mapRotator|_playerArrow|HudGui|RenderVitalsGui|VitalsGui|HudCamera|VRHud)")
        clues = []
        seen_s = set()
        for s in ss:
            if pats.search(s) and s not in seen_s:
                seen_s.add(s); clues.append(s)
        (out / "il2cpp_identifier_clues.txt").write_text("\n".join(clues), encoding="utf-8")
        report.append("")
        report.append("=" * 100)
        report.append("IL2CPP IDENTIFIER CLUES (generated wrapper strings, not method bodies)")
        for s in clues[:250]: report.append("  " + s)
    else:
        report.append(f"\nIl2CppSons.dll not found at {il2cpp}")

    # De-duplicate class examples.
    ex_seen=set(); ex_out=[]
    for r in class_examples:
        k=(r.get("asset_key"),r.get("path_id"))
        if k in ex_seen: continue
        ex_seen.add(k); ex_out.append(r)

    write_csv(out / "target_objects.csv", object_rows)
    write_csv(out / "resolved_components.csv", script_rows)
    write_csv(out / "scalar_state.csv", scalar_rows)
    write_csv(out / "rect_transforms.csv", rect_rows)
    write_csv(out / "local_dependency_edges.csv", edge_rows)
    write_csv(out / "parseable_class_examples.csv", ex_out)
    (out / "NATIVE_HUD_CONTRACT.txt").write_text("\n".join(report), encoding="utf-8")
    (out / "probe_config.json").write_text(json.dumps({
        "game": str(game), "db": str(db), "level7": str(level7),
        "exact_hierarchies": EXACT_HIERARCHIES, "dynamic_names": DYNAMIC_NAMES,
        "important_component_pids": IMPORTANT_COMPONENT_PIDS,
    }, indent=2), encoding="utf-8")

    zip_path = out.with_suffix(".zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(out.rglob("*")):
            if p.is_file(): z.write(p, p.relative_to(out.parent))

    print("DONE")
    print("Report:", out / "NATIVE_HUD_CONTRACT.txt")
    print("ZIP:   ", zip_path)
    print("Send the ZIP back to ChatGPT.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
