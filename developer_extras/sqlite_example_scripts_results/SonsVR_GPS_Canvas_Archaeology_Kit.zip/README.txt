SONSVR GPS / HUD CANVAS ARCHAEOLOGY KIT
======================================

Run:
  RUN_GPS_CANVAS_ARCHAEOLOGY.bat

Expected local paths:
  D:\SteamLibrary\steamapps\common\Sons Of The Forest
  D:\unity_dependency_hunter_out\unity_dependency_index.sqlite

Why this exists:
The SQLite slice established the object/reference graph very well, but it
intentionally does not retain most scalar Unity serialization fields. The next
question is now "what does the known-working native held GPS Canvas do
differently from the PlayerMiniMap Canvas that the VR mod converts?"

This dumper compares the live overlay, held GPS, inventory GPS prefab, and main
HUD at the level of Canvas/RectTransform/CanvasScaler/Mask/Image settings.

Read-only.

Output:
  gps_canvas_archaeology_output.zip

Send that ZIP back.
