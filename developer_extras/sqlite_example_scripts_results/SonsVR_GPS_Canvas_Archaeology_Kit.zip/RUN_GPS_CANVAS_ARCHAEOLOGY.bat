@echo off
setlocal EnableExtensions
title SonsVR GPS Canvas Archaeology

set "PY=C:\Program Files\Python310\python.exe"
if not exist "%PY%" set "PY=python"

set "GAME=D:\SteamLibrary\steamapps\common\Sons Of The Forest"
set "DB=D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"
set "OUT=%~dp0gps_canvas_archaeology_output"

echo.
echo ============================================================
echo  SonsVR GPS / HUD CANVAS ARCHAEOLOGY
echo ============================================================
echo.
echo Compares:
echo   - live PlayerMiniMap GPS
echo   - native held GPS
echo   - inventory GPS prefab
echo   - main HUD / VitalsRenderTexture
echo.
echo Read-only against game files and SQLite.
echo.

"%PY%" -c "import UnityPy" >nul 2>nul
if errorlevel 1 (
  echo UnityPy not found; installing/upgrading it...
  "%PY%" -m pip install -U UnityPy
  if errorlevel 1 (
    echo ERROR: UnityPy installation failed.
    pause
    exit /b 2
  )
)

if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%"

"%PY%" "%~dp0dump_gps_canvas_archaeology.py" ^
  --game "%GAME%" ^
  --db "%DB%" ^
  --out "%OUT%"

if errorlevel 1 (
  echo.
  echo ERROR: archaeology dump failed.
  pause
  exit /b 10
)

powershell -NoProfile -Command ^
  "Compress-Archive -Path '%OUT%\*' -DestinationPath '%~dp0gps_canvas_archaeology_output.zip' -Force"

echo.
echo ============================================================
echo  DONE
echo ============================================================
echo.
echo Send me:
echo   %~dp0gps_canvas_archaeology_output.zip
echo.
pause
