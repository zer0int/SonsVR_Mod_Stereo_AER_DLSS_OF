#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SonsVR GPS / HUD Canvas Archaeology Dumper
==========================================

Purpose
-------
The dependency SQLite has already told us WHICH objects reference which other
objects. What it intentionally does not retain are most scalar serialized
values: Canvas renderMode/sorting settings, RectTransform anchors/offsets/scale,
CanvasScaler settings, etc.

This script uses the existing SQLite only to locate exact objects, then loads
ONLY these three Unity containers with UnityPy and dumps their full typetrees:

  1) LIVE player overlay GPS in level7
  2) NATIVE HELD GPS in resources.assets
  3) INVENTORY GPS prefab in the gpstrackeritem Addressables bundle

It also dumps the main HUD Canvas / visible VitalsRenderTexture and both known
VitalsBackingCircle objects for comparison.

Read-only. It does not modify the game or the dependency DB.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from pathlib import Path
from typing import Any

try:
    import UnityPy
except Exception as exc:
    print("UnityPy is required. Install with:")
    print(f'  "{sys.executable}" -m pip install -U UnityPy')
    raise SystemExit(2) from exc

DEFAULT_GAME = r"D:\SteamLibrary\steamapps\common\Sons Of The Forest"
DEFAULT_DB = r"D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"

# Exact hierarchy nodes whose *attached components* we want.
TARGETS = [
    # Live overlay GPS
    ("LIVE", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/PlayerMiniMap"),
    ("LIVE", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem"),
    ("LIVE", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas"),
    ("LIVE", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas/ScreenMask"),
    ("LIVE", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas/ScreenMask/MapRotatorGroup"),
    ("LIVE", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas/ScreenMask/MapRotatorGroup/MapRoot"),
    ("LIVE", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas/ScreenMask/MapRotatorGroup/MapRoot/Map"),
    ("LIVE", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas/ScreenMask/ScreenBounds"),
    ("LIVE", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/PlayerMiniMap/GPSTrackerSystem/Canvas/VitalsBackingCircle"),

    # Main HUD / actual visible ring display
    ("HUD", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/ScreenSpaceCanvas"),
    ("HUD", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/ScreenSpaceCanvas/ToggleableHUD/PlayerVitalUiRenderTextureGroup"),
    ("HUD", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/ScreenSpaceCanvas/ToggleableHUD/PlayerVitalUiRenderTextureGroup/MaskVitals"),
    ("HUD", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/ScreenSpaceCanvas/ToggleableHUD/PlayerVitalUiRenderTextureGroup/MaskVitals/VitalsRenderTexture"),
    # Important duplicate name discovered in the SQLite slice:
    ("HUD", "SonsOfTheForest_Data/level7", "PlayerStandin/PlayerUI/ScreenSpaceCanvas/ToggleableHUD/PlayerVitalsUi/ArmourAndVitalsPiv/Vitals/VitalsBackingCircle"),

    # Native, already-world-present held tracker.
    ("HELD", "SonsOfTheForest_Data/resources.assets", "GPSTrackerHeld/GPSTrackerSystem"),
    ("HELD", "SonsOfTheForest_Data/resources.assets", "GPSTrackerHeld/GPSTrackerSystem/Canvas"),
    ("HELD", "SonsOfTheForest_Data/resources.assets", "GPSTrackerHeld/GPSTrackerSystem/Canvas/ScreenMask"),
    ("HELD", "SonsOfTheForest_Data/resources.assets", "GPSTrackerHeld/GPSTrackerSystem/Canvas/ScreenMask/MapRotatorGroup"),
    ("HELD", "SonsOfTheForest_Data/resources.assets", "GPSTrackerHeld/GPSTrackerSystem/Canvas/ScreenMask/ScreenBounds"),

    # Addressables inventory tracker prefab.
    ("INV", None, "GPSTrackerInventory/GPSTrackerSystem"),
    ("INV", None, "GPSTrackerInventory/GPSTrackerSystem/Canvas"),
    ("INV", None, "GPSTrackerInventory/GPSTrackerSystem/Canvas/ScreenMask"),
    ("INV", None, "GPSTrackerInventory/GPSTrackerSystem/Canvas/ScreenMask/MapRotatorGroup"),
    ("INV", None, "GPSTrackerInventory/GPSTrackerSystem/Canvas/ScreenMask/ScreenBounds"),
]

def open_db(path: Path):
    uri = "file:" + path.resolve().as_posix() + "?mode=ro&immutable=1"
    con = sqlite3.connect(uri, uri=True)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    return con

def clean(v: Any, depth=0):
    """JSON-safe compact representation, preserving scalar settings and PPtrs."""
    if depth > 16:
        return "<max-depth>"
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    if isinstance(v, bytes):
        return {"__bytes__": len(v), "hex_prefix": v[:64].hex()}
    if isinstance(v, dict):
        return {str(k): clean(x, depth+1) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        if len(v) > 256:
            return [clean(x, depth+1) for x in v[:256]] + [f"<... {len(v)-256} more ...>"]
        return [clean(x, depth+1) for x in v]
    # UnityPy wrappers / vector structs often expose __dict__.
    d = getattr(v, "__dict__", None)
    if isinstance(d, dict) and d:
        return {"__type__": type(v).__name__, **{str(k): clean(x, depth+1) for k, x in d.items()}}
    # PPtr-like wrappers.
    attrs = {}
    for k in ("m_FileID", "m_PathID", "file_id", "path_id", "x", "y", "z", "w"):
        if hasattr(v, k):
            try:
                attrs[k] = clean(getattr(v, k), depth+1)
            except Exception:
                pass
    if attrs:
        attrs["__type__"] = type(v).__name__
        return attrs
    return repr(v)

def parse_obj(obj):
    last = None
    for meth in ("parse_as_dict", "read_typetree"):
        fn = getattr(obj, meth, None)
        if callable(fn):
            try:
                d = fn()
                if isinstance(d, dict):
                    return d, None
            except Exception as exc:
                last = exc
    return None, last or RuntimeError("no typetree parser")

def assets_file_name(af):
    for a in ("name", "file_name"):
        x = getattr(af, a, None)
        if x:
            return str(x).replace("\\", "/")
    return "<serialized-file>"

def object_pid(obj):
    return int(getattr(obj, "path_id", getattr(obj, "m_PathID", 0)))

def object_type(obj):
    t = getattr(obj, "type", None)
    return str(getattr(t, "name", t))

def find_gpstracker_bundle(con):
    rows = con.execute("""
      SELECT DISTINCT source_file
      FROM objects
      WHERE source_file LIKE '%items_assets_gpstrackeritem%bundle'
      ORDER BY source_file
    """).fetchall()
    if not rows:
        raise RuntimeError("Could not locate gpstrackeritem bundle in dependency DB")
    return str(rows[0]["source_file"])

def owner_components(con, asset_key, go_pid):
    rows = con.execute("""
      SELECT e.target_path_id AS component_pid, o.type, o.script_class, o.parse_ok, o.parse_error
      FROM edges e
      LEFT JOIN objects o
        ON o.asset_key=e.target_asset_key AND o.path_id=e.target_path_id
      WHERE e.source_asset_key=? AND e.source_path_id=?
        AND e.field_path LIKE 'm_Component[%].component'
      ORDER BY e.field_path
    """, (asset_key, go_pid)).fetchall()
    return [dict(r) for r in rows]

def locate_targets(con, inv_source):
    located = []
    for family, source, hierarchy in TARGETS:
        src = inv_source if family == "INV" else source
        rows = con.execute("""
          SELECT *
          FROM objects
          WHERE source_file=? AND hierarchy=? AND type='GameObject'
          ORDER BY path_id
        """, (src, hierarchy)).fetchall()
        if not rows:
            located.append({
                "family": family, "source_file": src, "hierarchy": hierarchy,
                "missing": True, "reason": "GameObject not present in DB slice/index",
            })
            continue
        for go in rows:
            go = dict(go)
            comps = owner_components(con, go["asset_key"], int(go["path_id"]))
            located.append({
                "family": family,
                "source_file": src,
                "serialized_file": go["serialized_file"],
                "asset_key": go["asset_key"],
                "hierarchy": hierarchy,
                "go_path_id": int(go["path_id"]),
                "components": comps,
                "missing": False,
            })
    return located

def load_source(game: Path, source_file: str):
    path = game / Path(source_file.replace("/", "\\"))
    if not path.exists():
        # Pathlib on Windows handles forward slashes too, but retain simple fallback.
        path = game / Path(source_file)
    if not path.exists():
        raise FileNotFoundError(path)
    print("Loading:", path)
    env = UnityPy.load(str(path))
    by_key = {}
    by_pid = {}
    for obj in env.objects:
        ser = assets_file_name(obj.assets_file)
        pid = object_pid(obj)
        by_key[(ser.lower(), pid)] = obj
        by_pid.setdefault(pid, []).append(obj)
    return path, env, by_key, by_pid

def resolve_reader(by_key, by_pid, serialized_file, pid):
    obj = by_key.get((str(serialized_file).lower(), int(pid)))
    if obj is not None:
        return obj
    hits = by_pid.get(int(pid), [])
    if len(hits) == 1:
        return hits[0]
    return None

def dump_one(obj, meta):
    if obj is None:
        return {**meta, "error": "object reader not found in loaded source"}
    d, err = parse_obj(obj)
    out = {
        **meta,
        "unitypy_type": object_type(obj),
        "reader_serialized_file": assets_file_name(obj.assets_file),
        "reader_path_id": object_pid(obj),
    }
    if d is None:
        out["parse_error"] = repr(err)
        try:
            raw = bytes(obj.get_raw_data())
            out["raw_size"] = len(raw)
            out["raw_hex_first128"] = raw[:128].hex()
        except Exception as raw_exc:
            out["raw_error"] = repr(raw_exc)
    else:
        out["typetree"] = clean(d)
    return out

def summarize_scalar_fields(entry):
    d = entry.get("typetree")
    if not isinstance(d, dict):
        return []
    wanted = (
        "m_RenderMode", "m_PixelPerfect", "m_OverrideSorting", "m_OverridePixelPerfect",
        "m_SortingBucketNormalizedSize", "m_AdditionalShaderChannels",
        "m_SortingLayerID", "m_SortingOrder", "m_TargetDisplay",
        "m_ReferencePixelsPerUnit", "m_ScaleFactor", "m_UiScaleMode",
        "m_ReferenceResolution", "m_ScreenMatchMode", "m_MatchWidthOrHeight",
        "m_PhysicalUnit", "m_FallbackScreenDPI", "m_DefaultSpriteDPI",
        "m_DynamicPixelsPerUnit", "m_PresetInfoIsWorld",
        "m_AnchorMin", "m_AnchorMax", "m_AnchoredPosition", "m_SizeDelta",
        "m_Pivot", "m_LocalPosition", "m_LocalRotation", "m_LocalScale",
        "m_Enabled", "m_IsActive", "m_Maskable", "m_ShowMaskGraphic",
        "m_CullTransparentMesh", "m_Rect", "m_Depth", "m_CullingMask",
        "m_TargetTexture", "m_Orthographic", "m_OrthographicSize",
        "m_NearClipPlane", "m_FarClipPlane", "m_FieldOfView",
    )
    rows = []
    for k in wanted:
        if k in d:
            rows.append((k, d[k]))
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--game", default=DEFAULT_GAME)
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--out", default="gps_canvas_archaeology_output")
    args = ap.parse_args()

    game = Path(args.game)
    db = Path(args.db)
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)

    if not game.exists():
        print("ERROR missing game root:", game)
        return 2
    if not db.exists():
        print("ERROR missing DB:", db)
        return 2

    con = open_db(db)
    inv_source = find_gpstracker_bundle(con)
    located = locate_targets(con, inv_source)

    (outdir / "located_targets.json").write_text(
        json.dumps(located, indent=2, default=str), encoding="utf-8"
    )

    sources = sorted({x["source_file"] for x in located if not x.get("missing")})
    loaded = {}
    for src in sources:
        try:
            loaded[src] = load_source(game, src)
        except Exception as exc:
            loaded[src] = {"error": repr(exc)}
            print("ERROR loading", src, ":", repr(exc))

    dumps = []
    for item in located:
        if item.get("missing"):
            dumps.append(item)
            continue
        src = item["source_file"]
        loaded_src = loaded.get(src)
        if not isinstance(loaded_src, tuple):
            dumps.append({**item, "error": str(loaded_src)})
            continue
        _, _, by_key, by_pid = loaded_src
        ser = item["serialized_file"]

        # GameObject itself.
        go_obj = resolve_reader(by_key, by_pid, ser, item["go_path_id"])
        dumps.append(dump_one(go_obj, {
            "family": item["family"], "source_file": src, "hierarchy": item["hierarchy"],
            "role": "GameObject", "db_path_id": item["go_path_id"],
        }))

        # Every attached component, including stripped MonoBehaviours.
        for comp in item["components"]:
            pid = int(comp["component_pid"])
            reader = resolve_reader(by_key, by_pid, ser, pid)
            dumps.append(dump_one(reader, {
                "family": item["family"], "source_file": src, "hierarchy": item["hierarchy"],
                "role": "Component", "db_path_id": pid,
                "db_type": comp.get("type"), "db_script_class": comp.get("script_class"),
                "db_parse_ok": comp.get("parse_ok"), "db_parse_error": comp.get("parse_error"),
            }))

    (outdir / "full_dump.json").write_text(
        json.dumps(dumps, indent=2, default=str), encoding="utf-8"
    )

    lines = []
    lines.append("SONSVR GPS / HUD CANVAS ARCHAEOLOGY")
    lines.append("=" * 100)
    lines.append("")
    lines.append("This compares scalar serialized state that the dependency graph intentionally")
    lines.append("does not retain: Canvas mode, RectTransform geometry, CanvasScaler values, etc.")
    lines.append("")
    for entry in dumps:
        lines.append("-" * 100)
        lines.append(f"[{entry.get('family','?')}] {entry.get('hierarchy','?')}")
        lines.append(
            f"  {entry.get('role','?')} pid={entry.get('db_path_id')} "
            f"type={entry.get('unitypy_type', entry.get('db_type','?'))} "
            f"script={entry.get('db_script_class','') or ''}"
        )
        if entry.get("error"):
            lines.append(f"  ERROR: {entry['error']}")
            continue
        if entry.get("parse_error"):
            lines.append(f"  typetree parse failed: {entry['parse_error']}")
            lines.append(f"  raw_size={entry.get('raw_size','?')}")
            continue
        scalars = summarize_scalar_fields(entry)
        if not scalars:
            lines.append("  (no selected scalar fields)")
        else:
            for k, v in scalars:
                lines.append(f"  {k} = {json.dumps(v, ensure_ascii=False, default=str)}")
    (outdir / "SUMMARY.txt").write_text("\n".join(lines), encoding="utf-8")

    print()
    print("DONE")
    print("  ", outdir / "SUMMARY.txt")
    print("  ", outdir / "full_dump.json")
    print("  ", outdir / "located_targets.json")
    print()
    print("Zip the output directory and send it back.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
