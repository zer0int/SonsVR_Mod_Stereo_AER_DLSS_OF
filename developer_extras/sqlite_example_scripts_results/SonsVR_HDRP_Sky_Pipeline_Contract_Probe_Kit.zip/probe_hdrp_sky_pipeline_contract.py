#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
SonsVR HDRP Sky / Pipeline Contract Probe
=========================================

Read-only archaeology probe to answer four concrete questions for the V113 native-HUD
compositor work:

  1) What HDRP RenderPipelineAsset(s) are referenced by GraphicsSettings / QualitySettings,
     and can we recover the serialized color-buffer / alpha-related settings?
  2) What object(s) implement the persistent sky/cloud/background seen even when ordinary
     world geometry is culled?  HDRP sky/Volume, a camera-following sky dome, or something else?
  3) What are the authored camera clear/culling/far-clip settings for loading/MainCameraFP
     candidates and their HDAdditionalCameraData / Volume relationships?
  4) If there is actual sky/cloud GameObject geometry, what Unity layer is it on (especially
     whether it is layer 5, which the known loading camera renders)?

The dependency DB is opened read-only + immutable. Game files are loaded read-only with UnityPy.
Nothing is modified.
"""
from __future__ import annotations

import argparse, csv, datetime as dt, json, os, re, sqlite3, zipfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    import UnityPy
except Exception as exc:
    print("UnityPy is required. Install with:")
    print('  python -m pip install -U UnityPy')
    raise SystemExit(2) from exc

DEFAULT_GAME = r"D:\SteamLibrary\steamapps\common\Sons Of The Forest"
DEFAULT_DB = r"D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"

SKY_TERMS = [
    "sky", "cloud", "atmospher", "weather", "horizon",
    "visualenvironment", "physicallybasedsky", "hdrisky", "gradientsky",
    "volumetriccloud", "cloudlayer", "background", "skybox", "custompass", "fullscreen", "celestial"
]
PIPELINE_TERMS = [
    "hdrenderpipeline", "renderpipeline", "hdadditionalcameradata",
    "graphicssettings", "qualitysettings"
]
CAMERA_TERMS = [
    "maincamerafp", "loading", "sonsmainloading", "blankscene", "hudcamera"
]
VOLUME_TERMS = [
    "visualenvironment", "volumeprofile", "volumetriccloud", "physicallybasedsky",
    "hdrisky", "gradientsky", "cloudlayer", "fog"
]

# Scalar/field names that matter for this exact diagnosis. Recursive matching is substring-based.
INTERESTING_FIELD_PATTERNS = [
    r"color.*buffer.*format", r"alpha", r"render.*pipeline", r"custom.*render.*pipeline",
    r"clear.*color", r"background", r"culling.*mask", r"volume.*layer.*mask",
    r"probe.*layer.*mask", r"far.*clip", r"near.*clip", r"camera.*type",
    r"sky", r"cloud", r"atmospher", r"visual.*environment", r"volume.*profile",
    r"is.*global", r"priority", r"weight", r"layer", r"rendering.*path",
]
INTERESTING_RE = re.compile("|".join(f"(?:{p})" for p in INTERESTING_FIELD_PATTERNS), re.I)


def open_db(path: Path) -> sqlite3.Connection:
    uri = "file:" + path.resolve().as_posix() + "?mode=ro&immutable=1"
    con = sqlite3.connect(uri, uri=True)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("PRAGMA temp_store=MEMORY")
    con.execute("PRAGMA cache_size=-65536")
    return con


def columns(con: sqlite3.Connection, table: str) -> List[str]:
    return [str(r[1]) for r in con.execute(f"PRAGMA table_info({table})")]


def clean(v: Any, depth: int = 0):
    if depth > 10:
        return "<max-depth>"
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    if isinstance(v, bytes):
        return {"__bytes__": len(v), "hex_prefix": v[:48].hex()}
    if isinstance(v, dict):
        return {str(k): clean(x, depth + 1) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [clean(x, depth + 1) for x in v[:256]]
    d = getattr(v, "__dict__", None)
    if isinstance(d, dict) and d:
        return {"__type__": type(v).__name__, **{str(k): clean(x, depth + 1) for k, x in d.items()}}
    attrs = {}
    for k in ("m_FileID", "m_PathID", "file_id", "path_id", "x", "y", "z", "w"):
        if hasattr(v, k):
            try:
                attrs[k] = clean(getattr(v, k), depth + 1)
            except Exception:
                pass
    if attrs:
        attrs["__type__"] = type(v).__name__
        return attrs
    return repr(v)


def flatten_interesting(v: Any, path: str = "", out: Optional[List[dict]] = None, depth: int = 0) -> List[dict]:
    if out is None:
        out = []
    if depth > 16:
        return out
    if isinstance(v, dict):
        for k, x in v.items():
            p = f"{path}.{k}" if path else str(k)
            if INTERESTING_RE.search(str(k)) or INTERESTING_RE.search(p):
                if x is None or isinstance(x, (str, int, float, bool)):
                    out.append({"field_path": p, "value": x})
                elif isinstance(x, (dict, list, tuple)):
                    # Keep a compact value too, then recurse for precise leaves.
                    try:
                        s = json.dumps(clean(x), ensure_ascii=False)
                        if len(s) <= 1200:
                            out.append({"field_path": p, "value": s})
                    except Exception:
                        pass
            flatten_interesting(x, p, out, depth + 1)
    elif isinstance(v, (list, tuple)):
        for i, x in enumerate(v[:512]):
            flatten_interesting(x, f"{path}[{i}]", out, depth + 1)
    return out


def write_csv(path: Path, rows: List[dict]):
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys, seen = [], set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k); keys.append(k)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)


def table_schema_report(con: sqlite3.Connection) -> str:
    lines = []
    for t in ("objects", "edges", "aliases"):
        try:
            rows = con.execute(f"PRAGMA table_info({t})").fetchall()
        except Exception as e:
            lines.append(f"[{t}] ERROR {e}")
            continue
        lines.append(f"[{t}]")
        for r in rows:
            lines.append(f"  {r[1]} {r[2]}")
    return "\n".join(lines)


def build_term_where(obj_cols: List[str], terms: List[str], extra_cols: Optional[List[str]] = None):
    candidate_cols = [c for c in ("name", "script_class", "script_decl", "hierarchy", "source_file", "serialized_file", "asset_key", "type") if c in obj_cols]
    if extra_cols:
        candidate_cols += [c for c in extra_cols if c in obj_cols and c not in candidate_cols]
    clauses, params = [], []
    for term in terms:
        sub = []
        for c in candidate_cols:
            sub.append(f"lower(COALESCE({c},'')) LIKE ?")
            params.append(f"%{term.lower()}%")
        clauses.append("(" + " OR ".join(sub) + ")")
    return "(" + " OR ".join(clauses) + ")", params


def query_objects(con, obj_cols: List[str], terms: List[str], limit: int = 2000) -> List[dict]:
    where, params = build_term_where(obj_cols, terms)
    order = []
    for c in ("source_file", "hierarchy", "type", "name", "path_id"):
        if c in obj_cols:
            order.append(c)
    sql = f"SELECT * FROM objects WHERE {where}"
    if order:
        sql += " ORDER BY " + ",".join(order)
    sql += " LIMIT ?"
    return [dict(r) for r in con.execute(sql, (*params, limit)).fetchall()]


def query_type_objects(con, obj_cols: List[str], types: Iterable[str], limit: int = 1000) -> List[dict]:
    if "type" not in obj_cols:
        return []
    ts = list(types)
    ph = ",".join("?" for _ in ts)
    sql = f"SELECT * FROM objects WHERE type IN ({ph}) ORDER BY source_file,hierarchy,path_id LIMIT ?"
    return [dict(r) for r in con.execute(sql, (*ts, limit)).fetchall()]


def edge_rows_for(con, obj_rows: List[dict], both: bool = True, per_object_limit: int = 250) -> List[dict]:
    edge_cols = columns(con, "edges")
    req = {"source_asset_key", "source_path_id", "target_asset_key", "target_path_id"}
    if not req.issubset(set(edge_cols)):
        return []
    out, seen = [], set()
    for r in obj_rows:
        ak = r.get("asset_key"); pid = r.get("path_id")
        if ak is None or pid is None:
            continue
        qs = [
            ("FORWARD", "SELECT * FROM edges WHERE source_asset_key=? AND source_path_id=? LIMIT ?", (ak, int(pid), per_object_limit)),
        ]
        if both:
            qs.append(("REVERSE", "SELECT * FROM edges WHERE target_asset_key=? AND target_path_id=? LIMIT ?", (ak, int(pid), per_object_limit)))
        for direction, sql, params in qs:
            for e in con.execute(sql, params).fetchall():
                d = dict(e)
                key = (direction, tuple(d.get(c) for c in edge_cols))
                if key in seen:
                    continue
                seen.add(key)
                d["direction"] = direction
                d["seed_asset_key"] = ak
                d["seed_path_id"] = pid
                d["seed_type"] = r.get("type", "")
                d["seed_name"] = r.get("name", "")
                d["seed_script_class"] = r.get("script_class", "")
                d["seed_hierarchy"] = r.get("hierarchy", "")
                out.append(d)
    return out


def pipeline_reference_edges(con, obj_cols: List[str]) -> List[dict]:
    # Rather than guessing the exact serialized field name, find settings objects and then keep
    # pointer fields whose field_path mentions pipeline/render/quality/graphics.
    settings = query_type_objects(con, obj_cols, ["GraphicsSettings", "QualitySettings"], 200)
    term_settings = query_objects(con, obj_cols, ["graphicssettings", "qualitysettings"], 500)
    seeds = {(r.get("asset_key"), r.get("path_id")): r for r in settings + term_settings}
    out = []
    for r in seeds.values():
        ak, pid = r.get("asset_key"), r.get("path_id")
        if ak is None or pid is None:
            continue
        for e in con.execute("SELECT * FROM edges WHERE source_asset_key=? AND source_path_id=?", (ak, int(pid))).fetchall():
            d = dict(e)
            fp = str(d.get("field_path", ""))
            if re.search(r"pipeline|render|quality|graphics", fp, re.I):
                d.update(seed_type=r.get("type"), seed_name=r.get("name"), seed_hierarchy=r.get("hierarchy"), seed_source_file=r.get("source_file"))
                out.append(d)
    return out


def target_objects_from_edges(con, edges: List[dict]) -> List[dict]:
    out, seen = [], set()
    for e in edges:
        ak, pid = e.get("target_asset_key"), e.get("target_path_id")
        if ak is None or pid is None:
            continue
        k = (ak, int(pid))
        if k in seen:
            continue
        seen.add(k)
        rows = con.execute("SELECT * FROM objects WHERE asset_key=? AND path_id=?", k).fetchall()
        out.extend(dict(r) for r in rows)
    return out


def owner_gameobjects_from_edges(con, candidate_rows: List[dict]) -> List[dict]:
    # Components point from their GameObject via m_Component[n].component. Reverse those links.
    out, seen = [], set()
    for r in candidate_rows:
        ak, pid = r.get("asset_key"), r.get("path_id")
        if ak is None or pid is None:
            continue
        rows = con.execute("""
            SELECT e.*, o.*
            FROM edges e
            JOIN objects o ON o.asset_key=e.source_asset_key AND o.path_id=e.source_path_id
            WHERE e.target_asset_key=? AND e.target_path_id=?
              AND e.field_path LIKE 'm_Component[%].component'
              AND o.type='GameObject'
        """, (ak, int(pid))).fetchall()
        for rr in rows:
            d = dict(rr)
            k = (d.get("asset_key"), d.get("path_id"))
            if k in seen:
                continue
            seen.add(k); out.append(d)
    return out


def assets_name(af) -> str:
    for a in ("name", "file_name"):
        x = getattr(af, a, None)
        if x:
            return str(x).replace("\\", "/")
    return "<serialized-file>"


def obj_pid(obj) -> int:
    return int(getattr(obj, "path_id", getattr(obj, "m_PathID", 0)))


def parse_obj(obj):
    last = None
    for meth in ("parse_as_dict", "read_typetree"):
        fn = getattr(obj, meth, None)
        if callable(fn):
            try:
                d = fn()
                if isinstance(d, dict):
                    return d, None
            except Exception as exc:
                last = exc
    return None, last or RuntimeError("no typetree parser")


def load_source(game: Path, source_file: str, cache: dict):
    sf = str(source_file or "").replace("\\", "/")
    if not sf:
        return None
    if sf in cache:
        return cache[sf]
    p = game / Path(sf.replace("/", os.sep))
    if not p.exists():
        cache[sf] = None
        return None
    try:
        env = UnityPy.load(str(p))
        by_key, by_pid = {}, {}
        for obj in env.objects:
            ser = assets_name(obj.assets_file)
            pid = obj_pid(obj)
            by_key[(ser.lower(), pid)] = obj
            by_pid.setdefault(pid, []).append(obj)
        cache[sf] = (str(p), env, by_key, by_pid)
    except Exception as exc:
        cache[sf] = (str(p), None, {}, {}, repr(exc))
    return cache[sf]


def find_reader(loaded, serialized_file: str, pid: int):
    if not loaded or len(loaded) < 4:
        return None
    by_key, by_pid = loaded[2], loaded[3]
    o = by_key.get((str(serialized_file or "").lower(), int(pid)))
    if o is not None:
        return o
    hits = by_pid.get(int(pid), [])
    return hits[0] if len(hits) == 1 else None


def parse_candidates(game: Path, rows: List[dict], outdir: Path, max_objects: int = 300):
    cache = {}
    scalar_rows = []
    parsed_index = []
    parsed_dir = outdir / "parsed_typetrees"
    parsed_dir.mkdir(exist_ok=True)
    seen = set()
    count = 0
    for r in rows:
        if count >= max_objects:
            break
        sf, ser, pid = r.get("source_file"), r.get("serialized_file"), r.get("path_id")
        if not sf or pid is None:
            continue
        k = (sf, ser, int(pid))
        if k in seen:
            continue
        seen.add(k)
        loaded = load_source(game, sf, cache)
        obj = find_reader(loaded, ser, int(pid))
        if obj is None:
            continue
        d, err = parse_obj(obj)
        base = {
            "asset_key": r.get("asset_key"), "source_file": sf, "serialized_file": ser,
            "path_id": pid, "type": r.get("type"), "name": r.get("name"),
            "script_class": r.get("script_class"), "hierarchy": r.get("hierarchy"),
        }
        if d is None:
            parsed_index.append({**base, "parse_ok": 0, "parse_error": repr(err)})
            continue
        count += 1
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{count:03d}_{r.get('type','')}_{r.get('name','')}_{pid}")[:150]
        fp = parsed_dir / f"{safe}.json"
        fp.write_text(json.dumps(clean(d), indent=2, ensure_ascii=False), encoding="utf-8")
        parsed_index.append({**base, "parse_ok": 1, "json_file": str(fp.relative_to(outdir))})
        for item in flatten_interesting(d):
            scalar_rows.append({**base, **item})
    return parsed_index, scalar_rows


def dedup_rows(rows: List[dict]) -> List[dict]:
    out, seen = [], set()
    for r in rows:
        k = (r.get("asset_key"), r.get("path_id"), r.get("type"), r.get("hierarchy"), r.get("name"), r.get("script_class"))
        if k in seen:
            continue
        seen.add(k); out.append(r)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--game", default=DEFAULT_GAME)
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    game = Path(a.game)
    db = Path(a.db)
    if not db.exists():
        print("ERROR DB missing:", db); return 2
    if not game.exists():
        print("ERROR game folder missing:", game); return 3

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = Path(a.out) if a.out else Path.cwd() / f"hdrp_sky_pipeline_contract_{stamp}"
    out.mkdir(parents=True, exist_ok=True)

    con = open_db(db)
    obj_cols = columns(con, "objects")
    (out / "DB_SCHEMA.txt").write_text(table_schema_report(con), encoding="utf-8")

    # 1) Pipeline / Graphics / Quality settings and their exact pointer edges.
    settings_rows = query_type_objects(con, obj_cols, ["GraphicsSettings", "QualitySettings", "RenderSettings"], 1500)
    pipeline_hits = query_objects(con, obj_cols, PIPELINE_TERMS, 3000)
    pipe_edges = pipeline_reference_edges(con, obj_cols)
    pipe_targets = target_objects_from_edges(con, pipe_edges)
    pipeline_all = dedup_rows(settings_rows + pipeline_hits + pipe_targets)

    # 2) Sky/cloud/background candidates and their graph neighborhoods.
    sky_hits = query_objects(con, obj_cols, SKY_TERMS, 5000)
    volume_hits = query_objects(con, obj_cols, VOLUME_TERMS, 3500)
    sky_all = dedup_rows(sky_hits + volume_hits)
    sky_edges = edge_rows_for(con, sky_all, both=True, per_object_limit=120)

    # 3) Camera candidates. Standard Camera objects are also included if their hierarchy/source
    # contains relevant words. HDAdditionalCameraData objects are found via pipeline term search.
    camera_hits = query_objects(con, obj_cols, CAMERA_TERMS, 2500)
    hd_cam_hits = [r for r in pipeline_hits if re.search(r"HDAdditionalCameraData", str(r.get("script_class") or r.get("name") or ""), re.I)]
    camera_all = dedup_rows(camera_hits + hd_cam_hits)
    camera_edges = edge_rows_for(con, camera_all, both=True, per_object_limit=160)

    # 4) Find owner GameObjects for sky/cloud components; parsing these gives m_Layer if they are
    # real geometry/components. Also include sky GameObjects already matched directly.
    sky_owner_gos = owner_gameobjects_from_edges(con, sky_all)
    sky_gameobjects = [r for r in sky_all if r.get("type") == "GameObject"]
    sky_geometry_owners = dedup_rows(sky_owner_gos + sky_gameobjects)

    # Parse a focused union. Typetrees may be stripped for some MonoBehaviours; that's fine: the DB
    # rows/edges still tell us identities/dependencies, and parse failures are recorded explicitly.
    parse_union = dedup_rows(pipeline_all + sky_all + camera_all + sky_geometry_owners)
    # Avoid dumping enormous pixel/mesh/shader payloads merely because an asset filename contains
    # "sky" or "cloud". Their dependency rows are still preserved in the CSVs.
    heavy_types = {"Texture2D", "Texture3D", "Cubemap", "Mesh", "Shader", "ComputeShader", "AudioClip", "VideoClip"}
    parse_union = [r for r in parse_union if str(r.get("type") or "") not in heavy_types]
    parsed_index, interesting_fields = parse_candidates(game, parse_union, out, max_objects=350)

    # Save raw tables.
    write_csv(out / "pipeline_settings_and_assets.csv", pipeline_all)
    write_csv(out / "pipeline_reference_edges.csv", pipe_edges)
    write_csv(out / "sky_cloud_background_candidates.csv", sky_all)
    write_csv(out / "sky_cloud_dependency_edges.csv", sky_edges)
    write_csv(out / "camera_candidates.csv", camera_all)
    write_csv(out / "camera_dependency_edges.csv", camera_edges)
    write_csv(out / "sky_component_owner_gameobjects.csv", sky_geometry_owners)
    write_csv(out / "parsed_object_index.csv", parsed_index)
    write_csv(out / "interesting_serialized_fields.csv", interesting_fields)

    # Small human-readable summary emphasizing exactly what the next ChatGPT instance should inspect.
    lines = []
    lines.append("SONSVR HDRP SKY / PIPELINE CONTRACT PROBE")
    lines.append("=" * 100)
    lines.append("Read-only. Purpose: distinguish HDRP sky/Volume vs real sky-dome geometry and recover active pipeline/alpha clues.")
    lines.append("")
    lines.append(f"objects columns: {', '.join(obj_cols)}")
    lines.append(f"pipeline/settings candidates: {len(pipeline_all)}")
    lines.append(f"pipeline reference edges: {len(pipe_edges)}")
    lines.append(f"sky/cloud/background candidates: {len(sky_all)}")
    lines.append(f"sky/cloud graph edges: {len(sky_edges)}")
    lines.append(f"camera candidates: {len(camera_all)}")
    lines.append(f"sky/component owner GameObjects: {len(sky_geometry_owners)}")
    lines.append(f"parseable candidate objects: {sum(1 for r in parsed_index if r.get('parse_ok') == 1)}")
    lines.append("")

    lines.append("PIPELINE POINTERS FROM GRAPHICS/QUALITY SETTINGS")
    lines.append("-" * 100)
    for e in pipe_edges[:300]:
        lines.append(f"{e.get('seed_type')} {e.get('seed_source_file')} :: {e.get('field_path')} -> {e.get('target_asset_key')}#{e.get('target_path_id')}")
    lines.append("")

    lines.append("INTERESTING SERIALIZED FIELDS (color buffer / alpha / clear / sky / masks / clips / volumes)")
    lines.append("-" * 100)
    for r in interesting_fields[:1200]:
        lines.append(f"{r.get('type')} {r.get('script_class') or r.get('name')} [{r.get('source_file')} {r.get('hierarchy')}] :: {r.get('field_path')} = {r.get('value')}")
    lines.append("")

    lines.append("SKY/CLOUD OWNER GAMEOBJECTS — CHECK m_Layer IN parsed_typetrees / interesting_serialized_fields.csv")
    lines.append("-" * 100)
    for r in sky_geometry_owners[:500]:
        lines.append(f"{r.get('source_file')} :: {r.get('hierarchy')} name={r.get('name')} pid={r.get('path_id')}")
    lines.append("")

    lines.append("HIGH-VALUE SEARCH HINTS FOR REVIEW")
    lines.append("-" * 100)
    lines.append("1. In interesting_serialized_fields.csv search: colorBufferFormat / alpha / m_CustomRenderPipeline")
    lines.append("2. Search: clearColorMode / backgroundColor / volumeLayerMask / probeLayerMask / cullingMask / farClipPlane")
    lines.append("3. Search sky_cloud_background_candidates.csv for: VisualEnvironment, PhysicallyBasedSky, HDRISky, GradientSky, CloudLayer, VolumetricClouds")
    lines.append("4. Check sky_component_owner_gameobjects.csv + parsed JSON for m_Layer. If a cloud/sky dome is geometry, this tells us whether culling can isolate it.")
    lines.append("5. Compare loading/MainCameraFP camera rows/fields. If loading camera renders layer 5 yet sky persists and no sky geometry is layer 5, that strongly points to HDRP sky rather than mesh geometry.")
    lines.append("")
    lines.append("Do not infer an enum name from a numeric HDRP field in this report unless the corresponding generated HDRP assembly/version confirms the mapping.")

    (out / "HDRP_SKY_PIPELINE_CONTRACT.txt").write_text("\n".join(lines), encoding="utf-8")
    (out / "probe_config.json").write_text(json.dumps({
        "game": str(game), "db": str(db), "sky_terms": SKY_TERMS,
        "pipeline_terms": PIPELINE_TERMS, "camera_terms": CAMERA_TERMS,
        "volume_terms": VOLUME_TERMS,
    }, indent=2), encoding="utf-8")

    zip_path = out.with_suffix(".zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(out.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(out.parent))

    print("DONE")
    print("Report:", out / "HDRP_SKY_PIPELINE_CONTRACT.txt")
    print("ZIP:   ", zip_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
