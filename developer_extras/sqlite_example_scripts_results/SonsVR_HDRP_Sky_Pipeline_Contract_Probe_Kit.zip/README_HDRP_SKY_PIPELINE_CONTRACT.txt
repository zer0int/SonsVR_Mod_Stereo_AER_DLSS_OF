SonsVR — HDRP Sky / Pipeline Contract Probe
===========================================

WHY
---
This is the follow-up to the native pancake HUD query. It answers the specific V113
capture-camera questions without guessing game-specific dependencies:

  * Which HDRP RenderPipelineAsset(s) are referenced by GraphicsSettings / QualitySettings?
  * What serialized color-buffer / alpha clues can be recovered?
  * Is the persistent sky/cloud background an HDRP sky/Volume system or actual GameObject geometry?
  * If it is geometry, what layer is it on?
  * What clear/culling/far-clip/Volume-related state is authored for loading/MainCameraFP candidates?

RUN
---
Put these three files together anywhere:
  RUN_HDRP_SKY_PIPELINE_CONTRACT.bat
  probe_hdrp_sky_pipeline_contract.py
  README_HDRP_SKY_PIPELINE_CONTRACT.txt

Double-click RUN_HDRP_SKY_PIPELINE_CONTRACT.bat.

Expected inputs:
  D:\unity_dependency_hunter_out\unity_dependency_index.sqlite
  D:\SteamLibrary\steamapps\common\Sons Of The Forest

Needs UnityPy, same as the previous archaeology kit.

OUTPUT
------
A folder + ZIP named like:
  hdrp_sky_pipeline_contract_YYYYMMDD_HHMMSS
  hdrp_sky_pipeline_contract_YYYYMMDD_HHMMSS.zip

Send the ZIP back.

READ-ONLY GUARANTEE
-------------------
SQLite is opened mode=ro&immutable=1 with PRAGMA query_only=ON. Unity assets are
loaded read-only. Nothing in the game install or dependency DB is modified.
