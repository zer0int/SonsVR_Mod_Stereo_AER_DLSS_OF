#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, re, sqlite3, time, zipfile
from pathlib import Path

DEFAULT_DB = r"D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"
DEFAULT_GAME = r"D:\SteamLibrary\steamapps\common\Sons Of The Forest"

ASSET_TERMS = [
    "DLSS","DeepLearningSuperSampling","DynamicResolution","dynamic resolution","DynamicRes",
    "Upscale","Upscaler","upscale filter","TAAU","FSR","FSR2","FSR3","NVIDIA",
    "HDRenderPipelineAsset","HDRenderPipelineGlobalSettings","RenderPipelineAsset","FrameSettings",
    "HDCamera","RTHandle","RTHandleScale","ScalableBuffer","CameraDepthBufferMipChain",
    "DepthPyramid","DepthMip","MipChain","mip bias","MipBias","screen percentage",
    "render scale","RenderScale","resolution scale","low res","software dynamic","hardware dynamic",
]

DLL_KEYWORDS = [
    "DLSS","Dlss","DeepLearning","DynamicResolution","DynamicRes","Upscale","Upsampler",
    "TAAU","Taau","FSR","Fsr","NVIDIA","RTHandle","rtHandle","ScalableBuffer","MipBias",
    "MipMap","Mipmap","CameraDepth","DepthPyramid","ResolutionScale","ScreenPercentage",
    "FrameSettings","HDCamera","RenderViewport","finalViewport",
]

PRIORITY_DLL_PATTERNS = [
    "Sons.Dlss","Sons.Settings","Sons.SettingsWrappers","Sons.Rendering",
    "RenderPipelines.HighDefinition.Runtime","RenderPipelines.Core.Runtime",
    "UnityEngine.CoreModule","AEG.FSR",
]

def qident(name: str) -> str:
    return '"' + name.replace('"','""') + '"'

def get_tables(con):
    return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}

def get_columns(con, table):
    return [r[1] for r in con.execute(f"PRAGMA table_info({qident(table)})")]

def write_csv(path: Path, rows, fieldnames=None):
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames, seen = [], set()
        for r in rows:
            for k in r.keys():
                if k not in seen:
                    seen.add(k); fieldnames.append(k)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)

def sqlite_asset_scan(db: Path, out: Path, per_term_limit: int):
    print(f"[sqlite] opening read-only: {db}")
    uri = db.resolve().as_uri() + "?mode=ro"
    con = sqlite3.connect(uri, uri=True)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("PRAGMA temp_store=MEMORY")
    if not {"objects","edges"}.issubset(get_tables(con)):
        raise RuntimeError("DB is not a unity_reverse_dependency_hunter database (objects/edges missing)")

    obj_cols = get_columns(con, "objects")
    searchable = [c for c in ("name","script_decl","script_class","hierarchy","search_blob","source_file","serialized_file","type") if c in obj_cols]
    where_expr = " OR ".join([f"LOWER(COALESCE({qident(c)},'')) LIKE ?" for c in searchable])
    select_cols = ", ".join(qident(c) for c in obj_cols)

    by_key, term_counts = {}, []
    for term in ASSET_TERMS:
        pat = "%" + term.lower() + "%"
        sql = f"SELECT {select_cols} FROM objects WHERE {where_expr} LIMIT ?"
        params = [pat]*len(searchable) + [per_term_limit]
        rows = con.execute(sql, params).fetchall()
        print(f"[sqlite] {term!r}: {len(rows)}")
        term_counts.append({"term":term,"matches_returned":len(rows)})
        for row in rows:
            d = dict(row); key = (d.get("asset_key"), d.get("path_id"))
            if key not in by_key:
                d["matched_terms"] = set(); by_key[key] = d
            by_key[key]["matched_terms"].add(term)

    matches=[]
    for d in by_key.values():
        d=dict(d); d["matched_terms"]="; ".join(sorted(d["matched_terms"], key=str.lower)); matches.append(d)
    matches.sort(key=lambda d:(d.get("source_file",""),str(d.get("path_id",""))))
    write_csv(out/"sqlite_matched_objects.csv", matches)
    write_csv(out/"sqlite_term_counts.csv", term_counts)

    rx = re.compile(r"dlss|dynamic.?res|upscal|renderpipeline|framesettings|rthandle|depth.*mip|mip.*bias|scalablebuffer|nvidia|fsr|taau", re.I)
    focus=[]
    for d in matches:
        blob="\n".join(str(d.get(k,"")) for k in ("name","type","script_class","hierarchy","search_blob"))
        if rx.search(blob): focus.append(d)
    write_csv(out/"sqlite_focus_objects.csv", focus)

    match_keys={(d.get("asset_key"),int(d.get("path_id",0))) for d in matches if d.get("asset_key") is not None}
    outgoing, incoming, neighbor_keys = [], [], set()
    kl=list(match_keys)
    for i in range(0,len(kl),350):
        chunk=kl[i:i+350]
        clauses=" OR ".join(["(source_asset_key=? AND source_path_id=?)"]*len(chunk))
        params=[x for pair in chunk for x in pair]
        if clauses:
            for row in con.execute(f"SELECT * FROM edges WHERE {clauses}",params):
                d=dict(row); outgoing.append(d)
                if d.get("target_asset_key"): neighbor_keys.add((d["target_asset_key"],int(d["target_path_id"])))
        clauses=" OR ".join(["(target_asset_key=? AND target_path_id=?)"]*len(chunk))
        if clauses:
            for row in con.execute(f"SELECT * FROM edges WHERE {clauses}",params):
                d=dict(row); incoming.append(d); neighbor_keys.add((d["source_asset_key"],int(d["source_path_id"])))
    write_csv(out/"sqlite_outgoing_edges.csv", outgoing)
    write_csv(out/"sqlite_incoming_edges.csv", incoming)

    neighbors=[]; nl=list(neighbor_keys-match_keys)
    for i in range(0,len(nl),350):
        chunk=nl[i:i+350]
        clauses=" OR ".join(["(asset_key=? AND path_id=?)"]*len(chunk))
        params=[x for pair in chunk for x in pair]
        if clauses:
            for row in con.execute(f"SELECT {select_cols} FROM objects WHERE {clauses}",params): neighbors.append(dict(row))
    write_csv(out/"sqlite_neighbor_objects.csv", neighbors)

    pipeline=[]; seen=set()
    pipeline_rx=re.compile(r"HDRenderPipeline|RenderPipelineAsset|RenderPipelineGlobal|QualitySettings|GraphicsSettings|DynamicResolution|DLSS|FSR|Upscal",re.I)
    for t in ("renderpipeline","qualitysettings","graphicssettings","dynamicresolution","dlss","upscal","fsr"):
        pat="%"+t+"%"; params=[pat]*len(searchable)+[3000]
        sql=f"SELECT {select_cols} FROM objects WHERE {where_expr} LIMIT ?"
        for row in con.execute(sql,params):
            d=dict(row); blob="\n".join(str(d.get(k,"")) for k in searchable); key=(d.get("asset_key"),d.get("path_id"))
            if key not in seen and pipeline_rx.search(blob): seen.add(key); pipeline.append(d)
    write_csv(out/"sqlite_pipeline_settings_candidates.csv", pipeline)
    con.close()
    return {"matched_objects":len(matches),"focus_objects":len(focus),"outgoing_edges":len(outgoing),"incoming_edges":len(incoming),"neighbor_objects":len(neighbors),"pipeline_candidates":len(pipeline)}

def ascii_strings(data: bytes, min_len=4):
    out=[]; start=None
    for i,b in enumerate(data):
        ok=32<=b<=126
        if ok and start is None: start=i
        elif not ok and start is not None:
            if i-start>=min_len: out.append(data[start:i].decode("ascii","ignore"))
            start=None
    if start is not None and len(data)-start>=min_len: out.append(data[start:].decode("ascii","ignore"))
    return out

def find_assemblies_source(game_root: Path, explicit):
    if explicit:
        p=Path(explicit)
        if p.exists(): return p
        raise FileNotFoundError(f"--assemblies path not found: {p}")
    for p in (game_root/"MelonLoader"/"Il2CppAssemblies",game_root/"MelonLoader"/"Il2CppAssemblies.zip",game_root/"Il2CppAssemblies",game_root/"Il2CppAssemblies.zip"):
        if p.exists(): return p
    return None

def iter_dll_blobs(source: Path):
    if source.is_dir():
        for p in source.rglob("*.dll"):
            try: yield p.name,p.read_bytes()
            except Exception: pass
    elif source.is_file() and source.suffix.lower()==".zip":
        with zipfile.ZipFile(source,"r") as z:
            for n in z.namelist():
                if n.lower().endswith(".dll"):
                    try: yield Path(n).name,z.read(n)
                    except Exception: pass
    else: raise ValueError(f"Unsupported assemblies source: {source}")

def score_dll(name):
    low=name.lower(); return sum(10 for p in PRIORITY_DLL_PATTERNS if p.lower() in low)

def dll_scan(source: Path, out: Path):
    print(f"[dll] scanning: {source}")
    rows=[]; context=[]; surface=[]; summaries=[]
    keyword_rx=re.compile("|".join(re.escape(k) for k in DLL_KEYWORDS),re.I)
    method_rx=re.compile(r"NativeMethodInfoPtr_[A-Za-z0-9_`]+")
    field_rx=re.compile(r"NativeFieldInfoPtr_[A-Za-z0-9_`]+")
    bare_rx=re.compile(r"^(?:get|set|Is|Set|Get|Apply|Refresh|Matches|Enable|Disable|Request|Activate|Internal|Update)[A-Za-z0-9_`]+$")
    blobs=list(iter_dll_blobs(source)); blobs.sort(key=lambda x:(-score_dll(x[0]),x[0].lower()))
    for dll,data in blobs:
        strs=ascii_strings(data,4); hits=[(i,s) for i,s in enumerate(strs) if keyword_rx.search(s)]
        if not hits and score_dll(dll)==0: continue
        summaries.append({"dll":dll,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"keyword_hits":len(hits),"priority_score":score_dll(dll)})
        seen=set()
        for idx,s in hits[:3000]:
            key=(dll,s)
            if key in seen: continue
            seen.add(key); rows.append({"dll":dll,"string_index":idx,"value":s})
            lo=max(0,idx-3); hi=min(len(strs),idx+4)
            context.append(f"\n===== {dll} :: hit {idx} :: {s} ====="); context.extend(strs[lo:hi])
        methods=sorted(set(x for s in strs for x in method_rx.findall(s)))
        fields=sorted(set(x for s in strs for x in field_rx.findall(s)))
        bare=sorted(set(s for s in strs if bare_rx.match(s) and keyword_rx.search(s)))
        if methods or fields or bare:
            surface.append(f"\n## {dll}")
            for x in methods:
                if keyword_rx.search(x): surface.append("METHOD "+x)
            for x in fields:
                if keyword_rx.search(x): surface.append("FIELD  "+x)
            for x in bare: surface.append("NAME   "+x)
    write_csv(out/"dll_keyword_hits.csv",rows); write_csv(out/"dll_summary.csv",summaries)
    (out/"dll_keyword_context.txt").write_text("\n".join(context),encoding="utf-8")
    (out/"dll_callable_surface.txt").write_text("\n".join(surface),encoding="utf-8")
    return {"dlls_reported":len(summaries),"keyword_hits":len(rows)}

def source_scan(game_root: Path, out: Path):
    rx=re.compile(r"dlss|dynamic.?res|upscal|fsr|taau|render.?scale|mip.?bias",re.I)
    allowed={".json",".xml",".ini",".cfg",".txt",".yaml",".yml",".toml",".log"}; hits=[]; seen=set()
    for base in (game_root,game_root/"SonsOfTheForest_Data",game_root/"MelonLoader"):
        if not base.exists(): continue
        for p in base.rglob("*"):
            try: parts=p.relative_to(base).parts
            except Exception: parts=()
            if len(parts)>4 or not p.is_file() or p.suffix.lower() not in allowed: continue
            try:
                if p.stat().st_size>8_000_000: continue
                rp=str(p.resolve())
                if rp in seen: continue
                seen.add(rp); txt=p.read_text(encoding="utf-8",errors="ignore")
            except Exception: continue
            for ln,line in enumerate(txt.splitlines(),1):
                if rx.search(line): hits.append({"file":rp,"line":ln,"text":line[:2000]})
    write_csv(out/"plain_config_hits.csv",hits); return {"plain_config_hits":len(hits)}

def write_queries(out: Path):
    sql = """-- Manual follow-up queries for DB Browser for SQLite / sqlite3.exe.\n-- Run against D:\\unity_dependency_hunter_out\\unity_dependency_index.sqlite\n\n.headers on\n.mode column\n\nSELECT source_file, serialized_file, path_id, type, name, script_class, hierarchy\nFROM objects\nWHERE lower(search_blob) LIKE '%dlss%'\n   OR lower(search_blob) LIKE '%dynamicresolution%'\n   OR lower(search_blob) LIKE '%dynamic resolution%'\n   OR lower(search_blob) LIKE '%upscal%'\n   OR lower(search_blob) LIKE '%fsr%'\nORDER BY source_file, path_id\nLIMIT 1000;\n\nSELECT source_file, serialized_file, path_id, type, name, script_class, hierarchy,\n       substr(search_blob,1,4000) AS blob\nFROM objects\nWHERE lower(search_blob) LIKE '%renderpipeline%'\n   OR lower(name) LIKE '%renderpipeline%'\n   OR lower(script_class) LIKE '%renderpipeline%'\n   OR lower(search_blob) LIKE '%frame settings%'\nORDER BY source_file, path_id\nLIMIT 1000;\n\nSELECT source_file, serialized_file, path_id, type, name, script_class, hierarchy,\n       substr(search_blob,1,4000) AS blob\nFROM objects\nWHERE lower(search_blob) LIKE '%mip%bias%'\n   OR lower(search_blob) LIKE '%screen%percentage%'\n   OR lower(search_blob) LIKE '%resolution%scale%'\n   OR lower(search_blob) LIKE '%render%scale%'\nORDER BY source_file, path_id\nLIMIT 1000;\n"""
    (out/"manual_followup.sql").write_text(sql,encoding="utf-8")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--db",default=DEFAULT_DB); ap.add_argument("--game-root",default=DEFAULT_GAME)
    ap.add_argument("--assemblies",default=None,help="Il2CppAssemblies directory OR zip; auto-detected if omitted")
    ap.add_argument("--out",default="hdrp_dlss_forensics_output"); ap.add_argument("--per-term-limit",type=int,default=2500)
    a=ap.parse_args(); db=Path(a.db); game=Path(a.game_root); out=Path(a.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    if not db.exists(): raise SystemExit(f"ERROR: DB not found: {db}")
    report={"started":time.strftime("%Y-%m-%d %H:%M:%S"),"db":str(db),"game_root":str(game),"asset_terms":ASSET_TERMS,"dll_keywords":DLL_KEYWORDS}
    report["sqlite"]=sqlite_asset_scan(db,out,a.per_term_limit)
    asm=find_assemblies_source(game,a.assemblies)
    if asm is None:
        print("[dll] WARNING: generated assemblies not found; SQLite scan still completed."); report["dll"]={"error":"not found"}
    else:
        report["assemblies_source"]=str(asm); report["dll"]=dll_scan(asm,out)
    report["plain_configs"]=source_scan(game,out); write_queries(out)
    (out/"manifest.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    md=["# SonsVR HDRP / DLSS offline forensics","",f"- DB: `{db}`",f"- Game: `{game}`",f"- Assemblies: `{asm}`","","## Counts",""]
    for section in ("sqlite","dll","plain_configs"):
        md.append(f"### {section}")
        for k,v in report.get(section,{}).items(): md.append(f"- {k}: {v}")
        md.append("")
    md += ["## Inspect first","","1. `dll_callable_surface.txt`","2. `sqlite_pipeline_settings_candidates.csv`","3. `sqlite_focus_objects.csv`","4. `dll_keyword_context.txt`","5. incoming/outgoing edge CSVs","", "This run is intentionally OFFLINE. Runtime state comes next, after exact type/settings names are known."]
    (out/"REPORT.md").write_text("\n".join(md),encoding="utf-8")
    zout=out.with_suffix(".zip")
    if zout.exists(): zout.unlink()
    with zipfile.ZipFile(zout,"w",zipfile.ZIP_DEFLATED) as z:
        for p in out.rglob("*"):
            if p.is_file(): z.write(p,p.relative_to(out.parent))
    print(f"\n[done] {out}\n[zip]  {zout}\nPlease send the ZIP back.")

if __name__=="__main__": main()
