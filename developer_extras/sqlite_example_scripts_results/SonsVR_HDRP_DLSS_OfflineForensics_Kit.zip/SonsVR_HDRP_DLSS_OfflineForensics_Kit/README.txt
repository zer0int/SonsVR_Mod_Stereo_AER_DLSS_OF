SONSVR HDRP / DLSS / DEPTH-MAPPING FORENSICS
=============================================

THIS IS THE NEXT STEP, NOT ANOTHER HEADSET TEST.

We need two distinct evidence sources:

1) SQLite / serialized assets
   Answers:
   - Which HDRP pipeline/global settings assets exist?
   - What dynamic-resolution/upscaler/mip-bias values are serialized?
   - What references those settings?

2) Generated Il2Cpp assemblies
   Answers:
   - What game code surface exists for DLSS/FSR/TAAU/dynamic resolution?
   - Which exact methods/fields should a later runtime tracer hook?

The kit scans BOTH. It is read-only and does not launch the game.

WHY THIS MATTERS
----------------
Current runtime evidence has:
  eye color target:         3141 x 3317
  global HDRP depth alloc:  3840 x 4976

V50 currently copies _CameraDepthTexture using direct integer pixel identity.
That assumes the active RTHandle viewport begins at the expected origin and maps
1:1 to the eye target. We have not proved that.

The user's observation that the huge failure region MOVES when the game's
DLSS/superscale setting changes means we should capture every piece of HDRP
resolution state before changing the mapping.

RUN
---
Double-click:
  RUN_HDRP_DLSS_FORENSICS.bat

Defaults:
  DB   D:\unity_dependency_hunter_out\unity_dependency_index.sqlite
  GAME D:\SteamLibrary\steamapps\common\Sons Of The Forest

The script auto-detects common MelonLoader Il2CppAssemblies locations.

If assemblies are somewhere unusual, run manually:

  "C:\Program Files\Python310\python.exe" query_hdrp_dlss_forensics.py ^
    --db "D:\unity_dependency_hunter_out\unity_dependency_index.sqlite" ^
    --game-root "D:\SteamLibrary\steamapps\common\Sons Of The Forest" ^
    --assemblies "C:\path\to\Il2CppAssemblies"

--assemblies can be either a directory OR a zip.

SEND BACK
---------
  hdrp_dlss_forensics_output.zip

LOOK AT FIRST
-------------
  dll_callable_surface.txt
  sqlite_pipeline_settings_candidates.csv
  sqlite_focus_objects.csv
  dll_keyword_context.txt
  sqlite_incoming_edges.csv
  sqlite_outgoing_edges.csv

KNOWN HIGH-VALUE GENERATED CODE SURFACE
---------------------------------------
The current generated assemblies already contain a dedicated Sons.Dlss module
with names such as:
  ApplyDlssSetting
  SetDynamicResolutionOption
  SetDynamicResUpscaleFilter
  GetDynamicResolutionOption
  IsDlssSupported
  IsDlssEnabled / Disabled / Quality / Balanced / Performance / UltraPerformance
  DynamicResolutionSettingReceiver

HDRP/Core expose names such as:
  RTHandles.rtHandleProperties
  DynamicResolutionHandler.GetCurrentScale
  HardwareDynamicResIsEnabled
  SoftwareDynamicResIsEnabled
  RequestsHardwareDynamicResolution
  finalViewport
  runUpscalerFilterOnFullResolution
  SetUpscaleFilter

After the offline output resolves the exact surrounding types/assets, the next
build can be ONE passive runtime tracer, with no rendering modifications.
