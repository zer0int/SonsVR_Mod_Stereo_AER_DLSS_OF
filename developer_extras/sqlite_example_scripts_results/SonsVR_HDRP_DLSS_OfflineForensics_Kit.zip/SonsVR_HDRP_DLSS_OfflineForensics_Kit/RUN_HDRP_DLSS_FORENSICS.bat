@echo off
setlocal
cd /d "%~dp0"
set "PY=C:\Program Files\Python310\python.exe"
set "DB=D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"
set "GAME=D:\SteamLibrary\steamapps\common\Sons Of The Forest"
if not exist "%PY%" set "PY=python"

echo ================================================================
echo SonsVR HDRP / DLSS / Dynamic-Resolution OFFLINE FORENSICS
echo ================================================================
echo DB   : %DB%
echo GAME : %GAME%
echo READ-ONLY. No game launch. No DB mutation.
echo.

"%PY%" "%~dp0query_hdrp_dlss_forensics.py" ^
  --db "%DB%" ^
  --game-root "%GAME%" ^
  --out "%~dp0hdrp_dlss_forensics_output"

if errorlevel 1 (
  echo.
  echo FAILED.
  pause
  exit /b 1
)

echo.
echo DONE. Send back:
echo   %~dp0hdrp_dlss_forensics_output.zip
echo.
pause
