# Runtime capture plan — after the offline query

Do not change V50 mapping yet.

The next build should be passive logging only and should emit CHANGE EVENTS,
not per-frame spam. One gameplay session can then toggle the game's DLSS /
superscale option and record exactly what moves.

Capture at the exact `endCameraRendering` callback for MainCameraFP and both VR
eye cameras:

## Camera-local
- `pixelWidth`, `pixelHeight`
- `scaledPixelWidth`, `scaledPixelHeight`
- `pixelRect`, normalized `rect`
- target texture dimensions / `useDynamicScale` / mip count / dimension
- `Camera.allowDynamicResolution`
- `HDAdditionalCameraData.allowDynamicResolution`
- `HDAdditionalCameraData.allowDeepLearningSuperSampling`
- DLSS custom quality/attributes if present

## RTHandle / Dynamic Resolution
- `RTHandles.rtHandleProperties.currentViewportSize`
- `currentRenderTargetSize`
- `previousViewportSize`
- `previousRenderTargetSize`
- `rtHandleScale`
- `DynamicResolutionHandler.instance.GetCurrentScale()`
- `filter`
- `finalViewport`
- `HardwareDynamicResIsEnabled()`
- `SoftwareDynamicResIsEnabled()`
- `RequestsHardwareDynamicResolution()`
- `runUpscalerFilterOnFullResolution`
- `ScalableBufferManager.widthScaleFactor`
- `ScalableBufferManager.heightScaleFactor`

## Global textures
For each of these when bound:
- `_CameraDepthTexture`
- `_CameraColorTexture`
- `_CameraMotionVectorsTexture`
- `_DepthPyramidTexture`
- `_AfterPostProcessTexture`

Record:
- name
- width / height
- dimension
- mipmap count
- graphics format
- volume depth
- `useDynamicScale` when it is a RenderTexture

## Shader globals
- `_RTHandleScale`
- `_RTHandleScaleHistory`
- `_ScreenSize`
- `_PostProcessScreenSize`
- `_DynamicResolutionScreenSize`
- `_ZBufferParams`
- depth/color texel-size globals when present

## Game's own Sons.Dlss state
After the offline scan resolves exact types, capture/hook:
- `GetDynamicResolutionOption()`
- active DLSS setting
- active DLSS quality setting
- dynamic-resolution option
- upscale filter
- `IsDlssEnabled` / `IsDlssDisabled`
- `IsDynamicResolutionEnabled`
- the setting-change callbacks themselves

## Single-session toggle experiment
1. normal user's setting for ~3 sec
2. DLSS/superscale OFF
3. one quality mode
4. OFF again

The tracer should write a compact timeline showing which resolution / viewport /
filter / mip-bias values change at each toggle.

Only after this do we change V50's depth-atlas coordinate mapping.
