SONSVR STRIPPED MONOBEHAVIOUR RESOLVER
======================================

Why:
The first evidence slice revealed that many live level7 UI MonoBehaviours are
32-byte STRIPPED PREFAB INSTANCE components. The dependency hunter's typetree
parser therefore fails after the base MonoBehaviour header.

That is GOOD news: the base 32-byte header still contains m_Script.

This resolver manually reads that header and resolves ANNOYANCE CLASSNAME(TM).

Run:
    RUN_RESOLVER.bat

It expects:
    D:\SteamLibrary\steamapps\common\Sons Of The Forest
    D:\unity_dependency_hunter_out\unity_dependency_index.sqlite

It specifically resolves, among others:
    52635  live GPSTrackerSystem
    50300  live GPSLocator
    55763  CookingRecipesView
    57805  VitalsRenderTexture
    55855  MessageList

It also sweeps all parse-failed MonoBehaviours under PlayerStandin/PlayerUI
and cooking-ish level7 hierarchies.

Output:
    stripped_mb_evidence\REPORT.txt
    stripped_mb_evidence\stripped_monobehaviours.csv
    stripped_mb_evidence\manifest.json

Zip that folder and send it back.

Nothing is modified.
