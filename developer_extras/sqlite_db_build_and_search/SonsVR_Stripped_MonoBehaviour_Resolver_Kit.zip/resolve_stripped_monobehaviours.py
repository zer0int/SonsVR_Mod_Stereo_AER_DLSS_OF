#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
Sons of the Forest — Stripped MonoBehaviour Resolver

Why this exists
---------------
The dependency DB exposed a very specific Unity prefab-instance annoyance:
many LIVE level7 MonoBehaviours are exactly 32 bytes and fail typetree parsing,
for example:

  52635  PlayerMiniMap/GPSTrackerSystem            expected 308, actual 32
  50300  .../GPSLocator                            expected 156, actual 32
  55763  .../CookingRecipesView                    expected 84,  actual 32
  57805  .../VitalsRenderTexture                   expected 116, actual 32
  55855  .../MessageList                           expected 84,  actual 32

Those are stripped prefab-instance components. The custom serialized fields live
in the prefab asset, but the 32-byte base MonoBehaviour header still contains:

  m_GameObject : PPtr<GameObject>
  m_Enabled    : byte + alignment
  m_Script     : PPtr<MonoScript>
  m_Name       : string

So we can identify ANNOYANCE CLASSNAME(TM) without parsing the custom typetree.

This script:
  1. queries the giant dependency DB read-only to find parse-failed level7
     MonoBehaviours owned by PlayerUI / Cooking-ish objects;
  2. loads ONLY SonsOfTheForest_Data\level7 with UnityPy;
  3. reads only those suspect raw object bytes;
  4. manually decodes the base MonoBehaviour header;
  5. resolves m_Script through Unity external-file aliases back into the DB;
  6. exports a tiny CSV/TXT/JSON packet.

It does not modify game files or the big DB.
"""

from __future__ import annotations
import argparse, csv, json, sqlite3, struct, sys, re
from pathlib import Path
from collections import defaultdict

try:
    import UnityPy
except Exception as exc:
    print("UnityPy is required. Install with: python -m pip install -U UnityPy")
    raise SystemExit(2) from exc

DEFAULT_GAME = r"D:\SteamLibrary\steamapps\common\Sons Of The Forest"
DEFAULT_DB = r"D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"

# Exact suspects we already care about even if hierarchy joins fail.
IMPORTANT_PIDS = {
    52635: "LIVE GPSTrackerSystem stripped component",
    54514: "LIVE minimap Canvas component #2",
    50046: "LIVE minimap Canvas component #3",
    50300: "LIVE GPSLocator stripped component",
    55763: "LIVE CookingRecipesView stripped component",
    57805: "LIVE VitalsRenderTexture stripped component",
    55855: "LIVE MessageList stripped component",
    50189: "earlier PlayerMarker-related suspect",
}

def clean_external_name(path: str) -> str:
    s=(path or "").replace("\\","/").strip()
    if s.lower().startswith("archive:/"): s=s[9:]
    if s.lower().startswith("assets/"): s=s[7:]
    return s.rsplit("/",1)[-1].lower()

def open_db(path: Path):
    uri="file:"+path.resolve().as_posix()+"?mode=ro&immutable=1"
    con=sqlite3.connect(uri,uri=True)
    con.row_factory=sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("PRAGMA cache_size=-32768")
    return con

def raw_data(obj):
    fn=getattr(obj,"get_raw_data",None)
    if callable(fn):
        return bytes(fn())
    # Older/newer UnityPy fallbacks.
    reader=getattr(obj,"reader",None)
    if reader is not None:
        pos=getattr(reader,"Position",None)
        try:
            if hasattr(reader,"read_bytes"):
                return bytes(reader.read_bytes(int(getattr(obj,"byte_size"))))
        finally:
            if pos is not None:
                try: reader.Position=pos
                except Exception: pass
    raise RuntimeError("This UnityPy ObjectReader exposes no raw-data accessor")

def obj_pid(obj):
    return int(getattr(obj,"path_id",getattr(obj,"m_PathID",0)))

def obj_type(obj):
    t=getattr(obj,"type",None)
    return str(getattr(t,"name",t))

def externals(assets_file):
    out=[]
    for x in list(getattr(assets_file,"externals",[]) or []):
        p=getattr(x,"path",None)
        if p is None: p=getattr(x,"name",None)
        out.append(str(p or ""))
    return out

def parse_base(raw: bytes, endian="<"):
    if len(raw)<32:
        raise ValueError(f"MonoBehaviour raw data is only {len(raw)} bytes")
    go_fid=struct.unpack_from(endian+"i",raw,0)[0]
    go_pid=struct.unpack_from(endian+"q",raw,4)[0]
    enabled=raw[12]
    script_fid=struct.unpack_from(endian+"i",raw,16)[0]
    script_pid=struct.unpack_from(endian+"q",raw,20)[0]
    nlen=struct.unpack_from(endian+"I",raw,28)[0]
    name=""
    if 0 <= nlen <= max(0,len(raw)-32):
        try: name=raw[32:32+nlen].decode("utf-8","replace")
        except Exception: name=""
    return {
        "go_file_id":go_fid,"go_path_id":go_pid,"enabled":enabled,
        "script_file_id":script_fid,"script_path_id":script_pid,
        "name_len":nlen,"name":name,
    }

def resolve_script(con, current_asset_key, script_fid, script_pid, ext_list):
    if not script_pid:
        return [], ""

    candidates=[]
    hint=""
    if script_fid==0:
        candidates=con.execute(
            "SELECT * FROM objects WHERE asset_key=? AND path_id=? AND type='MonoScript'",
            (current_asset_key,script_pid)
        ).fetchall()
        return candidates,"same-file"

    idx=script_fid-1
    if 0 <= idx < len(ext_list):
        hint=clean_external_name(ext_list[idx])
        aks=[
            r["asset_key"] for r in con.execute(
                "SELECT asset_key FROM aliases WHERE alias=?",(hint,)
            ).fetchall()
        ]
        for ak in aks:
            candidates.extend(con.execute(
                "SELECT * FROM objects WHERE asset_key=? AND path_id=? AND type='MonoScript'",
                (ak,script_pid)
            ).fetchall())

    if not candidates:
        # Fallback: pathID-only candidates. We label ambiguity rather than guessing.
        candidates=con.execute(
            "SELECT * FROM objects WHERE path_id=? AND type='MonoScript'",
            (script_pid,)
        ).fetchall()

    return candidates,hint

def owner_map(con):
    # Component -> owning GameObject derived from GameObject.m_Component[].
    rows=con.execute("""
      SELECT e.target_path_id AS component_pid,
             go.path_id AS go_pid, go.name AS go_name, go.hierarchy AS hierarchy
      FROM edges e
      JOIN objects go
        ON go.asset_key=e.source_asset_key AND go.path_id=e.source_path_id
      WHERE e.source_asset_key='SonsOfTheForest_Data/level7::level7'
        AND e.target_asset_key='SonsOfTheForest_Data/level7::level7'
        AND e.field_path LIKE 'm_Component[%].component'
        AND go.type='GameObject'
    """).fetchall()
    return {int(r["component_pid"]):dict(r) for r in rows}

def choose_targets(con, owners):
    failed=con.execute("""
      SELECT path_id,parse_error
      FROM objects
      WHERE asset_key='SonsOfTheForest_Data/level7::level7'
        AND type='MonoBehaviour' AND parse_ok=0
    """).fetchall()

    targets={}
    for r in failed:
        pid=int(r["path_id"])
        owner=owners.get(pid,{})
        h=str(owner.get("hierarchy") or "")
        interesting=(
            h.startswith("PlayerStandin/PlayerUI/")
            or "Cooking" in h or "Cook" in h
            or pid in IMPORTANT_PIDS
        )
        if interesting:
            targets[pid]={
                "parse_error":str(r["parse_error"] or ""),
                "owner":owner,
                "reason":IMPORTANT_PIDS.get(pid,"PlayerUI/Cooking parse-failed MonoBehaviour"),
            }
    # Keep important PIDs even if DB neighborhood did not include them.
    for pid,reason in IMPORTANT_PIDS.items():
        targets.setdefault(pid,{
            "parse_error":"",
            "owner":owners.get(pid,{}),
            "reason":reason,
        })
    return targets

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--game",default=DEFAULT_GAME)
    ap.add_argument("--db",default=DEFAULT_DB)
    ap.add_argument("--out",default="")
    a=ap.parse_args()

    game=Path(a.game)
    level7=game/"SonsOfTheForest_Data"/"level7"
    db=Path(a.db)
    if not level7.exists():
        print("ERROR missing:",level7); return 2
    if not db.exists():
        print("ERROR missing:",db); return 2

    out=Path(a.out) if a.out else Path(__file__).resolve().parent/"stripped_mb_evidence"
    out.mkdir(parents=True,exist_ok=True)

    con=open_db(db)
    owners=owner_map(con)
    targets=choose_targets(con,owners)
    wanted=set(targets)

    print(f"Target parse-failed MonoBehaviours: {len(wanted)}")
    print("Loading level7 metadata with UnityPy (raw bytes only for targets)...")
    env=UnityPy.load(str(level7))

    found={}
    for obj in env.objects:
        pid=obj_pid(obj)
        if pid not in wanted or obj_type(obj)!="MonoBehaviour":
            continue
        found[pid]=obj

    rows=[]
    for pid in sorted(wanted):
        info=targets[pid]
        owner=info.get("owner") or {}
        row={
            "component_path_id":pid,
            "reason":info.get("reason",""),
            "owner_go_path_id":int(owner.get("go_pid") or 0),
            "owner_go_name":owner.get("go_name") or "",
            "owner_hierarchy":owner.get("hierarchy") or "",
            "parse_error":info.get("parse_error",""),
            "raw_size":0,
            "decoded_endian":"",
            "go_file_id":"",
            "go_path_id":"",
            "go_matches_db_owner":"",
            "enabled":"",
            "script_file_id":"",
            "script_path_id":"",
            "external_hint":"",
            "resolved_script_count":0,
            "resolved_script_class":"",
            "resolved_script_name":"",
            "resolved_script_asset_key":"",
            "raw_hex_first64":"",
            "error":"",
        }
        obj=found.get(pid)
        if obj is None:
            row["error"]="pathID not found as MonoBehaviour in UnityPy level7"
            rows.append(row); continue

        try:
            raw=raw_data(obj)
            row["raw_size"]=len(raw)
            row["raw_hex_first64"]=raw[:64].hex()

            # Little-endian should be correct for this Windows player. If the
            # decoded GameObject conflicts with the DB owner, try big-endian too.
            dec=parse_base(raw,"<")
            endian="<"
            db_go=int(owner.get("go_pid") or 0)
            if db_go and int(dec["go_path_id"])!=db_go:
                alt=parse_base(raw,">")
                if int(alt["go_path_id"])==db_go:
                    dec=alt; endian=">"
            row["decoded_endian"]="little" if endian=="<" else "big"

            for k in ("go_file_id","go_path_id","enabled","script_file_id","script_path_id"):
                row[k]=dec[k]
            row["go_matches_db_owner"]=(
                "" if not db_go else int(dec["go_path_id"])==db_go
            )

            ext=externals(obj.assets_file)
            scripts,hint=resolve_script(
                con,
                'SonsOfTheForest_Data/level7::level7',
                int(dec["script_file_id"]),int(dec["script_path_id"]),ext
            )
            row["external_hint"]=hint
            row["resolved_script_count"]=len(scripts)

            if len(scripts)==1:
                s=scripts[0]
                row["resolved_script_class"]=str(s["script_decl"] or "")
                row["resolved_script_name"]=str(s["name"] or "")
                row["resolved_script_asset_key"]=str(s["asset_key"] or "")
            elif scripts:
                classes=[]
                for s in scripts[:20]:
                    classes.append(str(s["script_decl"] or s["name"] or s["asset_key"]))
                row["resolved_script_class"]="AMBIGUOUS: "+" | ".join(classes)

        except Exception as exc:
            row["error"]=f"{type(exc).__name__}: {exc}"

        rows.append(row)

    cols=list(rows[0].keys()) if rows else []
    csv_path=out/"stripped_monobehaviours.csv"
    with csv_path.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=cols); w.writeheader(); w.writerows(rows)

    # Human report: important suspects first.
    def rank(r):
        return (0 if int(r["component_path_id"]) in IMPORTANT_PIDS else 1,
                str(r["owner_hierarchy"]),int(r["component_path_id"]))
    lines=[
        "SONS OF THE FOREST — STRIPPED MONOBEHAVIOUR RESOLUTION",
        "="*110,
        "",
    ]
    for r in sorted(rows,key=rank):
        lines.append(f"pathID {r['component_path_id']}  {r['reason']}")
        lines.append(f"  owner: {r['owner_hierarchy'] or r['owner_go_name'] or '<unknown>'}")
        lines.append(f"  raw: {r['raw_size']} bytes; endian={r['decoded_endian']}; ownerMatch={r['go_matches_db_owner']}")
        lines.append(f"  m_Script: fileID={r['script_file_id']} pathID={r['script_path_id']} external={r['external_hint']!r}")
        lines.append(f"  CLASS: {r['resolved_script_class'] or '<UNRESOLVED>'}")
        if r["error"]: lines.append(f"  ERROR: {r['error']}")
        lines.append("")

    (out/"REPORT.txt").write_text("\n".join(lines),encoding="utf-8")
    (out/"manifest.json").write_text(json.dumps({
        "game":str(game),"db":str(db),"level7":str(level7),
        "target_count":len(targets),"found_count":len(found),
        "resolved_unique_count":sum(1 for r in rows if r["resolved_script_count"]==1),
    },indent=2),encoding="utf-8")

    print("\nIMPORTANT RESULTS")
    print("-"*80)
    bypid={int(r["component_path_id"]):r for r in rows}
    for pid,reason in IMPORTANT_PIDS.items():
        r=bypid.get(pid)
        if not r: continue
        print(f"{pid:6d}  {reason}")
        print(f"        owner: {r['owner_hierarchy'] or '<unknown>'}")
        print(f"        CLASS: {r['resolved_script_class'] or '<UNRESOLVED>'}")
        if r["error"]: print(f"        ERROR: {r['error']}")

    print("\nDONE")
    print("Send me this folder zipped, especially REPORT.txt + CSV:")
    print(" ",out)
    return 0

if __name__=="__main__":
    raise SystemExit(main())
