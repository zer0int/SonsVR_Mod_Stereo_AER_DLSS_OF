@echo off
setlocal
title SonsVR - Resolve Stripped MonoBehaviours

set "PY=C:\Program Files\Python310\python.exe"
if not exist "%PY%" set "PY=python"

set "GAME=D:\SteamLibrary\steamapps\common\Sons Of The Forest"
set "DB=D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"

echo.
echo ============================================================
echo  SonsVR Stripped MonoBehaviour Resolver
echo ============================================================
echo.
echo Reads:
echo   %GAME%\SonsOfTheForest_Data\level7
echo   %DB%
echo.
echo Both are read-only. Nothing is modified.
echo.

"%PY%" "%~dp0resolve_stripped_monobehaviours.py" --game "%GAME%" --db "%DB%"

echo.
echo When done, zip the "stripped_mb_evidence" folder and send it to ChatGPT.
echo.
pause
