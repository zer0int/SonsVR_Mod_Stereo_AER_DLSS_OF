#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
Unity Dependency Evidence Slicer

Runs locally against the large SQLite DB produced by the reverse-dependency
hunter. The big DB is opened read-only + immutable; it is never copied or
modified.

Default exact pathIDs from our first pass:
  55763  CookingRecipesView-attached MonoBehaviour candidate
  57805  VitalsRenderTexture-attached MonoBehaviour candidate
  50189  PlayerMarker-related live component candidate

Default terms:
  CookingRecipesView, VitalsRenderTexture, PlayerMarker, PlayerMiniMap,
  GPSLocator, GPSTrackerSystem, GpsLocatorVisualsHookup, HudGui,
  ToggleableHUD, MessageList, CookingCog, CookingPotController

Output is a tiny evidence ZIP containing a reduced SQLite DB plus CSV/TXT.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import sqlite3
import sys
import zipfile
from collections import deque
from pathlib import Path

DEFAULT_DB = r"D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"
DEFAULT_PATH_IDS = [55763, 57805, 50189]
DEFAULT_TERMS = [
    "CookingRecipesView",
    "VitalsRenderTexture",
    "PlayerMarker",
    "PlayerMiniMap",
    "GPSLocator",
    "GPSTrackerSystem",
    "GpsLocatorVisualsHookup",
    "HudGui",
    "ToggleableHUD",
    "MessageList",
    "CookingCog",
    "CookingPotController",
]

OBJECT_COLUMNS = [
    "asset_key","source_file","serialized_file","path_id","type","name",
    "script_decl","script_class","hierarchy","gameobject_asset_key",
    "gameobject_path_id","parent_transform_asset_key",
    "parent_transform_path_id","search_blob","parse_ok","parse_error",
]
EDGE_COLUMNS = [
    "id","source_asset_key","source_path_id","field_path","file_id",
    "target_path_id","target_hint","target_asset_key","resolution",
]
FILE_COLUMNS = [
    "source_file","file_size","file_mtime","status","error",
    "object_count","edge_count",
]

SCHEMA = r"""
PRAGMA journal_mode=OFF;
PRAGMA synchronous=OFF;
CREATE TABLE objects (
    asset_key TEXT NOT NULL,
    source_file TEXT NOT NULL,
    serialized_file TEXT NOT NULL,
    path_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    name TEXT DEFAULT '',
    script_decl TEXT DEFAULT '',
    script_class TEXT DEFAULT '',
    hierarchy TEXT DEFAULT '',
    gameobject_asset_key TEXT DEFAULT '',
    gameobject_path_id INTEGER DEFAULT 0,
    parent_transform_asset_key TEXT DEFAULT '',
    parent_transform_path_id INTEGER DEFAULT 0,
    search_blob TEXT DEFAULT '',
    parse_ok INTEGER DEFAULT 1,
    parse_error TEXT DEFAULT '',
    PRIMARY KEY(asset_key,path_id)
);
CREATE TABLE edges (
    id INTEGER PRIMARY KEY,
    source_asset_key TEXT NOT NULL,
    source_path_id INTEGER NOT NULL,
    field_path TEXT NOT NULL,
    file_id INTEGER NOT NULL,
    target_path_id INTEGER NOT NULL,
    target_hint TEXT DEFAULT '',
    target_asset_key TEXT DEFAULT '',
    resolution TEXT DEFAULT ''
);
CREATE TABLE files (
    source_file TEXT PRIMARY KEY,
    file_size INTEGER NOT NULL,
    file_mtime REAL NOT NULL,
    status TEXT NOT NULL,
    error TEXT,
    object_count INTEGER DEFAULT 0,
    edge_count INTEGER DEFAULT 0
);
CREATE TABLE roots (
    reason TEXT NOT NULL,
    asset_key TEXT NOT NULL,
    path_id INTEGER NOT NULL,
    matched_term TEXT DEFAULT ''
);
CREATE INDEX idx_obj_name ON objects(name);
CREATE INDEX idx_obj_script ON objects(script_class);
CREATE INDEX idx_obj_hierarchy ON objects(hierarchy);
CREATE INDEX idx_edge_src ON edges(source_asset_key,source_path_id);
CREATE INDEX idx_edge_dst ON edges(target_asset_key,target_path_id);
"""

def args():
    p = argparse.ArgumentParser()
    p.add_argument("--db", default=DEFAULT_DB)
    p.add_argument("--out", default="")
    p.add_argument("--depth", type=int, default=4)
    p.add_argument("--max-nodes", type=int, default=12000)
    p.add_argument("--max-roots-per-term", type=int, default=50)
    p.add_argument("--term", action="append", default=[])
    p.add_argument("--path-id", action="append", type=int, default=[])
    return p.parse_args()

def open_big_db(path: Path):
    uri = "file:" + path.resolve().as_posix() + "?mode=ro&immutable=1"
    con = sqlite3.connect(uri, uri=True)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("PRAGMA temp_store=MEMORY")
    con.execute("PRAGMA cache_size=-65536")
    return con

def get_obj(con, k):
    return con.execute(
        "SELECT * FROM objects WHERE asset_key=? AND path_id=?", k
    ).fetchone()

def key(r):
    return (str(r["asset_key"]), int(r["path_id"]))

def search_pid(con, pid):
    return con.execute(
        """SELECT * FROM objects WHERE path_id=?
           ORDER BY CASE WHEN lower(serialized_file)='level7' THEN 0 ELSE 1 END,
                    source_file,serialized_file,type,name""",
        (pid,),
    ).fetchall()

def search_term(con, term, limit):
    q = f"%{term.lower()}%"
    return con.execute(
        """SELECT * FROM objects
           WHERE lower(name) LIKE ?
              OR lower(script_decl) LIKE ?
              OR lower(script_class) LIKE ?
              OR lower(hierarchy) LIKE ?
              OR lower(search_blob) LIKE ?
              OR lower(serialized_file) LIKE ?
              OR lower(source_file) LIKE ?
           ORDER BY
             CASE WHEN lower(name)=lower(?) THEN 0
                  WHEN lower(script_class)=lower(?) THEN 1
                  WHEN lower(name) LIKE ? THEN 2
                  WHEN lower(script_class) LIKE ? THEN 3
                  WHEN lower(hierarchy) LIKE ? THEN 4
                  ELSE 5 END,
             type,name,source_file,path_id
           LIMIT ?""",
        (q,q,q,q,q,q,q,term,term,q,q,q,limit),
    ).fetchall()

def fwd(con, k):
    out=[]
    for r in con.execute(
        "SELECT target_asset_key,target_path_id FROM edges "
        "WHERE source_asset_key=? AND source_path_id=?", k
    ):
        if r["target_asset_key"] and int(r["target_path_id"] or 0):
            out.append((str(r["target_asset_key"]), int(r["target_path_id"])))
    return out

def rev(con, k):
    return [
        (str(r["source_asset_key"]), int(r["source_path_id"]))
        for r in con.execute(
            "SELECT source_asset_key,source_path_id FROM edges "
            "WHERE target_asset_key=? AND target_path_id=?", k
        )
    ]

def local_structure(con, k):
    r = get_obj(con, k)
    if r is None:
        return []
    out=[]

    gak = str(r["gameobject_asset_key"] or "")
    gpid = int(r["gameobject_path_id"] or 0)
    if gak and gpid:
        go=(gak,gpid)
        out.append(go)
        for x in con.execute(
            "SELECT asset_key,path_id FROM objects "
            "WHERE gameobject_asset_key=? AND gameobject_path_id=?", go
        ):
            out.append((str(x["asset_key"]), int(x["path_id"])))

    pak = str(r["parent_transform_asset_key"] or "")
    ppid = int(r["parent_transform_path_id"] or 0)
    if pak and ppid:
        out.append((pak,ppid))

    for x in con.execute(
        "SELECT asset_key,path_id FROM objects "
        "WHERE parent_transform_asset_key=? AND parent_transform_path_id=?", k
    ):
        out.append((str(x["asset_key"]), int(x["path_id"])))

    for x in con.execute(
        """SELECT target_asset_key,target_path_id FROM edges
           WHERE source_asset_key=? AND source_path_id=?
             AND (field_path='m_Script' OR field_path LIKE '%.m_Script')
             AND target_asset_key<>''""", k
    ):
        out.append((str(x["target_asset_key"]), int(x["target_path_id"])))

    return out

def collect(con, roots, depth, max_nodes):
    seen=set(roots)
    q=deque((k,0) for k in roots)
    truncated=False
    while q:
        k,d=q.popleft()
        if len(seen) >= max_nodes:
            truncated=True
            break
        neighbors=list(local_structure(con,k))
        if d < depth:
            neighbors += fwd(con,k)
            neighbors += rev(con,k)
        for nk in neighbors:
            if nk not in seen:
                seen.add(nk)
                q.append((nk,d+1))
                if len(seen) >= max_nodes:
                    truncated=True
                    break
        if truncated:
            break
    return seen,truncated

def selected_edges(con, nodes):
    ns=set(nodes)
    byid={}
    for k in nodes:
        for e in con.execute(
            "SELECT * FROM edges WHERE source_asset_key=? AND source_path_id=?", k
        ):
            target_ok = (
                bool(e["target_asset_key"]) and
                (str(e["target_asset_key"]), int(e["target_path_id"])) in ns
            )
            if target_ok or not e["target_asset_key"]:
                byid[int(e["id"])] = e
        for e in con.execute(
            "SELECT * FROM edges WHERE target_asset_key=? AND target_path_id=?", k
        ):
            sk=(str(e["source_asset_key"]),int(e["source_path_id"]))
            if sk in ns:
                byid[int(e["id"])] = e
    return [byid[i] for i in sorted(byid)]

def write_csv(path, cols, rows):
    with path.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f)
        w.writerow(cols)
        for r in rows:
            w.writerow([r[c] for c in cols])

def make_mini(path, objects, edges, files, roots):
    if path.exists():
        path.unlink()
    con=sqlite3.connect(path)
    con.executescript(SCHEMA)
    qobj="INSERT INTO objects("+",".join(OBJECT_COLUMNS)+") VALUES("+",".join("?"*len(OBJECT_COLUMNS))+")"
    qedg="INSERT INTO edges("+",".join(EDGE_COLUMNS)+") VALUES("+",".join("?"*len(EDGE_COLUMNS))+")"
    qfil="INSERT INTO files("+",".join(FILE_COLUMNS)+") VALUES("+",".join("?"*len(FILE_COLUMNS))+")"
    con.executemany(qobj, [[r[c] for c in OBJECT_COLUMNS] for r in objects])
    con.executemany(qedg, [[r[c] for c in EDGE_COLUMNS] for r in edges])
    con.executemany(qfil, [[r[c] for c in FILE_COLUMNS] for r in files])
    con.executemany(
        "INSERT INTO roots(reason,asset_key,path_id,matched_term) VALUES(?,?,?,?)",
        roots,
    )
    con.commit()
    con.execute("VACUUM")
    con.close()

def label(r):
    bits=[str(r["type"])]
    if r["name"]: bits.append(repr(r["name"]))
    if r["script_class"]: bits.append("class="+str(r["script_class"]))
    if r["hierarchy"]: bits.append("GO="+str(r["hierarchy"]))
    return " | ".join(bits)

def report(objects, edges, roots, truncated):
    byk={(str(r["asset_key"]),int(r["path_id"])):r for r in objects}
    lines=[
        "UNITY DEPENDENCY EVIDENCE SLICE",
        "="*100,
        f"objects: {len(objects):,}",
        f"edges:   {len(edges):,}",
        f"truncated: {truncated}",
        "",
        "ROOT SUSPECTS",
        "-"*100,
    ]
    for reason,ak,pid,term in roots:
        r=byk.get((ak,int(pid)))
        lines.append(f"{reason} {term!r}")
        if r:
            lines.append(f"  {label(r)}")
            lines.append(f"  asset={ak} pathID={pid}")

    candidates=[]
    for r in objects:
        txt=" ".join(str(r[c] or "") for c in ("name","script_decl","script_class","hierarchy")).lower()
        score=0
        if r["type"]=="MonoBehaviour": score+=50
        if r["script_class"]: score+=75
        if r["type"] in ("GameObject","RectTransform","Transform","Canvas","CanvasRenderer"): score+=15
        for tok in ("cook","recipe","gps","tracker","locator","hud","gui","ui","vital","message","tooltip","canvas","map","rendertexture"):
            if tok in txt: score+=12
        if score: candidates.append((score,r))
    candidates.sort(key=lambda x:(-x[0],label(x[1]).lower()))

    lines += ["","TOP INTERESTING OBJECTS / CLASSES","-"*100]
    for score,r in candidates[:300]:
        lines.append(f"score={score:3d} {label(r)}")
        lines.append(f"          asset={r['asset_key']} pathID={r['path_id']}")

    lines += ["","MONOBEHAVIOUR -> MONOSCRIPT","-"*100]
    for e in edges:
        fp=str(e["field_path"] or "")
        if fp=="m_Script" or fp.endswith(".m_Script"):
            sr=byk.get((str(e["source_asset_key"]),int(e["source_path_id"])))
            tr=None
            if e["target_asset_key"]:
                tr=byk.get((str(e["target_asset_key"]),int(e["target_path_id"])))
            lines.append(label(sr) if sr else "<missing source>")
            lines.append("  --["+fp+"]--> "+(label(tr) if tr else "<unresolved>"))
    return "\n".join(lines)+"\n"

def sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    a=args()
    db=Path(a.db)
    if not db.exists():
        print(f"ERROR: DB not found: {db}",file=sys.stderr)
        return 2

    terms=a.term or list(DEFAULT_TERMS)
    pids=a.path_id or list(DEFAULT_PATH_IDS)
    stamp=dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out=Path(a.out) if a.out else Path(__file__).resolve().parent/f"evidence_slice_{stamp}"
    out.mkdir(parents=True,exist_ok=True)

    print("Opening giant DB READ-ONLY / IMMUTABLE:")
    print(" ",db)
    print("No copy will be made.\n")

    con=open_big_db(db)
    try:
        roots={}
        root_records=[]

        for pid in pids:
            hits=search_pid(con,pid)
            print(f"pathID {pid}: {len(hits)} match(es)")
            for r in hits:
                k=key(r)
                roots[k]=r
                root_records.append(("pathID",k[0],k[1],str(pid)))
                print("  ",r["serialized_file"],"::",label(r))

        for term in terms:
            hits=search_term(con,term,a.max_roots_per_term)
            print(f"{term!r}: {len(hits)} selected match(es)")
            for r in hits:
                k=key(r)
                roots[k]=r
                root_records.append(("term",k[0],k[1],term))

        nodes,truncated=collect(con,list(roots),max(0,a.depth),max(100,a.max_nodes))
        print(f"\nSelected {len(nodes):,} objects; truncated={truncated}")

        objects=[]
        source_files=set()
        for k in sorted(nodes):
            r=get_obj(con,k)
            if r is not None:
                objects.append(r)
                source_files.add(str(r["source_file"]))

        edges=selected_edges(con,nodes)
        print(f"Selected {len(edges):,} edges")

        files=[]
        for sf in sorted(source_files):
            r=con.execute("SELECT * FROM files WHERE source_file=?",(sf,)).fetchone()
            if r is not None: files.append(r)

        write_csv(out/"objects.csv",OBJECT_COLUMNS,objects)
        write_csv(out/"edges.csv",EDGE_COLUMNS,edges)
        with (out/"roots.csv").open("w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f); w.writerow(["reason","asset_key","path_id","matched_term"]); w.writerows(root_records)

        mini=out/"evidence.sqlite"
        make_mini(mini,objects,edges,files,root_records)
        (out/"report.txt").write_text(report(objects,edges,root_records,truncated),encoding="utf-8")

        manifest={
            "source_db":str(db),
            "source_db_size_bytes":db.stat().st_size,
            "depth":a.depth,
            "max_nodes":a.max_nodes,
            "truncated":truncated,
            "terms":terms,
            "path_ids":pids,
            "unique_root_count":len(roots),
            "object_count":len(objects),
            "edge_count":len(edges),
            "mini_db_sha256":sha256(mini),
        }
        (out/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")

        zpath=out.with_suffix(".zip")
        if zpath.exists(): zpath.unlink()
        with zipfile.ZipFile(zpath,"w",compression=zipfile.ZIP_DEFLATED) as z:
            for p in sorted(out.iterdir()):
                if p.is_file(): z.write(p,p.name)

        print("\nDONE")
        print("Evidence ZIP:",zpath)
        print(f"ZIP size: {zpath.stat().st_size/(1024*1024):.2f} MiB")
        print("\nSend me that ZIP.")
        return 0
    finally:
        con.close()

if __name__=="__main__":
    raise SystemExit(main())
