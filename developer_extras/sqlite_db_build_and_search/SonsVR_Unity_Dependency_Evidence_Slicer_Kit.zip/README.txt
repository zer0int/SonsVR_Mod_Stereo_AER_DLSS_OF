SONSVR UNITY DEPENDENCY EVIDENCE SLICER
=======================================

Extract this kit and double-click:

    RUN_SLICE.bat

Expected giant DB:
    D:\unity_dependency_hunter_out\unity_dependency_index.sqlite

The script opens that DB READ-ONLY / IMMUTABLE and exports only a small
neighborhood around our current suspects.

Default exact pathIDs:
    55763
    57805
    50189

Default search terms:
    CookingRecipesView
    VitalsRenderTexture
    PlayerMarker
    PlayerMiniMap
    GPSLocator
    GPSTrackerSystem
    GpsLocatorVisualsHookup
    HudGui
    ToggleableHUD
    MessageList
    CookingCog
    CookingPotController

Output:
    evidence_slice_YYYYMMDD_HHMMSS.zip

Send that ZIP back to ChatGPT.

It contains:
    evidence.sqlite
    objects.csv
    edges.csv
    roots.csv
    report.txt
    manifest.json

The big 3.6 GB database is never copied.
