@echo off
setlocal
title SonsVR - Slice Unity Dependency DB

set "PY=C:\Program Files\Python310\python.exe"
if not exist "%PY%" set "PY=python"

set "DB=D:\unity_dependency_hunter_out\unity_dependency_index.sqlite"

echo.
echo ============================================================
echo  SonsVR Unity Dependency Evidence Slicer
echo ============================================================
echo.
echo Big DB:
echo   %DB%
echo.
echo The database is opened READ-ONLY + IMMUTABLE.
echo It is NOT copied or modified.
echo.

"%PY%" "%~dp0slice_unity_dependency_db.py" --db "%DB%" --depth 4

echo.
pause
