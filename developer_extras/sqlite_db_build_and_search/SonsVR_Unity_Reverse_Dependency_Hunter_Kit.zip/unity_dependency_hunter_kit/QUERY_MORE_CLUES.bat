@echo off
setlocal
set "PY=C:\Program Files\Python310\python.exe"
if not exist "%PY%" set "PY=python"

REM Fast follow-up query. The expensive scan is reused.
REM Example below intentionally searches cooking/UI words.
"%PY%" "%~dp0unity_reverse_dependency_hunter.py" ^
  --query-only ^
  --seed "Cooking" ^
  --seed "Recipe" ^
  --seed "HudGui" ^
  --seed "GPSLocator" ^
  --seed "ToggleableHUD" ^
  --depth 10

pause
