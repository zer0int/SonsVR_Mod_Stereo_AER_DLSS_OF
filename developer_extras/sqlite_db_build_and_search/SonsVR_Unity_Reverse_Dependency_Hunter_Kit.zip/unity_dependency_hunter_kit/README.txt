UNITY REVERSE DEPENDENCY HUNTER
================================

Purpose
-------
Given one visible asset/object/class name such as:

    PlayerMarker
    CaveOutline
    Circle
    PlayerMiniMap
    VitalsRenderTexture
    CookingRecipesView

build the reverse Unity object graph:

    Sprite / Material / Texture
        <- Image / RawImage / renderer / serialized consumer
        <- GameObject / RectTransform
        <- MonoBehaviour
        <- prefab/controller/manager

This is specifically intended to hunt down the hidden native UI/controller
machinery behind Sons of the Forest's HUD/minimap/vitals/cooking systems.

It DOES NOT modify game files.

FIRST RUN
---------
Double-click:

    RUN_DEPENDENCY_HUNTER.bat

It uses:
    D:\SteamLibrary\steamapps\common\Sons Of The Forest

and prefers:
    C:\Program Files\Python310\python.exe

Edit the BAT if either moved.

The BAT installs UnityPy if needed, scans the game, then writes a persistent
SQLite index under:

    unity_dependency_hunter_out\unity_dependency_index.sqlite

The first scan may take a while. Later clue searches reuse the DB.

WHAT TO READ FIRST
------------------
Open the newest:

    unity_dependency_hunter_out\query_YYYYMMDD_HHMMSS\_SUMMARY.txt

Then inspect:

    *__REVERSE_TREE.txt
        Human-readable backwards tree. This is the main result.

    *__reverse_nodes.csv
        All reverse ancestors, ranked with a score favoring MonoBehaviours,
        script classes, GameObjects, HUD/UI/map/cooking names.

    *__reverse_graph.dot
        Graphviz graph if you want a visual dependency graph.

    *__forward_refs.txt
        The seed object's normal forward dependencies. Useful for confirming
        e.g. Sprite -> Texture/Material.

    *__seed_matches.csv
        Every indexed object/string/hierarchy matching the clue.

FAST FOLLOW-UP
--------------
Once the index exists, run:

    QUERY_MORE_CLUES.bat

or manually:

    python unity_reverse_dependency_hunter.py ^
      --query-only ^
      --seed "SomeAnnoyanceClassName" ^
      --depth 10

Repeat --seed as often as desired.

WHY THIS IS A REVERSE HUNTER
----------------------------
Unity references are normally stored on the CONSUMER. A Sprite does not say
"these prefabs use me"; an Image/MonoBehaviour stores a PPtr to the Sprite.

The scanner records every PPtr and reverses the graph globally, including
references crossing bundle/serialized-file boundaries where those references
can be resolved.

MONOBEHAVIOURS / IL2CPP
-----------------------
The script asks UnityPy's TypeTreeGenerator to load the local Windows game.
When successful this can recover stripped MonoBehaviour typetrees using the
game's IL2CPP data. Failure is non-fatal; embedded typetrees are still scanned.

It also resolves:
    MonoBehaviour.m_Script -> MonoScript
and records namespace/class/assembly names where available.

GAMEOBJECT PATHS
----------------
The scanner reconstructs:
    Component.m_GameObject
    Transform/RectTransform.m_Father
to generate hierarchy paths such as:

    PlayerStandin/PlayerUI/ScreenSpaceCanvas/ToggleableHUD/...

This is deliberately meant to connect static asset clues to the live names
we already see in VR logs.

PRACTICAL VS FULL PARSE
-----------------------
By default the scanner does NOT deeply typetree-parse gigantic leaf payload
classes such as Texture2D, Shader, AudioClip and Mesh. Their consumers are
still parsed, so reverse-reference discovery works.

Use:
    --full-parse
only if you specifically need refs/strings inside those payload types.

RESET / RESCAN
--------------
If game files changed and you want a completely fresh index:

    python unity_reverse_dependency_hunter.py --rebuild ...

The normal run already detects changed container size/mtime and rescans those
files incrementally.

USEFUL NEXT SEEDS
-----------------
After PlayerMarker/Circle:
    GPSLocator
    GPSTrackerSystem
    PlayerMiniMap
    VitalsRenderTexture
    PlayerVitalUiRenderTextureGroup
    HudGui
    ToggleableHUD
    MessageList
    Cooking
    CookingRecipesView
    AvailableRecipesView
    CraftMatScreenSpaceUi

Happy hunting for ANNOYANCE CLASSNAME(TM).
