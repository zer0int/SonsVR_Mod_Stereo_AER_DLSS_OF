@echo off
setlocal
title Sons of the Forest - Unity Reverse Dependency Hunter

REM ============================================================================
REM Edit this only if your game moved.
REM ============================================================================
set "GAME_ROOT=D:\SteamLibrary\steamapps\common\Sons Of The Forest"

REM Prefer the Python 3.10 install you've been using for the mod toolchain.
set "PY=C:\Program Files\Python310\python.exe"
if not exist "%PY%" set "PY=python"

echo.
echo ============================================================
echo  Unity Reverse Dependency Hunter
echo ============================================================
echo  Game: %GAME_ROOT%
echo  Python: %PY%
echo.

"%PY%" -c "import UnityPy" >nul 2>nul
if errorlevel 1 (
    echo [setup] UnityPy is not installed in this Python.
    echo [setup] Installing/upgrading UnityPy from PyPI...
    "%PY%" -m pip install -U UnityPy
    if errorlevel 1 (
        echo.
        echo ERROR: UnityPy installation failed.
        pause
        exit /b 1
    )
)

echo.
echo [run] Building/reusing the game-wide index and tracing first breadcrumbs...
echo.
"%PY%" "%~dp0unity_reverse_dependency_hunter.py" ^
  --root "%GAME_ROOT%" ^
  --seed "PlayerMarker" ^
  --seed "CaveOutline" ^
  --seed "Circle" ^
  --seed "PlayerMiniMap" ^
  --seed "VitalsRenderTexture" ^
  --seed "CookingRecipesView" ^
  --depth 8

echo.
echo Finished. Look in:
echo   %~dp0unity_dependency_hunter_out
echo.
pause
