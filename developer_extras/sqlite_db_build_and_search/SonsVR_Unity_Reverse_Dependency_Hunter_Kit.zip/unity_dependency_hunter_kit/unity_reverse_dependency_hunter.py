#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
Unity Reverse Dependency Hunter
================================

Game-wide reverse-reference crawler for Unity serialized assets/bundles.

Primary use case:
    "I found ONE visible thing (PlayerMarker, Circle, CaveOutline, etc.).
     What prefab/GameObject/MonoBehaviour ultimately consumes it?"

What it does
------------
1. Recursively scans Unity serialized asset containers under a game root.
2. Parses typetrees and records every PPtr-like reference it can find.
3. Resolves same-file and external-file PPtrs into a game-wide graph.
4. Reconstructs GameObject hierarchy from RectTransform/Transform parenting.
5. Resolves MonoBehaviour -> MonoScript class names where possible.
6. Searches by asset name, GameObject hierarchy, MonoScript class, and short
   string fields.
7. Walks the graph *backwards* from a seed, i.e.:
       PlayerMarker <- Image/RawImage <- GameObject <- prefab/controller ...
8. Emits TXT/CSV/DOT reports plus a persistent SQLite index so later searches
   are fast and do not need to rescan the game.

This script DOES NOT modify game files.

Tested for syntax on Python 3.10. Runtime asset parsing requires UnityPy.

Recommended command:
    python unity_reverse_dependency_hunter.py ^
        --root "D:\SteamLibrary\steamapps\common\Sons Of The Forest" ^
        --seed PlayerMarker --seed CaveOutline --seed Circle ^
        --depth 8

After the first scan, add new seeds freely. The SQLite index is reused.
"""

from __future__ import annotations

import argparse
import csv
import datetime as _dt
import json
import os
import re
import sqlite3
import sys
import traceback
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Optional

# =============================================================================
# USER CONFIG — CLI arguments override these.
# =============================================================================

GAME_ROOT = r"D:\SteamLibrary\steamapps\common\Sons Of The Forest"

# First useful breadcrumbs. Add/remove freely.
DEFAULT_SEEDS = [
    "PlayerMarker",
    "CaveOutline",
    "Circle",
    "PlayerMiniMap",
    "VitalsRenderTexture",
    "CookingRecipesView",
]

DEFAULT_REVERSE_DEPTH = 8
DEFAULT_MAX_BRANCHES_PER_NODE = 80

# Persistent index. Re-running with new --seed values reuses this.
DEFAULT_OUTPUT_DIR = Path(__file__).resolve().parent / "unity_dependency_hunter_out"

# Sons of the Forest version in the logs. Used only for UnityPy's optional
# typetree generator. The scanner continues if the generator cannot initialize.
GAME_UNITY_VERSION = "2022.2.16f1"
USE_TYPETREE_GENERATOR = True

# Parsing gigantic leaf payloads is pointless for reverse PPtr discovery and
# makes a game-wide scan much slower. Their *consumers* are still fully parsed.
SKIP_DEEP_PARSE_TYPES = {
    "Texture2D",
    "Texture3D",
    "Cubemap",
    "AudioClip",
    "VideoClip",
    "Shader",
    "Mesh",
    "TextAsset",
}

# Short scalar strings are indexed to make "Cooking", "GPS", "Hud", etc.
# searchable even when they occur in serialized fields rather than m_Name.
MAX_SEARCH_STRINGS_PER_OBJECT = 80
MAX_SEARCH_STRING_LENGTH = 240
MAX_SEARCH_BLOB_LENGTH = 12_000

# Unity container candidates. Resource sidecars (.resS/.resource) are NOT
# loaded as standalone serialized files; UnityPy reads them via their owners.
UNITY_FILE_SUFFIXES = {
    ".bundle",
    ".assets",
    ".unity3d",
    ".unityweb",
    ".unityraw",
}
UNITY_EXTENSIONLESS_NAMES = {
    "globalgamemanagers",
    "mainData",
    "resources",
}
UNITY_EXTENSIONLESS_RE = re.compile(r"^(level\d+|sharedassets\d+)$", re.I)

# =============================================================================
# IMPORT / COMPATIBILITY
# =============================================================================

try:
    import UnityPy  # type: ignore
except Exception as exc:
    print(
        "\nERROR: UnityPy is required.\n"
        "Install it with:\n"
        f'  "{sys.executable}" -m pip install -U UnityPy\n',
        file=sys.stderr,
    )
    raise SystemExit(2) from exc


def _unitypy_version() -> str:
    return str(getattr(UnityPy, "__version__", "unknown"))


# =============================================================================
# SMALL HELPERS
# =============================================================================

def norm_slashes(s: str) -> str:
    return str(s).replace("\\", "/")


def clean_external_name(path: str) -> str:
    """
    Mirror UnityPy PPtr external cleanup:
      archive:/... -> strip prefix
      assets/...   -> strip prefix
      use final filename/CAB component, lowercased
    """
    s = norm_slashes(path or "").strip()
    low = s.lower()
    if low.startswith("archive:/"):
        s = s[9:]
    if s.lower().startswith("assets/"):
        s = s[7:]
    return s.rsplit("/", 1)[-1].lower()


def safe_rel(path: Path, root: Path) -> str:
    try:
        return norm_slashes(str(path.resolve().relative_to(root.resolve())))
    except Exception:
        return norm_slashes(str(path.resolve()))


def utcish_stamp() -> str:
    return _dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def scalar_string(value: Any) -> Optional[str]:
    if not isinstance(value, str):
        return None
    s = value.replace("\x00", "").strip()
    if not s or len(s) > MAX_SEARCH_STRING_LENGTH:
        return None
    printable = sum(ch.isprintable() for ch in s)
    if printable < max(1, int(len(s) * 0.90)):
        return None
    return s


def object_path_id(obj: Any) -> int:
    for name in ("path_id", "m_PathID"):
        if hasattr(obj, name):
            try:
                return int(getattr(obj, name))
            except Exception:
                pass
    raise AttributeError("Object has no path_id/m_PathID")


def object_type_name(obj: Any) -> str:
    t = getattr(obj, "type", None)
    name = getattr(t, "name", None)
    return str(name if name is not None else t if t is not None else "Unknown")


def assets_file_name(af: Any) -> str:
    for attr in ("name", "file_name"):
        x = getattr(af, attr, None)
        if x:
            return norm_slashes(str(x))
    return "<serialized-file>"


def parse_object_dict(obj: Any) -> dict:
    """UnityPy 1.x/current-master compatibility."""
    methods = ("parse_as_dict", "read_typetree")
    last = None
    for meth in methods:
        fn = getattr(obj, meth, None)
        if callable(fn):
            try:
                data = fn()
                if isinstance(data, dict):
                    return data
            except Exception as exc:
                last = exc
    if last:
        raise last
    raise RuntimeError("No dict typetree parser exposed by this UnityPy ObjectReader")


def peek_object_name(obj: Any) -> str:
    fn = getattr(obj, "peek_name", None)
    if callable(fn):
        try:
            x = fn()
            if x is not None:
                return str(x)
        except Exception:
            pass
    return ""


def external_paths_for_assets_file(af: Any) -> list[str]:
    out = []
    for ext in list(getattr(af, "externals", []) or []):
        p = getattr(ext, "path", None)
        if p is None:
            p = getattr(ext, "name", None)
        out.append(str(p or ""))
    return out


def extract_pptr_pair(value: Any) -> Optional[tuple[int, int]]:
    """
    Supports typetree dicts and wrapped UnityPy PPtr objects.
    """
    if isinstance(value, dict):
        # Avoid falsely recognizing arbitrary dicts unless both keys exist.
        if "m_FileID" in value and "m_PathID" in value:
            try:
                return int(value["m_FileID"]), int(value["m_PathID"])
            except Exception:
                return None
        return None

    if hasattr(value, "m_FileID") and hasattr(value, "m_PathID"):
        try:
            return int(value.m_FileID), int(value.m_PathID)
        except Exception:
            return None

    if hasattr(value, "file_id") and hasattr(value, "path_id"):
        try:
            return int(value.file_id), int(value.path_id)
        except Exception:
            return None

    return None


@dataclass
class FoundPPtr:
    field_path: str
    file_id: int
    path_id: int


def walk_tree(
    node: Any,
    path: str = "",
    *,
    collect_strings: bool = True,
) -> tuple[list[FoundPPtr], list[str]]:
    refs: list[FoundPPtr] = []
    strings: list[str] = []

    def rec(x: Any, p: str) -> None:
        pair = extract_pptr_pair(x)
        if pair is not None:
            fid, pid = pair
            if pid != 0:
                refs.append(FoundPPtr(p or "<root>", fid, pid))
            # Do not recursively treat m_FileID/m_PathID integers as fields.
            return

        if isinstance(x, dict):
            for k, v in x.items():
                kp = f"{p}.{k}" if p else str(k)
                rec(v, kp)
            return

        if isinstance(x, (list, tuple)):
            # Preserve a little index context, but compress very large arrays.
            for i, v in enumerate(x):
                ip = f"{p}[{i}]"
                rec(v, ip)
            return

        if collect_strings and len(strings) < MAX_SEARCH_STRINGS_PER_OBJECT:
            s = scalar_string(x)
            if s is not None:
                strings.append(f"{p}={s}" if p else s)

    rec(node, path)
    return refs, strings


def get_nested(tree: dict, *names: str) -> str:
    for name in names:
        if name in tree and tree[name] is not None:
            return str(tree[name])
    return ""


# =============================================================================
# FILE DISCOVERY
# =============================================================================

def is_unity_candidate(path: Path) -> bool:
    if not path.is_file():
        return False

    suffix = path.suffix.lower()
    if suffix in UNITY_FILE_SUFFIXES:
        return True

    # Sidecar binary payloads should not be fed to UnityPy independently.
    if suffix in {".ress", ".resource", ".res", ".split0", ".split1"}:
        return False

    if suffix == "":
        name = path.name
        if name in UNITY_EXTENSIONLESS_NAMES or UNITY_EXTENSIONLESS_RE.match(name):
            return True

        # Addressables occasionally use extensionless UnityFS containers.
        try:
            with path.open("rb") as f:
                magic = f.read(8)
            if magic.startswith((b"UnityFS", b"UnityRaw", b"UnityWeb")):
                return True
        except Exception:
            pass

    return False


def discover_unity_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for dp, _, fns in os.walk(root):
        d = Path(dp)
        for fn in fns:
            p = d / fn
            if is_unity_candidate(p):
                files.append(p)
    files.sort(key=lambda p: safe_rel(p, root).lower())
    return files


# =============================================================================
# SQLITE
# =============================================================================

SCHEMA = r"""
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA temp_store=MEMORY;

CREATE TABLE IF NOT EXISTS files (
    source_file TEXT PRIMARY KEY,
    file_size INTEGER NOT NULL,
    file_mtime REAL NOT NULL,
    status TEXT NOT NULL,
    error TEXT,
    object_count INTEGER DEFAULT 0,
    edge_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS objects (
    asset_key TEXT NOT NULL,
    source_file TEXT NOT NULL,
    serialized_file TEXT NOT NULL,
    path_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    name TEXT DEFAULT '',
    script_decl TEXT DEFAULT '',
    script_class TEXT DEFAULT '',
    hierarchy TEXT DEFAULT '',
    gameobject_asset_key TEXT DEFAULT '',
    gameobject_path_id INTEGER DEFAULT 0,
    parent_transform_asset_key TEXT DEFAULT '',
    parent_transform_path_id INTEGER DEFAULT 0,
    search_blob TEXT DEFAULT '',
    parse_ok INTEGER DEFAULT 1,
    parse_error TEXT DEFAULT '',
    PRIMARY KEY (asset_key, path_id)
);

CREATE TABLE IF NOT EXISTS aliases (
    alias TEXT NOT NULL,
    asset_key TEXT NOT NULL,
    source_file TEXT NOT NULL,
    PRIMARY KEY (alias, asset_key)
);

CREATE TABLE IF NOT EXISTS edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_asset_key TEXT NOT NULL,
    source_path_id INTEGER NOT NULL,
    field_path TEXT NOT NULL,
    file_id INTEGER NOT NULL,
    target_path_id INTEGER NOT NULL,
    target_hint TEXT DEFAULT '',
    target_asset_key TEXT DEFAULT '',
    resolution TEXT DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_objects_name ON objects(name);
CREATE INDEX IF NOT EXISTS idx_objects_type ON objects(type);
CREATE INDEX IF NOT EXISTS idx_objects_script ON objects(script_class);
CREATE INDEX IF NOT EXISTS idx_objects_hierarchy ON objects(hierarchy);
CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_asset_key, source_path_id);
CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_asset_key, target_path_id);
CREATE INDEX IF NOT EXISTS idx_edges_hint ON edges(target_hint, target_path_id);
"""


def open_db(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(path))
    con.executescript(SCHEMA)
    con.row_factory = sqlite3.Row
    return con


def delete_source_file_rows(con: sqlite3.Connection, source_file: str) -> None:
    asset_keys = [
        r[0]
        for r in con.execute(
            "SELECT DISTINCT asset_key FROM objects WHERE source_file=?",
            (source_file,),
        )
    ]
    for ak in asset_keys:
        con.execute("DELETE FROM edges WHERE source_asset_key=?", (ak,))
    con.execute("DELETE FROM aliases WHERE source_file=?", (source_file,))
    con.execute("DELETE FROM objects WHERE source_file=?", (source_file,))
    con.execute("DELETE FROM files WHERE source_file=?", (source_file,))


# =============================================================================
# TYPETREE GENERATOR
# =============================================================================

def build_typetree_generator(root: Path):
    if not USE_TYPETREE_GENERATOR:
        return None

    try:
        from UnityPy.helpers.TypeTreeGenerator import TypeTreeGenerator  # type: ignore
    except Exception as exc:
        print(f"[typetree] TypeTreeGenerator unavailable in this UnityPy: {exc}")
        return None

    try:
        print(
            f"[typetree] Initializing local-game generator for Unity "
            f"{GAME_UNITY_VERSION} ..."
        )
        gen = TypeTreeGenerator(GAME_UNITY_VERSION)
        gen.load_local_game(str(root))
        print("[typetree] local-game generator ready.")
        return gen
    except Exception as exc:
        print(
            "[typetree] Could not initialize local-game generator; continuing "
            f"with embedded typetrees only: {type(exc).__name__}: {exc}"
        )
        return None


# =============================================================================
# INDEXING
# =============================================================================

def scan_one_file(
    con: sqlite3.Connection,
    root: Path,
    path: Path,
    typetree_generator: Any,
    *,
    full_parse: bool,
) -> tuple[int, int]:
    rel = safe_rel(path, root)
    stat = path.stat()

    old = con.execute(
        "SELECT file_size, file_mtime, status FROM files WHERE source_file=?",
        (rel,),
    ).fetchone()
    if (
        old
        and int(old["file_size"]) == stat.st_size
        and abs(float(old["file_mtime"]) - stat.st_mtime) < 0.001
        and old["status"] == "indexed"
    ):
        row = con.execute(
            "SELECT object_count, edge_count FROM files WHERE source_file=?",
            (rel,),
        ).fetchone()
        return int(row["object_count"]), int(row["edge_count"])

    if old:
        delete_source_file_rows(con, rel)

    con.execute(
        "INSERT OR REPLACE INTO files(source_file,file_size,file_mtime,status) "
        "VALUES(?,?,?,'scanning')",
        (rel, stat.st_size, stat.st_mtime),
    )
    con.commit()

    obj_count = 0
    edge_count = 0

    try:
        env = UnityPy.load(str(path))
        if typetree_generator is not None:
            try:
                env.typetree_generator = typetree_generator
            except Exception:
                pass

        # Cache per-serialized-file external paths.
        external_cache: dict[int, list[str]] = {}

        for obj in env.objects:
            obj_count += 1
            af = obj.assets_file
            serialized = assets_file_name(af)
            asset_key = f"{rel}::{serialized}"
            pid = object_path_id(obj)
            typ = object_type_name(obj)

            # Aliases used to resolve external PPtrs later.
            for alias in {
                serialized.lower(),
                clean_external_name(serialized),
                Path(serialized).name.lower(),
            }:
                if alias:
                    con.execute(
                        "INSERT OR IGNORE INTO aliases(alias,asset_key,source_file) "
                        "VALUES(?,?,?)",
                        (alias, asset_key, rel),
                    )

            name = peek_object_name(obj)
            script_decl = ""
            parse_ok = 1
            parse_error = ""
            search_strings: list[str] = []
            refs: list[FoundPPtr] = []

            if full_parse or typ not in SKIP_DEEP_PARSE_TYPES:
                try:
                    tree = parse_object_dict(obj)
                    if not name:
                        name = str(tree.get("m_Name", "") or "")

                    # MonoScript declarations are the bridge from serialized
                    # MonoBehaviour to actual human class names.
                    if typ == "MonoScript":
                        ns = get_nested(tree, "m_Namespace")
                        cls = get_nested(tree, "m_ClassName")
                        asm = get_nested(tree, "m_AssemblyName")
                        lhs = f"{ns}.{cls}".strip(".") if cls else name
                        script_decl = lhs
                        if asm:
                            script_decl = f"{lhs} [{asm}]" if lhs else f"[{asm}]"

                    refs, search_strings = walk_tree(tree)
                except Exception as exc:
                    parse_ok = 0
                    parse_error = f"{type(exc).__name__}: {exc}"[:1000]
            else:
                # Name-only leaf. Reverse references *to* this object are still
                # discovered from its consumers.
                parse_ok = 2  # deliberately shallow

            blob_parts = []
            if name:
                blob_parts.append(f"name={name}")
            if script_decl:
                blob_parts.append(f"script={script_decl}")
            blob_parts.extend(search_strings)
            search_blob = "\n".join(blob_parts)[:MAX_SEARCH_BLOB_LENGTH]

            con.execute(
                """
                INSERT OR REPLACE INTO objects(
                    asset_key,source_file,serialized_file,path_id,type,name,
                    script_decl,search_blob,parse_ok,parse_error
                ) VALUES(?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    asset_key,
                    rel,
                    serialized,
                    pid,
                    typ,
                    name,
                    script_decl,
                    search_blob,
                    parse_ok,
                    parse_error,
                ),
            )

            af_id = id(af)
            if af_id not in external_cache:
                external_cache[af_id] = external_paths_for_assets_file(af)
            exts = external_cache[af_id]

            for ref in refs:
                hint = ""
                if ref.file_id > 0:
                    idx = ref.file_id - 1
                    if 0 <= idx < len(exts):
                        hint = clean_external_name(exts[idx])

                con.execute(
                    """
                    INSERT INTO edges(
                        source_asset_key,source_path_id,field_path,file_id,
                        target_path_id,target_hint
                    ) VALUES(?,?,?,?,?,?)
                    """,
                    (
                        asset_key,
                        pid,
                        ref.field_path,
                        ref.file_id,
                        ref.path_id,
                        hint,
                    ),
                )
                edge_count += 1

        con.execute(
            """
            UPDATE files SET status='indexed', error='', object_count=?, edge_count=?
            WHERE source_file=?
            """,
            (obj_count, edge_count, rel),
        )
        con.commit()
        return obj_count, edge_count

    except Exception as exc:
        err = f"{type(exc).__name__}: {exc}"
        con.execute(
            "UPDATE files SET status='failed', error=? WHERE source_file=?",
            (err[:4000], rel),
        )
        con.commit()
        print(f"\n[FAILED] {rel}\n  {err}")
        return 0, 0


def resolve_edges(con: sqlite3.Connection) -> None:
    print("\n[resolve] Resolving PPtrs across serialized files ...")

    # Same-file references are exact.
    con.execute(
        """
        UPDATE edges
        SET target_asset_key=source_asset_key, resolution='same-file'
        WHERE file_id=0
        """
    )
    con.commit()

    alias_map: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for row in con.execute("SELECT alias, asset_key, source_file FROM aliases"):
        alias_map[row["alias"]].append((row["asset_key"], row["source_file"]))

    asset_source = {
        r["asset_key"]: r["source_file"]
        for r in con.execute("SELECT DISTINCT asset_key, source_file FROM objects")
    }

    rows = con.execute(
        """
        SELECT id, source_asset_key, target_hint
        FROM edges
        WHERE file_id>0 AND (target_asset_key='' OR resolution='')
        """
    ).fetchall()

    resolved = 0
    ambiguous = 0
    missing = 0

    for r in rows:
        hint = (r["target_hint"] or "").lower()
        cands = alias_map.get(hint, [])
        if len(cands) == 1:
            target_ak = cands[0][0]
            res = "external-unique"
            resolved += 1
        elif len(cands) > 1:
            # Prefer same physical directory when this disambiguates repeated
            # sharedassets-style names.
            src_file = asset_source.get(r["source_asset_key"], "")
            src_dir = str(Path(src_file).parent).lower()
            same_dir = [
                c for c in cands
                if str(Path(c[1]).parent).lower() == src_dir
            ]
            if len(same_dir) == 1:
                target_ak = same_dir[0][0]
                res = "external-same-dir"
                resolved += 1
            else:
                target_ak = ""
                res = f"ambiguous:{len(cands)}"
                ambiguous += 1
        else:
            target_ak = ""
            res = "missing"
            missing += 1

        con.execute(
            "UPDATE edges SET target_asset_key=?, resolution=? WHERE id=?",
            (target_ak, res, r["id"]),
        )

    con.commit()
    print(
        f"[resolve] resolved={resolved:,} ambiguous={ambiguous:,} "
        f"missing={missing:,}"
    )


def enrich_components_and_hierarchy(con: sqlite3.Connection) -> None:
    print("[enrich] Resolving Component->GameObject and MonoBehaviour->MonoScript ...")

    # Reset derived columns so re-running after an incremental scan is safe.
    con.execute(
        """
        UPDATE objects
        SET script_class='', hierarchy='', gameobject_asset_key='',
            gameobject_path_id=0, parent_transform_asset_key='',
            parent_transform_path_id=0
        """
    )

    # Component -> GameObject.
    rows = con.execute(
        """
        SELECT source_asset_key, source_path_id, target_asset_key, target_path_id
        FROM edges
        WHERE target_asset_key<>'' AND
              (field_path='m_GameObject' OR field_path LIKE '%.m_GameObject')
        """
    ).fetchall()
    for r in rows:
        con.execute(
            """
            UPDATE objects
            SET gameobject_asset_key=?, gameobject_path_id=?
            WHERE asset_key=? AND path_id=?
            """,
            (
                r["target_asset_key"],
                r["target_path_id"],
                r["source_asset_key"],
                r["source_path_id"],
            ),
        )

    # Transform -> parent Transform.
    rows = con.execute(
        """
        SELECT source_asset_key, source_path_id, target_asset_key, target_path_id
        FROM edges
        WHERE target_asset_key<>'' AND
              (field_path='m_Father' OR field_path LIKE '%.m_Father')
        """
    ).fetchall()
    for r in rows:
        con.execute(
            """
            UPDATE objects
            SET parent_transform_asset_key=?, parent_transform_path_id=?
            WHERE asset_key=? AND path_id=?
            """,
            (
                r["target_asset_key"],
                r["target_path_id"],
                r["source_asset_key"],
                r["source_path_id"],
            ),
        )

    # MonoBehaviour -> MonoScript declaration.
    rows = con.execute(
        """
        SELECT e.source_asset_key, e.source_path_id,
               o.script_decl, o.name
        FROM edges e
        JOIN objects o
          ON o.asset_key=e.target_asset_key AND o.path_id=e.target_path_id
        WHERE e.target_asset_key<>'' AND
              (e.field_path='m_Script' OR e.field_path LIKE '%.m_Script')
        """
    ).fetchall()
    for r in rows:
        cls = r["script_decl"] or r["name"] or ""
        if cls:
            con.execute(
                """
                UPDATE objects SET script_class=?
                WHERE asset_key=? AND path_id=?
                """,
                (cls, r["source_asset_key"], r["source_path_id"]),
            )
    con.commit()

    # Build Transform -> GameObject map and GO names.
    transform_rows = con.execute(
        """
        SELECT asset_key,path_id,type,name,gameobject_asset_key,gameobject_path_id,
               parent_transform_asset_key,parent_transform_path_id
        FROM objects
        WHERE type IN ('Transform','RectTransform')
        """
    ).fetchall()

    transform_to_go: dict[tuple[str, int], tuple[str, int]] = {}
    transform_parent: dict[tuple[str, int], tuple[str, int]] = {}
    for r in transform_rows:
        tk = (r["asset_key"], int(r["path_id"]))
        if r["gameobject_asset_key"] and int(r["gameobject_path_id"]):
            transform_to_go[tk] = (
                r["gameobject_asset_key"],
                int(r["gameobject_path_id"]),
            )
        if r["parent_transform_asset_key"] and int(r["parent_transform_path_id"]):
            transform_parent[tk] = (
                r["parent_transform_asset_key"],
                int(r["parent_transform_path_id"]),
            )

    go_name = {
        (r["asset_key"], int(r["path_id"])): (r["name"] or f"<GameObject:{r['path_id']}>")
        for r in con.execute(
            "SELECT asset_key,path_id,name FROM objects WHERE type='GameObject'"
        )
    }

    go_to_transform = {go: tr for tr, go in transform_to_go.items()}
    hierarchy_cache: dict[tuple[str, int], str] = {}

    def hierarchy_for_go(go: tuple[str, int], stack: set[tuple[str, int]]) -> str:
        if go in hierarchy_cache:
            return hierarchy_cache[go]
        if go in stack:
            return go_name.get(go, f"<cycle:{go[1]}>")
        stack = set(stack)
        stack.add(go)

        here = go_name.get(go, f"<GameObject:{go[1]}>")
        tr = go_to_transform.get(go)
        if tr is None:
            hierarchy_cache[go] = here
            return here

        ptr = transform_parent.get(tr)
        if ptr is None or ptr[1] == 0:
            hierarchy_cache[go] = here
            return here

        pgo = transform_to_go.get(ptr)
        if pgo is None:
            hierarchy_cache[go] = here
            return here

        parent = hierarchy_for_go(pgo, stack)
        result = f"{parent}/{here}" if parent else here
        hierarchy_cache[go] = result
        return result

    print(f"[enrich] Reconstructing {len(go_name):,} GameObject hierarchy paths ...")
    for go in go_name:
        h = hierarchy_for_go(go, set())
        con.execute(
            "UPDATE objects SET hierarchy=? WHERE asset_key=? AND path_id=?",
            (h, go[0], go[1]),
        )

    # Components inherit their owning GameObject's hierarchy.
    comp_rows = con.execute(
        """
        SELECT asset_key,path_id,gameobject_asset_key,gameobject_path_id
        FROM objects
        WHERE gameobject_asset_key<>'' AND gameobject_path_id<>0
        """
    ).fetchall()
    for r in comp_rows:
        go = (r["gameobject_asset_key"], int(r["gameobject_path_id"]))
        h = hierarchy_cache.get(go, go_name.get(go, ""))
        if h:
            con.execute(
                "UPDATE objects SET hierarchy=? WHERE asset_key=? AND path_id=?",
                (h, r["asset_key"], r["path_id"]),
            )

    con.commit()


def index_game(
    con: sqlite3.Connection,
    root: Path,
    *,
    rebuild: bool,
    full_parse: bool,
    max_files: int,
) -> None:
    if rebuild:
        print("[index] --rebuild requested: clearing prior index.")
        con.executescript(
            """
            DELETE FROM edges;
            DELETE FROM aliases;
            DELETE FROM objects;
            DELETE FROM files;
            """
        )
        con.commit()

    files = discover_unity_files(root)
    if max_files > 0:
        files = files[:max_files]

    print(f"[index] UnityPy={_unitypy_version()}")
    print(f"[index] root={root}")
    print(f"[index] candidate containers={len(files):,}")
    print(
        "[index] mode="
        + ("FULL typetree parse" if full_parse else "practical parse (huge leaf payloads shallow)")
    )

    typetree_generator = build_typetree_generator(root)

    total_objects = 0
    total_edges = 0
    for i, p in enumerate(files, 1):
        rel = safe_rel(p, root)
        print(f"\r[index] {i:>5}/{len(files):<5} {rel[:100]:<100}", end="", flush=True)
        objs, edges = scan_one_file(
            con, root, p, typetree_generator, full_parse=full_parse
        )
        total_objects += objs
        total_edges += edges

    print()
    failed = con.execute(
        "SELECT COUNT(*) FROM files WHERE status='failed'"
    ).fetchone()[0]
    indexed = con.execute(
        "SELECT COUNT(*) FROM files WHERE status='indexed'"
    ).fetchone()[0]
    print(
        f"[index] indexed files={indexed:,}, failed={failed:,}, "
        f"objects(seen this pass)={total_objects:,}, edges(seen this pass)={total_edges:,}"
    )

    resolve_edges(con)
    enrich_components_and_hierarchy(con)


# =============================================================================
# QUERY / REPORTING
# =============================================================================

def row_key(row: sqlite3.Row) -> tuple[str, int]:
    return row["asset_key"], int(row["path_id"])


def object_row(
    con: sqlite3.Connection, key: tuple[str, int]
) -> Optional[sqlite3.Row]:
    return con.execute(
        """
        SELECT * FROM objects WHERE asset_key=? AND path_id=?
        """,
        key,
    ).fetchone()


def object_label(row: Optional[sqlite3.Row]) -> str:
    if row is None:
        return "<missing object>"
    bits = [row["type"]]
    if row["name"]:
        bits.append(repr(row["name"]))
    if row["script_class"]:
        bits.append(f"class={row['script_class']}")
    if row["hierarchy"]:
        bits.append(f"GO={row['hierarchy']}")
    bits.append(f"pathID={row['path_id']}")
    return " | ".join(bits)


def search_seed(con: sqlite3.Connection, seed: str) -> list[sqlite3.Row]:
    q = f"%{seed.lower()}%"
    rows = con.execute(
        """
        SELECT *
        FROM objects
        WHERE lower(name) LIKE ?
           OR lower(script_decl) LIKE ?
           OR lower(script_class) LIKE ?
           OR lower(hierarchy) LIKE ?
           OR lower(search_blob) LIKE ?
           OR lower(serialized_file) LIKE ?
           OR lower(source_file) LIKE ?
        ORDER BY
          CASE WHEN lower(name)=lower(?) THEN 0
               WHEN lower(name) LIKE ? THEN 1
               WHEN lower(script_class) LIKE ? THEN 2
               WHEN lower(hierarchy) LIKE ? THEN 3
               ELSE 4 END,
          type, name, source_file, path_id
        """,
        (q, q, q, q, q, q, q, seed, q, q, q),
    ).fetchall()
    return rows


def reverse_consumers(
    con: sqlite3.Connection,
    key: tuple[str, int],
) -> list[sqlite3.Row]:
    return con.execute(
        """
        SELECT e.*, o.*
        FROM edges e
        JOIN objects o
          ON o.asset_key=e.source_asset_key
         AND o.path_id=e.source_path_id
        WHERE e.target_asset_key=? AND e.target_path_id=?
        ORDER BY o.type, o.name, e.field_path
        """,
        key,
    ).fetchall()


def forward_refs(
    con: sqlite3.Connection,
    key: tuple[str, int],
) -> list[sqlite3.Row]:
    return con.execute(
        """
        SELECT e.*,
               o.type AS target_type,
               o.name AS target_name,
               o.script_class AS target_script_class,
               o.hierarchy AS target_hierarchy,
               o.source_file AS target_source_file,
               o.serialized_file AS target_serialized_file
        FROM edges e
        LEFT JOIN objects o
          ON o.asset_key=e.target_asset_key
         AND o.path_id=e.target_path_id
        WHERE e.source_asset_key=? AND e.source_path_id=?
        ORDER BY e.field_path
        """,
        key,
    ).fetchall()


def sanitize_filename(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s.strip())
    return s[:120] or "seed"


def write_seed_search_csv(path: Path, rows: list[sqlite3.Row]) -> None:
    cols = [
        "type", "name", "script_decl", "script_class", "hierarchy",
        "source_file", "serialized_file", "asset_key", "path_id",
        "parse_ok", "parse_error",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for r in rows:
            w.writerow([r[c] for c in cols])


def build_reverse_graph(
    con: sqlite3.Connection,
    root_key: tuple[str, int],
    *,
    max_depth: int,
    max_branches: int,
) -> tuple[
    dict[tuple[str, int], int],
    list[tuple[tuple[str, int], tuple[str, int], str]],
]:
    depths = {root_key: 0}
    edges_out: list[tuple[tuple[str, int], tuple[str, int], str]] = []
    q = deque([root_key])

    while q:
        target = q.popleft()
        d = depths[target]
        if d >= max_depth:
            continue

        consumers = reverse_consumers(con, target)
        if max_branches > 0:
            consumers = consumers[:max_branches]

        for r in consumers:
            src = (r["source_asset_key"], int(r["source_path_id"]))
            field = r["field_path"]
            edges_out.append((src, target, field))
            if src not in depths:
                depths[src] = d + 1
                q.append(src)

    return depths, edges_out


def interesting_score(row: sqlite3.Row, depth: int) -> int:
    typ = row["type"]
    script = (row["script_class"] or "").lower()
    name = (row["name"] or "").lower()
    hierarchy = (row["hierarchy"] or "").lower()

    score = max(0, 100 - depth * 7)
    if typ == "MonoBehaviour":
        score += 40
    if typ in {"GameObject", "RectTransform", "Transform", "Canvas", "CanvasRenderer"}:
        score += 25
    if row["script_class"]:
        score += 45
    joined = f"{script} {name} {hierarchy}"
    for token in (
        "hud", "gui", "ui", "map", "gps", "vital", "cook", "recipe",
        "canvas", "screen", "marker", "tracker", "inventory", "tooltip",
        "quickselect", "message", "prompt", "rendertexture",
    ):
        if token in joined:
            score += 12
    return score


def write_reverse_txt(
    con: sqlite3.Connection,
    path: Path,
    seed: str,
    root_row: sqlite3.Row,
    depths: dict[tuple[str, int], int],
    graph_edges: list[tuple[tuple[str, int], tuple[str, int], str]],
) -> None:
    children: dict[
        tuple[str, int],
        list[tuple[tuple[str, int], str]]
    ] = defaultdict(list)
    # graph edge is source -> target, but tree display starts at target and
    # expands backwards to sources.
    for src, target, field in graph_edges:
        children[target].append((src, field))

    for k in children:
        children[k].sort(
            key=lambda x: (
                depths.get(x[0], 999),
                object_label(object_row(con, x[0])).lower(),
                x[1],
            )
        )

    root = row_key(root_row)
    lines = [
        f"UNITY REVERSE DEPENDENCY HUNTER",
        f"seed: {seed}",
        f"root: {object_label(root_row)}",
        f"asset: {root_row['asset_key']}",
        "",
        "Arrow meaning: TARGET <-[field]-- CONSUMER",
        "i.e. the indented object is one thing that references/uses its parent.",
        "",
    ]

    printed_once: set[tuple[str, int]] = set()

    def rec(target: tuple[str, int], indent: str, stack: set[tuple[str, int]]) -> None:
        for src, field in children.get(target, []):
            row = object_row(con, src)
            cycle = src in stack
            repeated = src in printed_once
            mark = " [CYCLE]" if cycle else " [seen]" if repeated else ""
            lines.append(
                f"{indent}<- [{field}] {object_label(row)}{mark}"
            )
            if row:
                lines.append(f"{indent}   asset={row['asset_key']}")
            if cycle or repeated:
                continue
            printed_once.add(src)
            rec(src, indent + "    ", stack | {src})

    printed_once.add(root)
    rec(root, "", {root})

    # Ranked "human brains/controller" candidates.
    candidates = []
    for key, depth in depths.items():
        row = object_row(con, key)
        if row is None or key == root:
            continue
        candidates.append((interesting_score(row, depth), depth, row))
    candidates.sort(key=lambda x: (-x[0], x[1], object_label(x[2]).lower()))

    lines += [
        "",
        "=" * 100,
        "TOP INTERESTING REVERSE ANCESTORS",
        "(biased toward MonoBehaviours, script classes, GameObjects, HUD/UI/map/cooking names)",
        "=" * 100,
    ]
    for score, depth, row in candidates[:100]:
        lines.append(
            f"score={score:3d} depth={depth:2d}  {object_label(row)}"
        )
        lines.append(f"    asset={row['asset_key']}")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_graph_dot(
    con: sqlite3.Connection,
    path: Path,
    root_key: tuple[str, int],
    depths: dict[tuple[str, int], int],
    graph_edges: list[tuple[tuple[str, int], tuple[str, int], str]],
) -> None:
    def node_id(k: tuple[str, int]) -> str:
        return "n" + str(abs(hash(k)))

    def esc(s: str) -> str:
        return (
            s.replace("\\", "\\\\")
             .replace('"', '\\"')
             .replace("\n", "\\n")
        )

    lines = [
        "digraph UnityReverseDeps {",
        '  rankdir="LR";',
        '  graph [overlap=false, splines=true];',
        '  node [shape=box, fontsize=9];',
    ]

    for key, depth in sorted(depths.items(), key=lambda kv: kv[1]):
        row = object_row(con, key)
        label = object_label(row)
        shape = "doubleoctagon" if key == root_key else "box"
        lines.append(
            f'  {node_id(key)} [shape={shape}, label="{esc(label)}"];'
        )

    for src, target, field in graph_edges:
        lines.append(
            f'  {node_id(target)} -> {node_id(src)} '
            f'[label="{esc(field)}", fontsize=8];'
        )

    lines.append("}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_reverse_nodes_csv(
    con: sqlite3.Connection,
    path: Path,
    depths: dict[tuple[str, int], int],
) -> None:
    cols = [
        "depth", "score", "type", "name", "script_class", "hierarchy",
        "source_file", "serialized_file", "asset_key", "path_id",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(cols)
        records = []
        for key, depth in depths.items():
            row = object_row(con, key)
            if row:
                records.append(
                    (
                        depth,
                        interesting_score(row, depth),
                        row,
                    )
                )
        records.sort(key=lambda x: (x[0], -x[1], object_label(x[2]).lower()))
        for depth, score, r in records:
            w.writerow([
                depth, score, r["type"], r["name"], r["script_class"],
                r["hierarchy"], r["source_file"], r["serialized_file"],
                r["asset_key"], r["path_id"],
            ])


def write_forward_txt(
    con: sqlite3.Connection,
    path: Path,
    root_row: sqlite3.Row,
) -> None:
    key = row_key(root_row)
    lines = [
        "FORWARD REFERENCES OF SEED OBJECT",
        object_label(root_row),
        f"asset={root_row['asset_key']}",
        "",
    ]
    for r in forward_refs(con, key):
        target_label = "UNRESOLVED"
        if r["target_asset_key"]:
            tr = object_row(
                con, (r["target_asset_key"], int(r["target_path_id"]))
            )
            target_label = object_label(tr)
        lines.append(
            f"[{r['field_path']}] -> {target_label}"
        )
        lines.append(
            f"    fileID={r['file_id']} targetPathID={r['target_path_id']} "
            f"hint={r['target_hint']!r} resolution={r['resolution']}"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_failures_report(con: sqlite3.Connection, path: Path) -> None:
    rows = con.execute(
        "SELECT * FROM files WHERE status='failed' ORDER BY source_file"
    ).fetchall()
    lines = [
        f"Failed Unity containers: {len(rows)}",
        "",
    ]
    for r in rows:
        lines.append(r["source_file"])
        lines.append(f"  {r['error']}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def query_and_report(
    con: sqlite3.Connection,
    output_dir: Path,
    seeds: list[str],
    *,
    max_depth: int,
    max_branches: int,
    max_seed_matches: int,
) -> Path:
    run_dir = output_dir / f"query_{utcish_stamp()}"
    run_dir.mkdir(parents=True, exist_ok=True)

    summary_lines = [
        "UNITY REVERSE DEPENDENCY HUNTER — QUERY SUMMARY",
        f"UnityPy: {_unitypy_version()}",
        f"DB: {output_dir / 'unity_dependency_index.sqlite'}",
        "",
    ]

    for seed in seeds:
        safe = sanitize_filename(seed)
        hits = search_seed(con, seed)
        write_seed_search_csv(run_dir / f"{safe}__seed_matches.csv", hits)

        summary_lines.append(f"SEED {seed!r}: {len(hits)} match(es)")
        if not hits:
            summary_lines.append("  NO MATCHES")
            summary_lines.append("")
            continue

        roots = hits[:max_seed_matches]
        for i, root in enumerate(roots, 1):
            key = row_key(root)
            suffix = f"{safe}__root{i:02d}"
            summary_lines.append(
                f"  root{i:02d}: {object_label(root)}"
            )
            summary_lines.append(f"           {root['asset_key']}")

            depths, graph_edges = build_reverse_graph(
                con,
                key,
                max_depth=max_depth,
                max_branches=max_branches,
            )
            summary_lines.append(
                f"           reverse graph: nodes={len(depths)} "
                f"edges={len(graph_edges)}"
            )

            write_reverse_txt(
                con,
                run_dir / f"{suffix}__REVERSE_TREE.txt",
                seed,
                root,
                depths,
                graph_edges,
            )
            write_reverse_nodes_csv(
                con,
                run_dir / f"{suffix}__reverse_nodes.csv",
                depths,
            )
            write_graph_dot(
                con,
                run_dir / f"{suffix}__reverse_graph.dot",
                key,
                depths,
                graph_edges,
            )
            write_forward_txt(
                con,
                run_dir / f"{suffix}__forward_refs.txt",
                root,
            )

        summary_lines.append("")

    write_failures_report(con, run_dir / "_failed_containers.txt")
    (run_dir / "_SUMMARY.txt").write_text(
        "\n".join(summary_lines) + "\n", encoding="utf-8"
    )

    return run_dir


# =============================================================================
# STATS / DIAGNOSTICS
# =============================================================================

def print_db_stats(con: sqlite3.Connection) -> None:
    def one(sql: str) -> int:
        return int(con.execute(sql).fetchone()[0])

    indexed = one("SELECT COUNT(*) FROM files WHERE status='indexed'")
    failed = one("SELECT COUNT(*) FROM files WHERE status='failed'")
    objects = one("SELECT COUNT(*) FROM objects")
    edges = one("SELECT COUNT(*) FROM edges")
    resolved = one("SELECT COUNT(*) FROM edges WHERE target_asset_key<>''")
    mono = one(
        "SELECT COUNT(*) FROM objects "
        "WHERE type='MonoBehaviour' AND script_class<>''"
    )
    hier = one("SELECT COUNT(*) FROM objects WHERE hierarchy<>''")

    print("\n[index stats]")
    print(f"  files indexed : {indexed:,}")
    print(f"  files failed  : {failed:,}")
    print(f"  objects       : {objects:,}")
    print(f"  PPtr edges    : {edges:,}")
    print(f"  resolved edges: {resolved:,}")
    print(f"  MonoBehaviours with resolved class: {mono:,}")
    print(f"  objects with GO hierarchy: {hier:,}")


# =============================================================================
# CLI
# =============================================================================

def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Game-wide Unity reverse PPtr/dependency hunter."
    )
    p.add_argument(
        "--root",
        default=GAME_ROOT,
        help=f"Unity game root (default: {GAME_ROOT})",
    )
    p.add_argument(
        "--out",
        default=str(DEFAULT_OUTPUT_DIR),
        help=f"Output/index directory (default: {DEFAULT_OUTPUT_DIR})",
    )
    p.add_argument(
        "--seed",
        action="append",
        default=[],
        help=(
            "Search seed. Repeatable. If omitted, uses DEFAULT_SEEDS from the "
            "top of the script."
        ),
    )
    p.add_argument(
        "--depth",
        type=int,
        default=DEFAULT_REVERSE_DEPTH,
        help=f"Reverse traversal depth (default {DEFAULT_REVERSE_DEPTH})",
    )
    p.add_argument(
        "--max-branches",
        type=int,
        default=DEFAULT_MAX_BRANCHES_PER_NODE,
        help=(
            "Maximum reverse consumers expanded per node. 0 = unlimited. "
            f"Default {DEFAULT_MAX_BRANCHES_PER_NODE}."
        ),
    )
    p.add_argument(
        "--max-seed-matches",
        type=int,
        default=12,
        help="Generate full graph reports for at most N matches per seed.",
    )
    p.add_argument(
        "--rebuild",
        action="store_true",
        help="Throw away the prior SQLite index and rescan everything.",
    )
    p.add_argument(
        "--query-only",
        action="store_true",
        help="Do not scan; query the existing SQLite index only.",
    )
    p.add_argument(
        "--full-parse",
        action="store_true",
        help=(
            "Parse typetrees even for huge leaf payload classes "
            "(Texture2D/Shader/Mesh/etc.). Slower; usually unnecessary."
        ),
    )
    p.add_argument(
        "--max-files",
        type=int,
        default=0,
        help="Debug option: scan only first N discovered containers. 0 = all.",
    )
    return p


def main() -> int:
    args = build_arg_parser().parse_args()

    root = Path(args.root)
    if not root.exists():
        print(f"ERROR: game root does not exist: {root}", file=sys.stderr)
        return 2

    output_dir = Path(args.out)
    output_dir.mkdir(parents=True, exist_ok=True)
    db_path = output_dir / "unity_dependency_index.sqlite"
    con = open_db(db_path)

    try:
        if not args.query_only:
            index_game(
                con,
                root,
                rebuild=args.rebuild,
                full_parse=args.full_parse,
                max_files=args.max_files,
            )
        elif not db_path.exists():
            print("ERROR: --query-only used but index DB does not exist.")
            return 2

        print_db_stats(con)

        seeds = args.seed or list(DEFAULT_SEEDS)
        print("\n[query] seeds:")
        for s in seeds:
            print(f"  - {s}")

        run_dir = query_and_report(
            con,
            output_dir,
            seeds,
            max_depth=max(0, args.depth),
            max_branches=max(0, args.max_branches),
            max_seed_matches=max(1, args.max_seed_matches),
        )

        print("\nDONE.")
        print(f"Index DB : {db_path}")
        print(f"Reports  : {run_dir}")
        print("\nStart with:")
        print(f"  {run_dir / '_SUMMARY.txt'}")
        print("\nThen inspect any:")
        print("  *__REVERSE_TREE.txt")
        print("  *__reverse_nodes.csv")
        print("  *__reverse_graph.dot")
        print("  *__forward_refs.txt")
        print("\nFor a new clue, rerun with --query-only --seed NewThing")
        return 0

    finally:
        con.close()


if __name__ == "__main__":
    raise SystemExit(main())
