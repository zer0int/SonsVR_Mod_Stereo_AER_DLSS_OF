@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 "%~dp0COMPARE_SONSVR_RELEASE.py" %*
) else (
    python "%~dp0COMPARE_SONSVR_RELEASE.py" %*
)
echo.
echo Press any key to close.
pause >nul
