#!/usr/bin/env python3
"""Read-only comparison of an original SonsVR distribution ZIP and a game install.

Compares every file shipped in the ZIP by SHA-256. Also lists unshipped files
under the three original mod-owned directories, without scanning unrelated game
content. No files in the game directory are modified or deleted.
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path, PurePosixPath
import sys
from zipfile import ZipFile, BadZipFile

DEFAULT_GAME = r"D:\SteamLibrary\steamapps\common\Sons Of The Forest"
DEFAULT_ZIP = "SonsVR_Mod_Alpha0.7.1.zip"
SCOPES = (
    "Mods",
    "UserLibs",
    "SonsOfTheForest_Data/StreamingAssets/SteamVR",
)
# Expected difference set for *this* project, not for arbitrary installations.
EXPECTED_REPLACEMENT = {"mods/sonsvr_mod.dll"}
EXPECTED_NEW = {"mods/sonsvr_nvof_v90.dll", "mods/sonsvr_settings.ini"}
CHUNK = 1024 * 1024


def digest(stream):
    h = hashlib.sha256()
    for block in iter(lambda: stream.read(CHUNK), b""):
        h.update(block)
    return h.hexdigest()


def normalize_zip_name(filename):
    """Normalize archive paths without writing any of them to disk."""
    filename = filename.replace("\\", "/")
    path = PurePosixPath(filename)
    if (path.is_absolute() or not path.parts or
            any(part in (".", "..") for part in path.parts) or
            ":" in path.parts[0]):
        raise ValueError(f"Unsafe archive path: {filename!r}")
    return str(path)


def is_scoped(rel):
    low = rel.casefold()
    return any(low == root.casefold() or low.startswith(root.casefold() + "/")
               for root in SCOPES)


def original_manifest(zf):
    result = {}
    for entry in zf.infolist():
        if entry.is_dir():
            continue
        rel = normalize_zip_name(entry.filename)
        key = rel.casefold()
        if key in result:
            raise ValueError(f"Duplicate/case-colliding path in ZIP: {rel}")
        result[key] = (rel, entry)
    return result


def installed_manifest(root):
    result = {}
    for subdir in SCOPES:
        base = root.joinpath(*subdir.split("/"))
        if not base.is_dir():
            continue
        for path in base.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(root).as_posix()
            key = rel.casefold()
            if key in result:
                raise ValueError(f"Case-colliding files in installation: {rel}")
            result[key] = (rel, path)
    return result


def compare(zip_file, game):
    rows = {"SAME": [], "CHANGED": [], "MISSING": [], "ADDED": []}
    with ZipFile(zip_file) as zf:
        original = original_manifest(zf)
        installed = installed_manifest(game)
        for key, (archive_rel, info) in sorted(original.items()):
            disk_rec = installed.get(key)
            # Search outside scanning scopes only for original archive entries.
            # The supplied Alpha ZIP entries are all within those scopes.
            if disk_rec is None and not is_scoped(archive_rel):
                candidate = game.joinpath(*archive_rel.split("/"))
                disk_rec = (archive_rel, candidate) if candidate.is_file() else None
            if disk_rec is None:
                rows["MISSING"].append((archive_rel, "not installed"))
                continue
            disk_rel, disk_path = disk_rec
            if disk_path.stat().st_size != info.file_size:
                rows["CHANGED"].append((archive_rel, f"{info.file_size:,} -> {disk_path.stat().st_size:,} bytes"))
                continue
            with zf.open(info) as archive_stream, disk_path.open("rb") as disk_stream:
                equal = digest(archive_stream) == digest(disk_stream)
            rows["SAME" if equal else "CHANGED"].append((archive_rel, "identical" if equal else "SHA-256 differs (same size)"))
        for key, (rel, path) in sorted(installed.items()):
            if key not in original:
                rows["ADDED"].append((rel, f"{path.stat().st_size:,} bytes"))
    return rows, len(original)


def format_report(zip_file, game, rows, original_count):
    output = [
        "SonsVR original-release vs installed-game comparison",
        "=" * 55,
        f"Original ZIP: {zip_file}",
        f"Game folder:  {game}",
        f"Original archive entries: {original_count}",
        "",
        "Interpretation: SAME/CHANGED/MISSING compare the six original",
        "release files (or whatever is in your reference ZIP). ADDED lists",
        "other files under Mods, UserLibs and SteamVR bindings directories.",
        "ADDED does not automatically mean 'ours' or 'needed for release'.",
        "",
    ]
    for heading in ("CHANGED", "MISSING", "ADDED", "SAME"):
        items = rows[heading]
        output.append(f"[{heading}] {len(items)}")
        for path, why in items:
            output.append(f"  {path}    ({why})")
        if not items:
            output.append("  (none)")
        output.append("")
    changed_keys = {path.casefold() for path, _ in rows["CHANGED"]}
    added_keys = {path.casefold() for path, _ in rows["ADDED"]}
    unexpected_changed = changed_keys - EXPECTED_REPLACEMENT
    unexpected_added = added_keys - EXPECTED_NEW
    unexpected_missing = rows["MISSING"]
    output.extend([
        "RELEASE DELTA CHECK (user's working hypothesis)",
        "-" * 46,
        "Expected modified original: Mods/SonsVR_Mod.dll",
        "Expected additional files: Mods/SonsVR_NvOF_V90.dll, Mods/SonsVR_Settings.ini",
        f"Unexpected changed original files: {len(unexpected_changed)}",
        f"Unexpected additional scoped files: {len(unexpected_added)}",
        f"Missing original files: {len(unexpected_missing)}",
    ])
    for key in sorted(unexpected_changed):
        output.append(f"  REVIEW changed: {key}")
    for key in sorted(unexpected_added):
        output.append(f"  REVIEW additional: {key}")
    if not unexpected_changed and not unexpected_added and not unexpected_missing:
        output.append("RESULT: Only expected differences were found in compared paths.")
    else:
        output.append("RESULT: Review the items above before assembling a release ZIP.")
    output.extend([
        "",
        "LIMITATION: This cannot detect arbitrary additional/modified files",
        "elsewhere in the game installation without a clean vanilla-game baseline.",
        "It DOES verify every path supplied in the original ZIP.",
        "No game files were changed by this script.",
    ])
    return "\n".join(output) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zip", dest="zip_file", default=DEFAULT_ZIP,
                        help=f"Original archive, relative to working directory (default: {DEFAULT_ZIP})")
    parser.add_argument("--game", default=DEFAULT_GAME,
                        help="Installed game directory")
    parser.add_argument("--report", default="SonsVR_diff_report.txt",
                        help="Output report path (default: ./SonsVR_diff_report.txt)")
    args = parser.parse_args()
    zip_file = Path(args.zip_file).expanduser().resolve()
    game = Path(args.game).expanduser().resolve()
    report = Path(args.report).expanduser().resolve()
    if not zip_file.is_file():
        parser.error(f"ZIP not found: {zip_file}")
    if not game.is_dir():
        parser.error(f"Game folder not found: {game}")
    try:
        rows, original_count = compare(zip_file, game)
        message = format_report(zip_file, game, rows, original_count)
    except (OSError, BadZipFile, ValueError) as exc:
        print(f"Comparison failed: {exc}", file=sys.stderr)
        return 2
    print(message)
    report.write_text(message, encoding="utf-8")
    print(f"Report saved: {report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
