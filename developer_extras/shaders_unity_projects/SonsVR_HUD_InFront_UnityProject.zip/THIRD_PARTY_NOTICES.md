This shader adapts the interface and clipping/stencil conventions of Unity's
`UI/Default` built-in shader (Copyright (c) 2016 Unity Technologies), originally
published under the MIT License. Original source:
https://github.com/TwoTailsGames/Unity-Built-in-Shaders/blob/master/DefaultResourcesExtra/UI/UI-Default.shader

The project adds a depth-test property and HDRP-facing pass and is not affiliated
with Unity Technologies.
