@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "UNITY_EXE=%UNITY_EDITOR_EXE%"
if not defined UNITY_EXE set "UNITY_EXE=C:\Program Files\Unity\Hub\Editor\2022.2.16f1\Editor\Unity.exe"
if not exist "%UNITY_EXE%" (
    echo.
    echo ERROR: Unity 2022.2.16f1 was not found at:
    echo "%UNITY_EXE%"
    echo Set UNITY_EDITOR_EXE to your actual Unity.exe path, or open this project
    echo in Unity Hub and use SonsVR ^> Build V164 HUD In-Front Shader Bundle.
    exit /b 1
)

echo Building HUD shader bundle with "%UNITY_EXE%"
"%UNITY_EXE%" -batchmode -nographics -quit -projectPath "%~dp0" -executeMethod BuildSonsVRHudInFront.BuildBatch -logFile "%~dp0BUILD_HUD_SHADER.log"
if errorlevel 1 (
    echo ERROR: Unity build failed. See BUILD_HUD_SHADER.log
    exit /b 1
)
if not exist "%~dp0BUNDLE_OUT\sonsvr_hud_infront" (
    echo ERROR: No BUNDLE_OUT\sonsvr_hud_infront found. See BUILD_HUD_SHADER.log
    exit /b 1
)
for %%F in ("%~dp0BUNDLE_OUT\sonsvr_hud_infront") do echo PASS: %%~fF (%%~zF bytes)
echo Send BUNDLE_OUT\sonsvr_hud_infront back for the V164 mod-side A/B test.
exit /b 0
