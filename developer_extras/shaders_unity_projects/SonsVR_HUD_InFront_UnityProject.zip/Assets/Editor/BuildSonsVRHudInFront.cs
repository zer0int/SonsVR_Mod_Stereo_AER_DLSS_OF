using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

/// <summary>
/// Builds an independent Windows64 shader bundle. No SonsVR gameplay assets,
/// camera, or production depth bundles are modified by this editor tool.
/// </summary>
public static class BuildSonsVRHudInFront
{
    private const string ShaderPath = "Assets/Shaders/SonsVR_HudUI_InFront.shader";
    private const string MaterialPath = "Assets/Shaders/SonsVR_HudUI_InFront_Template.mat";
    private const string ShaderName = "SonsVR/HUD/UIAlwaysInFront";
    private const string BundleName = "sonsvr_hud_infront";

    [MenuItem("SonsVR/Build V164 HUD In-Front Shader Bundle (Windows64)")]
    public static void BuildFromMenu() { BuildInternal(); }

    // For Unity.exe -batchmode -executeMethod BuildSonsVRHudInFront.BuildBatch
    public static void BuildBatch() { BuildInternal(); }

    private static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException("[SonsVR V164 HUD] " + message);
    }

    private static void BuildInternal()
    {
        Shader shader = AssetDatabase.LoadAssetAtPath<Shader>(ShaderPath);
        Require(shader != null, "Shader missing: " + ShaderPath);
        Require(shader.name == ShaderName,
            "Unexpected shader name: " + shader.name + " (expected " + ShaderName + ")");

        if (ShaderUtil.ShaderHasError(shader))
        {
            foreach (var msg in ShaderUtil.GetShaderMessages(shader))
                Debug.LogError("[SonsVR V164 HUD] Compiler: " + msg.severity + " " + msg.message);
            throw new InvalidOperationException("Shader has compilation errors; see Console or Editor.log.");
        }

        Material template = AssetDatabase.LoadAssetAtPath<Material>(MaterialPath);
        if (template == null)
        {
            template = new Material(shader);
            template.name = "SonsVR_HudUI_InFront_Template";
            AssetDatabase.CreateAsset(template, MaterialPath);
        }
        else if (template.shader != shader)
        {
            template.shader = shader;
            EditorUtility.SetDirty(template);
        }

        // Include an actual material in the bundle so the shader variant is
        // referenced, while retaining runtime ability to clone the game's own UI materials.
        template.SetInt("_ZTest", (int)CompareFunction.Always);
        template.SetInt("_StencilComp", (int)CompareFunction.Always);
        template.SetInt("_Stencil", 0);
        template.SetInt("_StencilOp", 0);
        template.SetInt("_StencilReadMask", 255);
        template.SetInt("_StencilWriteMask", 255);
        template.SetInt("_ColorMask", 15);
        template.renderQueue = 3050;
        EditorUtility.SetDirty(template);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);

        Require(!ShaderUtil.ShaderHasError(shader), "Shader compilation error after import.");
        // The original V164 builder used pass index 0 unconditionally. That can
        // report an empty tag when the active pipeline rejects the SubShader.
        // First verify the actually exposed pass, then inspect its LightMode.
        int passIndex = template.FindPass("HudUIInFront");
        Require(shader.isSupported,
            "Shader has no supported SubShader in this Unity project. " +
            "Check the shader source and Project Graphics pipeline setup.");
        Require(passIndex >= 0,
            "HudUIInFront pass unavailable (shader.passCount=" + shader.passCount +
            "). The ShaderLab SubShader may have been filtered by its RenderPipeline tag.");

        string shaderSource = File.ReadAllText(Path.GetFullPath(Path.Combine(Application.dataPath, "../" + ShaderPath)));
        Require(shaderSource.Contains("\"LightMode\" = \"SRPDefaultUnlit\""),
            "Shader source is missing its SRPDefaultUnlit LightMode pass tag.");
        string lightMode = shader.FindPassTagValue(passIndex, new ShaderTagId("LightMode")).name;
        // Some Editor import contexts return an empty ShaderTagId here despite
        // an otherwise selectable, source-tagged pass. Don't reject a valid
        // shader solely because optional pass-tag introspection is unavailable.
        if (String.IsNullOrEmpty(lightMode))
            Debug.LogWarning("[SonsVR V164B HUD] LightMode introspection returned " +
                "an empty tag, but the named pass exists and its source declares " +
                "SRPDefaultUnlit. Proceeding to the bundle compiler.");
        else
            Require(lightMode == "SRPDefaultUnlit",
                "Unexpected HudUIInFront LightMode tag: " + lightMode);

        Debug.Log("[SonsVR V164B HUD] Shader OK: passIndex=" + passIndex +
            " passCount=" + shader.passCount +
            " isSupported=" + shader.isSupported + " LightMode=" + lightMode);

        foreach (string property in new[] {
            "_MainTex", "_Color", "_Stencil", "_StencilComp", "_StencilOp",
            "_StencilReadMask", "_StencilWriteMask", "_ColorMask", "_ZTest", "_UseUIAlphaClip" })
            Require(template.HasProperty(property), "Missing UI material property " + property);

        string output = Path.GetFullPath(Path.Combine(Application.dataPath, "../BUNDLE_OUT"));
        Directory.CreateDirectory(output);
        string bundlePath = Path.Combine(output, BundleName);
        if (File.Exists(bundlePath)) File.Delete(bundlePath);

        var bundle = new AssetBundleBuild
        {
            assetBundleName = BundleName,
            assetNames = new[] { ShaderPath, MaterialPath }
        };

        AssetBundleManifest manifest = BuildPipeline.BuildAssetBundles(
            output, new[] { bundle }, BuildAssetBundleOptions.ForceRebuildAssetBundle,
            BuildTarget.StandaloneWindows64);

        Require(manifest != null, "BuildPipeline.BuildAssetBundles returned null.");
        Require(File.Exists(bundlePath), "Bundle not written: " + bundlePath);
        Require(new FileInfo(bundlePath).Length > 1024,
            "Suspiciously small bundle: " + bundlePath);

        Debug.Log("[SonsVR V164 HUD] SUCCESS: " + bundlePath +
                  " (" + new FileInfo(bundlePath).Length + " bytes)" +
                  " | shader=" + ShaderName + " | pass=HudUIInFront | queue=3050");
        if (!Application.isBatchMode) EditorUtility.RevealInFinder(bundlePath);
    }
}
