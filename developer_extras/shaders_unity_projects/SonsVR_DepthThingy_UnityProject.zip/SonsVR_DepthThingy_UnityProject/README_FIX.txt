Extract these files over the existing SonsVR_DepthThingy_UnityProject folder and allow overwrite.
Then let Unity finish its package refresh and use SonsVR -> Build Depth THINGY again.
