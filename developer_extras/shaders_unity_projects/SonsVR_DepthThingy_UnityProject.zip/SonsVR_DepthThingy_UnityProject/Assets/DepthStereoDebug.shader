Shader "Hidden/SonsVR/DepthStereoDebug"
{
    Properties
    {
        _DepthArraySlice ("Depth array slice", Float) = 0
        _DepthUvScaleBias ("Depth UV scale/bias", Vector) = (1,1,0,0)
        _DepthMetersMax ("Debug max depth (m)", Float) = 50
    }

    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Overlay" }
        Cull Off
        ZWrite Off
        ZTest Always

        Pass
        {
            HLSLPROGRAM
            #pragma target 4.5
            #pragma vertex Vert
            #pragma fragment Frag

            struct Attributes
            {
                float4 positionOS : POSITION;
                float2 uv : TEXCOORD0;
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float2 uv : TEXCOORD0;
            };

            Texture2DArray<float> _CameraDepthTexture;
            SamplerState sampler_CameraDepthTexture;

            float4 _ZBufferParams;
            float4 _DepthUvScaleBias;
            float _DepthArraySlice;
            float _DepthMetersMax;

            Varyings Vert(Attributes input)
            {
                Varyings output;
                output.positionCS = input.positionOS;
                output.uv = input.uv;
                return output;
            }

            float LinearEyeDepthFromRaw(float rawDepth)
            {
                return rcp(_ZBufferParams.z * rawDepth + _ZBufferParams.w);
            }

            float4 Frag(Varyings input) : SV_Target
            {
                float2 depthUv = input.uv * _DepthUvScaleBias.xy + _DepthUvScaleBias.zw;
                float rawDepth = _CameraDepthTexture.SampleLevel(
                    sampler_CameraDepthTexture,
                    float3(depthUv, _DepthArraySlice),
                    0
                );

                float eyeMeters = LinearEyeDepthFromRaw(rawDepth);
                float maxMeters = max(_DepthMetersMax, 0.001);
                float normalized = saturate(eyeMeters / maxMeters);

                // Near = bright, far = dark. This is only a diagnostic shader;
                // the later stereo-warp shader will reconstruct actual 3D positions.
                float shade = 1.0 - normalized;
                return float4(shade, shade, shade, 1.0);
            }
            ENDHLSL
        }
    }
    Fallback Off
}
