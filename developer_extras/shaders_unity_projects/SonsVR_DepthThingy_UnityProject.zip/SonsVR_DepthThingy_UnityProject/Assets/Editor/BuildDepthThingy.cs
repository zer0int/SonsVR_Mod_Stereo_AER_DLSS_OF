using System.IO;
using UnityEditor;
using UnityEngine;

public static class BuildDepthThingy
{
    private const string ShaderAssetPath = "Assets/DepthStereoDebug.shader";
    private const string BundleName = "sonsvr_depththingy";

    [MenuItem("SonsVR/Build Depth THINGY")]
    public static void Build()
    {
        string outputDir = Path.GetFullPath(Path.Combine(Application.dataPath, "../THINGY_OUT"));
        Directory.CreateDirectory(outputDir);

        // Remove stale output so a failed build can never masquerade as a successful new THINGY.
        string bundlePath = Path.Combine(outputDir, BundleName);
        string bundleManifestPath = bundlePath + ".manifest";
        string rootBundlePath = Path.Combine(outputDir, Path.GetFileName(outputDir));
        string rootManifestPath = rootBundlePath + ".manifest";
        if (File.Exists(bundlePath)) File.Delete(bundlePath);
        if (File.Exists(bundleManifestPath)) File.Delete(bundleManifestPath);
        if (File.Exists(rootBundlePath)) File.Delete(rootBundlePath);
        if (File.Exists(rootManifestPath)) File.Delete(rootManifestPath);

        var build = new AssetBundleBuild
        {
            assetBundleName = BundleName,
            assetNames = new[] { ShaderAssetPath }
        };

        AssetBundleManifest manifest = BuildPipeline.BuildAssetBundles(
            outputDir,
            new[] { build },
            BuildAssetBundleOptions.ForceRebuildAssetBundle,
            BuildTarget.StandaloneWindows64
        );

        if (manifest == null || !File.Exists(bundlePath))
            throw new System.Exception("AssetBundle build failed; no fresh sonsVR depth THINGY was produced. See the Unity Console/Editor.log.");

        var info = new FileInfo(bundlePath);
        Debug.Log("[SonsVR] Depth THINGY built successfully: " + bundlePath + " (" + info.Length + " bytes)");
        EditorUtility.RevealInFinder(bundlePath);
    }
}
