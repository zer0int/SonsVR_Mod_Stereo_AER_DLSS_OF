SONSVR DEPTH THINGY — ONE-TIME UNITY PROJECT
===========================================

What this is:
A tiny Unity 2022.2.16f1 project whose only job is to compile one custom shader
into a Windows AssetBundle for the SonsVR mod experiments.

What to do:
1. Extract this whole folder somewhere simple, e.g.
       C:\Users\zer0int\SonsVR_DepthThingy_UnityProject

2. Open Unity Hub.

3. Click Projects on the left.

4. Use Add/Open project from disk (wording can vary slightly) and choose THE
   FOLDER containing Assets and ProjectSettings — this folder itself.

5. Hub should show the project as a 2022.2.16f1 project. Open it.
   That launches the actual Unity Editor. The Editor is the big multi-panel
   application with Scene/Game/Hierarchy/Project/Inspector/Console panels.

6. Let Unity finish importing/compiling. Wait until the progress/spinner stops.

7. In the Editor menu bar click:
       SonsVR > Build Depth THINGY

8. Unity creates/reveals:
       THINGY_OUT\sonsvr_depththingy

9. Upload ONLY the file named:
       sonsvr_depththingy
   back to ChatGPT.

You do not need to press Play, create a scene, install packages, or understand
Unity's Hierarchy/Inspector for this step.

The shader in this first bundle is deliberately diagnostic: it knows how to
sample the HDRP depth texture as a Texture2DArray and visualize linearized depth.
The actual cross-eye reprojection shader will evolve from this once packaging is
proven.
